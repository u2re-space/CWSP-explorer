import { r as __require$1 } from "./rolldown-runtime.js";
import { t as f } from "../vendor/marked.js";
import { t as renderMathInElement } from "../vendor/katex.js";
import { t as src_default } from "../vendor/marked-katex-extension.js";
//#region ../../node_modules/docx/dist/index.mjs
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esmMin = (fn, res) => () => (fn && (res = fn(fn = 0)), res);
var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
var __require = /* @__PURE__ */ ((x) => typeof __require$1 !== "undefined" ? __require$1 : typeof Proxy !== "undefined" ? new Proxy(x, { get: (a, b) => (typeof __require$1 !== "undefined" ? __require$1 : a)[b] }) : x)(function(x) {
	if (typeof __require$1 !== "undefined") return __require$1.apply(this, arguments);
	throw Error("Calling `require` for \"" + x + "\" in an environment that doesn't expose the `require` function. See https://rolldown.rs/in-depth/bundling-cjs#require-external-modules for more details.");
});
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof(o);
}
function toPrimitive(t, r) {
	if ("object" != _typeof(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function toPropertyKey(t) {
	var i = toPrimitive(t, "string");
	return "symbol" == _typeof(i) ? i : i + "";
}
function _defineProperty(e, r, t) {
	return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
/**
* Abstract base class for all XML components in the library.
*
* BaseXmlComponent defines the minimal interface that all XML components must implement.
* It stores the XML element name (rootKey) and requires subclasses to implement
* the prepForXml method for serialization.
*
* @example
* ```typescript
* class MyElement extends BaseXmlComponent {
*   constructor() {
*     super("w:myElement");
*   }
*
*   prepForXml(context: IContext): IXmlableObject {
*     return { "w:myElement": {} };
*   }
* }
* ```
*/
var BaseXmlComponent = class {
	/**
	* Creates a new BaseXmlComponent with the specified XML element name.
	*
	* @param rootKey - The XML element name (e.g., "w:p", "w:r", "w:t")
	*/
	constructor(rootKey) {
		_defineProperty(
			this,
			/** The XML element name for this component (e.g., "w:p" for paragraph). */
			"rootKey",
			void 0
		);
		this.rootKey = rootKey;
	}
};
/**
* XML Component module for the docx library.
*
* This module provides the core XmlComponent class that all WordprocessingML elements
* extend from. XmlComponent manages the conversion of component trees into XML structures
* that can be serialized into DOCX files.
*
* @module
*/
/**
* Empty object singleton used for empty XML elements.
*
* This sealed object is used to generate self-closing XML tags when an element
* has no children or attributes.
*
* @internal
*/
var EMPTY_OBJECT = Object.seal({});
/**
* Base class for all XML components in WordprocessingML documents.
*
* XmlComponent provides the infrastructure for building XML element trees
* that are serialized into document.xml and other parts of the DOCX package.
* It manages a collection of child components and handles the conversion to
* the intermediate object format used by the xml serialization library.
*
* @example
* ```typescript
* // Creating a custom XML component
* class MyElement extends XmlComponent {
*   constructor(text: string) {
*     super("w:myElement");
*     this.root.push(new Attributes({ val: text }));
*   }
* }
*
* const element = new MyElement("Hello");
* // When serialized: <w:myElement w:val="Hello"/>
* ```
*/
var XmlComponent = class extends BaseXmlComponent {
	/**
	* Creates a new XmlComponent.
	*
	* @param rootKey - The XML element name (e.g., "w:p", "w:r", "w:t")
	*/
	constructor(rootKey) {
		super(rootKey);
		_defineProperty(
			this,
			/**
			* Array of child components, text nodes, and attributes.
			*
			* This array forms the content of the XML element. It can contain other
			* XmlComponents, string values (text nodes), or attribute components.
			*/
			"root",
			void 0
		);
		this.root = new Array();
	}
	/**
	* Prepares this component and its children for XML serialization.
	*
	* This method is called by the Formatter to convert the component tree into
	* an object structure compatible with the xml library (https://www.npmjs.com/package/xml).
	* It recursively processes all children and handles special cases like
	* attribute-only elements and empty elements.
	*
	* The method can be overridden by subclasses to customize XML representation
	* or execute side effects during serialization (e.g., creating relationships).
	*
	* @param context - The serialization context containing document state
	* @returns The XML-serializable object, or undefined to exclude from output
	*
	* @example
	* ```typescript
	* // Override to add custom serialization logic
	* prepForXml(context: IContext): IXmlableObject | undefined {
	*   // Custom logic here
	*   return super.prepForXml(context);
	* }
	* ```
	*/
	prepForXml(context) {
		var _children$;
		context.stack.push(this);
		const children = this.root.map((comp) => {
			if (comp instanceof BaseXmlComponent) return comp.prepForXml(context);
			return comp;
		}).filter((comp) => comp !== void 0);
		context.stack.pop();
		return { [this.rootKey]: children.length ? children.length === 1 && ((_children$ = children[0]) === null || _children$ === void 0 ? void 0 : _children$._attr) ? children[0] : children : EMPTY_OBJECT };
	}
	/**
	* Adds a child element to this component.
	*
	* @deprecated Do not use this method. It is only used internally by the library. It will be removed in a future version.
	* @param child - The child component or text string to add
	* @returns This component (for chaining)
	*/
	addChildElement(child) {
		this.root.push(child);
		return this;
	}
};
/**
* XML component that is excluded from output if it has no meaningful content.
*
* IgnoreIfEmptyXmlComponent is useful for optional container elements that
* should only appear in the XML if they contain children or attributes.
* If the element would be empty, it returns undefined instead, causing it
* to be excluded from the output.
*
* @example
* ```typescript
* class OptionalContainer extends IgnoreIfEmptyXmlComponent {
*   constructor(items?: Item[]) {
*     super("w:container");
*     if (items) {
*       items.forEach(item => this.root.push(item));
*     }
*   }
* }
*
* const container1 = new OptionalContainer([item1, item2]);
* // Renders: <w:container>...</w:container>
*
* const container2 = new OptionalContainer();
* // Renders: nothing (excluded from output)
* ```
*/
var IgnoreIfEmptyXmlComponent = class extends XmlComponent {
	constructor(rootKey, includeIfEmpty) {
		super(rootKey);
		_defineProperty(this, "includeIfEmpty", void 0);
		this.includeIfEmpty = includeIfEmpty;
	}
	/**
	* Prepares the component for XML serialization, excluding it if empty.
	*
	* @param context - The serialization context
	* @returns The XML-serializable object, or undefined if empty
	*/
	prepForXml(context) {
		const result = super.prepForXml(context);
		if (this.includeIfEmpty) return result;
		if (result && (typeof result[this.rootKey] !== "object" || Object.keys(result[this.rootKey]).length)) return result;
	}
};
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread2(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
/**
* XML attribute components for the docx library.
*
* This module provides base classes for creating XML element attributes.
* Attributes are represented as special components with the "_attr" key.
*
* @module
*/
/**
* Base class for creating XML attributes with automatic name mapping.
*
* XmlAttributeComponent allows you to define attributes using JavaScript-friendly
* property names that are automatically mapped to XML attribute names. Subclasses
* can define an xmlKeys map to specify the transformation.
*
* @example
* ```typescript
* class MyAttributes extends XmlAttributeComponent<{ fontSize: number }> {
*   protected readonly xmlKeys = { fontSize: "w:sz" };
* }
*
* new MyAttributes({ fontSize: 24 });
* // Generates: _attr: { "w:sz": 24 }
* ```
*/
var XmlAttributeComponent = class extends BaseXmlComponent {
	/**
	* Creates a new attribute component.
	*
	* @param root - The attribute data object
	*/
	constructor(root) {
		super("_attr");
		_defineProperty(this, "root", void 0);
		_defineProperty(
			this,
			/** Optional mapping from property names to XML attribute names. */
			"xmlKeys",
			void 0
		);
		this.root = root;
	}
	/**
	* Converts the attribute data to an XML-serializable object.
	*
	* This method transforms the property names using xmlKeys (if defined)
	* and filters out undefined values.
	*
	* @param _ - Context (unused for attributes)
	* @returns Object with _attr key containing the mapped attributes
	*/
	prepForXml(_) {
		const attrs = {};
		Object.entries(this.root).forEach(([key, value]) => {
			if (value !== void 0) {
				const newKey = this.xmlKeys && this.xmlKeys[key] || key;
				attrs[newKey] = value;
			}
		});
		return { _attr: attrs };
	}
};
/**
* Next-generation attribute component with explicit key-value pairs.
*
* NextAttributeComponent provides an alternative approach to attributes where
* each property explicitly specifies both its XML attribute name and value.
* This gives more control but is more verbose than XmlAttributeComponent.
*
* @example
* ```typescript
* new NextAttributeComponent({
*   fontSize: { key: "w:sz", value: 24 },
*   bold: { key: "w:b", value: true }
* });
* // Generates: _attr: { "w:sz": 24, "w:b": true }
* ```
*/
var NextAttributeComponent = class extends BaseXmlComponent {
	/**
	* Creates a new NextAttributeComponent.
	*
	* @param root - Attribute payload with explicit key-value mappings
	*/
	constructor(root) {
		super("_attr");
		_defineProperty(this, "root", void 0);
		this.root = root;
	}
	/**
	* Converts the attribute payload to an XML-serializable object.
	*
	* Extracts the key and value from each property and filters out
	* undefined values.
	*
	* @param _ - Context (unused for attributes)
	* @returns Object with _attr key containing the attributes
	*/
	prepForXml(_) {
		return { _attr: Object.values(this.root).filter(({ value }) => value !== void 0).reduce((acc, { key, value }) => _objectSpread2(_objectSpread2({}, acc), {}, { [key]: value }), {}) };
	}
};
/**
* Common XML attributes module for WordprocessingML elements.
*
* This module provides a reusable Attributes class with commonly used
* WordprocessingML attribute mappings.
*
* @module
*/
/**
* Common XML attributes used across WordprocessingML elements.
*
* This class provides a convenient way to add common attributes to XML elements.
* It automatically maps JavaScript-friendly property names to their corresponding
* w: (WordprocessingML) namespace prefixed XML attribute names.
*
* @example
* ```typescript
* // Create an element with a value attribute
* new Attributes({ val: "someValue" });
* // Generates: <element w:val="someValue"/>
*
* // Multiple attributes
* new Attributes({ color: "FF0000", sz: "24" });
* // Generates: <element w:color="FF0000" w:sz="24"/>
* ```
*/
var Attributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			val: "w:val",
			color: "w:color",
			fill: "w:fill",
			space: "w:space",
			sz: "w:sz",
			type: "w:type",
			rsidR: "w:rsidR",
			rsidRPr: "w:rsidRPr",
			rsidSect: "w:rsidSect",
			w: "w:w",
			h: "w:h",
			top: "w:top",
			right: "w:right",
			bottom: "w:bottom",
			left: "w:left",
			header: "w:header",
			footer: "w:footer",
			gutter: "w:gutter",
			linePitch: "w:linePitch",
			pos: "w:pos"
		});
	}
};
var require_events = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var R = typeof Reflect === "object" ? Reflect : null;
	var ReflectApply = R && typeof R.apply === "function" ? R.apply : function ReflectApply(target, receiver, args) {
		return Function.prototype.apply.call(target, receiver, args);
	};
	var ReflectOwnKeys;
	if (R && typeof R.ownKeys === "function") ReflectOwnKeys = R.ownKeys;
	else if (Object.getOwnPropertySymbols) ReflectOwnKeys = function ReflectOwnKeys(target) {
		return Object.getOwnPropertyNames(target).concat(Object.getOwnPropertySymbols(target));
	};
	else ReflectOwnKeys = function ReflectOwnKeys(target) {
		return Object.getOwnPropertyNames(target);
	};
	function ProcessEmitWarning(warning) {
		if (console && console.warn) console.warn(warning);
	}
	var NumberIsNaN = Number.isNaN || function NumberIsNaN(value) {
		return value !== value;
	};
	function EventEmitter() {
		EventEmitter.init.call(this);
	}
	module.exports = EventEmitter;
	module.exports.once = once;
	EventEmitter.EventEmitter = EventEmitter;
	EventEmitter.prototype._events = void 0;
	EventEmitter.prototype._eventsCount = 0;
	EventEmitter.prototype._maxListeners = void 0;
	var defaultMaxListeners = 10;
	function checkListener(listener) {
		if (typeof listener !== "function") throw new TypeError("The \"listener\" argument must be of type Function. Received type " + typeof listener);
	}
	Object.defineProperty(EventEmitter, "defaultMaxListeners", {
		enumerable: true,
		get: function() {
			return defaultMaxListeners;
		},
		set: function(arg) {
			if (typeof arg !== "number" || arg < 0 || NumberIsNaN(arg)) throw new RangeError("The value of \"defaultMaxListeners\" is out of range. It must be a non-negative number. Received " + arg + ".");
			defaultMaxListeners = arg;
		}
	});
	EventEmitter.init = function() {
		if (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) {
			this._events = Object.create(null);
			this._eventsCount = 0;
		}
		this._maxListeners = this._maxListeners || void 0;
	};
	EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
		if (typeof n !== "number" || n < 0 || NumberIsNaN(n)) throw new RangeError("The value of \"n\" is out of range. It must be a non-negative number. Received " + n + ".");
		this._maxListeners = n;
		return this;
	};
	function _getMaxListeners(that) {
		if (that._maxListeners === void 0) return EventEmitter.defaultMaxListeners;
		return that._maxListeners;
	}
	EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
		return _getMaxListeners(this);
	};
	EventEmitter.prototype.emit = function emit(type) {
		var args = [];
		for (var i = 1; i < arguments.length; i++) args.push(arguments[i]);
		var doError = type === "error";
		var events = this._events;
		if (events !== void 0) doError = doError && events.error === void 0;
		else if (!doError) return false;
		if (doError) {
			var er;
			if (args.length > 0) er = args[0];
			if (er instanceof Error) throw er;
			var err = /* @__PURE__ */ new Error("Unhandled error." + (er ? " (" + er.message + ")" : ""));
			err.context = er;
			throw err;
		}
		var handler = events[type];
		if (handler === void 0) return false;
		if (typeof handler === "function") ReflectApply(handler, this, args);
		else {
			var len = handler.length;
			var listeners = arrayClone(handler, len);
			for (var i = 0; i < len; ++i) ReflectApply(listeners[i], this, args);
		}
		return true;
	};
	function _addListener(target, type, listener, prepend) {
		var m;
		var events;
		var existing;
		checkListener(listener);
		events = target._events;
		if (events === void 0) {
			events = target._events = Object.create(null);
			target._eventsCount = 0;
		} else {
			if (events.newListener !== void 0) {
				target.emit("newListener", type, listener.listener ? listener.listener : listener);
				events = target._events;
			}
			existing = events[type];
		}
		if (existing === void 0) {
			existing = events[type] = listener;
			++target._eventsCount;
		} else {
			if (typeof existing === "function") existing = events[type] = prepend ? [listener, existing] : [existing, listener];
			else if (prepend) existing.unshift(listener);
			else existing.push(listener);
			m = _getMaxListeners(target);
			if (m > 0 && existing.length > m && !existing.warned) {
				existing.warned = true;
				var w = /* @__PURE__ */ new Error("Possible EventEmitter memory leak detected. " + existing.length + " " + String(type) + " listeners added. Use emitter.setMaxListeners() to increase limit");
				w.name = "MaxListenersExceededWarning";
				w.emitter = target;
				w.type = type;
				w.count = existing.length;
				ProcessEmitWarning(w);
			}
		}
		return target;
	}
	EventEmitter.prototype.addListener = function addListener(type, listener) {
		return _addListener(this, type, listener, false);
	};
	EventEmitter.prototype.on = EventEmitter.prototype.addListener;
	EventEmitter.prototype.prependListener = function prependListener(type, listener) {
		return _addListener(this, type, listener, true);
	};
	function onceWrapper() {
		if (!this.fired) {
			this.target.removeListener(this.type, this.wrapFn);
			this.fired = true;
			if (arguments.length === 0) return this.listener.call(this.target);
			return this.listener.apply(this.target, arguments);
		}
	}
	function _onceWrap(target, type, listener) {
		var state = {
			fired: false,
			wrapFn: void 0,
			target,
			type,
			listener
		};
		var wrapped = onceWrapper.bind(state);
		wrapped.listener = listener;
		state.wrapFn = wrapped;
		return wrapped;
	}
	EventEmitter.prototype.once = function once(type, listener) {
		checkListener(listener);
		this.on(type, _onceWrap(this, type, listener));
		return this;
	};
	EventEmitter.prototype.prependOnceListener = function prependOnceListener(type, listener) {
		checkListener(listener);
		this.prependListener(type, _onceWrap(this, type, listener));
		return this;
	};
	EventEmitter.prototype.removeListener = function removeListener(type, listener) {
		var list, events, position, i, originalListener;
		checkListener(listener);
		events = this._events;
		if (events === void 0) return this;
		list = events[type];
		if (list === void 0) return this;
		if (list === listener || list.listener === listener) if (--this._eventsCount === 0) this._events = Object.create(null);
		else {
			delete events[type];
			if (events.removeListener) this.emit("removeListener", type, list.listener || listener);
		}
		else if (typeof list !== "function") {
			position = -1;
			for (i = list.length - 1; i >= 0; i--) if (list[i] === listener || list[i].listener === listener) {
				originalListener = list[i].listener;
				position = i;
				break;
			}
			if (position < 0) return this;
			if (position === 0) list.shift();
			else spliceOne(list, position);
			if (list.length === 1) events[type] = list[0];
			if (events.removeListener !== void 0) this.emit("removeListener", type, originalListener || listener);
		}
		return this;
	};
	EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
	EventEmitter.prototype.removeAllListeners = function removeAllListeners(type) {
		var listeners, events = this._events, i;
		if (events === void 0) return this;
		if (events.removeListener === void 0) {
			if (arguments.length === 0) {
				this._events = Object.create(null);
				this._eventsCount = 0;
			} else if (events[type] !== void 0) if (--this._eventsCount === 0) this._events = Object.create(null);
			else delete events[type];
			return this;
		}
		if (arguments.length === 0) {
			var keys = Object.keys(events);
			var key;
			for (i = 0; i < keys.length; ++i) {
				key = keys[i];
				if (key === "removeListener") continue;
				this.removeAllListeners(key);
			}
			this.removeAllListeners("removeListener");
			this._events = Object.create(null);
			this._eventsCount = 0;
			return this;
		}
		listeners = events[type];
		if (typeof listeners === "function") this.removeListener(type, listeners);
		else if (listeners !== void 0) for (i = listeners.length - 1; i >= 0; i--) this.removeListener(type, listeners[i]);
		return this;
	};
	function _listeners(target, type, unwrap) {
		var events = target._events;
		if (events === void 0) return [];
		var evlistener = events[type];
		if (evlistener === void 0) return [];
		if (typeof evlistener === "function") return unwrap ? [evlistener.listener || evlistener] : [evlistener];
		return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
	}
	EventEmitter.prototype.listeners = function listeners(type) {
		return _listeners(this, type, true);
	};
	EventEmitter.prototype.rawListeners = function rawListeners(type) {
		return _listeners(this, type, false);
	};
	EventEmitter.listenerCount = function(emitter, type) {
		if (typeof emitter.listenerCount === "function") return emitter.listenerCount(type);
		else return listenerCount.call(emitter, type);
	};
	EventEmitter.prototype.listenerCount = listenerCount;
	function listenerCount(type) {
		var events = this._events;
		if (events !== void 0) {
			var evlistener = events[type];
			if (typeof evlistener === "function") return 1;
			else if (evlistener !== void 0) return evlistener.length;
		}
		return 0;
	}
	EventEmitter.prototype.eventNames = function eventNames() {
		return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
	};
	function arrayClone(arr, n) {
		var copy = new Array(n);
		for (var i = 0; i < n; ++i) copy[i] = arr[i];
		return copy;
	}
	function spliceOne(list, index) {
		for (; index + 1 < list.length; index++) list[index] = list[index + 1];
		list.pop();
	}
	function unwrapListeners(arr) {
		var ret = new Array(arr.length);
		for (var i = 0; i < ret.length; ++i) ret[i] = arr[i].listener || arr[i];
		return ret;
	}
	function once(emitter, name) {
		return new Promise(function(resolve, reject) {
			function errorListener(err) {
				emitter.removeListener(name, resolver);
				reject(err);
			}
			function resolver() {
				if (typeof emitter.removeListener === "function") emitter.removeListener("error", errorListener);
				resolve([].slice.call(arguments));
			}
			eventTargetAgnosticAddListener(emitter, name, resolver, { once: true });
			if (name !== "error") addErrorHandlerIfEventEmitter(emitter, errorListener, { once: true });
		});
	}
	function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
		if (typeof emitter.on === "function") eventTargetAgnosticAddListener(emitter, "error", handler, flags);
	}
	function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
		if (typeof emitter.on === "function") if (flags.once) emitter.once(name, listener);
		else emitter.on(name, listener);
		else if (typeof emitter.addEventListener === "function") emitter.addEventListener(name, function wrapListener(arg) {
			if (flags.once) emitter.removeEventListener(name, wrapListener);
			listener(arg);
		});
		else throw new TypeError("The \"emitter\" argument must be of type EventEmitter. Received type " + typeof emitter);
	}
}));
var require_inherits_browser = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	if (typeof Object.create === "function") module.exports = function inherits(ctor, superCtor) {
		if (superCtor) {
			ctor.super_ = superCtor;
			ctor.prototype = Object.create(superCtor.prototype, { constructor: {
				value: ctor,
				enumerable: false,
				writable: true,
				configurable: true
			} });
		}
	};
	else module.exports = function inherits(ctor, superCtor) {
		if (superCtor) {
			ctor.super_ = superCtor;
			var TempCtor = function() {};
			TempCtor.prototype = superCtor.prototype;
			ctor.prototype = new TempCtor();
			ctor.prototype.constructor = ctor;
		}
	};
}));
var global;
var init_dist$1 = __esmMin((() => {
	global = globalThis || self;
}));
function getDefaultExportFromCjs(x) {
	return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
}
function defaultSetTimout() {
	throw new Error("setTimeout has not been defined");
}
function defaultClearTimeout() {
	throw new Error("clearTimeout has not been defined");
}
function runTimeout(fun) {
	if (cachedSetTimeout === setTimeout) return setTimeout(fun, 0);
	if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
		cachedSetTimeout = setTimeout;
		return setTimeout(fun, 0);
	}
	try {
		return cachedSetTimeout(fun, 0);
	} catch (e) {
		try {
			return cachedSetTimeout.call(null, fun, 0);
		} catch (e) {
			return cachedSetTimeout.call(this, fun, 0);
		}
	}
}
function runClearTimeout(marker) {
	if (cachedClearTimeout === clearTimeout) return clearTimeout(marker);
	if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
		cachedClearTimeout = clearTimeout;
		return clearTimeout(marker);
	}
	try {
		return cachedClearTimeout(marker);
	} catch (e) {
		try {
			return cachedClearTimeout.call(null, marker);
		} catch (e) {
			return cachedClearTimeout.call(this, marker);
		}
	}
}
function cleanUpNextTick() {
	if (!draining || !currentQueue) return;
	draining = false;
	if (currentQueue.length) queue = currentQueue.concat(queue);
	else queueIndex = -1;
	if (queue.length) drainQueue();
}
function drainQueue() {
	if (draining) return;
	var timeout = runTimeout(cleanUpNextTick);
	draining = true;
	var len = queue.length;
	while (len) {
		currentQueue = queue;
		queue = [];
		while (++queueIndex < len) if (currentQueue) currentQueue[queueIndex].run();
		queueIndex = -1;
		len = queue.length;
	}
	currentQueue = null;
	draining = false;
	runClearTimeout(timeout);
}
function Item(fun, array) {
	this.fun = fun;
	this.array = array;
}
function noop() {}
var browser;
var process;
var cachedSetTimeout;
var cachedClearTimeout;
var queue;
var draining;
var currentQueue;
var queueIndex;
var browserExports;
var process$1;
var init_dist = __esmMin((() => {
	browser = { exports: {} };
	process = browser.exports = {};
	(function() {
		try {
			if (typeof setTimeout === "function") cachedSetTimeout = setTimeout;
			else cachedSetTimeout = defaultSetTimout;
		} catch (e) {
			cachedSetTimeout = defaultSetTimout;
		}
		try {
			if (typeof clearTimeout === "function") cachedClearTimeout = clearTimeout;
			else cachedClearTimeout = defaultClearTimeout;
		} catch (e) {
			cachedClearTimeout = defaultClearTimeout;
		}
	})();
	queue = [];
	draining = false;
	queueIndex = -1;
	process.nextTick = function(fun) {
		var args = new Array(arguments.length - 1);
		if (arguments.length > 1) for (var i = 1; i < arguments.length; i++) args[i - 1] = arguments[i];
		queue.push(new Item(fun, args));
		if (queue.length === 1 && !draining) runTimeout(drainQueue);
	};
	Item.prototype.run = function() {
		this.fun.apply(null, this.array);
	};
	process.title = "browser";
	process.browser = true;
	process.env = {};
	process.argv = [];
	process.version = "";
	process.versions = {};
	process.on = noop;
	process.addListener = noop;
	process.once = noop;
	process.off = noop;
	process.removeListener = noop;
	process.removeAllListeners = noop;
	process.emit = noop;
	process.prependListener = noop;
	process.prependOnceListener = noop;
	process.listeners = function(name) {
		return [];
	};
	process.binding = function(name) {
		throw new Error("process.binding is not supported");
	};
	process.cwd = function() {
		return "/";
	};
	process.chdir = function(dir) {
		throw new Error("process.chdir is not supported");
	};
	process.umask = function() {
		return 0;
	};
	browserExports = browser.exports;
	process$1 = /* @__PURE__ */ getDefaultExportFromCjs(browserExports);
}));
var require_stream_browser = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_events().EventEmitter;
}));
var require_base64_js = /* @__PURE__ */ __commonJSMin(((exports) => {
	exports.byteLength = byteLength;
	exports.toByteArray = toByteArray;
	exports.fromByteArray = fromByteArray;
	var lookup = [];
	var revLookup = [];
	var Arr = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
	var code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	for (var i = 0, len = code.length; i < len; ++i) {
		lookup[i] = code[i];
		revLookup[code.charCodeAt(i)] = i;
	}
	revLookup["-".charCodeAt(0)] = 62;
	revLookup["_".charCodeAt(0)] = 63;
	function getLens(b64) {
		var len = b64.length;
		if (len % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
		var validLen = b64.indexOf("=");
		if (validLen === -1) validLen = len;
		var placeHoldersLen = validLen === len ? 0 : 4 - validLen % 4;
		return [validLen, placeHoldersLen];
	}
	function byteLength(b64) {
		var lens = getLens(b64);
		var validLen = lens[0];
		var placeHoldersLen = lens[1];
		return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
	}
	function _byteLength(b64, validLen, placeHoldersLen) {
		return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
	}
	function toByteArray(b64) {
		var tmp;
		var lens = getLens(b64);
		var validLen = lens[0];
		var placeHoldersLen = lens[1];
		var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
		var curByte = 0;
		var len = placeHoldersLen > 0 ? validLen - 4 : validLen;
		var i;
		for (i = 0; i < len; i += 4) {
			tmp = revLookup[b64.charCodeAt(i)] << 18 | revLookup[b64.charCodeAt(i + 1)] << 12 | revLookup[b64.charCodeAt(i + 2)] << 6 | revLookup[b64.charCodeAt(i + 3)];
			arr[curByte++] = tmp >> 16 & 255;
			arr[curByte++] = tmp >> 8 & 255;
			arr[curByte++] = tmp & 255;
		}
		if (placeHoldersLen === 2) {
			tmp = revLookup[b64.charCodeAt(i)] << 2 | revLookup[b64.charCodeAt(i + 1)] >> 4;
			arr[curByte++] = tmp & 255;
		}
		if (placeHoldersLen === 1) {
			tmp = revLookup[b64.charCodeAt(i)] << 10 | revLookup[b64.charCodeAt(i + 1)] << 4 | revLookup[b64.charCodeAt(i + 2)] >> 2;
			arr[curByte++] = tmp >> 8 & 255;
			arr[curByte++] = tmp & 255;
		}
		return arr;
	}
	function tripletToBase64(num) {
		return lookup[num >> 18 & 63] + lookup[num >> 12 & 63] + lookup[num >> 6 & 63] + lookup[num & 63];
	}
	function encodeChunk(uint8, start, end) {
		var tmp;
		var output = [];
		for (var i = start; i < end; i += 3) {
			tmp = (uint8[i] << 16 & 16711680) + (uint8[i + 1] << 8 & 65280) + (uint8[i + 2] & 255);
			output.push(tripletToBase64(tmp));
		}
		return output.join("");
	}
	function fromByteArray(uint8) {
		var tmp;
		var len = uint8.length;
		var extraBytes = len % 3;
		var parts = [];
		var maxChunkLength = 16383;
		for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) parts.push(encodeChunk(uint8, i, i + maxChunkLength > len2 ? len2 : i + maxChunkLength));
		if (extraBytes === 1) {
			tmp = uint8[len - 1];
			parts.push(lookup[tmp >> 2] + lookup[tmp << 4 & 63] + "==");
		} else if (extraBytes === 2) {
			tmp = (uint8[len - 2] << 8) + uint8[len - 1];
			parts.push(lookup[tmp >> 10] + lookup[tmp >> 4 & 63] + lookup[tmp << 2 & 63] + "=");
		}
		return parts.join("");
	}
}));
var require_ieee754 = /* @__PURE__ */ __commonJSMin(((exports) => {
	/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
	exports.read = function(buffer, offset, isLE, mLen, nBytes) {
		var e, m;
		var eLen = nBytes * 8 - mLen - 1;
		var eMax = (1 << eLen) - 1;
		var eBias = eMax >> 1;
		var nBits = -7;
		var i = isLE ? nBytes - 1 : 0;
		var d = isLE ? -1 : 1;
		var s = buffer[offset + i];
		i += d;
		e = s & (1 << -nBits) - 1;
		s >>= -nBits;
		nBits += eLen;
		for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8);
		m = e & (1 << -nBits) - 1;
		e >>= -nBits;
		nBits += mLen;
		for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8);
		if (e === 0) e = 1 - eBias;
		else if (e === eMax) return m ? NaN : (s ? -1 : 1) * Infinity;
		else {
			m = m + Math.pow(2, mLen);
			e = e - eBias;
		}
		return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
	};
	exports.write = function(buffer, value, offset, isLE, mLen, nBytes) {
		var e, m, c;
		var eLen = nBytes * 8 - mLen - 1;
		var eMax = (1 << eLen) - 1;
		var eBias = eMax >> 1;
		var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
		var i = isLE ? 0 : nBytes - 1;
		var d = isLE ? 1 : -1;
		var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
		value = Math.abs(value);
		if (isNaN(value) || value === Infinity) {
			m = isNaN(value) ? 1 : 0;
			e = eMax;
		} else {
			e = Math.floor(Math.log(value) / Math.LN2);
			if (value * (c = Math.pow(2, -e)) < 1) {
				e--;
				c *= 2;
			}
			if (e + eBias >= 1) value += rt / c;
			else value += rt * Math.pow(2, 1 - eBias);
			if (value * c >= 2) {
				e++;
				c /= 2;
			}
			if (e + eBias >= eMax) {
				m = 0;
				e = eMax;
			} else if (e + eBias >= 1) {
				m = (value * c - 1) * Math.pow(2, mLen);
				e = e + eBias;
			} else {
				m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
				e = 0;
			}
		}
		for (; mLen >= 8; buffer[offset + i] = m & 255, i += d, m /= 256, mLen -= 8);
		e = e << mLen | m;
		eLen += mLen;
		for (; eLen > 0; buffer[offset + i] = e & 255, i += d, e /= 256, eLen -= 8);
		buffer[offset + i - d] |= s * 128;
	};
}));
/*!
* The buffer module from node.js, for the browser.
*
* @author   Feross Aboukhadijeh <https://feross.org>
* @license  MIT
*/
var require_buffer = /* @__PURE__ */ __commonJSMin(((exports) => {
	var base64 = require_base64_js();
	var ieee754 = require_ieee754();
	var customInspectSymbol = typeof Symbol === "function" && typeof Symbol["for"] === "function" ? Symbol["for"]("nodejs.util.inspect.custom") : null;
	exports.Buffer = Buffer;
	exports.SlowBuffer = SlowBuffer;
	exports.INSPECT_MAX_BYTES = 50;
	var K_MAX_LENGTH = 2147483647;
	exports.kMaxLength = K_MAX_LENGTH;
	/**
	* If `Buffer.TYPED_ARRAY_SUPPORT`:
	*   === true    Use Uint8Array implementation (fastest)
	*   === false   Print warning and recommend using `buffer` v4.x which has an Object
	*               implementation (most compatible, even IE6)
	*
	* Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
	* Opera 11.6+, iOS 4.2+.
	*
	* We report that the browser does not support typed arrays if the are not subclassable
	* using __proto__. Firefox 4-29 lacks support for adding new properties to `Uint8Array`
	* (See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438). IE 10 lacks support
	* for __proto__ and has a buggy typed array implementation.
	*/
	Buffer.TYPED_ARRAY_SUPPORT = typedArraySupport();
	if (!Buffer.TYPED_ARRAY_SUPPORT && typeof console !== "undefined" && typeof console.error === "function") console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support.");
	function typedArraySupport() {
		try {
			var arr = /* @__PURE__ */ new Uint8Array(1);
			var proto = { foo: function() {
				return 42;
			} };
			Object.setPrototypeOf(proto, Uint8Array.prototype);
			Object.setPrototypeOf(arr, proto);
			return arr.foo() === 42;
		} catch (e) {
			return false;
		}
	}
	Object.defineProperty(Buffer.prototype, "parent", {
		enumerable: true,
		get: function() {
			if (!Buffer.isBuffer(this)) return void 0;
			return this.buffer;
		}
	});
	Object.defineProperty(Buffer.prototype, "offset", {
		enumerable: true,
		get: function() {
			if (!Buffer.isBuffer(this)) return void 0;
			return this.byteOffset;
		}
	});
	function createBuffer(length) {
		if (length > K_MAX_LENGTH) throw new RangeError("The value \"" + length + "\" is invalid for option \"size\"");
		var buf = new Uint8Array(length);
		Object.setPrototypeOf(buf, Buffer.prototype);
		return buf;
	}
	/**
	* The Buffer constructor returns instances of `Uint8Array` that have their
	* prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
	* `Uint8Array`, so the returned instances will have all the node `Buffer` methods
	* and the `Uint8Array` methods. Square bracket notation works as expected -- it
	* returns a single octet.
	*
	* The `Uint8Array` prototype remains unmodified.
	*/
	function Buffer(arg, encodingOrOffset, length) {
		if (typeof arg === "number") {
			if (typeof encodingOrOffset === "string") throw new TypeError("The \"string\" argument must be of type string. Received type number");
			return allocUnsafe(arg);
		}
		return from(arg, encodingOrOffset, length);
	}
	Buffer.poolSize = 8192;
	function from(value, encodingOrOffset, length) {
		if (typeof value === "string") return fromString(value, encodingOrOffset);
		if (ArrayBuffer.isView(value)) return fromArrayView(value);
		if (value == null) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value);
		if (isInstance(value, ArrayBuffer) || value && isInstance(value.buffer, ArrayBuffer)) return fromArrayBuffer(value, encodingOrOffset, length);
		if (typeof SharedArrayBuffer !== "undefined" && (isInstance(value, SharedArrayBuffer) || value && isInstance(value.buffer, SharedArrayBuffer))) return fromArrayBuffer(value, encodingOrOffset, length);
		if (typeof value === "number") throw new TypeError("The \"value\" argument must not be of type number. Received type number");
		var valueOf = value.valueOf && value.valueOf();
		if (valueOf != null && valueOf !== value) return Buffer.from(valueOf, encodingOrOffset, length);
		var b = fromObject(value);
		if (b) return b;
		if (typeof Symbol !== "undefined" && Symbol.toPrimitive != null && typeof value[Symbol.toPrimitive] === "function") return Buffer.from(value[Symbol.toPrimitive]("string"), encodingOrOffset, length);
		throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value);
	}
	/**
	* Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
	* if value is a number.
	* Buffer.from(str[, encoding])
	* Buffer.from(array)
	* Buffer.from(buffer)
	* Buffer.from(arrayBuffer[, byteOffset[, length]])
	**/
	Buffer.from = function(value, encodingOrOffset, length) {
		return from(value, encodingOrOffset, length);
	};
	Object.setPrototypeOf(Buffer.prototype, Uint8Array.prototype);
	Object.setPrototypeOf(Buffer, Uint8Array);
	function assertSize(size) {
		if (typeof size !== "number") throw new TypeError("\"size\" argument must be of type number");
		else if (size < 0) throw new RangeError("The value \"" + size + "\" is invalid for option \"size\"");
	}
	function alloc(size, fill, encoding) {
		assertSize(size);
		if (size <= 0) return createBuffer(size);
		if (fill !== void 0) return typeof encoding === "string" ? createBuffer(size).fill(fill, encoding) : createBuffer(size).fill(fill);
		return createBuffer(size);
	}
	/**
	* Creates a new filled Buffer instance.
	* alloc(size[, fill[, encoding]])
	**/
	Buffer.alloc = function(size, fill, encoding) {
		return alloc(size, fill, encoding);
	};
	function allocUnsafe(size) {
		assertSize(size);
		return createBuffer(size < 0 ? 0 : checked(size) | 0);
	}
	/**
	* Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
	* */
	Buffer.allocUnsafe = function(size) {
		return allocUnsafe(size);
	};
	/**
	* Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
	*/
	Buffer.allocUnsafeSlow = function(size) {
		return allocUnsafe(size);
	};
	function fromString(string, encoding) {
		if (typeof encoding !== "string" || encoding === "") encoding = "utf8";
		if (!Buffer.isEncoding(encoding)) throw new TypeError("Unknown encoding: " + encoding);
		var length = byteLength(string, encoding) | 0;
		var buf = createBuffer(length);
		var actual = buf.write(string, encoding);
		if (actual !== length) buf = buf.slice(0, actual);
		return buf;
	}
	function fromArrayLike(array) {
		var length = array.length < 0 ? 0 : checked(array.length) | 0;
		var buf = createBuffer(length);
		for (var i = 0; i < length; i += 1) buf[i] = array[i] & 255;
		return buf;
	}
	function fromArrayView(arrayView) {
		if (isInstance(arrayView, Uint8Array)) {
			var copy = new Uint8Array(arrayView);
			return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength);
		}
		return fromArrayLike(arrayView);
	}
	function fromArrayBuffer(array, byteOffset, length) {
		if (byteOffset < 0 || array.byteLength < byteOffset) throw new RangeError("\"offset\" is outside of buffer bounds");
		if (array.byteLength < byteOffset + (length || 0)) throw new RangeError("\"length\" is outside of buffer bounds");
		var buf;
		if (byteOffset === void 0 && length === void 0) buf = new Uint8Array(array);
		else if (length === void 0) buf = new Uint8Array(array, byteOffset);
		else buf = new Uint8Array(array, byteOffset, length);
		Object.setPrototypeOf(buf, Buffer.prototype);
		return buf;
	}
	function fromObject(obj) {
		if (Buffer.isBuffer(obj)) {
			var len = checked(obj.length) | 0;
			var buf = createBuffer(len);
			if (buf.length === 0) return buf;
			obj.copy(buf, 0, 0, len);
			return buf;
		}
		if (obj.length !== void 0) {
			if (typeof obj.length !== "number" || numberIsNaN(obj.length)) return createBuffer(0);
			return fromArrayLike(obj);
		}
		if (obj.type === "Buffer" && Array.isArray(obj.data)) return fromArrayLike(obj.data);
	}
	function checked(length) {
		if (length >= K_MAX_LENGTH) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + K_MAX_LENGTH.toString(16) + " bytes");
		return length | 0;
	}
	function SlowBuffer(length) {
		if (+length != length) length = 0;
		return Buffer.alloc(+length);
	}
	Buffer.isBuffer = function isBuffer(b) {
		return b != null && b._isBuffer === true && b !== Buffer.prototype;
	};
	Buffer.compare = function compare(a, b) {
		if (isInstance(a, Uint8Array)) a = Buffer.from(a, a.offset, a.byteLength);
		if (isInstance(b, Uint8Array)) b = Buffer.from(b, b.offset, b.byteLength);
		if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) throw new TypeError("The \"buf1\", \"buf2\" arguments must be one of type Buffer or Uint8Array");
		if (a === b) return 0;
		var x = a.length;
		var y = b.length;
		for (var i = 0, len = Math.min(x, y); i < len; ++i) if (a[i] !== b[i]) {
			x = a[i];
			y = b[i];
			break;
		}
		if (x < y) return -1;
		if (y < x) return 1;
		return 0;
	};
	Buffer.isEncoding = function isEncoding(encoding) {
		switch (String(encoding).toLowerCase()) {
			case "hex":
			case "utf8":
			case "utf-8":
			case "ascii":
			case "latin1":
			case "binary":
			case "base64":
			case "ucs2":
			case "ucs-2":
			case "utf16le":
			case "utf-16le": return true;
			default: return false;
		}
	};
	Buffer.concat = function concat(list, length) {
		if (!Array.isArray(list)) throw new TypeError("\"list\" argument must be an Array of Buffers");
		if (list.length === 0) return Buffer.alloc(0);
		var i;
		if (length === void 0) {
			length = 0;
			for (i = 0; i < list.length; ++i) length += list[i].length;
		}
		var buffer = Buffer.allocUnsafe(length);
		var pos = 0;
		for (i = 0; i < list.length; ++i) {
			var buf = list[i];
			if (isInstance(buf, Uint8Array)) if (pos + buf.length > buffer.length) Buffer.from(buf).copy(buffer, pos);
			else Uint8Array.prototype.set.call(buffer, buf, pos);
			else if (!Buffer.isBuffer(buf)) throw new TypeError("\"list\" argument must be an Array of Buffers");
			else buf.copy(buffer, pos);
			pos += buf.length;
		}
		return buffer;
	};
	function byteLength(string, encoding) {
		if (Buffer.isBuffer(string)) return string.length;
		if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) return string.byteLength;
		if (typeof string !== "string") throw new TypeError("The \"string\" argument must be one of type string, Buffer, or ArrayBuffer. Received type " + typeof string);
		var len = string.length;
		var mustMatch = arguments.length > 2 && arguments[2] === true;
		if (!mustMatch && len === 0) return 0;
		var loweredCase = false;
		for (;;) switch (encoding) {
			case "ascii":
			case "latin1":
			case "binary": return len;
			case "utf8":
			case "utf-8": return utf8ToBytes(string).length;
			case "ucs2":
			case "ucs-2":
			case "utf16le":
			case "utf-16le": return len * 2;
			case "hex": return len >>> 1;
			case "base64": return base64ToBytes(string).length;
			default:
				if (loweredCase) return mustMatch ? -1 : utf8ToBytes(string).length;
				encoding = ("" + encoding).toLowerCase();
				loweredCase = true;
		}
	}
	Buffer.byteLength = byteLength;
	function slowToString(encoding, start, end) {
		var loweredCase = false;
		if (start === void 0 || start < 0) start = 0;
		if (start > this.length) return "";
		if (end === void 0 || end > this.length) end = this.length;
		if (end <= 0) return "";
		end >>>= 0;
		start >>>= 0;
		if (end <= start) return "";
		if (!encoding) encoding = "utf8";
		while (true) switch (encoding) {
			case "hex": return hexSlice(this, start, end);
			case "utf8":
			case "utf-8": return utf8Slice(this, start, end);
			case "ascii": return asciiSlice(this, start, end);
			case "latin1":
			case "binary": return latin1Slice(this, start, end);
			case "base64": return base64Slice(this, start, end);
			case "ucs2":
			case "ucs-2":
			case "utf16le":
			case "utf-16le": return utf16leSlice(this, start, end);
			default:
				if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
				encoding = (encoding + "").toLowerCase();
				loweredCase = true;
		}
	}
	Buffer.prototype._isBuffer = true;
	function swap(b, n, m) {
		var i = b[n];
		b[n] = b[m];
		b[m] = i;
	}
	Buffer.prototype.swap16 = function swap16() {
		var len = this.length;
		if (len % 2 !== 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
		for (var i = 0; i < len; i += 2) swap(this, i, i + 1);
		return this;
	};
	Buffer.prototype.swap32 = function swap32() {
		var len = this.length;
		if (len % 4 !== 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
		for (var i = 0; i < len; i += 4) {
			swap(this, i, i + 3);
			swap(this, i + 1, i + 2);
		}
		return this;
	};
	Buffer.prototype.swap64 = function swap64() {
		var len = this.length;
		if (len % 8 !== 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
		for (var i = 0; i < len; i += 8) {
			swap(this, i, i + 7);
			swap(this, i + 1, i + 6);
			swap(this, i + 2, i + 5);
			swap(this, i + 3, i + 4);
		}
		return this;
	};
	Buffer.prototype.toString = function toString() {
		var length = this.length;
		if (length === 0) return "";
		if (arguments.length === 0) return utf8Slice(this, 0, length);
		return slowToString.apply(this, arguments);
	};
	Buffer.prototype.toLocaleString = Buffer.prototype.toString;
	Buffer.prototype.equals = function equals(b) {
		if (!Buffer.isBuffer(b)) throw new TypeError("Argument must be a Buffer");
		if (this === b) return true;
		return Buffer.compare(this, b) === 0;
	};
	Buffer.prototype.inspect = function inspect() {
		var str = "";
		var max = exports.INSPECT_MAX_BYTES;
		str = this.toString("hex", 0, max).replace(/(.{2})/g, "$1 ").trim();
		if (this.length > max) str += " ... ";
		return "<Buffer " + str + ">";
	};
	if (customInspectSymbol) Buffer.prototype[customInspectSymbol] = Buffer.prototype.inspect;
	Buffer.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
		if (isInstance(target, Uint8Array)) target = Buffer.from(target, target.offset, target.byteLength);
		if (!Buffer.isBuffer(target)) throw new TypeError("The \"target\" argument must be one of type Buffer or Uint8Array. Received type " + typeof target);
		if (start === void 0) start = 0;
		if (end === void 0) end = target ? target.length : 0;
		if (thisStart === void 0) thisStart = 0;
		if (thisEnd === void 0) thisEnd = this.length;
		if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) throw new RangeError("out of range index");
		if (thisStart >= thisEnd && start >= end) return 0;
		if (thisStart >= thisEnd) return -1;
		if (start >= end) return 1;
		start >>>= 0;
		end >>>= 0;
		thisStart >>>= 0;
		thisEnd >>>= 0;
		if (this === target) return 0;
		var x = thisEnd - thisStart;
		var y = end - start;
		var len = Math.min(x, y);
		var thisCopy = this.slice(thisStart, thisEnd);
		var targetCopy = target.slice(start, end);
		for (var i = 0; i < len; ++i) if (thisCopy[i] !== targetCopy[i]) {
			x = thisCopy[i];
			y = targetCopy[i];
			break;
		}
		if (x < y) return -1;
		if (y < x) return 1;
		return 0;
	};
	function bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
		if (buffer.length === 0) return -1;
		if (typeof byteOffset === "string") {
			encoding = byteOffset;
			byteOffset = 0;
		} else if (byteOffset > 2147483647) byteOffset = 2147483647;
		else if (byteOffset < -2147483648) byteOffset = -2147483648;
		byteOffset = +byteOffset;
		if (numberIsNaN(byteOffset)) byteOffset = dir ? 0 : buffer.length - 1;
		if (byteOffset < 0) byteOffset = buffer.length + byteOffset;
		if (byteOffset >= buffer.length) if (dir) return -1;
		else byteOffset = buffer.length - 1;
		else if (byteOffset < 0) if (dir) byteOffset = 0;
		else return -1;
		if (typeof val === "string") val = Buffer.from(val, encoding);
		if (Buffer.isBuffer(val)) {
			if (val.length === 0) return -1;
			return arrayIndexOf(buffer, val, byteOffset, encoding, dir);
		} else if (typeof val === "number") {
			val = val & 255;
			if (typeof Uint8Array.prototype.indexOf === "function") if (dir) return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset);
			else return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset);
			return arrayIndexOf(buffer, [val], byteOffset, encoding, dir);
		}
		throw new TypeError("val must be string, number or Buffer");
	}
	function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
		var indexSize = 1;
		var arrLength = arr.length;
		var valLength = val.length;
		if (encoding !== void 0) {
			encoding = String(encoding).toLowerCase();
			if (encoding === "ucs2" || encoding === "ucs-2" || encoding === "utf16le" || encoding === "utf-16le") {
				if (arr.length < 2 || val.length < 2) return -1;
				indexSize = 2;
				arrLength /= 2;
				valLength /= 2;
				byteOffset /= 2;
			}
		}
		function read(buf, i) {
			if (indexSize === 1) return buf[i];
			else return buf.readUInt16BE(i * indexSize);
		}
		var i;
		if (dir) {
			var foundIndex = -1;
			for (i = byteOffset; i < arrLength; i++) if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
				if (foundIndex === -1) foundIndex = i;
				if (i - foundIndex + 1 === valLength) return foundIndex * indexSize;
			} else {
				if (foundIndex !== -1) i -= i - foundIndex;
				foundIndex = -1;
			}
		} else {
			if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
			for (i = byteOffset; i >= 0; i--) {
				var found = true;
				for (var j = 0; j < valLength; j++) if (read(arr, i + j) !== read(val, j)) {
					found = false;
					break;
				}
				if (found) return i;
			}
		}
		return -1;
	}
	Buffer.prototype.includes = function includes(val, byteOffset, encoding) {
		return this.indexOf(val, byteOffset, encoding) !== -1;
	};
	Buffer.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
		return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
	};
	Buffer.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
		return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
	};
	function hexWrite(buf, string, offset, length) {
		offset = Number(offset) || 0;
		var remaining = buf.length - offset;
		if (!length) length = remaining;
		else {
			length = Number(length);
			if (length > remaining) length = remaining;
		}
		var strLen = string.length;
		if (length > strLen / 2) length = strLen / 2;
		for (var i = 0; i < length; ++i) {
			var parsed = parseInt(string.substr(i * 2, 2), 16);
			if (numberIsNaN(parsed)) return i;
			buf[offset + i] = parsed;
		}
		return i;
	}
	function utf8Write(buf, string, offset, length) {
		return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
	}
	function asciiWrite(buf, string, offset, length) {
		return blitBuffer(asciiToBytes(string), buf, offset, length);
	}
	function base64Write(buf, string, offset, length) {
		return blitBuffer(base64ToBytes(string), buf, offset, length);
	}
	function ucs2Write(buf, string, offset, length) {
		return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
	}
	Buffer.prototype.write = function write(string, offset, length, encoding) {
		if (offset === void 0) {
			encoding = "utf8";
			length = this.length;
			offset = 0;
		} else if (length === void 0 && typeof offset === "string") {
			encoding = offset;
			length = this.length;
			offset = 0;
		} else if (isFinite(offset)) {
			offset = offset >>> 0;
			if (isFinite(length)) {
				length = length >>> 0;
				if (encoding === void 0) encoding = "utf8";
			} else {
				encoding = length;
				length = void 0;
			}
		} else throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
		var remaining = this.length - offset;
		if (length === void 0 || length > remaining) length = remaining;
		if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) throw new RangeError("Attempt to write outside buffer bounds");
		if (!encoding) encoding = "utf8";
		var loweredCase = false;
		for (;;) switch (encoding) {
			case "hex": return hexWrite(this, string, offset, length);
			case "utf8":
			case "utf-8": return utf8Write(this, string, offset, length);
			case "ascii":
			case "latin1":
			case "binary": return asciiWrite(this, string, offset, length);
			case "base64": return base64Write(this, string, offset, length);
			case "ucs2":
			case "ucs-2":
			case "utf16le":
			case "utf-16le": return ucs2Write(this, string, offset, length);
			default:
				if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
				encoding = ("" + encoding).toLowerCase();
				loweredCase = true;
		}
	};
	Buffer.prototype.toJSON = function toJSON() {
		return {
			type: "Buffer",
			data: Array.prototype.slice.call(this._arr || this, 0)
		};
	};
	function base64Slice(buf, start, end) {
		if (start === 0 && end === buf.length) return base64.fromByteArray(buf);
		else return base64.fromByteArray(buf.slice(start, end));
	}
	function utf8Slice(buf, start, end) {
		end = Math.min(buf.length, end);
		var res = [];
		var i = start;
		while (i < end) {
			var firstByte = buf[i];
			var codePoint = null;
			var bytesPerSequence = firstByte > 239 ? 4 : firstByte > 223 ? 3 : firstByte > 191 ? 2 : 1;
			if (i + bytesPerSequence <= end) {
				var secondByte, thirdByte, fourthByte, tempCodePoint;
				switch (bytesPerSequence) {
					case 1:
						if (firstByte < 128) codePoint = firstByte;
						break;
					case 2:
						secondByte = buf[i + 1];
						if ((secondByte & 192) === 128) {
							tempCodePoint = (firstByte & 31) << 6 | secondByte & 63;
							if (tempCodePoint > 127) codePoint = tempCodePoint;
						}
						break;
					case 3:
						secondByte = buf[i + 1];
						thirdByte = buf[i + 2];
						if ((secondByte & 192) === 128 && (thirdByte & 192) === 128) {
							tempCodePoint = (firstByte & 15) << 12 | (secondByte & 63) << 6 | thirdByte & 63;
							if (tempCodePoint > 2047 && (tempCodePoint < 55296 || tempCodePoint > 57343)) codePoint = tempCodePoint;
						}
						break;
					case 4:
						secondByte = buf[i + 1];
						thirdByte = buf[i + 2];
						fourthByte = buf[i + 3];
						if ((secondByte & 192) === 128 && (thirdByte & 192) === 128 && (fourthByte & 192) === 128) {
							tempCodePoint = (firstByte & 15) << 18 | (secondByte & 63) << 12 | (thirdByte & 63) << 6 | fourthByte & 63;
							if (tempCodePoint > 65535 && tempCodePoint < 1114112) codePoint = tempCodePoint;
						}
				}
			}
			if (codePoint === null) {
				codePoint = 65533;
				bytesPerSequence = 1;
			} else if (codePoint > 65535) {
				codePoint -= 65536;
				res.push(codePoint >>> 10 & 1023 | 55296);
				codePoint = 56320 | codePoint & 1023;
			}
			res.push(codePoint);
			i += bytesPerSequence;
		}
		return decodeCodePointsArray(res);
	}
	var MAX_ARGUMENTS_LENGTH = 4096;
	function decodeCodePointsArray(codePoints) {
		var len = codePoints.length;
		if (len <= MAX_ARGUMENTS_LENGTH) return String.fromCharCode.apply(String, codePoints);
		var res = "";
		var i = 0;
		while (i < len) res += String.fromCharCode.apply(String, codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH));
		return res;
	}
	function asciiSlice(buf, start, end) {
		var ret = "";
		end = Math.min(buf.length, end);
		for (var i = start; i < end; ++i) ret += String.fromCharCode(buf[i] & 127);
		return ret;
	}
	function latin1Slice(buf, start, end) {
		var ret = "";
		end = Math.min(buf.length, end);
		for (var i = start; i < end; ++i) ret += String.fromCharCode(buf[i]);
		return ret;
	}
	function hexSlice(buf, start, end) {
		var len = buf.length;
		if (!start || start < 0) start = 0;
		if (!end || end < 0 || end > len) end = len;
		var out = "";
		for (var i = start; i < end; ++i) out += hexSliceLookupTable[buf[i]];
		return out;
	}
	function utf16leSlice(buf, start, end) {
		var bytes = buf.slice(start, end);
		var res = "";
		for (var i = 0; i < bytes.length - 1; i += 2) res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256);
		return res;
	}
	Buffer.prototype.slice = function slice(start, end) {
		var len = this.length;
		start = ~~start;
		end = end === void 0 ? len : ~~end;
		if (start < 0) {
			start += len;
			if (start < 0) start = 0;
		} else if (start > len) start = len;
		if (end < 0) {
			end += len;
			if (end < 0) end = 0;
		} else if (end > len) end = len;
		if (end < start) end = start;
		var newBuf = this.subarray(start, end);
		Object.setPrototypeOf(newBuf, Buffer.prototype);
		return newBuf;
	};
	function checkOffset(offset, ext, length) {
		if (offset % 1 !== 0 || offset < 0) throw new RangeError("offset is not uint");
		if (offset + ext > length) throw new RangeError("Trying to access beyond buffer length");
	}
	Buffer.prototype.readUintLE = Buffer.prototype.readUIntLE = function readUIntLE(offset, byteLength, noAssert) {
		offset = offset >>> 0;
		byteLength = byteLength >>> 0;
		if (!noAssert) checkOffset(offset, byteLength, this.length);
		var val = this[offset];
		var mul = 1;
		var i = 0;
		while (++i < byteLength && (mul *= 256)) val += this[offset + i] * mul;
		return val;
	};
	Buffer.prototype.readUintBE = Buffer.prototype.readUIntBE = function readUIntBE(offset, byteLength, noAssert) {
		offset = offset >>> 0;
		byteLength = byteLength >>> 0;
		if (!noAssert) checkOffset(offset, byteLength, this.length);
		var val = this[offset + --byteLength];
		var mul = 1;
		while (byteLength > 0 && (mul *= 256)) val += this[offset + --byteLength] * mul;
		return val;
	};
	Buffer.prototype.readUint8 = Buffer.prototype.readUInt8 = function readUInt8(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 1, this.length);
		return this[offset];
	};
	Buffer.prototype.readUint16LE = Buffer.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 2, this.length);
		return this[offset] | this[offset + 1] << 8;
	};
	Buffer.prototype.readUint16BE = Buffer.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 2, this.length);
		return this[offset] << 8 | this[offset + 1];
	};
	Buffer.prototype.readUint32LE = Buffer.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 4, this.length);
		return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 16777216;
	};
	Buffer.prototype.readUint32BE = Buffer.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 4, this.length);
		return this[offset] * 16777216 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
	};
	Buffer.prototype.readIntLE = function readIntLE(offset, byteLength, noAssert) {
		offset = offset >>> 0;
		byteLength = byteLength >>> 0;
		if (!noAssert) checkOffset(offset, byteLength, this.length);
		var val = this[offset];
		var mul = 1;
		var i = 0;
		while (++i < byteLength && (mul *= 256)) val += this[offset + i] * mul;
		mul *= 128;
		if (val >= mul) val -= Math.pow(2, 8 * byteLength);
		return val;
	};
	Buffer.prototype.readIntBE = function readIntBE(offset, byteLength, noAssert) {
		offset = offset >>> 0;
		byteLength = byteLength >>> 0;
		if (!noAssert) checkOffset(offset, byteLength, this.length);
		var i = byteLength;
		var mul = 1;
		var val = this[offset + --i];
		while (i > 0 && (mul *= 256)) val += this[offset + --i] * mul;
		mul *= 128;
		if (val >= mul) val -= Math.pow(2, 8 * byteLength);
		return val;
	};
	Buffer.prototype.readInt8 = function readInt8(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 1, this.length);
		if (!(this[offset] & 128)) return this[offset];
		return (255 - this[offset] + 1) * -1;
	};
	Buffer.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 2, this.length);
		var val = this[offset] | this[offset + 1] << 8;
		return val & 32768 ? val | 4294901760 : val;
	};
	Buffer.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 2, this.length);
		var val = this[offset + 1] | this[offset] << 8;
		return val & 32768 ? val | 4294901760 : val;
	};
	Buffer.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 4, this.length);
		return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
	};
	Buffer.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 4, this.length);
		return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
	};
	Buffer.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 4, this.length);
		return ieee754.read(this, offset, true, 23, 4);
	};
	Buffer.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 4, this.length);
		return ieee754.read(this, offset, false, 23, 4);
	};
	Buffer.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 8, this.length);
		return ieee754.read(this, offset, true, 52, 8);
	};
	Buffer.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
		offset = offset >>> 0;
		if (!noAssert) checkOffset(offset, 8, this.length);
		return ieee754.read(this, offset, false, 52, 8);
	};
	function checkInt(buf, value, offset, ext, max, min) {
		if (!Buffer.isBuffer(buf)) throw new TypeError("\"buffer\" argument must be a Buffer instance");
		if (value > max || value < min) throw new RangeError("\"value\" argument is out of bounds");
		if (offset + ext > buf.length) throw new RangeError("Index out of range");
	}
	Buffer.prototype.writeUintLE = Buffer.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength, noAssert) {
		value = +value;
		offset = offset >>> 0;
		byteLength = byteLength >>> 0;
		if (!noAssert) {
			var maxBytes = Math.pow(2, 8 * byteLength) - 1;
			checkInt(this, value, offset, byteLength, maxBytes, 0);
		}
		var mul = 1;
		var i = 0;
		this[offset] = value & 255;
		while (++i < byteLength && (mul *= 256)) this[offset + i] = value / mul & 255;
		return offset + byteLength;
	};
	Buffer.prototype.writeUintBE = Buffer.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength, noAssert) {
		value = +value;
		offset = offset >>> 0;
		byteLength = byteLength >>> 0;
		if (!noAssert) {
			var maxBytes = Math.pow(2, 8 * byteLength) - 1;
			checkInt(this, value, offset, byteLength, maxBytes, 0);
		}
		var i = byteLength - 1;
		var mul = 1;
		this[offset + i] = value & 255;
		while (--i >= 0 && (mul *= 256)) this[offset + i] = value / mul & 255;
		return offset + byteLength;
	};
	Buffer.prototype.writeUint8 = Buffer.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkInt(this, value, offset, 1, 255, 0);
		this[offset] = value & 255;
		return offset + 1;
	};
	Buffer.prototype.writeUint16LE = Buffer.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
		this[offset] = value & 255;
		this[offset + 1] = value >>> 8;
		return offset + 2;
	};
	Buffer.prototype.writeUint16BE = Buffer.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
		this[offset] = value >>> 8;
		this[offset + 1] = value & 255;
		return offset + 2;
	};
	Buffer.prototype.writeUint32LE = Buffer.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
		this[offset + 3] = value >>> 24;
		this[offset + 2] = value >>> 16;
		this[offset + 1] = value >>> 8;
		this[offset] = value & 255;
		return offset + 4;
	};
	Buffer.prototype.writeUint32BE = Buffer.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
		this[offset] = value >>> 24;
		this[offset + 1] = value >>> 16;
		this[offset + 2] = value >>> 8;
		this[offset + 3] = value & 255;
		return offset + 4;
	};
	Buffer.prototype.writeIntLE = function writeIntLE(value, offset, byteLength, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) {
			var limit = Math.pow(2, 8 * byteLength - 1);
			checkInt(this, value, offset, byteLength, limit - 1, -limit);
		}
		var i = 0;
		var mul = 1;
		var sub = 0;
		this[offset] = value & 255;
		while (++i < byteLength && (mul *= 256)) {
			if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) sub = 1;
			this[offset + i] = (value / mul >> 0) - sub & 255;
		}
		return offset + byteLength;
	};
	Buffer.prototype.writeIntBE = function writeIntBE(value, offset, byteLength, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) {
			var limit = Math.pow(2, 8 * byteLength - 1);
			checkInt(this, value, offset, byteLength, limit - 1, -limit);
		}
		var i = byteLength - 1;
		var mul = 1;
		var sub = 0;
		this[offset + i] = value & 255;
		while (--i >= 0 && (mul *= 256)) {
			if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) sub = 1;
			this[offset + i] = (value / mul >> 0) - sub & 255;
		}
		return offset + byteLength;
	};
	Buffer.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkInt(this, value, offset, 1, 127, -128);
		if (value < 0) value = 255 + value + 1;
		this[offset] = value & 255;
		return offset + 1;
	};
	Buffer.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
		this[offset] = value & 255;
		this[offset + 1] = value >>> 8;
		return offset + 2;
	};
	Buffer.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
		this[offset] = value >>> 8;
		this[offset + 1] = value & 255;
		return offset + 2;
	};
	Buffer.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
		this[offset] = value & 255;
		this[offset + 1] = value >>> 8;
		this[offset + 2] = value >>> 16;
		this[offset + 3] = value >>> 24;
		return offset + 4;
	};
	Buffer.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
		if (value < 0) value = 4294967295 + value + 1;
		this[offset] = value >>> 24;
		this[offset + 1] = value >>> 16;
		this[offset + 2] = value >>> 8;
		this[offset + 3] = value & 255;
		return offset + 4;
	};
	function checkIEEE754(buf, value, offset, ext, max, min) {
		if (offset + ext > buf.length) throw new RangeError("Index out of range");
		if (offset < 0) throw new RangeError("Index out of range");
	}
	function writeFloat(buf, value, offset, littleEndian, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkIEEE754(buf, value, offset, 4, 34028234663852886e22, -34028234663852886e22);
		ieee754.write(buf, value, offset, littleEndian, 23, 4);
		return offset + 4;
	}
	Buffer.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
		return writeFloat(this, value, offset, true, noAssert);
	};
	Buffer.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
		return writeFloat(this, value, offset, false, noAssert);
	};
	function writeDouble(buf, value, offset, littleEndian, noAssert) {
		value = +value;
		offset = offset >>> 0;
		if (!noAssert) checkIEEE754(buf, value, offset, 8, 17976931348623157e292, -17976931348623157e292);
		ieee754.write(buf, value, offset, littleEndian, 52, 8);
		return offset + 8;
	}
	Buffer.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
		return writeDouble(this, value, offset, true, noAssert);
	};
	Buffer.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
		return writeDouble(this, value, offset, false, noAssert);
	};
	Buffer.prototype.copy = function copy(target, targetStart, start, end) {
		if (!Buffer.isBuffer(target)) throw new TypeError("argument should be a Buffer");
		if (!start) start = 0;
		if (!end && end !== 0) end = this.length;
		if (targetStart >= target.length) targetStart = target.length;
		if (!targetStart) targetStart = 0;
		if (end > 0 && end < start) end = start;
		if (end === start) return 0;
		if (target.length === 0 || this.length === 0) return 0;
		if (targetStart < 0) throw new RangeError("targetStart out of bounds");
		if (start < 0 || start >= this.length) throw new RangeError("Index out of range");
		if (end < 0) throw new RangeError("sourceEnd out of bounds");
		if (end > this.length) end = this.length;
		if (target.length - targetStart < end - start) end = target.length - targetStart + start;
		var len = end - start;
		if (this === target && typeof Uint8Array.prototype.copyWithin === "function") this.copyWithin(targetStart, start, end);
		else Uint8Array.prototype.set.call(target, this.subarray(start, end), targetStart);
		return len;
	};
	Buffer.prototype.fill = function fill(val, start, end, encoding) {
		if (typeof val === "string") {
			if (typeof start === "string") {
				encoding = start;
				start = 0;
				end = this.length;
			} else if (typeof end === "string") {
				encoding = end;
				end = this.length;
			}
			if (encoding !== void 0 && typeof encoding !== "string") throw new TypeError("encoding must be a string");
			if (typeof encoding === "string" && !Buffer.isEncoding(encoding)) throw new TypeError("Unknown encoding: " + encoding);
			if (val.length === 1) {
				var code = val.charCodeAt(0);
				if (encoding === "utf8" && code < 128 || encoding === "latin1") val = code;
			}
		} else if (typeof val === "number") val = val & 255;
		else if (typeof val === "boolean") val = Number(val);
		if (start < 0 || this.length < start || this.length < end) throw new RangeError("Out of range index");
		if (end <= start) return this;
		start = start >>> 0;
		end = end === void 0 ? this.length : end >>> 0;
		if (!val) val = 0;
		var i;
		if (typeof val === "number") for (i = start; i < end; ++i) this[i] = val;
		else {
			var bytes = Buffer.isBuffer(val) ? val : Buffer.from(val, encoding);
			var len = bytes.length;
			if (len === 0) throw new TypeError("The value \"" + val + "\" is invalid for argument \"value\"");
			for (i = 0; i < end - start; ++i) this[i + start] = bytes[i % len];
		}
		return this;
	};
	var INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;
	function base64clean(str) {
		str = str.split("=")[0];
		str = str.trim().replace(INVALID_BASE64_RE, "");
		if (str.length < 2) return "";
		while (str.length % 4 !== 0) str = str + "=";
		return str;
	}
	function utf8ToBytes(string, units) {
		units = units || Infinity;
		var codePoint;
		var length = string.length;
		var leadSurrogate = null;
		var bytes = [];
		for (var i = 0; i < length; ++i) {
			codePoint = string.charCodeAt(i);
			if (codePoint > 55295 && codePoint < 57344) {
				if (!leadSurrogate) {
					if (codePoint > 56319) {
						if ((units -= 3) > -1) bytes.push(239, 191, 189);
						continue;
					} else if (i + 1 === length) {
						if ((units -= 3) > -1) bytes.push(239, 191, 189);
						continue;
					}
					leadSurrogate = codePoint;
					continue;
				}
				if (codePoint < 56320) {
					if ((units -= 3) > -1) bytes.push(239, 191, 189);
					leadSurrogate = codePoint;
					continue;
				}
				codePoint = (leadSurrogate - 55296 << 10 | codePoint - 56320) + 65536;
			} else if (leadSurrogate) {
				if ((units -= 3) > -1) bytes.push(239, 191, 189);
			}
			leadSurrogate = null;
			if (codePoint < 128) {
				if ((units -= 1) < 0) break;
				bytes.push(codePoint);
			} else if (codePoint < 2048) {
				if ((units -= 2) < 0) break;
				bytes.push(codePoint >> 6 | 192, codePoint & 63 | 128);
			} else if (codePoint < 65536) {
				if ((units -= 3) < 0) break;
				bytes.push(codePoint >> 12 | 224, codePoint >> 6 & 63 | 128, codePoint & 63 | 128);
			} else if (codePoint < 1114112) {
				if ((units -= 4) < 0) break;
				bytes.push(codePoint >> 18 | 240, codePoint >> 12 & 63 | 128, codePoint >> 6 & 63 | 128, codePoint & 63 | 128);
			} else throw new Error("Invalid code point");
		}
		return bytes;
	}
	function asciiToBytes(str) {
		var byteArray = [];
		for (var i = 0; i < str.length; ++i) byteArray.push(str.charCodeAt(i) & 255);
		return byteArray;
	}
	function utf16leToBytes(str, units) {
		var c, hi, lo;
		var byteArray = [];
		for (var i = 0; i < str.length; ++i) {
			if ((units -= 2) < 0) break;
			c = str.charCodeAt(i);
			hi = c >> 8;
			lo = c % 256;
			byteArray.push(lo);
			byteArray.push(hi);
		}
		return byteArray;
	}
	function base64ToBytes(str) {
		return base64.toByteArray(base64clean(str));
	}
	function blitBuffer(src, dst, offset, length) {
		for (var i = 0; i < length; ++i) {
			if (i + offset >= dst.length || i >= src.length) break;
			dst[i + offset] = src[i];
		}
		return i;
	}
	function isInstance(obj, type) {
		return obj instanceof type || obj != null && obj.constructor != null && obj.constructor.name != null && obj.constructor.name === type.name;
	}
	function numberIsNaN(obj) {
		return obj !== obj;
	}
	var hexSliceLookupTable = (function() {
		var alphabet = "0123456789abcdef";
		var table = new Array(256);
		for (var i = 0; i < 16; ++i) {
			var i16 = i * 16;
			for (var j = 0; j < 16; ++j) table[i16 + j] = alphabet[i] + alphabet[j];
		}
		return table;
	})();
}));
var require_shams$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./shams')} */
	module.exports = function hasSymbols() {
		if (typeof Symbol !== "function" || typeof Object.getOwnPropertySymbols !== "function") return false;
		if (typeof Symbol.iterator === "symbol") return true;
		/** @type {{ [k in symbol]?: unknown }} */
		var obj = {};
		var sym = Symbol("test");
		var symObj = Object(sym);
		if (typeof sym === "string") return false;
		if (Object.prototype.toString.call(sym) !== "[object Symbol]") return false;
		if (Object.prototype.toString.call(symObj) !== "[object Symbol]") return false;
		var symVal = 42;
		obj[sym] = symVal;
		for (var _ in obj) return false;
		if (typeof Object.keys === "function" && Object.keys(obj).length !== 0) return false;
		if (typeof Object.getOwnPropertyNames === "function" && Object.getOwnPropertyNames(obj).length !== 0) return false;
		var syms = Object.getOwnPropertySymbols(obj);
		if (syms.length !== 1 || syms[0] !== sym) return false;
		if (!Object.prototype.propertyIsEnumerable.call(obj, sym)) return false;
		if (typeof Object.getOwnPropertyDescriptor === "function") {
			var descriptor = Object.getOwnPropertyDescriptor(obj, sym);
			if (descriptor.value !== symVal || descriptor.enumerable !== true) return false;
		}
		return true;
	};
}));
var require_shams = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var hasSymbols = require_shams$1();
	/** @type {import('.')} */
	module.exports = function hasToStringTagShams() {
		return hasSymbols() && !!Symbol.toStringTag;
	};
}));
var require_es_object_atoms = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('.')} */
	module.exports = Object;
}));
var require_es_errors = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('.')} */
	module.exports = Error;
}));
var require_eval = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./eval')} */
	module.exports = EvalError;
}));
var require_range = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./range')} */
	module.exports = RangeError;
}));
var require_ref = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./ref')} */
	module.exports = ReferenceError;
}));
var require_syntax = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./syntax')} */
	module.exports = SyntaxError;
}));
var require_type = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./type')} */
	module.exports = TypeError;
}));
var require_uri = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./uri')} */
	module.exports = URIError;
}));
var require_abs = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./abs')} */
	module.exports = Math.abs;
}));
var require_floor = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./floor')} */
	module.exports = Math.floor;
}));
var require_max = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./max')} */
	module.exports = Math.max;
}));
var require_min = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./min')} */
	module.exports = Math.min;
}));
var require_pow = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./pow')} */
	module.exports = Math.pow;
}));
var require_round = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./round')} */
	module.exports = Math.round;
}));
var require_isNaN = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./isNaN')} */
	module.exports = Number.isNaN || function isNaN(a) {
		return a !== a;
	};
}));
var require_sign = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var $isNaN = require_isNaN();
	/** @type {import('./sign')} */
	module.exports = function sign(number) {
		if ($isNaN(number) || number === 0) return number;
		return number < 0 ? -1 : 1;
	};
}));
var require_gOPD = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./gOPD')} */
	module.exports = Object.getOwnPropertyDescriptor;
}));
var require_gopd = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('.')} */
	var $gOPD = require_gOPD();
	if ($gOPD) try {
		$gOPD([], "length");
	} catch (e) {
		$gOPD = null;
	}
	module.exports = $gOPD;
}));
var require_es_define_property = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('.')} */
	var $defineProperty = Object.defineProperty || false;
	if ($defineProperty) try {
		$defineProperty({}, "a", { value: 1 });
	} catch (e) {
		$defineProperty = false;
	}
	module.exports = $defineProperty;
}));
var require_has_symbols = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var origSymbol = typeof Symbol !== "undefined" && Symbol;
	var hasSymbolSham = require_shams$1();
	/** @type {import('.')} */
	module.exports = function hasNativeSymbols() {
		if (typeof origSymbol !== "function") return false;
		if (typeof Symbol !== "function") return false;
		if (typeof origSymbol("foo") !== "symbol") return false;
		if (typeof Symbol("bar") !== "symbol") return false;
		return hasSymbolSham();
	};
}));
var require_Reflect_getPrototypeOf = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./Reflect.getPrototypeOf')} */
	module.exports = typeof Reflect !== "undefined" && Reflect.getPrototypeOf || null;
}));
var require_Object_getPrototypeOf = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./Object.getPrototypeOf')} */
	module.exports = require_es_object_atoms().getPrototypeOf || null;
}));
var require_implementation = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ERROR_MESSAGE = "Function.prototype.bind called on incompatible ";
	var toStr = Object.prototype.toString;
	var max = Math.max;
	var funcType = "[object Function]";
	var concatty = function concatty(a, b) {
		var arr = [];
		for (var i = 0; i < a.length; i += 1) arr[i] = a[i];
		for (var j = 0; j < b.length; j += 1) arr[j + a.length] = b[j];
		return arr;
	};
	var slicy = function slicy(arrLike, offset) {
		var arr = [];
		for (var i = offset || 0, j = 0; i < arrLike.length; i += 1, j += 1) arr[j] = arrLike[i];
		return arr;
	};
	var joiny = function(arr, joiner) {
		var str = "";
		for (var i = 0; i < arr.length; i += 1) {
			str += arr[i];
			if (i + 1 < arr.length) str += joiner;
		}
		return str;
	};
	module.exports = function bind(that) {
		var target = this;
		if (typeof target !== "function" || toStr.apply(target) !== funcType) throw new TypeError(ERROR_MESSAGE + target);
		var args = slicy(arguments, 1);
		var bound;
		var binder = function() {
			if (this instanceof bound) {
				var result = target.apply(this, concatty(args, arguments));
				if (Object(result) === result) return result;
				return this;
			}
			return target.apply(that, concatty(args, arguments));
		};
		var boundLength = max(0, target.length - args.length);
		var boundArgs = [];
		for (var i = 0; i < boundLength; i++) boundArgs[i] = "$" + i;
		bound = Function("binder", "return function (" + joiny(boundArgs, ",") + "){ return binder.apply(this,arguments); }")(binder);
		if (target.prototype) {
			var Empty = function Empty() {};
			Empty.prototype = target.prototype;
			bound.prototype = new Empty();
			Empty.prototype = null;
		}
		return bound;
	};
}));
var require_function_bind = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var implementation = require_implementation();
	module.exports = Function.prototype.bind || implementation;
}));
var require_functionCall = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./functionCall')} */
	module.exports = Function.prototype.call;
}));
var require_functionApply = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./functionApply')} */
	module.exports = Function.prototype.apply;
}));
var require_reflectApply = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('./reflectApply')} */
	module.exports = typeof Reflect !== "undefined" && Reflect && Reflect.apply;
}));
var require_actualApply = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var bind = require_function_bind();
	var $apply = require_functionApply();
	var $call = require_functionCall();
	/** @type {import('./actualApply')} */
	module.exports = require_reflectApply() || bind.call($call, $apply);
}));
var require_call_bind_apply_helpers = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var bind = require_function_bind();
	var $TypeError = require_type();
	var $call = require_functionCall();
	var $actualApply = require_actualApply();
	/** @type {(args: [Function, thisArg?: unknown, ...args: unknown[]]) => Function} TODO FIXME, find a way to use import('.') */
	module.exports = function callBindBasic(args) {
		if (args.length < 1 || typeof args[0] !== "function") throw new $TypeError("a function is required");
		return $actualApply(bind, $call, args);
	};
}));
var require_get = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var callBind = require_call_bind_apply_helpers();
	var gOPD = require_gopd();
	var hasProtoAccessor;
	try {
		hasProtoAccessor = [].__proto__ === Array.prototype;
	} catch (e) {
		if (!e || typeof e !== "object" || !("code" in e) || e.code !== "ERR_PROTO_ACCESS") throw e;
	}
	var desc = !!hasProtoAccessor && gOPD && gOPD(Object.prototype, "__proto__");
	var $Object = Object;
	var $getPrototypeOf = $Object.getPrototypeOf;
	/** @type {import('./get')} */
	module.exports = desc && typeof desc.get === "function" ? callBind([desc.get]) : typeof $getPrototypeOf === "function" ? function getDunder(value) {
		return $getPrototypeOf(value == null ? value : $Object(value));
	} : false;
}));
var require_get_proto = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var reflectGetProto = require_Reflect_getPrototypeOf();
	var originalGetProto = require_Object_getPrototypeOf();
	var getDunderProto = require_get();
	/** @type {import('.')} */
	module.exports = reflectGetProto ? function getProto(O) {
		return reflectGetProto(O);
	} : originalGetProto ? function getProto(O) {
		if (!O || typeof O !== "object" && typeof O !== "function") throw new TypeError("getProto: not an object");
		return originalGetProto(O);
	} : getDunderProto ? function getProto(O) {
		return getDunderProto(O);
	} : null;
}));
var require_hasown = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var call = Function.prototype.call;
	var $hasOwn = Object.prototype.hasOwnProperty;
	/** @type {import('.')} */
	module.exports = require_function_bind().call(call, $hasOwn);
}));
var require_get_intrinsic = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var undefined;
	var $Object = require_es_object_atoms();
	var $Error = require_es_errors();
	var $EvalError = require_eval();
	var $RangeError = require_range();
	var $ReferenceError = require_ref();
	var $SyntaxError = require_syntax();
	var $TypeError = require_type();
	var $URIError = require_uri();
	var abs = require_abs();
	var floor = require_floor();
	var max = require_max();
	var min = require_min();
	var pow = require_pow();
	var round = require_round();
	var sign = require_sign();
	var $Function = Function;
	var getEvalledConstructor = function(expressionSyntax) {
		try {
			return $Function("\"use strict\"; return (" + expressionSyntax + ").constructor;")();
		} catch (e) {}
	};
	var $gOPD = require_gopd();
	var $defineProperty = require_es_define_property();
	var throwTypeError = function() {
		throw new $TypeError();
	};
	var ThrowTypeError = $gOPD ? function() {
		try {
			arguments.callee;
			return throwTypeError;
		} catch (calleeThrows) {
			try {
				return $gOPD(arguments, "callee").get;
			} catch (gOPDthrows) {
				return throwTypeError;
			}
		}
	}() : throwTypeError;
	var hasSymbols = require_has_symbols()();
	var getProto = require_get_proto();
	var $ObjectGPO = require_Object_getPrototypeOf();
	var $ReflectGPO = require_Reflect_getPrototypeOf();
	var $apply = require_functionApply();
	var $call = require_functionCall();
	var needsEval = {};
	var TypedArray = typeof Uint8Array === "undefined" || !getProto ? undefined : getProto(Uint8Array);
	var INTRINSICS = {
		__proto__: null,
		"%AggregateError%": typeof AggregateError === "undefined" ? undefined : AggregateError,
		"%Array%": Array,
		"%ArrayBuffer%": typeof ArrayBuffer === "undefined" ? undefined : ArrayBuffer,
		"%ArrayIteratorPrototype%": hasSymbols && getProto ? getProto([][Symbol.iterator]()) : undefined,
		"%AsyncFromSyncIteratorPrototype%": undefined,
		"%AsyncFunction%": needsEval,
		"%AsyncGenerator%": needsEval,
		"%AsyncGeneratorFunction%": needsEval,
		"%AsyncIteratorPrototype%": needsEval,
		"%Atomics%": typeof Atomics === "undefined" ? undefined : Atomics,
		"%BigInt%": typeof BigInt === "undefined" ? undefined : BigInt,
		"%BigInt64Array%": typeof BigInt64Array === "undefined" ? undefined : BigInt64Array,
		"%BigUint64Array%": typeof BigUint64Array === "undefined" ? undefined : BigUint64Array,
		"%Boolean%": Boolean,
		"%DataView%": typeof DataView === "undefined" ? undefined : DataView,
		"%Date%": Date,
		"%decodeURI%": decodeURI,
		"%decodeURIComponent%": decodeURIComponent,
		"%encodeURI%": encodeURI,
		"%encodeURIComponent%": encodeURIComponent,
		"%Error%": $Error,
		"%eval%": eval,
		"%EvalError%": $EvalError,
		"%Float16Array%": typeof Float16Array === "undefined" ? undefined : Float16Array,
		"%Float32Array%": typeof Float32Array === "undefined" ? undefined : Float32Array,
		"%Float64Array%": typeof Float64Array === "undefined" ? undefined : Float64Array,
		"%FinalizationRegistry%": typeof FinalizationRegistry === "undefined" ? undefined : FinalizationRegistry,
		"%Function%": $Function,
		"%GeneratorFunction%": needsEval,
		"%Int8Array%": typeof Int8Array === "undefined" ? undefined : Int8Array,
		"%Int16Array%": typeof Int16Array === "undefined" ? undefined : Int16Array,
		"%Int32Array%": typeof Int32Array === "undefined" ? undefined : Int32Array,
		"%isFinite%": isFinite,
		"%isNaN%": isNaN,
		"%IteratorPrototype%": hasSymbols && getProto ? getProto(getProto([][Symbol.iterator]())) : undefined,
		"%JSON%": typeof JSON === "object" ? JSON : undefined,
		"%Map%": typeof Map === "undefined" ? undefined : Map,
		"%MapIteratorPrototype%": typeof Map === "undefined" || !hasSymbols || !getProto ? undefined : getProto((/* @__PURE__ */ new Map())[Symbol.iterator]()),
		"%Math%": Math,
		"%Number%": Number,
		"%Object%": $Object,
		"%Object.getOwnPropertyDescriptor%": $gOPD,
		"%parseFloat%": parseFloat,
		"%parseInt%": parseInt,
		"%Promise%": typeof Promise === "undefined" ? undefined : Promise,
		"%Proxy%": typeof Proxy === "undefined" ? undefined : Proxy,
		"%RangeError%": $RangeError,
		"%ReferenceError%": $ReferenceError,
		"%Reflect%": typeof Reflect === "undefined" ? undefined : Reflect,
		"%RegExp%": RegExp,
		"%Set%": typeof Set === "undefined" ? undefined : Set,
		"%SetIteratorPrototype%": typeof Set === "undefined" || !hasSymbols || !getProto ? undefined : getProto((/* @__PURE__ */ new Set())[Symbol.iterator]()),
		"%SharedArrayBuffer%": typeof SharedArrayBuffer === "undefined" ? undefined : SharedArrayBuffer,
		"%String%": String,
		"%StringIteratorPrototype%": hasSymbols && getProto ? getProto(""[Symbol.iterator]()) : undefined,
		"%Symbol%": hasSymbols ? Symbol : undefined,
		"%SyntaxError%": $SyntaxError,
		"%ThrowTypeError%": ThrowTypeError,
		"%TypedArray%": TypedArray,
		"%TypeError%": $TypeError,
		"%Uint8Array%": typeof Uint8Array === "undefined" ? undefined : Uint8Array,
		"%Uint8ClampedArray%": typeof Uint8ClampedArray === "undefined" ? undefined : Uint8ClampedArray,
		"%Uint16Array%": typeof Uint16Array === "undefined" ? undefined : Uint16Array,
		"%Uint32Array%": typeof Uint32Array === "undefined" ? undefined : Uint32Array,
		"%URIError%": $URIError,
		"%WeakMap%": typeof WeakMap === "undefined" ? undefined : WeakMap,
		"%WeakRef%": typeof WeakRef === "undefined" ? undefined : WeakRef,
		"%WeakSet%": typeof WeakSet === "undefined" ? undefined : WeakSet,
		"%Function.prototype.call%": $call,
		"%Function.prototype.apply%": $apply,
		"%Object.defineProperty%": $defineProperty,
		"%Object.getPrototypeOf%": $ObjectGPO,
		"%Math.abs%": abs,
		"%Math.floor%": floor,
		"%Math.max%": max,
		"%Math.min%": min,
		"%Math.pow%": pow,
		"%Math.round%": round,
		"%Math.sign%": sign,
		"%Reflect.getPrototypeOf%": $ReflectGPO
	};
	if (getProto) try {
		null.error;
	} catch (e) {
		INTRINSICS["%Error.prototype%"] = getProto(getProto(e));
	}
	var doEval = function doEval(name) {
		var value;
		if (name === "%AsyncFunction%") value = getEvalledConstructor("async function () {}");
		else if (name === "%GeneratorFunction%") value = getEvalledConstructor("function* () {}");
		else if (name === "%AsyncGeneratorFunction%") value = getEvalledConstructor("async function* () {}");
		else if (name === "%AsyncGenerator%") {
			var fn = doEval("%AsyncGeneratorFunction%");
			if (fn) value = fn.prototype;
		} else if (name === "%AsyncIteratorPrototype%") {
			var gen = doEval("%AsyncGenerator%");
			if (gen && getProto) value = getProto(gen.prototype);
		}
		INTRINSICS[name] = value;
		return value;
	};
	var LEGACY_ALIASES = {
		__proto__: null,
		"%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
		"%ArrayPrototype%": ["Array", "prototype"],
		"%ArrayProto_entries%": [
			"Array",
			"prototype",
			"entries"
		],
		"%ArrayProto_forEach%": [
			"Array",
			"prototype",
			"forEach"
		],
		"%ArrayProto_keys%": [
			"Array",
			"prototype",
			"keys"
		],
		"%ArrayProto_values%": [
			"Array",
			"prototype",
			"values"
		],
		"%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
		"%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
		"%AsyncGeneratorPrototype%": [
			"AsyncGeneratorFunction",
			"prototype",
			"prototype"
		],
		"%BooleanPrototype%": ["Boolean", "prototype"],
		"%DataViewPrototype%": ["DataView", "prototype"],
		"%DatePrototype%": ["Date", "prototype"],
		"%ErrorPrototype%": ["Error", "prototype"],
		"%EvalErrorPrototype%": ["EvalError", "prototype"],
		"%Float32ArrayPrototype%": ["Float32Array", "prototype"],
		"%Float64ArrayPrototype%": ["Float64Array", "prototype"],
		"%FunctionPrototype%": ["Function", "prototype"],
		"%Generator%": ["GeneratorFunction", "prototype"],
		"%GeneratorPrototype%": [
			"GeneratorFunction",
			"prototype",
			"prototype"
		],
		"%Int8ArrayPrototype%": ["Int8Array", "prototype"],
		"%Int16ArrayPrototype%": ["Int16Array", "prototype"],
		"%Int32ArrayPrototype%": ["Int32Array", "prototype"],
		"%JSONParse%": ["JSON", "parse"],
		"%JSONStringify%": ["JSON", "stringify"],
		"%MapPrototype%": ["Map", "prototype"],
		"%NumberPrototype%": ["Number", "prototype"],
		"%ObjectPrototype%": ["Object", "prototype"],
		"%ObjProto_toString%": [
			"Object",
			"prototype",
			"toString"
		],
		"%ObjProto_valueOf%": [
			"Object",
			"prototype",
			"valueOf"
		],
		"%PromisePrototype%": ["Promise", "prototype"],
		"%PromiseProto_then%": [
			"Promise",
			"prototype",
			"then"
		],
		"%Promise_all%": ["Promise", "all"],
		"%Promise_reject%": ["Promise", "reject"],
		"%Promise_resolve%": ["Promise", "resolve"],
		"%RangeErrorPrototype%": ["RangeError", "prototype"],
		"%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
		"%RegExpPrototype%": ["RegExp", "prototype"],
		"%SetPrototype%": ["Set", "prototype"],
		"%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
		"%StringPrototype%": ["String", "prototype"],
		"%SymbolPrototype%": ["Symbol", "prototype"],
		"%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
		"%TypedArrayPrototype%": ["TypedArray", "prototype"],
		"%TypeErrorPrototype%": ["TypeError", "prototype"],
		"%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
		"%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
		"%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
		"%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
		"%URIErrorPrototype%": ["URIError", "prototype"],
		"%WeakMapPrototype%": ["WeakMap", "prototype"],
		"%WeakSetPrototype%": ["WeakSet", "prototype"]
	};
	var bind = require_function_bind();
	var hasOwn = require_hasown();
	var $concat = bind.call($call, Array.prototype.concat);
	var $spliceApply = bind.call($apply, Array.prototype.splice);
	var $replace = bind.call($call, String.prototype.replace);
	var $strSlice = bind.call($call, String.prototype.slice);
	var $exec = bind.call($call, RegExp.prototype.exec);
	var rePropName = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g;
	var reEscapeChar = /\\(\\)?/g;
	var stringToPath = function stringToPath(string) {
		var first = $strSlice(string, 0, 1);
		var last = $strSlice(string, -1);
		if (first === "%" && last !== "%") throw new $SyntaxError("invalid intrinsic syntax, expected closing `%`");
		else if (last === "%" && first !== "%") throw new $SyntaxError("invalid intrinsic syntax, expected opening `%`");
		var result = [];
		$replace(string, rePropName, function(match, number, quote, subString) {
			result[result.length] = quote ? $replace(subString, reEscapeChar, "$1") : number || match;
		});
		return result;
	};
	var getBaseIntrinsic = function getBaseIntrinsic(name, allowMissing) {
		var intrinsicName = name;
		var alias;
		if (hasOwn(LEGACY_ALIASES, intrinsicName)) {
			alias = LEGACY_ALIASES[intrinsicName];
			intrinsicName = "%" + alias[0] + "%";
		}
		if (hasOwn(INTRINSICS, intrinsicName)) {
			var value = INTRINSICS[intrinsicName];
			if (value === needsEval) value = doEval(intrinsicName);
			if (typeof value === "undefined" && !allowMissing) throw new $TypeError("intrinsic " + name + " exists, but is not available. Please file an issue!");
			return {
				alias,
				name: intrinsicName,
				value
			};
		}
		throw new $SyntaxError("intrinsic " + name + " does not exist!");
	};
	module.exports = function GetIntrinsic(name, allowMissing) {
		if (typeof name !== "string" || name.length === 0) throw new $TypeError("intrinsic name must be a non-empty string");
		if (arguments.length > 1 && typeof allowMissing !== "boolean") throw new $TypeError("\"allowMissing\" argument must be a boolean");
		if ($exec(/^%?[^%]*%?$/, name) === null) throw new $SyntaxError("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
		var parts = stringToPath(name);
		var intrinsicBaseName = parts.length > 0 ? parts[0] : "";
		var intrinsic = getBaseIntrinsic("%" + intrinsicBaseName + "%", allowMissing);
		var intrinsicRealName = intrinsic.name;
		var value = intrinsic.value;
		var skipFurtherCaching = false;
		var alias = intrinsic.alias;
		if (alias) {
			intrinsicBaseName = alias[0];
			$spliceApply(parts, $concat([0, 1], alias));
		}
		for (var i = 1, isOwn = true; i < parts.length; i += 1) {
			var part = parts[i];
			var first = $strSlice(part, 0, 1);
			var last = $strSlice(part, -1);
			if ((first === "\"" || first === "'" || first === "`" || last === "\"" || last === "'" || last === "`") && first !== last) throw new $SyntaxError("property names with quotes must have matching quotes");
			if (part === "constructor" || !isOwn) skipFurtherCaching = true;
			intrinsicBaseName += "." + part;
			intrinsicRealName = "%" + intrinsicBaseName + "%";
			if (hasOwn(INTRINSICS, intrinsicRealName)) value = INTRINSICS[intrinsicRealName];
			else if (value != null) {
				if (!(part in value)) {
					if (!allowMissing) throw new $TypeError("base intrinsic for " + name + " exists, but the property is not available.");
					return;
				}
				if ($gOPD && i + 1 >= parts.length) {
					var desc = $gOPD(value, part);
					isOwn = !!desc;
					if (isOwn && "get" in desc && !("originalValue" in desc.get)) value = desc.get;
					else value = value[part];
				} else {
					isOwn = hasOwn(value, part);
					value = value[part];
				}
				if (isOwn && !skipFurtherCaching) INTRINSICS[intrinsicRealName] = value;
			}
		}
		return value;
	};
}));
var require_call_bound = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var GetIntrinsic = require_get_intrinsic();
	var callBindBasic = require_call_bind_apply_helpers();
	/** @type {(thisArg: string, searchString: string, position?: number) => number} */
	var $indexOf = callBindBasic([GetIntrinsic("%String.prototype.indexOf%")]);
	/** @type {import('.')} */
	module.exports = function callBoundIntrinsic(name, allowMissing) {
		var intrinsic = GetIntrinsic(name, !!allowMissing);
		if (typeof intrinsic === "function" && $indexOf(name, ".prototype.") > -1) return callBindBasic([intrinsic]);
		return intrinsic;
	};
}));
var require_is_arguments = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var hasToStringTag = require_shams()();
	var $toString = require_call_bound()("Object.prototype.toString");
	/** @type {import('.')} */
	var isStandardArguments = function isArguments(value) {
		if (hasToStringTag && value && typeof value === "object" && Symbol.toStringTag in value) return false;
		return $toString(value) === "[object Arguments]";
	};
	/** @type {import('.')} */
	var isLegacyArguments = function isArguments(value) {
		if (isStandardArguments(value)) return true;
		return value !== null && typeof value === "object" && "length" in value && typeof value.length === "number" && value.length >= 0 && $toString(value) !== "[object Array]" && "callee" in value && $toString(value.callee) === "[object Function]";
	};
	var supportsStandardArguments = function() {
		return isStandardArguments(arguments);
	}();
	isStandardArguments.isLegacyArguments = isLegacyArguments;
	/** @type {import('.')} */
	module.exports = supportsStandardArguments ? isStandardArguments : isLegacyArguments;
}));
var require_is_generator_function = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var toStr = Object.prototype.toString;
	var fnToStr = Function.prototype.toString;
	var isFnRegex = /^\s*(?:function)?\*/;
	var hasToStringTag = require_shams()();
	var getProto = Object.getPrototypeOf;
	var getGeneratorFunc = function() {
		if (!hasToStringTag) return false;
		try {
			return Function("return function*() {}")();
		} catch (e) {}
	};
	var GeneratorFunction;
	module.exports = function isGeneratorFunction(fn) {
		if (typeof fn !== "function") return false;
		if (isFnRegex.test(fnToStr.call(fn))) return true;
		if (!hasToStringTag) return toStr.call(fn) === "[object GeneratorFunction]";
		if (!getProto) return false;
		if (typeof GeneratorFunction === "undefined") {
			var generatorFunc = getGeneratorFunc();
			GeneratorFunction = generatorFunc ? getProto(generatorFunc) : false;
		}
		return getProto(fn) === GeneratorFunction;
	};
}));
var require_is_callable = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var fnToStr = Function.prototype.toString;
	var reflectApply = typeof Reflect === "object" && Reflect !== null && Reflect.apply;
	var badArrayLike;
	var isCallableMarker;
	if (typeof reflectApply === "function" && typeof Object.defineProperty === "function") try {
		badArrayLike = Object.defineProperty({}, "length", { get: function() {
			throw isCallableMarker;
		} });
		isCallableMarker = {};
		reflectApply(function() {
			throw 42;
		}, null, badArrayLike);
	} catch (_) {
		if (_ !== isCallableMarker) reflectApply = null;
	}
	else reflectApply = null;
	var constructorRegex = /^\s*class\b/;
	var isES6ClassFn = function isES6ClassFunction(value) {
		try {
			var fnStr = fnToStr.call(value);
			return constructorRegex.test(fnStr);
		} catch (e) {
			return false;
		}
	};
	var tryFunctionObject = function tryFunctionToStr(value) {
		try {
			if (isES6ClassFn(value)) return false;
			fnToStr.call(value);
			return true;
		} catch (e) {
			return false;
		}
	};
	var toStr = Object.prototype.toString;
	var objectClass = "[object Object]";
	var fnClass = "[object Function]";
	var genClass = "[object GeneratorFunction]";
	var ddaClass = "[object HTMLAllCollection]";
	var ddaClass2 = "[object HTML document.all class]";
	var ddaClass3 = "[object HTMLCollection]";
	var hasToStringTag = typeof Symbol === "function" && !!Symbol.toStringTag;
	var isIE68 = !(0 in [,]);
	var isDDA = function isDocumentDotAll() {
		return false;
	};
	if (typeof document === "object") {
		var all = document.all;
		if (toStr.call(all) === toStr.call(document.all)) isDDA = function isDocumentDotAll(value) {
			if ((isIE68 || !value) && (typeof value === "undefined" || typeof value === "object")) try {
				var str = toStr.call(value);
				return (str === ddaClass || str === ddaClass2 || str === ddaClass3 || str === objectClass) && value("") == null;
			} catch (e) {}
			return false;
		};
	}
	module.exports = reflectApply ? function isCallable(value) {
		if (isDDA(value)) return true;
		if (!value) return false;
		if (typeof value !== "function" && typeof value !== "object") return false;
		try {
			reflectApply(value, null, badArrayLike);
		} catch (e) {
			if (e !== isCallableMarker) return false;
		}
		return !isES6ClassFn(value) && tryFunctionObject(value);
	} : function isCallable(value) {
		if (isDDA(value)) return true;
		if (!value) return false;
		if (typeof value !== "function" && typeof value !== "object") return false;
		if (hasToStringTag) return tryFunctionObject(value);
		if (isES6ClassFn(value)) return false;
		var strClass = toStr.call(value);
		if (strClass !== fnClass && strClass !== genClass && !/^\[object HTML/.test(strClass)) return false;
		return tryFunctionObject(value);
	};
}));
var require_for_each = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var isCallable = require_is_callable();
	var toStr = Object.prototype.toString;
	var hasOwnProperty = Object.prototype.hasOwnProperty;
	/** @type {<This, A extends readonly unknown[]>(arr: A, iterator: (this: This | void, value: A[number], index: number, arr: A) => void, receiver: This | undefined) => void} */
	var forEachArray = function forEachArray(array, iterator, receiver) {
		for (var i = 0, len = array.length; i < len; i++) if (hasOwnProperty.call(array, i)) if (receiver == null) iterator(array[i], i, array);
		else iterator.call(receiver, array[i], i, array);
	};
	/** @type {<This, S extends string>(string: S, iterator: (this: This | void, value: S[number], index: number, string: S) => void, receiver: This | undefined) => void} */
	var forEachString = function forEachString(string, iterator, receiver) {
		for (var i = 0, len = string.length; i < len; i++) if (receiver == null) iterator(string.charAt(i), i, string);
		else iterator.call(receiver, string.charAt(i), i, string);
	};
	/** @type {<This, O>(obj: O, iterator: (this: This | void, value: O[keyof O], index: keyof O, obj: O) => void, receiver: This | undefined) => void} */
	var forEachObject = function forEachObject(object, iterator, receiver) {
		for (var k in object) if (hasOwnProperty.call(object, k)) if (receiver == null) iterator(object[k], k, object);
		else iterator.call(receiver, object[k], k, object);
	};
	/** @type {(x: unknown) => x is readonly unknown[]} */
	function isArray(x) {
		return toStr.call(x) === "[object Array]";
	}
	/** @type {import('.')._internal} */
	module.exports = function forEach(list, iterator, thisArg) {
		if (!isCallable(iterator)) throw new TypeError("iterator must be a function");
		var receiver;
		if (arguments.length >= 3) receiver = thisArg;
		if (isArray(list)) forEachArray(list, iterator, receiver);
		else if (typeof list === "string") forEachString(list, iterator, receiver);
		else forEachObject(list, iterator, receiver);
	};
}));
var require_possible_typed_array_names = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {import('.')} */
	module.exports = [
		"Float32Array",
		"Float64Array",
		"Int8Array",
		"Int16Array",
		"Int32Array",
		"Uint8Array",
		"Uint8ClampedArray",
		"Uint16Array",
		"Uint32Array",
		"BigInt64Array",
		"BigUint64Array"
	];
}));
var require_available_typed_arrays = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	init_dist$1();
	var possibleNames = require_possible_typed_array_names();
	var g = typeof globalThis === "undefined" ? global : globalThis;
	/** @type {import('.')} */
	module.exports = function availableTypedArrays() {
		var out = [];
		for (var i = 0; i < possibleNames.length; i++) if (typeof g[possibleNames[i]] === "function") out[out.length] = possibleNames[i];
		return out;
	};
}));
var require_define_data_property = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var $defineProperty = require_es_define_property();
	var $SyntaxError = require_syntax();
	var $TypeError = require_type();
	var gopd = require_gopd();
	/** @type {import('.')} */
	module.exports = function defineDataProperty(obj, property, value) {
		if (!obj || typeof obj !== "object" && typeof obj !== "function") throw new $TypeError("`obj` must be an object or a function`");
		if (typeof property !== "string" && typeof property !== "symbol") throw new $TypeError("`property` must be a string or a symbol`");
		if (arguments.length > 3 && typeof arguments[3] !== "boolean" && arguments[3] !== null) throw new $TypeError("`nonEnumerable`, if provided, must be a boolean or null");
		if (arguments.length > 4 && typeof arguments[4] !== "boolean" && arguments[4] !== null) throw new $TypeError("`nonWritable`, if provided, must be a boolean or null");
		if (arguments.length > 5 && typeof arguments[5] !== "boolean" && arguments[5] !== null) throw new $TypeError("`nonConfigurable`, if provided, must be a boolean or null");
		if (arguments.length > 6 && typeof arguments[6] !== "boolean") throw new $TypeError("`loose`, if provided, must be a boolean");
		var nonEnumerable = arguments.length > 3 ? arguments[3] : null;
		var nonWritable = arguments.length > 4 ? arguments[4] : null;
		var nonConfigurable = arguments.length > 5 ? arguments[5] : null;
		var loose = arguments.length > 6 ? arguments[6] : false;
		var desc = !!gopd && gopd(obj, property);
		if ($defineProperty) $defineProperty(obj, property, {
			configurable: nonConfigurable === null && desc ? desc.configurable : !nonConfigurable,
			enumerable: nonEnumerable === null && desc ? desc.enumerable : !nonEnumerable,
			value,
			writable: nonWritable === null && desc ? desc.writable : !nonWritable
		});
		else if (loose || !nonEnumerable && !nonWritable && !nonConfigurable) obj[property] = value;
		else throw new $SyntaxError("This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.");
	};
}));
var require_has_property_descriptors = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var $defineProperty = require_es_define_property();
	var hasPropertyDescriptors = function hasPropertyDescriptors() {
		return !!$defineProperty;
	};
	hasPropertyDescriptors.hasArrayLengthDefineBug = function hasArrayLengthDefineBug() {
		if (!$defineProperty) return null;
		try {
			return $defineProperty([], "length", { value: 1 }).length !== 1;
		} catch (e) {
			return true;
		}
	};
	module.exports = hasPropertyDescriptors;
}));
var require_set_function_length = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var GetIntrinsic = require_get_intrinsic();
	var define = require_define_data_property();
	var hasDescriptors = require_has_property_descriptors()();
	var gOPD = require_gopd();
	var $TypeError = require_type();
	var $floor = GetIntrinsic("%Math.floor%");
	/** @type {import('.')} */
	module.exports = function setFunctionLength(fn, length) {
		if (typeof fn !== "function") throw new $TypeError("`fn` is not a function");
		if (typeof length !== "number" || length < 0 || length > 4294967295 || $floor(length) !== length) throw new $TypeError("`length` must be a positive 32-bit integer");
		var loose = arguments.length > 2 && !!arguments[2];
		var functionLengthIsConfigurable = true;
		var functionLengthIsWritable = true;
		if ("length" in fn && gOPD) {
			var desc = gOPD(fn, "length");
			if (desc && !desc.configurable) functionLengthIsConfigurable = false;
			if (desc && !desc.writable) functionLengthIsWritable = false;
		}
		if (functionLengthIsConfigurable || functionLengthIsWritable || !loose) if (hasDescriptors) define(fn, "length", length, true, true);
		else define(fn, "length", length);
		return fn;
	};
}));
var require_applyBind = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var bind = require_function_bind();
	var $apply = require_functionApply();
	var actualApply = require_actualApply();
	/** @type {import('./applyBind')} */
	module.exports = function applyBind() {
		return actualApply(bind, $apply, arguments);
	};
}));
var require_call_bind = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var setFunctionLength = require_set_function_length();
	var $defineProperty = require_es_define_property();
	var callBindBasic = require_call_bind_apply_helpers();
	var applyBind = require_applyBind();
	module.exports = function callBind(originalFunction) {
		var func = callBindBasic(arguments);
		var adjustedLength = originalFunction.length - (arguments.length - 1);
		return setFunctionLength(func, 1 + (adjustedLength > 0 ? adjustedLength : 0), true);
	};
	if ($defineProperty) $defineProperty(module.exports, "apply", { value: applyBind });
	else module.exports.apply = applyBind;
}));
var require_which_typed_array = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	init_dist$1();
	var forEach = require_for_each();
	var availableTypedArrays = require_available_typed_arrays();
	var callBind = require_call_bind();
	var callBound = require_call_bound();
	var gOPD = require_gopd();
	var getProto = require_get_proto();
	var $toString = callBound("Object.prototype.toString");
	var hasToStringTag = require_shams()();
	var g = typeof globalThis === "undefined" ? global : globalThis;
	var typedArrays = availableTypedArrays();
	var $slice = callBound("String.prototype.slice");
	/** @type {<T = unknown>(array: readonly T[], value: unknown) => number} */
	var $indexOf = callBound("Array.prototype.indexOf", true) || function indexOf(array, value) {
		for (var i = 0; i < array.length; i += 1) if (array[i] === value) return i;
		return -1;
	};
	/** @typedef {import('./types').Getter} Getter */
	/** @type {import('./types').Cache} */
	var cache = { __proto__: null };
	if (hasToStringTag && gOPD && getProto) forEach(typedArrays, function(typedArray) {
		var arr = new g[typedArray]();
		if (Symbol.toStringTag in arr && getProto) {
			var proto = getProto(arr);
			var descriptor = gOPD(proto, Symbol.toStringTag);
			if (!descriptor && proto) descriptor = gOPD(getProto(proto), Symbol.toStringTag);
			cache["$" + typedArray] = callBind(descriptor.get);
		}
	});
	else forEach(typedArrays, function(typedArray) {
		var arr = new g[typedArray]();
		var fn = arr.slice || arr.set;
		if (fn) cache["$" + typedArray] = callBind(fn);
	});
	/** @type {(value: object) => false | import('.').TypedArrayName} */
	var tryTypedArrays = function tryAllTypedArrays(value) {
		/** @type {ReturnType<typeof tryAllTypedArrays>} */ var found = false;
		forEach(
			cache,
			/** @type {(getter: Getter, name: `\$${import('.').TypedArrayName}`) => void} */
			function(getter, typedArray) {
				if (!found) try {
					if ("$" + getter(value) === typedArray) found = $slice(typedArray, 1);
				} catch (e) {}
			}
		);
		return found;
	};
	/** @type {(value: object) => false | import('.').TypedArrayName} */
	var trySlices = function tryAllSlices(value) {
		/** @type {ReturnType<typeof tryAllSlices>} */ var found = false;
		forEach(
			cache,
			/** @type {(getter: Getter, name: `\$${import('.').TypedArrayName}`) => void} */
			function(getter, name) {
				if (!found) try {
					getter(value);
					found = $slice(name, 1);
				} catch (e) {}
			}
		);
		return found;
	};
	/** @type {import('.')} */
	module.exports = function whichTypedArray(value) {
		if (!value || typeof value !== "object") return false;
		if (!hasToStringTag) {
			/** @type {string} */
			var tag = $slice($toString(value), 8, -1);
			if ($indexOf(typedArrays, tag) > -1) return tag;
			if (tag !== "Object") return false;
			return trySlices(value);
		}
		if (!gOPD) return null;
		return tryTypedArrays(value);
	};
}));
var require_is_typed_array = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var whichTypedArray = require_which_typed_array();
	/** @type {import('.')} */
	module.exports = function isTypedArray(value) {
		return !!whichTypedArray(value);
	};
}));
var require_types = /* @__PURE__ */ __commonJSMin(((exports) => {
	var isArgumentsObject = require_is_arguments();
	var isGeneratorFunction = require_is_generator_function();
	var whichTypedArray = require_which_typed_array();
	var isTypedArray = require_is_typed_array();
	function uncurryThis(f) {
		return f.call.bind(f);
	}
	var BigIntSupported = typeof BigInt !== "undefined";
	var SymbolSupported = typeof Symbol !== "undefined";
	var ObjectToString = uncurryThis(Object.prototype.toString);
	var numberValue = uncurryThis(Number.prototype.valueOf);
	var stringValue = uncurryThis(String.prototype.valueOf);
	var booleanValue = uncurryThis(Boolean.prototype.valueOf);
	if (BigIntSupported) var bigIntValue = uncurryThis(BigInt.prototype.valueOf);
	if (SymbolSupported) var symbolValue = uncurryThis(Symbol.prototype.valueOf);
	function checkBoxedPrimitive(value, prototypeValueOf) {
		if (typeof value !== "object") return false;
		try {
			prototypeValueOf(value);
			return true;
		} catch (e) {
			return false;
		}
	}
	exports.isArgumentsObject = isArgumentsObject;
	exports.isGeneratorFunction = isGeneratorFunction;
	exports.isTypedArray = isTypedArray;
	function isPromise(input) {
		return typeof Promise !== "undefined" && input instanceof Promise || input !== null && typeof input === "object" && typeof input.then === "function" && typeof input.catch === "function";
	}
	exports.isPromise = isPromise;
	function isArrayBufferView(value) {
		if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) return ArrayBuffer.isView(value);
		return isTypedArray(value) || isDataView(value);
	}
	exports.isArrayBufferView = isArrayBufferView;
	function isUint8Array(value) {
		return whichTypedArray(value) === "Uint8Array";
	}
	exports.isUint8Array = isUint8Array;
	function isUint8ClampedArray(value) {
		return whichTypedArray(value) === "Uint8ClampedArray";
	}
	exports.isUint8ClampedArray = isUint8ClampedArray;
	function isUint16Array(value) {
		return whichTypedArray(value) === "Uint16Array";
	}
	exports.isUint16Array = isUint16Array;
	function isUint32Array(value) {
		return whichTypedArray(value) === "Uint32Array";
	}
	exports.isUint32Array = isUint32Array;
	function isInt8Array(value) {
		return whichTypedArray(value) === "Int8Array";
	}
	exports.isInt8Array = isInt8Array;
	function isInt16Array(value) {
		return whichTypedArray(value) === "Int16Array";
	}
	exports.isInt16Array = isInt16Array;
	function isInt32Array(value) {
		return whichTypedArray(value) === "Int32Array";
	}
	exports.isInt32Array = isInt32Array;
	function isFloat32Array(value) {
		return whichTypedArray(value) === "Float32Array";
	}
	exports.isFloat32Array = isFloat32Array;
	function isFloat64Array(value) {
		return whichTypedArray(value) === "Float64Array";
	}
	exports.isFloat64Array = isFloat64Array;
	function isBigInt64Array(value) {
		return whichTypedArray(value) === "BigInt64Array";
	}
	exports.isBigInt64Array = isBigInt64Array;
	function isBigUint64Array(value) {
		return whichTypedArray(value) === "BigUint64Array";
	}
	exports.isBigUint64Array = isBigUint64Array;
	function isMapToString(value) {
		return ObjectToString(value) === "[object Map]";
	}
	isMapToString.working = typeof Map !== "undefined" && isMapToString(/* @__PURE__ */ new Map());
	function isMap(value) {
		if (typeof Map === "undefined") return false;
		return isMapToString.working ? isMapToString(value) : value instanceof Map;
	}
	exports.isMap = isMap;
	function isSetToString(value) {
		return ObjectToString(value) === "[object Set]";
	}
	isSetToString.working = typeof Set !== "undefined" && isSetToString(/* @__PURE__ */ new Set());
	function isSet(value) {
		if (typeof Set === "undefined") return false;
		return isSetToString.working ? isSetToString(value) : value instanceof Set;
	}
	exports.isSet = isSet;
	function isWeakMapToString(value) {
		return ObjectToString(value) === "[object WeakMap]";
	}
	isWeakMapToString.working = typeof WeakMap !== "undefined" && isWeakMapToString(/* @__PURE__ */ new WeakMap());
	function isWeakMap(value) {
		if (typeof WeakMap === "undefined") return false;
		return isWeakMapToString.working ? isWeakMapToString(value) : value instanceof WeakMap;
	}
	exports.isWeakMap = isWeakMap;
	function isWeakSetToString(value) {
		return ObjectToString(value) === "[object WeakSet]";
	}
	isWeakSetToString.working = typeof WeakSet !== "undefined" && isWeakSetToString(/* @__PURE__ */ new WeakSet());
	function isWeakSet(value) {
		return isWeakSetToString(value);
	}
	exports.isWeakSet = isWeakSet;
	function isArrayBufferToString(value) {
		return ObjectToString(value) === "[object ArrayBuffer]";
	}
	isArrayBufferToString.working = typeof ArrayBuffer !== "undefined" && isArrayBufferToString(/* @__PURE__ */ new ArrayBuffer());
	function isArrayBuffer(value) {
		if (typeof ArrayBuffer === "undefined") return false;
		return isArrayBufferToString.working ? isArrayBufferToString(value) : value instanceof ArrayBuffer;
	}
	exports.isArrayBuffer = isArrayBuffer;
	function isDataViewToString(value) {
		return ObjectToString(value) === "[object DataView]";
	}
	isDataViewToString.working = typeof ArrayBuffer !== "undefined" && typeof DataView !== "undefined" && isDataViewToString(new DataView(/* @__PURE__ */ new ArrayBuffer(1), 0, 1));
	function isDataView(value) {
		if (typeof DataView === "undefined") return false;
		return isDataViewToString.working ? isDataViewToString(value) : value instanceof DataView;
	}
	exports.isDataView = isDataView;
	var SharedArrayBufferCopy = typeof SharedArrayBuffer !== "undefined" ? SharedArrayBuffer : void 0;
	function isSharedArrayBufferToString(value) {
		return ObjectToString(value) === "[object SharedArrayBuffer]";
	}
	function isSharedArrayBuffer(value) {
		if (typeof SharedArrayBufferCopy === "undefined") return false;
		if (typeof isSharedArrayBufferToString.working === "undefined") isSharedArrayBufferToString.working = isSharedArrayBufferToString(new SharedArrayBufferCopy());
		return isSharedArrayBufferToString.working ? isSharedArrayBufferToString(value) : value instanceof SharedArrayBufferCopy;
	}
	exports.isSharedArrayBuffer = isSharedArrayBuffer;
	function isAsyncFunction(value) {
		return ObjectToString(value) === "[object AsyncFunction]";
	}
	exports.isAsyncFunction = isAsyncFunction;
	function isMapIterator(value) {
		return ObjectToString(value) === "[object Map Iterator]";
	}
	exports.isMapIterator = isMapIterator;
	function isSetIterator(value) {
		return ObjectToString(value) === "[object Set Iterator]";
	}
	exports.isSetIterator = isSetIterator;
	function isGeneratorObject(value) {
		return ObjectToString(value) === "[object Generator]";
	}
	exports.isGeneratorObject = isGeneratorObject;
	function isWebAssemblyCompiledModule(value) {
		return ObjectToString(value) === "[object WebAssembly.Module]";
	}
	exports.isWebAssemblyCompiledModule = isWebAssemblyCompiledModule;
	function isNumberObject(value) {
		return checkBoxedPrimitive(value, numberValue);
	}
	exports.isNumberObject = isNumberObject;
	function isStringObject(value) {
		return checkBoxedPrimitive(value, stringValue);
	}
	exports.isStringObject = isStringObject;
	function isBooleanObject(value) {
		return checkBoxedPrimitive(value, booleanValue);
	}
	exports.isBooleanObject = isBooleanObject;
	function isBigIntObject(value) {
		return BigIntSupported && checkBoxedPrimitive(value, bigIntValue);
	}
	exports.isBigIntObject = isBigIntObject;
	function isSymbolObject(value) {
		return SymbolSupported && checkBoxedPrimitive(value, symbolValue);
	}
	exports.isSymbolObject = isSymbolObject;
	function isBoxedPrimitive(value) {
		return isNumberObject(value) || isStringObject(value) || isBooleanObject(value) || isBigIntObject(value) || isSymbolObject(value);
	}
	exports.isBoxedPrimitive = isBoxedPrimitive;
	function isAnyArrayBuffer(value) {
		return typeof Uint8Array !== "undefined" && (isArrayBuffer(value) || isSharedArrayBuffer(value));
	}
	exports.isAnyArrayBuffer = isAnyArrayBuffer;
	[
		"isProxy",
		"isExternal",
		"isModuleNamespaceObject"
	].forEach(function(method) {
		Object.defineProperty(exports, method, {
			enumerable: false,
			value: function() {
				throw new Error(method + " is not supported in userland");
			}
		});
	});
}));
var require_isBufferBrowser = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = function isBuffer(arg) {
		return arg && typeof arg === "object" && typeof arg.copy === "function" && typeof arg.fill === "function" && typeof arg.readUInt8 === "function";
	};
}));
var require_util = /* @__PURE__ */ __commonJSMin(((exports) => {
	init_dist();
	var getOwnPropertyDescriptors = Object.getOwnPropertyDescriptors || function getOwnPropertyDescriptors(obj) {
		var keys = Object.keys(obj);
		var descriptors = {};
		for (var i = 0; i < keys.length; i++) descriptors[keys[i]] = Object.getOwnPropertyDescriptor(obj, keys[i]);
		return descriptors;
	};
	var formatRegExp = /%[sdj%]/g;
	exports.format = function(f) {
		if (!isString(f)) {
			var objects = [];
			for (var i = 0; i < arguments.length; i++) objects.push(inspect(arguments[i]));
			return objects.join(" ");
		}
		var i = 1;
		var args = arguments;
		var len = args.length;
		var str = String(f).replace(formatRegExp, function(x) {
			if (x === "%%") return "%";
			if (i >= len) return x;
			switch (x) {
				case "%s": return String(args[i++]);
				case "%d": return Number(args[i++]);
				case "%j": try {
					return JSON.stringify(args[i++]);
				} catch (_) {
					return "[Circular]";
				}
				default: return x;
			}
		});
		for (var x = args[i]; i < len; x = args[++i]) if (isNull(x) || !isObject(x)) str += " " + x;
		else str += " " + inspect(x);
		return str;
	};
	exports.deprecate = function(fn, msg) {
		if (typeof process$1 !== "undefined" && process$1.noDeprecation === true) return fn;
		if (typeof process$1 === "undefined") return function() {
			return exports.deprecate(fn, msg).apply(this, arguments);
		};
		var warned = false;
		function deprecated() {
			if (!warned) {
				if (process$1.throwDeprecation) throw new Error(msg);
				else if (process$1.traceDeprecation) console.trace(msg);
				else console.error(msg);
				warned = true;
			}
			return fn.apply(this, arguments);
		}
		return deprecated;
	};
	var debugs = {};
	var debugEnvRegex = /^$/;
	if (process$1.env.NODE_DEBUG) {
		var debugEnv = process$1.env.NODE_DEBUG;
		debugEnv = debugEnv.replace(/[|\\{}()[\]^$+?.]/g, "\\$&").replace(/\*/g, ".*").replace(/,/g, "$|^").toUpperCase();
		debugEnvRegex = new RegExp("^" + debugEnv + "$", "i");
	}
	exports.debuglog = function(set) {
		set = set.toUpperCase();
		if (!debugs[set]) if (debugEnvRegex.test(set)) {
			var pid = process$1.pid;
			debugs[set] = function() {
				var msg = exports.format.apply(exports, arguments);
				console.error("%s %d: %s", set, pid, msg);
			};
		} else debugs[set] = function() {};
		return debugs[set];
	};
	/**
	* Echos the value of a value. Trys to print the value out
	* in the best way possible given the different types.
	*
	* @param {Object} obj The object to print out.
	* @param {Object} opts Optional options object that alters the output.
	*/
	function inspect(obj, opts) {
		var ctx = {
			seen: [],
			stylize: stylizeNoColor
		};
		if (arguments.length >= 3) ctx.depth = arguments[2];
		if (arguments.length >= 4) ctx.colors = arguments[3];
		if (isBoolean(opts)) ctx.showHidden = opts;
		else if (opts) exports._extend(ctx, opts);
		if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
		if (isUndefined(ctx.depth)) ctx.depth = 2;
		if (isUndefined(ctx.colors)) ctx.colors = false;
		if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
		if (ctx.colors) ctx.stylize = stylizeWithColor;
		return formatValue(ctx, obj, ctx.depth);
	}
	exports.inspect = inspect;
	inspect.colors = {
		"bold": [1, 22],
		"italic": [3, 23],
		"underline": [4, 24],
		"inverse": [7, 27],
		"white": [37, 39],
		"grey": [90, 39],
		"black": [30, 39],
		"blue": [34, 39],
		"cyan": [36, 39],
		"green": [32, 39],
		"magenta": [35, 39],
		"red": [31, 39],
		"yellow": [33, 39]
	};
	inspect.styles = {
		"special": "cyan",
		"number": "yellow",
		"boolean": "yellow",
		"undefined": "grey",
		"null": "bold",
		"string": "green",
		"date": "magenta",
		"regexp": "red"
	};
	function stylizeWithColor(str, styleType) {
		var style = inspect.styles[styleType];
		if (style) return "\x1B[" + inspect.colors[style][0] + "m" + str + "\x1B[" + inspect.colors[style][1] + "m";
		else return str;
	}
	function stylizeNoColor(str, styleType) {
		return str;
	}
	function arrayToHash(array) {
		var hash = {};
		array.forEach(function(val, idx) {
			hash[val] = true;
		});
		return hash;
	}
	function formatValue(ctx, value, recurseTimes) {
		if (ctx.customInspect && value && isFunction(value.inspect) && value.inspect !== exports.inspect && !(value.constructor && value.constructor.prototype === value)) {
			var ret = value.inspect(recurseTimes, ctx);
			if (!isString(ret)) ret = formatValue(ctx, ret, recurseTimes);
			return ret;
		}
		var primitive = formatPrimitive(ctx, value);
		if (primitive) return primitive;
		var keys = Object.keys(value);
		var visibleKeys = arrayToHash(keys);
		if (ctx.showHidden) keys = Object.getOwnPropertyNames(value);
		if (isError(value) && (keys.indexOf("message") >= 0 || keys.indexOf("description") >= 0)) return formatError(value);
		if (keys.length === 0) {
			if (isFunction(value)) {
				var name = value.name ? ": " + value.name : "";
				return ctx.stylize("[Function" + name + "]", "special");
			}
			if (isRegExp(value)) return ctx.stylize(RegExp.prototype.toString.call(value), "regexp");
			if (isDate(value)) return ctx.stylize(Date.prototype.toString.call(value), "date");
			if (isError(value)) return formatError(value);
		}
		var base = "", array = false, braces = ["{", "}"];
		if (isArray(value)) {
			array = true;
			braces = ["[", "]"];
		}
		if (isFunction(value)) base = " [Function" + (value.name ? ": " + value.name : "") + "]";
		if (isRegExp(value)) base = " " + RegExp.prototype.toString.call(value);
		if (isDate(value)) base = " " + Date.prototype.toUTCString.call(value);
		if (isError(value)) base = " " + formatError(value);
		if (keys.length === 0 && (!array || value.length == 0)) return braces[0] + base + braces[1];
		if (recurseTimes < 0) if (isRegExp(value)) return ctx.stylize(RegExp.prototype.toString.call(value), "regexp");
		else return ctx.stylize("[Object]", "special");
		ctx.seen.push(value);
		var output;
		if (array) output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
		else output = keys.map(function(key) {
			return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
		});
		ctx.seen.pop();
		return reduceToSingleString(output, base, braces);
	}
	function formatPrimitive(ctx, value) {
		if (isUndefined(value)) return ctx.stylize("undefined", "undefined");
		if (isString(value)) {
			var simple = "'" + JSON.stringify(value).replace(/^"|"$/g, "").replace(/'/g, "\\'").replace(/\\"/g, "\"") + "'";
			return ctx.stylize(simple, "string");
		}
		if (isNumber(value)) return ctx.stylize("" + value, "number");
		if (isBoolean(value)) return ctx.stylize("" + value, "boolean");
		if (isNull(value)) return ctx.stylize("null", "null");
	}
	function formatError(value) {
		return "[" + Error.prototype.toString.call(value) + "]";
	}
	function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
		var output = [];
		for (var i = 0, l = value.length; i < l; ++i) if (hasOwnProperty(value, String(i))) output.push(formatProperty(ctx, value, recurseTimes, visibleKeys, String(i), true));
		else output.push("");
		keys.forEach(function(key) {
			if (!key.match(/^\d+$/)) output.push(formatProperty(ctx, value, recurseTimes, visibleKeys, key, true));
		});
		return output;
	}
	function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
		var name, str, desc = Object.getOwnPropertyDescriptor(value, key) || { value: value[key] };
		if (desc.get) if (desc.set) str = ctx.stylize("[Getter/Setter]", "special");
		else str = ctx.stylize("[Getter]", "special");
		else if (desc.set) str = ctx.stylize("[Setter]", "special");
		if (!hasOwnProperty(visibleKeys, key)) name = "[" + key + "]";
		if (!str) if (ctx.seen.indexOf(desc.value) < 0) {
			if (isNull(recurseTimes)) str = formatValue(ctx, desc.value, null);
			else str = formatValue(ctx, desc.value, recurseTimes - 1);
			if (str.indexOf("\n") > -1) if (array) str = str.split("\n").map(function(line) {
				return "  " + line;
			}).join("\n").slice(2);
			else str = "\n" + str.split("\n").map(function(line) {
				return "   " + line;
			}).join("\n");
		} else str = ctx.stylize("[Circular]", "special");
		if (isUndefined(name)) {
			if (array && key.match(/^\d+$/)) return str;
			name = JSON.stringify("" + key);
			if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
				name = name.slice(1, -1);
				name = ctx.stylize(name, "name");
			} else {
				name = name.replace(/'/g, "\\'").replace(/\\"/g, "\"").replace(/(^"|"$)/g, "'");
				name = ctx.stylize(name, "string");
			}
		}
		return name + ": " + str;
	}
	function reduceToSingleString(output, base, braces) {
		var numLinesEst = 0;
		if (output.reduce(function(prev, cur) {
			numLinesEst++;
			if (cur.indexOf("\n") >= 0) numLinesEst++;
			return prev + cur.replace(/\u001b\[\d\d?m/g, "").length + 1;
		}, 0) > 60) return braces[0] + (base === "" ? "" : base + "\n ") + " " + output.join(",\n  ") + " " + braces[1];
		return braces[0] + base + " " + output.join(", ") + " " + braces[1];
	}
	exports.types = require_types();
	function isArray(ar) {
		return Array.isArray(ar);
	}
	exports.isArray = isArray;
	function isBoolean(arg) {
		return typeof arg === "boolean";
	}
	exports.isBoolean = isBoolean;
	function isNull(arg) {
		return arg === null;
	}
	exports.isNull = isNull;
	function isNullOrUndefined(arg) {
		return arg == null;
	}
	exports.isNullOrUndefined = isNullOrUndefined;
	function isNumber(arg) {
		return typeof arg === "number";
	}
	exports.isNumber = isNumber;
	function isString(arg) {
		return typeof arg === "string";
	}
	exports.isString = isString;
	function isSymbol(arg) {
		return typeof arg === "symbol";
	}
	exports.isSymbol = isSymbol;
	function isUndefined(arg) {
		return arg === void 0;
	}
	exports.isUndefined = isUndefined;
	function isRegExp(re) {
		return isObject(re) && objectToString(re) === "[object RegExp]";
	}
	exports.isRegExp = isRegExp;
	exports.types.isRegExp = isRegExp;
	function isObject(arg) {
		return typeof arg === "object" && arg !== null;
	}
	exports.isObject = isObject;
	function isDate(d) {
		return isObject(d) && objectToString(d) === "[object Date]";
	}
	exports.isDate = isDate;
	exports.types.isDate = isDate;
	function isError(e) {
		return isObject(e) && (objectToString(e) === "[object Error]" || e instanceof Error);
	}
	exports.isError = isError;
	exports.types.isNativeError = isError;
	function isFunction(arg) {
		return typeof arg === "function";
	}
	exports.isFunction = isFunction;
	function isPrimitive(arg) {
		return arg === null || typeof arg === "boolean" || typeof arg === "number" || typeof arg === "string" || typeof arg === "symbol" || typeof arg === "undefined";
	}
	exports.isPrimitive = isPrimitive;
	exports.isBuffer = require_isBufferBrowser();
	function objectToString(o) {
		return Object.prototype.toString.call(o);
	}
	function pad(n) {
		return n < 10 ? "0" + n.toString(10) : n.toString(10);
	}
	var months = [
		"Jan",
		"Feb",
		"Mar",
		"Apr",
		"May",
		"Jun",
		"Jul",
		"Aug",
		"Sep",
		"Oct",
		"Nov",
		"Dec"
	];
	function timestamp() {
		var d = /* @__PURE__ */ new Date();
		var time = [
			pad(d.getHours()),
			pad(d.getMinutes()),
			pad(d.getSeconds())
		].join(":");
		return [
			d.getDate(),
			months[d.getMonth()],
			time
		].join(" ");
	}
	exports.log = function() {
		console.log("%s - %s", timestamp(), exports.format.apply(exports, arguments));
	};
	/**
	* Inherit the prototype methods from one constructor into another.
	*
	* The Function.prototype.inherits from lang.js rewritten as a standalone
	* function (not on Function.prototype). NOTE: If this file is to be loaded
	* during bootstrapping this function needs to be rewritten using some native
	* functions as prototype setup using normal JavaScript does not work as
	* expected during bootstrapping (see mirror.js in r114903).
	*
	* @param {function} ctor Constructor function which needs to inherit the
	*     prototype.
	* @param {function} superCtor Constructor function to inherit prototype from.
	*/
	exports.inherits = require_inherits_browser();
	exports._extend = function(origin, add) {
		if (!add || !isObject(add)) return origin;
		var keys = Object.keys(add);
		var i = keys.length;
		while (i--) origin[keys[i]] = add[keys[i]];
		return origin;
	};
	function hasOwnProperty(obj, prop) {
		return Object.prototype.hasOwnProperty.call(obj, prop);
	}
	var kCustomPromisifiedSymbol = typeof Symbol !== "undefined" ? Symbol("util.promisify.custom") : void 0;
	exports.promisify = function promisify(original) {
		if (typeof original !== "function") throw new TypeError("The \"original\" argument must be of type Function");
		if (kCustomPromisifiedSymbol && original[kCustomPromisifiedSymbol]) {
			var fn = original[kCustomPromisifiedSymbol];
			if (typeof fn !== "function") throw new TypeError("The \"util.promisify.custom\" argument must be of type Function");
			Object.defineProperty(fn, kCustomPromisifiedSymbol, {
				value: fn,
				enumerable: false,
				writable: false,
				configurable: true
			});
			return fn;
		}
		function fn() {
			var promiseResolve, promiseReject;
			var promise = new Promise(function(resolve, reject) {
				promiseResolve = resolve;
				promiseReject = reject;
			});
			var args = [];
			for (var i = 0; i < arguments.length; i++) args.push(arguments[i]);
			args.push(function(err, value) {
				if (err) promiseReject(err);
				else promiseResolve(value);
			});
			try {
				original.apply(this, args);
			} catch (err) {
				promiseReject(err);
			}
			return promise;
		}
		Object.setPrototypeOf(fn, Object.getPrototypeOf(original));
		if (kCustomPromisifiedSymbol) Object.defineProperty(fn, kCustomPromisifiedSymbol, {
			value: fn,
			enumerable: false,
			writable: false,
			configurable: true
		});
		return Object.defineProperties(fn, getOwnPropertyDescriptors(original));
	};
	exports.promisify.custom = kCustomPromisifiedSymbol;
	function callbackifyOnRejected(reason, cb) {
		if (!reason) {
			var newReason = /* @__PURE__ */ new Error("Promise was rejected with a falsy value");
			newReason.reason = reason;
			reason = newReason;
		}
		return cb(reason);
	}
	function callbackify(original) {
		if (typeof original !== "function") throw new TypeError("The \"original\" argument must be of type Function");
		function callbackified() {
			var args = [];
			for (var i = 0; i < arguments.length; i++) args.push(arguments[i]);
			var maybeCb = args.pop();
			if (typeof maybeCb !== "function") throw new TypeError("The last argument must be of type Function");
			var self = this;
			var cb = function() {
				return maybeCb.apply(self, arguments);
			};
			original.apply(this, args).then(function(ret) {
				process$1.nextTick(cb.bind(null, null, ret));
			}, function(rej) {
				process$1.nextTick(callbackifyOnRejected.bind(null, rej, cb));
			});
		}
		Object.setPrototypeOf(callbackified, Object.getPrototypeOf(original));
		Object.defineProperties(callbackified, getOwnPropertyDescriptors(original));
		return callbackified;
	}
	exports.callbackify = callbackify;
}));
var require_buffer_list = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function ownKeys(object, enumerableOnly) {
		var keys = Object.keys(object);
		if (Object.getOwnPropertySymbols) {
			var symbols = Object.getOwnPropertySymbols(object);
			enumerableOnly && (symbols = symbols.filter(function(sym) {
				return Object.getOwnPropertyDescriptor(object, sym).enumerable;
			})), keys.push.apply(keys, symbols);
		}
		return keys;
	}
	function _objectSpread(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = null != arguments[i] ? arguments[i] : {};
			i % 2 ? ownKeys(Object(source), !0).forEach(function(key) {
				_defineProperty(target, key, source[key]);
			}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
				Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
			});
		}
		return target;
	}
	function _defineProperty(obj, key, value) {
		key = _toPropertyKey(key);
		if (key in obj) Object.defineProperty(obj, key, {
			value,
			enumerable: true,
			configurable: true,
			writable: true
		});
		else obj[key] = value;
		return obj;
	}
	function _classCallCheck(instance, Constructor) {
		if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
	}
	function _defineProperties(target, props) {
		for (var i = 0; i < props.length; i++) {
			var descriptor = props[i];
			descriptor.enumerable = descriptor.enumerable || false;
			descriptor.configurable = true;
			if ("value" in descriptor) descriptor.writable = true;
			Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
		}
	}
	function _createClass(Constructor, protoProps, staticProps) {
		if (protoProps) _defineProperties(Constructor.prototype, protoProps);
		if (staticProps) _defineProperties(Constructor, staticProps);
		Object.defineProperty(Constructor, "prototype", { writable: false });
		return Constructor;
	}
	function _toPropertyKey(arg) {
		var key = _toPrimitive(arg, "string");
		return typeof key === "symbol" ? key : String(key);
	}
	function _toPrimitive(input, hint) {
		if (typeof input !== "object" || input === null) return input;
		var prim = input[Symbol.toPrimitive];
		if (prim !== void 0) {
			var res = prim.call(input, hint || "default");
			if (typeof res !== "object") return res;
			throw new TypeError("@@toPrimitive must return a primitive value.");
		}
		return (hint === "string" ? String : Number)(input);
	}
	var Buffer = require_buffer().Buffer;
	var inspect = require_util().inspect;
	var custom = inspect && inspect.custom || "inspect";
	function copyBuffer(src, target, offset) {
		Buffer.prototype.copy.call(src, target, offset);
	}
	module.exports = /* @__PURE__ */ function() {
		function BufferList() {
			_classCallCheck(this, BufferList);
			this.head = null;
			this.tail = null;
			this.length = 0;
		}
		_createClass(BufferList, [
			{
				key: "push",
				value: function push(v) {
					var entry = {
						data: v,
						next: null
					};
					if (this.length > 0) this.tail.next = entry;
					else this.head = entry;
					this.tail = entry;
					++this.length;
				}
			},
			{
				key: "unshift",
				value: function unshift(v) {
					var entry = {
						data: v,
						next: this.head
					};
					if (this.length === 0) this.tail = entry;
					this.head = entry;
					++this.length;
				}
			},
			{
				key: "shift",
				value: function shift() {
					if (this.length === 0) return;
					var ret = this.head.data;
					if (this.length === 1) this.head = this.tail = null;
					else this.head = this.head.next;
					--this.length;
					return ret;
				}
			},
			{
				key: "clear",
				value: function clear() {
					this.head = this.tail = null;
					this.length = 0;
				}
			},
			{
				key: "join",
				value: function join(s) {
					if (this.length === 0) return "";
					var p = this.head;
					var ret = "" + p.data;
					while (p = p.next) ret += s + p.data;
					return ret;
				}
			},
			{
				key: "concat",
				value: function concat(n) {
					if (this.length === 0) return Buffer.alloc(0);
					var ret = Buffer.allocUnsafe(n >>> 0);
					var p = this.head;
					var i = 0;
					while (p) {
						copyBuffer(p.data, ret, i);
						i += p.data.length;
						p = p.next;
					}
					return ret;
				}
			},
			{
				key: "consume",
				value: function consume(n, hasStrings) {
					var ret;
					if (n < this.head.data.length) {
						ret = this.head.data.slice(0, n);
						this.head.data = this.head.data.slice(n);
					} else if (n === this.head.data.length) ret = this.shift();
					else ret = hasStrings ? this._getString(n) : this._getBuffer(n);
					return ret;
				}
			},
			{
				key: "first",
				value: function first() {
					return this.head.data;
				}
			},
			{
				key: "_getString",
				value: function _getString(n) {
					var p = this.head;
					var c = 1;
					var ret = p.data;
					n -= ret.length;
					while (p = p.next) {
						var str = p.data;
						var nb = n > str.length ? str.length : n;
						if (nb === str.length) ret += str;
						else ret += str.slice(0, n);
						n -= nb;
						if (n === 0) {
							if (nb === str.length) {
								++c;
								if (p.next) this.head = p.next;
								else this.head = this.tail = null;
							} else {
								this.head = p;
								p.data = str.slice(nb);
							}
							break;
						}
						++c;
					}
					this.length -= c;
					return ret;
				}
			},
			{
				key: "_getBuffer",
				value: function _getBuffer(n) {
					var ret = Buffer.allocUnsafe(n);
					var p = this.head;
					var c = 1;
					p.data.copy(ret);
					n -= p.data.length;
					while (p = p.next) {
						var buf = p.data;
						var nb = n > buf.length ? buf.length : n;
						buf.copy(ret, ret.length - n, 0, nb);
						n -= nb;
						if (n === 0) {
							if (nb === buf.length) {
								++c;
								if (p.next) this.head = p.next;
								else this.head = this.tail = null;
							} else {
								this.head = p;
								p.data = buf.slice(nb);
							}
							break;
						}
						++c;
					}
					this.length -= c;
					return ret;
				}
			},
			{
				key: custom,
				value: function value(_, options) {
					return inspect(this, _objectSpread(_objectSpread({}, options), {}, {
						depth: 0,
						customInspect: false
					}));
				}
			}
		]);
		return BufferList;
	}();
}));
var require_destroy = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	init_dist();
	function destroy(err, cb) {
		var _this = this;
		var readableDestroyed = this._readableState && this._readableState.destroyed;
		var writableDestroyed = this._writableState && this._writableState.destroyed;
		if (readableDestroyed || writableDestroyed) {
			if (cb) cb(err);
			else if (err) {
				if (!this._writableState) process$1.nextTick(emitErrorNT, this, err);
				else if (!this._writableState.errorEmitted) {
					this._writableState.errorEmitted = true;
					process$1.nextTick(emitErrorNT, this, err);
				}
			}
			return this;
		}
		if (this._readableState) this._readableState.destroyed = true;
		if (this._writableState) this._writableState.destroyed = true;
		this._destroy(err || null, function(err) {
			if (!cb && err) if (!_this._writableState) process$1.nextTick(emitErrorAndCloseNT, _this, err);
			else if (!_this._writableState.errorEmitted) {
				_this._writableState.errorEmitted = true;
				process$1.nextTick(emitErrorAndCloseNT, _this, err);
			} else process$1.nextTick(emitCloseNT, _this);
			else if (cb) {
				process$1.nextTick(emitCloseNT, _this);
				cb(err);
			} else process$1.nextTick(emitCloseNT, _this);
		});
		return this;
	}
	function emitErrorAndCloseNT(self, err) {
		emitErrorNT(self, err);
		emitCloseNT(self);
	}
	function emitCloseNT(self) {
		if (self._writableState && !self._writableState.emitClose) return;
		if (self._readableState && !self._readableState.emitClose) return;
		self.emit("close");
	}
	function undestroy() {
		if (this._readableState) {
			this._readableState.destroyed = false;
			this._readableState.reading = false;
			this._readableState.ended = false;
			this._readableState.endEmitted = false;
		}
		if (this._writableState) {
			this._writableState.destroyed = false;
			this._writableState.ended = false;
			this._writableState.ending = false;
			this._writableState.finalCalled = false;
			this._writableState.prefinished = false;
			this._writableState.finished = false;
			this._writableState.errorEmitted = false;
		}
	}
	function emitErrorNT(self, err) {
		self.emit("error", err);
	}
	function errorOrDestroy(stream, err) {
		var rState = stream._readableState;
		var wState = stream._writableState;
		if (rState && rState.autoDestroy || wState && wState.autoDestroy) stream.destroy(err);
		else stream.emit("error", err);
	}
	module.exports = {
		destroy,
		undestroy,
		errorOrDestroy
	};
}));
var require_errors_browser = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _inheritsLoose(subClass, superClass) {
		subClass.prototype = Object.create(superClass.prototype);
		subClass.prototype.constructor = subClass;
		subClass.__proto__ = superClass;
	}
	var codes = {};
	function createErrorType(code, message, Base) {
		if (!Base) Base = Error;
		function getMessage(arg1, arg2, arg3) {
			if (typeof message === "string") return message;
			else return message(arg1, arg2, arg3);
		}
		var NodeError = /* @__PURE__ */ function(_Base) {
			_inheritsLoose(NodeError, _Base);
			function NodeError(arg1, arg2, arg3) {
				return _Base.call(this, getMessage(arg1, arg2, arg3)) || this;
			}
			return NodeError;
		}(Base);
		NodeError.prototype.name = Base.name;
		NodeError.prototype.code = code;
		codes[code] = NodeError;
	}
	function oneOf(expected, thing) {
		if (Array.isArray(expected)) {
			var len = expected.length;
			expected = expected.map(function(i) {
				return String(i);
			});
			if (len > 2) return "one of ".concat(thing, " ").concat(expected.slice(0, len - 1).join(", "), ", or ") + expected[len - 1];
			else if (len === 2) return "one of ".concat(thing, " ").concat(expected[0], " or ").concat(expected[1]);
			else return "of ".concat(thing, " ").concat(expected[0]);
		} else return "of ".concat(thing, " ").concat(String(expected));
	}
	function startsWith(str, search, pos) {
		return str.substr(!pos || pos < 0 ? 0 : +pos, search.length) === search;
	}
	function endsWith(str, search, this_len) {
		if (this_len === void 0 || this_len > str.length) this_len = str.length;
		return str.substring(this_len - search.length, this_len) === search;
	}
	function includes(str, search, start) {
		if (typeof start !== "number") start = 0;
		if (start + search.length > str.length) return false;
		else return str.indexOf(search, start) !== -1;
	}
	createErrorType("ERR_INVALID_OPT_VALUE", function(name, value) {
		return "The value \"" + value + "\" is invalid for option \"" + name + "\"";
	}, TypeError);
	createErrorType("ERR_INVALID_ARG_TYPE", function(name, expected, actual) {
		var determiner;
		if (typeof expected === "string" && startsWith(expected, "not ")) {
			determiner = "must not be";
			expected = expected.replace(/^not /, "");
		} else determiner = "must be";
		var msg;
		if (endsWith(name, " argument")) msg = "The ".concat(name, " ").concat(determiner, " ").concat(oneOf(expected, "type"));
		else {
			var type = includes(name, ".") ? "property" : "argument";
			msg = "The \"".concat(name, "\" ").concat(type, " ").concat(determiner, " ").concat(oneOf(expected, "type"));
		}
		msg += ". Received type ".concat(typeof actual);
		return msg;
	}, TypeError);
	createErrorType("ERR_STREAM_PUSH_AFTER_EOF", "stream.push() after EOF");
	createErrorType("ERR_METHOD_NOT_IMPLEMENTED", function(name) {
		return "The " + name + " method is not implemented";
	});
	createErrorType("ERR_STREAM_PREMATURE_CLOSE", "Premature close");
	createErrorType("ERR_STREAM_DESTROYED", function(name) {
		return "Cannot call " + name + " after a stream was destroyed";
	});
	createErrorType("ERR_MULTIPLE_CALLBACK", "Callback called multiple times");
	createErrorType("ERR_STREAM_CANNOT_PIPE", "Cannot pipe, not readable");
	createErrorType("ERR_STREAM_WRITE_AFTER_END", "write after end");
	createErrorType("ERR_STREAM_NULL_VALUES", "May not write null values to stream", TypeError);
	createErrorType("ERR_UNKNOWN_ENCODING", function(arg) {
		return "Unknown encoding: " + arg;
	}, TypeError);
	createErrorType("ERR_STREAM_UNSHIFT_AFTER_END_EVENT", "stream.unshift() after end event");
	module.exports.codes = codes;
}));
var require_state = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ERR_INVALID_OPT_VALUE = require_errors_browser().codes.ERR_INVALID_OPT_VALUE;
	function highWaterMarkFrom(options, isDuplex, duplexKey) {
		return options.highWaterMark != null ? options.highWaterMark : isDuplex ? options[duplexKey] : null;
	}
	function getHighWaterMark(state, options, duplexKey, isDuplex) {
		var hwm = highWaterMarkFrom(options, isDuplex, duplexKey);
		if (hwm != null) {
			if (!(isFinite(hwm) && Math.floor(hwm) === hwm) || hwm < 0) throw new ERR_INVALID_OPT_VALUE(isDuplex ? duplexKey : "highWaterMark", hwm);
			return Math.floor(hwm);
		}
		return state.objectMode ? 16 : 16384;
	}
	module.exports = { getHighWaterMark };
}));
var require_browser = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	init_dist$1();
	/**
	* Module exports.
	*/
	module.exports = deprecate;
	/**
	* Mark that a method should not be used.
	* Returns a modified function which warns once by default.
	*
	* If `localStorage.noDeprecation = true` is set, then it is a no-op.
	*
	* If `localStorage.throwDeprecation = true` is set, then deprecated functions
	* will throw an Error when invoked.
	*
	* If `localStorage.traceDeprecation = true` is set, then deprecated functions
	* will invoke `console.trace()` instead of `console.error()`.
	*
	* @param {Function} fn - the function to deprecate
	* @param {String} msg - the string to print to the console when `fn` is invoked
	* @returns {Function} a new "deprecated" version of `fn`
	* @api public
	*/
	function deprecate(fn, msg) {
		if (config("noDeprecation")) return fn;
		var warned = false;
		function deprecated() {
			if (!warned) {
				if (config("throwDeprecation")) throw new Error(msg);
				else if (config("traceDeprecation")) console.trace(msg);
				else console.warn(msg);
				warned = true;
			}
			return fn.apply(this, arguments);
		}
		return deprecated;
	}
	/**
	* Checks `localStorage` for boolean values for the given `name`.
	*
	* @param {String} name
	* @returns {Boolean}
	* @api private
	*/
	function config(name) {
		try {
			if (!global.localStorage) return false;
		} catch (_) {
			return false;
		}
		var val = global.localStorage[name];
		if (null == val) return false;
		return String(val).toLowerCase() === "true";
	}
}));
var require__stream_writable = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	init_dist$1();
	init_dist();
	module.exports = Writable;
	function CorkedRequest(state) {
		var _this = this;
		this.next = null;
		this.entry = null;
		this.finish = function() {
			onCorkedFinish(_this, state);
		};
	}
	var Duplex;
	Writable.WritableState = WritableState;
	var internalUtil = { deprecate: require_browser() };
	var Stream = require_stream_browser();
	var Buffer = require_buffer().Buffer;
	var OurUint8Array = (typeof global !== "undefined" ? global : typeof window !== "undefined" ? window : typeof self !== "undefined" ? self : {}).Uint8Array || function() {};
	function _uint8ArrayToBuffer(chunk) {
		return Buffer.from(chunk);
	}
	function _isUint8Array(obj) {
		return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
	}
	var destroyImpl = require_destroy();
	var getHighWaterMark = require_state().getHighWaterMark;
	var _require$codes = require_errors_browser().codes, ERR_INVALID_ARG_TYPE = _require$codes.ERR_INVALID_ARG_TYPE, ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED, ERR_MULTIPLE_CALLBACK = _require$codes.ERR_MULTIPLE_CALLBACK, ERR_STREAM_CANNOT_PIPE = _require$codes.ERR_STREAM_CANNOT_PIPE, ERR_STREAM_DESTROYED = _require$codes.ERR_STREAM_DESTROYED, ERR_STREAM_NULL_VALUES = _require$codes.ERR_STREAM_NULL_VALUES, ERR_STREAM_WRITE_AFTER_END = _require$codes.ERR_STREAM_WRITE_AFTER_END, ERR_UNKNOWN_ENCODING = _require$codes.ERR_UNKNOWN_ENCODING;
	var errorOrDestroy = destroyImpl.errorOrDestroy;
	require_inherits_browser()(Writable, Stream);
	function nop() {}
	function WritableState(options, stream, isDuplex) {
		Duplex = Duplex || require__stream_duplex();
		options = options || {};
		if (typeof isDuplex !== "boolean") isDuplex = stream instanceof Duplex;
		this.objectMode = !!options.objectMode;
		if (isDuplex) this.objectMode = this.objectMode || !!options.writableObjectMode;
		this.highWaterMark = getHighWaterMark(this, options, "writableHighWaterMark", isDuplex);
		this.finalCalled = false;
		this.needDrain = false;
		this.ending = false;
		this.ended = false;
		this.finished = false;
		this.destroyed = false;
		var noDecode = options.decodeStrings === false;
		this.decodeStrings = !noDecode;
		this.defaultEncoding = options.defaultEncoding || "utf8";
		this.length = 0;
		this.writing = false;
		this.corked = 0;
		this.sync = true;
		this.bufferProcessing = false;
		this.onwrite = function(er) {
			onwrite(stream, er);
		};
		this.writecb = null;
		this.writelen = 0;
		this.bufferedRequest = null;
		this.lastBufferedRequest = null;
		this.pendingcb = 0;
		this.prefinished = false;
		this.errorEmitted = false;
		this.emitClose = options.emitClose !== false;
		this.autoDestroy = !!options.autoDestroy;
		this.bufferedRequestCount = 0;
		this.corkedRequestsFree = new CorkedRequest(this);
	}
	WritableState.prototype.getBuffer = function getBuffer() {
		var current = this.bufferedRequest;
		var out = [];
		while (current) {
			out.push(current);
			current = current.next;
		}
		return out;
	};
	(function() {
		try {
			Object.defineProperty(WritableState.prototype, "buffer", { get: internalUtil.deprecate(function writableStateBufferGetter() {
				return this.getBuffer();
			}, "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.", "DEP0003") });
		} catch (_) {}
	})();
	var realHasInstance;
	if (typeof Symbol === "function" && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] === "function") {
		realHasInstance = Function.prototype[Symbol.hasInstance];
		Object.defineProperty(Writable, Symbol.hasInstance, { value: function value(object) {
			if (realHasInstance.call(this, object)) return true;
			if (this !== Writable) return false;
			return object && object._writableState instanceof WritableState;
		} });
	} else realHasInstance = function realHasInstance(object) {
		return object instanceof this;
	};
	function Writable(options) {
		Duplex = Duplex || require__stream_duplex();
		var isDuplex = this instanceof Duplex;
		if (!isDuplex && !realHasInstance.call(Writable, this)) return new Writable(options);
		this._writableState = new WritableState(options, this, isDuplex);
		this.writable = true;
		if (options) {
			if (typeof options.write === "function") this._write = options.write;
			if (typeof options.writev === "function") this._writev = options.writev;
			if (typeof options.destroy === "function") this._destroy = options.destroy;
			if (typeof options.final === "function") this._final = options.final;
		}
		Stream.call(this);
	}
	Writable.prototype.pipe = function() {
		errorOrDestroy(this, new ERR_STREAM_CANNOT_PIPE());
	};
	function writeAfterEnd(stream, cb) {
		var er = new ERR_STREAM_WRITE_AFTER_END();
		errorOrDestroy(stream, er);
		process$1.nextTick(cb, er);
	}
	function validChunk(stream, state, chunk, cb) {
		var er;
		if (chunk === null) er = new ERR_STREAM_NULL_VALUES();
		else if (typeof chunk !== "string" && !state.objectMode) er = new ERR_INVALID_ARG_TYPE("chunk", ["string", "Buffer"], chunk);
		if (er) {
			errorOrDestroy(stream, er);
			process$1.nextTick(cb, er);
			return false;
		}
		return true;
	}
	Writable.prototype.write = function(chunk, encoding, cb) {
		var state = this._writableState;
		var ret = false;
		var isBuf = !state.objectMode && _isUint8Array(chunk);
		if (isBuf && !Buffer.isBuffer(chunk)) chunk = _uint8ArrayToBuffer(chunk);
		if (typeof encoding === "function") {
			cb = encoding;
			encoding = null;
		}
		if (isBuf) encoding = "buffer";
		else if (!encoding) encoding = state.defaultEncoding;
		if (typeof cb !== "function") cb = nop;
		if (state.ending) writeAfterEnd(this, cb);
		else if (isBuf || validChunk(this, state, chunk, cb)) {
			state.pendingcb++;
			ret = writeOrBuffer(this, state, isBuf, chunk, encoding, cb);
		}
		return ret;
	};
	Writable.prototype.cork = function() {
		this._writableState.corked++;
	};
	Writable.prototype.uncork = function() {
		var state = this._writableState;
		if (state.corked) {
			state.corked--;
			if (!state.writing && !state.corked && !state.bufferProcessing && state.bufferedRequest) clearBuffer(this, state);
		}
	};
	Writable.prototype.setDefaultEncoding = function setDefaultEncoding(encoding) {
		if (typeof encoding === "string") encoding = encoding.toLowerCase();
		if (!([
			"hex",
			"utf8",
			"utf-8",
			"ascii",
			"binary",
			"base64",
			"ucs2",
			"ucs-2",
			"utf16le",
			"utf-16le",
			"raw"
		].indexOf((encoding + "").toLowerCase()) > -1)) throw new ERR_UNKNOWN_ENCODING(encoding);
		this._writableState.defaultEncoding = encoding;
		return this;
	};
	Object.defineProperty(Writable.prototype, "writableBuffer", {
		enumerable: false,
		get: function get() {
			return this._writableState && this._writableState.getBuffer();
		}
	});
	function decodeChunk(state, chunk, encoding) {
		if (!state.objectMode && state.decodeStrings !== false && typeof chunk === "string") chunk = Buffer.from(chunk, encoding);
		return chunk;
	}
	Object.defineProperty(Writable.prototype, "writableHighWaterMark", {
		enumerable: false,
		get: function get() {
			return this._writableState.highWaterMark;
		}
	});
	function writeOrBuffer(stream, state, isBuf, chunk, encoding, cb) {
		if (!isBuf) {
			var newChunk = decodeChunk(state, chunk, encoding);
			if (chunk !== newChunk) {
				isBuf = true;
				encoding = "buffer";
				chunk = newChunk;
			}
		}
		var len = state.objectMode ? 1 : chunk.length;
		state.length += len;
		var ret = state.length < state.highWaterMark;
		if (!ret) state.needDrain = true;
		if (state.writing || state.corked) {
			var last = state.lastBufferedRequest;
			state.lastBufferedRequest = {
				chunk,
				encoding,
				isBuf,
				callback: cb,
				next: null
			};
			if (last) last.next = state.lastBufferedRequest;
			else state.bufferedRequest = state.lastBufferedRequest;
			state.bufferedRequestCount += 1;
		} else doWrite(stream, state, false, len, chunk, encoding, cb);
		return ret;
	}
	function doWrite(stream, state, writev, len, chunk, encoding, cb) {
		state.writelen = len;
		state.writecb = cb;
		state.writing = true;
		state.sync = true;
		if (state.destroyed) state.onwrite(new ERR_STREAM_DESTROYED("write"));
		else if (writev) stream._writev(chunk, state.onwrite);
		else stream._write(chunk, encoding, state.onwrite);
		state.sync = false;
	}
	function onwriteError(stream, state, sync, er, cb) {
		--state.pendingcb;
		if (sync) {
			process$1.nextTick(cb, er);
			process$1.nextTick(finishMaybe, stream, state);
			stream._writableState.errorEmitted = true;
			errorOrDestroy(stream, er);
		} else {
			cb(er);
			stream._writableState.errorEmitted = true;
			errorOrDestroy(stream, er);
			finishMaybe(stream, state);
		}
	}
	function onwriteStateUpdate(state) {
		state.writing = false;
		state.writecb = null;
		state.length -= state.writelen;
		state.writelen = 0;
	}
	function onwrite(stream, er) {
		var state = stream._writableState;
		var sync = state.sync;
		var cb = state.writecb;
		if (typeof cb !== "function") throw new ERR_MULTIPLE_CALLBACK();
		onwriteStateUpdate(state);
		if (er) onwriteError(stream, state, sync, er, cb);
		else {
			var finished = needFinish(state) || stream.destroyed;
			if (!finished && !state.corked && !state.bufferProcessing && state.bufferedRequest) clearBuffer(stream, state);
			if (sync) process$1.nextTick(afterWrite, stream, state, finished, cb);
			else afterWrite(stream, state, finished, cb);
		}
	}
	function afterWrite(stream, state, finished, cb) {
		if (!finished) onwriteDrain(stream, state);
		state.pendingcb--;
		cb();
		finishMaybe(stream, state);
	}
	function onwriteDrain(stream, state) {
		if (state.length === 0 && state.needDrain) {
			state.needDrain = false;
			stream.emit("drain");
		}
	}
	function clearBuffer(stream, state) {
		state.bufferProcessing = true;
		var entry = state.bufferedRequest;
		if (stream._writev && entry && entry.next) {
			var l = state.bufferedRequestCount;
			var buffer = new Array(l);
			var holder = state.corkedRequestsFree;
			holder.entry = entry;
			var count = 0;
			var allBuffers = true;
			while (entry) {
				buffer[count] = entry;
				if (!entry.isBuf) allBuffers = false;
				entry = entry.next;
				count += 1;
			}
			buffer.allBuffers = allBuffers;
			doWrite(stream, state, true, state.length, buffer, "", holder.finish);
			state.pendingcb++;
			state.lastBufferedRequest = null;
			if (holder.next) {
				state.corkedRequestsFree = holder.next;
				holder.next = null;
			} else state.corkedRequestsFree = new CorkedRequest(state);
			state.bufferedRequestCount = 0;
		} else {
			while (entry) {
				var chunk = entry.chunk;
				var encoding = entry.encoding;
				var cb = entry.callback;
				doWrite(stream, state, false, state.objectMode ? 1 : chunk.length, chunk, encoding, cb);
				entry = entry.next;
				state.bufferedRequestCount--;
				if (state.writing) break;
			}
			if (entry === null) state.lastBufferedRequest = null;
		}
		state.bufferedRequest = entry;
		state.bufferProcessing = false;
	}
	Writable.prototype._write = function(chunk, encoding, cb) {
		cb(new ERR_METHOD_NOT_IMPLEMENTED("_write()"));
	};
	Writable.prototype._writev = null;
	Writable.prototype.end = function(chunk, encoding, cb) {
		var state = this._writableState;
		if (typeof chunk === "function") {
			cb = chunk;
			chunk = null;
			encoding = null;
		} else if (typeof encoding === "function") {
			cb = encoding;
			encoding = null;
		}
		if (chunk !== null && chunk !== void 0) this.write(chunk, encoding);
		if (state.corked) {
			state.corked = 1;
			this.uncork();
		}
		if (!state.ending) endWritable(this, state, cb);
		return this;
	};
	Object.defineProperty(Writable.prototype, "writableLength", {
		enumerable: false,
		get: function get() {
			return this._writableState.length;
		}
	});
	function needFinish(state) {
		return state.ending && state.length === 0 && state.bufferedRequest === null && !state.finished && !state.writing;
	}
	function callFinal(stream, state) {
		stream._final(function(err) {
			state.pendingcb--;
			if (err) errorOrDestroy(stream, err);
			state.prefinished = true;
			stream.emit("prefinish");
			finishMaybe(stream, state);
		});
	}
	function prefinish(stream, state) {
		if (!state.prefinished && !state.finalCalled) if (typeof stream._final === "function" && !state.destroyed) {
			state.pendingcb++;
			state.finalCalled = true;
			process$1.nextTick(callFinal, stream, state);
		} else {
			state.prefinished = true;
			stream.emit("prefinish");
		}
	}
	function finishMaybe(stream, state) {
		var need = needFinish(state);
		if (need) {
			prefinish(stream, state);
			if (state.pendingcb === 0) {
				state.finished = true;
				stream.emit("finish");
				if (state.autoDestroy) {
					var rState = stream._readableState;
					if (!rState || rState.autoDestroy && rState.endEmitted) stream.destroy();
				}
			}
		}
		return need;
	}
	function endWritable(stream, state, cb) {
		state.ending = true;
		finishMaybe(stream, state);
		if (cb) if (state.finished) process$1.nextTick(cb);
		else stream.once("finish", cb);
		state.ended = true;
		stream.writable = false;
	}
	function onCorkedFinish(corkReq, state, err) {
		var entry = corkReq.entry;
		corkReq.entry = null;
		while (entry) {
			var cb = entry.callback;
			state.pendingcb--;
			cb(err);
			entry = entry.next;
		}
		state.corkedRequestsFree.next = corkReq;
	}
	Object.defineProperty(Writable.prototype, "destroyed", {
		enumerable: false,
		get: function get() {
			if (this._writableState === void 0) return false;
			return this._writableState.destroyed;
		},
		set: function set(value) {
			if (!this._writableState) return;
			this._writableState.destroyed = value;
		}
	});
	Writable.prototype.destroy = destroyImpl.destroy;
	Writable.prototype._undestroy = destroyImpl.undestroy;
	Writable.prototype._destroy = function(err, cb) {
		cb(err);
	};
}));
var require__stream_duplex = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	init_dist();
	var objectKeys = Object.keys || function(obj) {
		var keys = [];
		for (var key in obj) keys.push(key);
		return keys;
	};
	module.exports = Duplex;
	var Readable = require__stream_readable();
	var Writable = require__stream_writable();
	require_inherits_browser()(Duplex, Readable);
	var keys = objectKeys(Writable.prototype);
	for (var v = 0; v < keys.length; v++) {
		var method = keys[v];
		if (!Duplex.prototype[method]) Duplex.prototype[method] = Writable.prototype[method];
	}
	function Duplex(options) {
		if (!(this instanceof Duplex)) return new Duplex(options);
		Readable.call(this, options);
		Writable.call(this, options);
		this.allowHalfOpen = true;
		if (options) {
			if (options.readable === false) this.readable = false;
			if (options.writable === false) this.writable = false;
			if (options.allowHalfOpen === false) {
				this.allowHalfOpen = false;
				this.once("end", onend);
			}
		}
	}
	Object.defineProperty(Duplex.prototype, "writableHighWaterMark", {
		enumerable: false,
		get: function get() {
			return this._writableState.highWaterMark;
		}
	});
	Object.defineProperty(Duplex.prototype, "writableBuffer", {
		enumerable: false,
		get: function get() {
			return this._writableState && this._writableState.getBuffer();
		}
	});
	Object.defineProperty(Duplex.prototype, "writableLength", {
		enumerable: false,
		get: function get() {
			return this._writableState.length;
		}
	});
	function onend() {
		if (this._writableState.ended) return;
		process$1.nextTick(onEndNT, this);
	}
	function onEndNT(self) {
		self.end();
	}
	Object.defineProperty(Duplex.prototype, "destroyed", {
		enumerable: false,
		get: function get() {
			if (this._readableState === void 0 || this._writableState === void 0) return false;
			return this._readableState.destroyed && this._writableState.destroyed;
		},
		set: function set(value) {
			if (this._readableState === void 0 || this._writableState === void 0) return;
			this._readableState.destroyed = value;
			this._writableState.destroyed = value;
		}
	});
}));
var require_safe_buffer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var buffer = require_buffer();
	var Buffer = buffer.Buffer;
	function copyProps(src, dst) {
		for (var key in src) dst[key] = src[key];
	}
	if (Buffer.from && Buffer.alloc && Buffer.allocUnsafe && Buffer.allocUnsafeSlow) module.exports = buffer;
	else {
		copyProps(buffer, exports);
		exports.Buffer = SafeBuffer;
	}
	function SafeBuffer(arg, encodingOrOffset, length) {
		return Buffer(arg, encodingOrOffset, length);
	}
	copyProps(Buffer, SafeBuffer);
	SafeBuffer.from = function(arg, encodingOrOffset, length) {
		if (typeof arg === "number") throw new TypeError("Argument must not be a number");
		return Buffer(arg, encodingOrOffset, length);
	};
	SafeBuffer.alloc = function(size, fill, encoding) {
		if (typeof size !== "number") throw new TypeError("Argument must be a number");
		var buf = Buffer(size);
		if (fill !== void 0) if (typeof encoding === "string") buf.fill(fill, encoding);
		else buf.fill(fill);
		else buf.fill(0);
		return buf;
	};
	SafeBuffer.allocUnsafe = function(size) {
		if (typeof size !== "number") throw new TypeError("Argument must be a number");
		return Buffer(size);
	};
	SafeBuffer.allocUnsafeSlow = function(size) {
		if (typeof size !== "number") throw new TypeError("Argument must be a number");
		return buffer.SlowBuffer(size);
	};
}));
var require_string_decoder = /* @__PURE__ */ __commonJSMin(((exports) => {
	var Buffer = require_safe_buffer().Buffer;
	var isEncoding = Buffer.isEncoding || function(encoding) {
		encoding = "" + encoding;
		switch (encoding && encoding.toLowerCase()) {
			case "hex":
			case "utf8":
			case "utf-8":
			case "ascii":
			case "binary":
			case "base64":
			case "ucs2":
			case "ucs-2":
			case "utf16le":
			case "utf-16le":
			case "raw": return true;
			default: return false;
		}
	};
	function _normalizeEncoding(enc) {
		if (!enc) return "utf8";
		var retried;
		while (true) switch (enc) {
			case "utf8":
			case "utf-8": return "utf8";
			case "ucs2":
			case "ucs-2":
			case "utf16le":
			case "utf-16le": return "utf16le";
			case "latin1":
			case "binary": return "latin1";
			case "base64":
			case "ascii":
			case "hex": return enc;
			default:
				if (retried) return;
				enc = ("" + enc).toLowerCase();
				retried = true;
		}
	}
	function normalizeEncoding(enc) {
		var nenc = _normalizeEncoding(enc);
		if (typeof nenc !== "string" && (Buffer.isEncoding === isEncoding || !isEncoding(enc))) throw new Error("Unknown encoding: " + enc);
		return nenc || enc;
	}
	exports.StringDecoder = StringDecoder;
	function StringDecoder(encoding) {
		this.encoding = normalizeEncoding(encoding);
		var nb;
		switch (this.encoding) {
			case "utf16le":
				this.text = utf16Text;
				this.end = utf16End;
				nb = 4;
				break;
			case "utf8":
				this.fillLast = utf8FillLast;
				nb = 4;
				break;
			case "base64":
				this.text = base64Text;
				this.end = base64End;
				nb = 3;
				break;
			default:
				this.write = simpleWrite;
				this.end = simpleEnd;
				return;
		}
		this.lastNeed = 0;
		this.lastTotal = 0;
		this.lastChar = Buffer.allocUnsafe(nb);
	}
	StringDecoder.prototype.write = function(buf) {
		if (buf.length === 0) return "";
		var r;
		var i;
		if (this.lastNeed) {
			r = this.fillLast(buf);
			if (r === void 0) return "";
			i = this.lastNeed;
			this.lastNeed = 0;
		} else i = 0;
		if (i < buf.length) return r ? r + this.text(buf, i) : this.text(buf, i);
		return r || "";
	};
	StringDecoder.prototype.end = utf8End;
	StringDecoder.prototype.text = utf8Text;
	StringDecoder.prototype.fillLast = function(buf) {
		if (this.lastNeed <= buf.length) {
			buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed);
			return this.lastChar.toString(this.encoding, 0, this.lastTotal);
		}
		buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, buf.length);
		this.lastNeed -= buf.length;
	};
	function utf8CheckByte(byte) {
		if (byte <= 127) return 0;
		else if (byte >> 5 === 6) return 2;
		else if (byte >> 4 === 14) return 3;
		else if (byte >> 3 === 30) return 4;
		return byte >> 6 === 2 ? -1 : -2;
	}
	function utf8CheckIncomplete(self, buf, i) {
		var j = buf.length - 1;
		if (j < i) return 0;
		var nb = utf8CheckByte(buf[j]);
		if (nb >= 0) {
			if (nb > 0) self.lastNeed = nb - 1;
			return nb;
		}
		if (--j < i || nb === -2) return 0;
		nb = utf8CheckByte(buf[j]);
		if (nb >= 0) {
			if (nb > 0) self.lastNeed = nb - 2;
			return nb;
		}
		if (--j < i || nb === -2) return 0;
		nb = utf8CheckByte(buf[j]);
		if (nb >= 0) {
			if (nb > 0) if (nb === 2) nb = 0;
			else self.lastNeed = nb - 3;
			return nb;
		}
		return 0;
	}
	function utf8CheckExtraBytes(self, buf, p) {
		if ((buf[0] & 192) !== 128) {
			self.lastNeed = 0;
			return "�";
		}
		if (self.lastNeed > 1 && buf.length > 1) {
			if ((buf[1] & 192) !== 128) {
				self.lastNeed = 1;
				return "�";
			}
			if (self.lastNeed > 2 && buf.length > 2) {
				if ((buf[2] & 192) !== 128) {
					self.lastNeed = 2;
					return "�";
				}
			}
		}
	}
	function utf8FillLast(buf) {
		var p = this.lastTotal - this.lastNeed;
		var r = utf8CheckExtraBytes(this, buf, p);
		if (r !== void 0) return r;
		if (this.lastNeed <= buf.length) {
			buf.copy(this.lastChar, p, 0, this.lastNeed);
			return this.lastChar.toString(this.encoding, 0, this.lastTotal);
		}
		buf.copy(this.lastChar, p, 0, buf.length);
		this.lastNeed -= buf.length;
	}
	function utf8Text(buf, i) {
		var total = utf8CheckIncomplete(this, buf, i);
		if (!this.lastNeed) return buf.toString("utf8", i);
		this.lastTotal = total;
		var end = buf.length - (total - this.lastNeed);
		buf.copy(this.lastChar, 0, end);
		return buf.toString("utf8", i, end);
	}
	function utf8End(buf) {
		var r = buf && buf.length ? this.write(buf) : "";
		if (this.lastNeed) return r + "�";
		return r;
	}
	function utf16Text(buf, i) {
		if ((buf.length - i) % 2 === 0) {
			var r = buf.toString("utf16le", i);
			if (r) {
				var c = r.charCodeAt(r.length - 1);
				if (c >= 55296 && c <= 56319) {
					this.lastNeed = 2;
					this.lastTotal = 4;
					this.lastChar[0] = buf[buf.length - 2];
					this.lastChar[1] = buf[buf.length - 1];
					return r.slice(0, -1);
				}
			}
			return r;
		}
		this.lastNeed = 1;
		this.lastTotal = 2;
		this.lastChar[0] = buf[buf.length - 1];
		return buf.toString("utf16le", i, buf.length - 1);
	}
	function utf16End(buf) {
		var r = buf && buf.length ? this.write(buf) : "";
		if (this.lastNeed) {
			var end = this.lastTotal - this.lastNeed;
			return r + this.lastChar.toString("utf16le", 0, end);
		}
		return r;
	}
	function base64Text(buf, i) {
		var n = (buf.length - i) % 3;
		if (n === 0) return buf.toString("base64", i);
		this.lastNeed = 3 - n;
		this.lastTotal = 3;
		if (n === 1) this.lastChar[0] = buf[buf.length - 1];
		else {
			this.lastChar[0] = buf[buf.length - 2];
			this.lastChar[1] = buf[buf.length - 1];
		}
		return buf.toString("base64", i, buf.length - n);
	}
	function base64End(buf) {
		var r = buf && buf.length ? this.write(buf) : "";
		if (this.lastNeed) return r + this.lastChar.toString("base64", 0, 3 - this.lastNeed);
		return r;
	}
	function simpleWrite(buf) {
		return buf.toString(this.encoding);
	}
	function simpleEnd(buf) {
		return buf && buf.length ? this.write(buf) : "";
	}
}));
var require_end_of_stream = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ERR_STREAM_PREMATURE_CLOSE = require_errors_browser().codes.ERR_STREAM_PREMATURE_CLOSE;
	function once(callback) {
		var called = false;
		return function() {
			if (called) return;
			called = true;
			for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
			callback.apply(this, args);
		};
	}
	function noop() {}
	function isRequest(stream) {
		return stream.setHeader && typeof stream.abort === "function";
	}
	function eos(stream, opts, callback) {
		if (typeof opts === "function") return eos(stream, null, opts);
		if (!opts) opts = {};
		callback = once(callback || noop);
		var readable = opts.readable || opts.readable !== false && stream.readable;
		var writable = opts.writable || opts.writable !== false && stream.writable;
		var onlegacyfinish = function onlegacyfinish() {
			if (!stream.writable) onfinish();
		};
		var writableEnded = stream._writableState && stream._writableState.finished;
		var onfinish = function onfinish() {
			writable = false;
			writableEnded = true;
			if (!readable) callback.call(stream);
		};
		var readableEnded = stream._readableState && stream._readableState.endEmitted;
		var onend = function onend() {
			readable = false;
			readableEnded = true;
			if (!writable) callback.call(stream);
		};
		var onerror = function onerror(err) {
			callback.call(stream, err);
		};
		var onclose = function onclose() {
			var err;
			if (readable && !readableEnded) {
				if (!stream._readableState || !stream._readableState.ended) err = new ERR_STREAM_PREMATURE_CLOSE();
				return callback.call(stream, err);
			}
			if (writable && !writableEnded) {
				if (!stream._writableState || !stream._writableState.ended) err = new ERR_STREAM_PREMATURE_CLOSE();
				return callback.call(stream, err);
			}
		};
		var onrequest = function onrequest() {
			stream.req.on("finish", onfinish);
		};
		if (isRequest(stream)) {
			stream.on("complete", onfinish);
			stream.on("abort", onclose);
			if (stream.req) onrequest();
			else stream.on("request", onrequest);
		} else if (writable && !stream._writableState) {
			stream.on("end", onlegacyfinish);
			stream.on("close", onlegacyfinish);
		}
		stream.on("end", onend);
		stream.on("finish", onfinish);
		if (opts.error !== false) stream.on("error", onerror);
		stream.on("close", onclose);
		return function() {
			stream.removeListener("complete", onfinish);
			stream.removeListener("abort", onclose);
			stream.removeListener("request", onrequest);
			if (stream.req) stream.req.removeListener("finish", onfinish);
			stream.removeListener("end", onlegacyfinish);
			stream.removeListener("close", onlegacyfinish);
			stream.removeListener("finish", onfinish);
			stream.removeListener("end", onend);
			stream.removeListener("error", onerror);
			stream.removeListener("close", onclose);
		};
	}
	module.exports = eos;
}));
var require_async_iterator = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	init_dist();
	var _Object$setPrototypeO;
	function _defineProperty(obj, key, value) {
		key = _toPropertyKey(key);
		if (key in obj) Object.defineProperty(obj, key, {
			value,
			enumerable: true,
			configurable: true,
			writable: true
		});
		else obj[key] = value;
		return obj;
	}
	function _toPropertyKey(arg) {
		var key = _toPrimitive(arg, "string");
		return typeof key === "symbol" ? key : String(key);
	}
	function _toPrimitive(input, hint) {
		if (typeof input !== "object" || input === null) return input;
		var prim = input[Symbol.toPrimitive];
		if (prim !== void 0) {
			var res = prim.call(input, hint || "default");
			if (typeof res !== "object") return res;
			throw new TypeError("@@toPrimitive must return a primitive value.");
		}
		return (hint === "string" ? String : Number)(input);
	}
	var finished = require_end_of_stream();
	var kLastResolve = Symbol("lastResolve");
	var kLastReject = Symbol("lastReject");
	var kError = Symbol("error");
	var kEnded = Symbol("ended");
	var kLastPromise = Symbol("lastPromise");
	var kHandlePromise = Symbol("handlePromise");
	var kStream = Symbol("stream");
	function createIterResult(value, done) {
		return {
			value,
			done
		};
	}
	function readAndResolve(iter) {
		var resolve = iter[kLastResolve];
		if (resolve !== null) {
			var data = iter[kStream].read();
			if (data !== null) {
				iter[kLastPromise] = null;
				iter[kLastResolve] = null;
				iter[kLastReject] = null;
				resolve(createIterResult(data, false));
			}
		}
	}
	function onReadable(iter) {
		process$1.nextTick(readAndResolve, iter);
	}
	function wrapForNext(lastPromise, iter) {
		return function(resolve, reject) {
			lastPromise.then(function() {
				if (iter[kEnded]) {
					resolve(createIterResult(void 0, true));
					return;
				}
				iter[kHandlePromise](resolve, reject);
			}, reject);
		};
	}
	var AsyncIteratorPrototype = Object.getPrototypeOf(function() {});
	var ReadableStreamAsyncIteratorPrototype = Object.setPrototypeOf((_Object$setPrototypeO = {
		get stream() {
			return this[kStream];
		},
		next: function next() {
			var _this = this;
			var error = this[kError];
			if (error !== null) return Promise.reject(error);
			if (this[kEnded]) return Promise.resolve(createIterResult(void 0, true));
			if (this[kStream].destroyed) return new Promise(function(resolve, reject) {
				process$1.nextTick(function() {
					if (_this[kError]) reject(_this[kError]);
					else resolve(createIterResult(void 0, true));
				});
			});
			var lastPromise = this[kLastPromise];
			var promise;
			if (lastPromise) promise = new Promise(wrapForNext(lastPromise, this));
			else {
				var data = this[kStream].read();
				if (data !== null) return Promise.resolve(createIterResult(data, false));
				promise = new Promise(this[kHandlePromise]);
			}
			this[kLastPromise] = promise;
			return promise;
		}
	}, _defineProperty(_Object$setPrototypeO, Symbol.asyncIterator, function() {
		return this;
	}), _defineProperty(_Object$setPrototypeO, "return", function _return() {
		var _this2 = this;
		return new Promise(function(resolve, reject) {
			_this2[kStream].destroy(null, function(err) {
				if (err) {
					reject(err);
					return;
				}
				resolve(createIterResult(void 0, true));
			});
		});
	}), _Object$setPrototypeO), AsyncIteratorPrototype);
	module.exports = function createReadableStreamAsyncIterator(stream) {
		var _Object$create;
		var iterator = Object.create(ReadableStreamAsyncIteratorPrototype, (_Object$create = {}, _defineProperty(_Object$create, kStream, {
			value: stream,
			writable: true
		}), _defineProperty(_Object$create, kLastResolve, {
			value: null,
			writable: true
		}), _defineProperty(_Object$create, kLastReject, {
			value: null,
			writable: true
		}), _defineProperty(_Object$create, kError, {
			value: null,
			writable: true
		}), _defineProperty(_Object$create, kEnded, {
			value: stream._readableState.endEmitted,
			writable: true
		}), _defineProperty(_Object$create, kHandlePromise, {
			value: function value(resolve, reject) {
				var data = iterator[kStream].read();
				if (data) {
					iterator[kLastPromise] = null;
					iterator[kLastResolve] = null;
					iterator[kLastReject] = null;
					resolve(createIterResult(data, false));
				} else {
					iterator[kLastResolve] = resolve;
					iterator[kLastReject] = reject;
				}
			},
			writable: true
		}), _Object$create));
		iterator[kLastPromise] = null;
		finished(stream, function(err) {
			if (err && err.code !== "ERR_STREAM_PREMATURE_CLOSE") {
				var reject = iterator[kLastReject];
				if (reject !== null) {
					iterator[kLastPromise] = null;
					iterator[kLastResolve] = null;
					iterator[kLastReject] = null;
					reject(err);
				}
				iterator[kError] = err;
				return;
			}
			var resolve = iterator[kLastResolve];
			if (resolve !== null) {
				iterator[kLastPromise] = null;
				iterator[kLastResolve] = null;
				iterator[kLastReject] = null;
				resolve(createIterResult(void 0, true));
			}
			iterator[kEnded] = true;
		});
		stream.on("readable", onReadable.bind(null, iterator));
		return iterator;
	};
}));
var require_from_browser = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = function() {
		throw new Error("Readable.from is not available in the browser");
	};
}));
var require__stream_readable = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	init_dist$1();
	init_dist();
	module.exports = Readable;
	var Duplex;
	Readable.ReadableState = ReadableState;
	require_events().EventEmitter;
	var EElistenerCount = function EElistenerCount(emitter, type) {
		return emitter.listeners(type).length;
	};
	var Stream = require_stream_browser();
	var Buffer = require_buffer().Buffer;
	var OurUint8Array = (typeof global !== "undefined" ? global : typeof window !== "undefined" ? window : typeof self !== "undefined" ? self : {}).Uint8Array || function() {};
	function _uint8ArrayToBuffer(chunk) {
		return Buffer.from(chunk);
	}
	function _isUint8Array(obj) {
		return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
	}
	var debugUtil = require_util();
	var debug;
	if (debugUtil && debugUtil.debuglog) debug = debugUtil.debuglog("stream");
	else debug = function debug() {};
	var BufferList = require_buffer_list();
	var destroyImpl = require_destroy();
	var getHighWaterMark = require_state().getHighWaterMark;
	var _require$codes = require_errors_browser().codes, ERR_INVALID_ARG_TYPE = _require$codes.ERR_INVALID_ARG_TYPE, ERR_STREAM_PUSH_AFTER_EOF = _require$codes.ERR_STREAM_PUSH_AFTER_EOF, ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED, ERR_STREAM_UNSHIFT_AFTER_END_EVENT = _require$codes.ERR_STREAM_UNSHIFT_AFTER_END_EVENT;
	var StringDecoder;
	var createReadableStreamAsyncIterator;
	var from;
	require_inherits_browser()(Readable, Stream);
	var errorOrDestroy = destroyImpl.errorOrDestroy;
	var kProxyEvents = [
		"error",
		"close",
		"destroy",
		"pause",
		"resume"
	];
	function prependListener(emitter, event, fn) {
		if (typeof emitter.prependListener === "function") return emitter.prependListener(event, fn);
		if (!emitter._events || !emitter._events[event]) emitter.on(event, fn);
		else if (Array.isArray(emitter._events[event])) emitter._events[event].unshift(fn);
		else emitter._events[event] = [fn, emitter._events[event]];
	}
	function ReadableState(options, stream, isDuplex) {
		Duplex = Duplex || require__stream_duplex();
		options = options || {};
		if (typeof isDuplex !== "boolean") isDuplex = stream instanceof Duplex;
		this.objectMode = !!options.objectMode;
		if (isDuplex) this.objectMode = this.objectMode || !!options.readableObjectMode;
		this.highWaterMark = getHighWaterMark(this, options, "readableHighWaterMark", isDuplex);
		this.buffer = new BufferList();
		this.length = 0;
		this.pipes = null;
		this.pipesCount = 0;
		this.flowing = null;
		this.ended = false;
		this.endEmitted = false;
		this.reading = false;
		this.sync = true;
		this.needReadable = false;
		this.emittedReadable = false;
		this.readableListening = false;
		this.resumeScheduled = false;
		this.paused = true;
		this.emitClose = options.emitClose !== false;
		this.autoDestroy = !!options.autoDestroy;
		this.destroyed = false;
		this.defaultEncoding = options.defaultEncoding || "utf8";
		this.awaitDrain = 0;
		this.readingMore = false;
		this.decoder = null;
		this.encoding = null;
		if (options.encoding) {
			if (!StringDecoder) StringDecoder = require_string_decoder().StringDecoder;
			this.decoder = new StringDecoder(options.encoding);
			this.encoding = options.encoding;
		}
	}
	function Readable(options) {
		Duplex = Duplex || require__stream_duplex();
		if (!(this instanceof Readable)) return new Readable(options);
		var isDuplex = this instanceof Duplex;
		this._readableState = new ReadableState(options, this, isDuplex);
		this.readable = true;
		if (options) {
			if (typeof options.read === "function") this._read = options.read;
			if (typeof options.destroy === "function") this._destroy = options.destroy;
		}
		Stream.call(this);
	}
	Object.defineProperty(Readable.prototype, "destroyed", {
		enumerable: false,
		get: function get() {
			if (this._readableState === void 0) return false;
			return this._readableState.destroyed;
		},
		set: function set(value) {
			if (!this._readableState) return;
			this._readableState.destroyed = value;
		}
	});
	Readable.prototype.destroy = destroyImpl.destroy;
	Readable.prototype._undestroy = destroyImpl.undestroy;
	Readable.prototype._destroy = function(err, cb) {
		cb(err);
	};
	Readable.prototype.push = function(chunk, encoding) {
		var state = this._readableState;
		var skipChunkCheck;
		if (!state.objectMode) {
			if (typeof chunk === "string") {
				encoding = encoding || state.defaultEncoding;
				if (encoding !== state.encoding) {
					chunk = Buffer.from(chunk, encoding);
					encoding = "";
				}
				skipChunkCheck = true;
			}
		} else skipChunkCheck = true;
		return readableAddChunk(this, chunk, encoding, false, skipChunkCheck);
	};
	Readable.prototype.unshift = function(chunk) {
		return readableAddChunk(this, chunk, null, true, false);
	};
	function readableAddChunk(stream, chunk, encoding, addToFront, skipChunkCheck) {
		debug("readableAddChunk", chunk);
		var state = stream._readableState;
		if (chunk === null) {
			state.reading = false;
			onEofChunk(stream, state);
		} else {
			var er;
			if (!skipChunkCheck) er = chunkInvalid(state, chunk);
			if (er) errorOrDestroy(stream, er);
			else if (state.objectMode || chunk && chunk.length > 0) {
				if (typeof chunk !== "string" && !state.objectMode && Object.getPrototypeOf(chunk) !== Buffer.prototype) chunk = _uint8ArrayToBuffer(chunk);
				if (addToFront) if (state.endEmitted) errorOrDestroy(stream, new ERR_STREAM_UNSHIFT_AFTER_END_EVENT());
				else addChunk(stream, state, chunk, true);
				else if (state.ended) errorOrDestroy(stream, new ERR_STREAM_PUSH_AFTER_EOF());
				else if (state.destroyed) return false;
				else {
					state.reading = false;
					if (state.decoder && !encoding) {
						chunk = state.decoder.write(chunk);
						if (state.objectMode || chunk.length !== 0) addChunk(stream, state, chunk, false);
						else maybeReadMore(stream, state);
					} else addChunk(stream, state, chunk, false);
				}
			} else if (!addToFront) {
				state.reading = false;
				maybeReadMore(stream, state);
			}
		}
		return !state.ended && (state.length < state.highWaterMark || state.length === 0);
	}
	function addChunk(stream, state, chunk, addToFront) {
		if (state.flowing && state.length === 0 && !state.sync) {
			state.awaitDrain = 0;
			stream.emit("data", chunk);
		} else {
			state.length += state.objectMode ? 1 : chunk.length;
			if (addToFront) state.buffer.unshift(chunk);
			else state.buffer.push(chunk);
			if (state.needReadable) emitReadable(stream);
		}
		maybeReadMore(stream, state);
	}
	function chunkInvalid(state, chunk) {
		var er;
		if (!_isUint8Array(chunk) && typeof chunk !== "string" && chunk !== void 0 && !state.objectMode) er = new ERR_INVALID_ARG_TYPE("chunk", [
			"string",
			"Buffer",
			"Uint8Array"
		], chunk);
		return er;
	}
	Readable.prototype.isPaused = function() {
		return this._readableState.flowing === false;
	};
	Readable.prototype.setEncoding = function(enc) {
		if (!StringDecoder) StringDecoder = require_string_decoder().StringDecoder;
		var decoder = new StringDecoder(enc);
		this._readableState.decoder = decoder;
		this._readableState.encoding = this._readableState.decoder.encoding;
		var p = this._readableState.buffer.head;
		var content = "";
		while (p !== null) {
			content += decoder.write(p.data);
			p = p.next;
		}
		this._readableState.buffer.clear();
		if (content !== "") this._readableState.buffer.push(content);
		this._readableState.length = content.length;
		return this;
	};
	var MAX_HWM = 1073741824;
	function computeNewHighWaterMark(n) {
		if (n >= MAX_HWM) n = MAX_HWM;
		else {
			n--;
			n |= n >>> 1;
			n |= n >>> 2;
			n |= n >>> 4;
			n |= n >>> 8;
			n |= n >>> 16;
			n++;
		}
		return n;
	}
	function howMuchToRead(n, state) {
		if (n <= 0 || state.length === 0 && state.ended) return 0;
		if (state.objectMode) return 1;
		if (n !== n) if (state.flowing && state.length) return state.buffer.head.data.length;
		else return state.length;
		if (n > state.highWaterMark) state.highWaterMark = computeNewHighWaterMark(n);
		if (n <= state.length) return n;
		if (!state.ended) {
			state.needReadable = true;
			return 0;
		}
		return state.length;
	}
	Readable.prototype.read = function(n) {
		debug("read", n);
		n = parseInt(n, 10);
		var state = this._readableState;
		var nOrig = n;
		if (n !== 0) state.emittedReadable = false;
		if (n === 0 && state.needReadable && ((state.highWaterMark !== 0 ? state.length >= state.highWaterMark : state.length > 0) || state.ended)) {
			debug("read: emitReadable", state.length, state.ended);
			if (state.length === 0 && state.ended) endReadable(this);
			else emitReadable(this);
			return null;
		}
		n = howMuchToRead(n, state);
		if (n === 0 && state.ended) {
			if (state.length === 0) endReadable(this);
			return null;
		}
		var doRead = state.needReadable;
		debug("need readable", doRead);
		if (state.length === 0 || state.length - n < state.highWaterMark) {
			doRead = true;
			debug("length less than watermark", doRead);
		}
		if (state.ended || state.reading) {
			doRead = false;
			debug("reading or ended", doRead);
		} else if (doRead) {
			debug("do read");
			state.reading = true;
			state.sync = true;
			if (state.length === 0) state.needReadable = true;
			this._read(state.highWaterMark);
			state.sync = false;
			if (!state.reading) n = howMuchToRead(nOrig, state);
		}
		var ret;
		if (n > 0) ret = fromList(n, state);
		else ret = null;
		if (ret === null) {
			state.needReadable = state.length <= state.highWaterMark;
			n = 0;
		} else {
			state.length -= n;
			state.awaitDrain = 0;
		}
		if (state.length === 0) {
			if (!state.ended) state.needReadable = true;
			if (nOrig !== n && state.ended) endReadable(this);
		}
		if (ret !== null) this.emit("data", ret);
		return ret;
	};
	function onEofChunk(stream, state) {
		debug("onEofChunk");
		if (state.ended) return;
		if (state.decoder) {
			var chunk = state.decoder.end();
			if (chunk && chunk.length) {
				state.buffer.push(chunk);
				state.length += state.objectMode ? 1 : chunk.length;
			}
		}
		state.ended = true;
		if (state.sync) emitReadable(stream);
		else {
			state.needReadable = false;
			if (!state.emittedReadable) {
				state.emittedReadable = true;
				emitReadable_(stream);
			}
		}
	}
	function emitReadable(stream) {
		var state = stream._readableState;
		debug("emitReadable", state.needReadable, state.emittedReadable);
		state.needReadable = false;
		if (!state.emittedReadable) {
			debug("emitReadable", state.flowing);
			state.emittedReadable = true;
			process$1.nextTick(emitReadable_, stream);
		}
	}
	function emitReadable_(stream) {
		var state = stream._readableState;
		debug("emitReadable_", state.destroyed, state.length, state.ended);
		if (!state.destroyed && (state.length || state.ended)) {
			stream.emit("readable");
			state.emittedReadable = false;
		}
		state.needReadable = !state.flowing && !state.ended && state.length <= state.highWaterMark;
		flow(stream);
	}
	function maybeReadMore(stream, state) {
		if (!state.readingMore) {
			state.readingMore = true;
			process$1.nextTick(maybeReadMore_, stream, state);
		}
	}
	function maybeReadMore_(stream, state) {
		while (!state.reading && !state.ended && (state.length < state.highWaterMark || state.flowing && state.length === 0)) {
			var len = state.length;
			debug("maybeReadMore read 0");
			stream.read(0);
			if (len === state.length) break;
		}
		state.readingMore = false;
	}
	Readable.prototype._read = function(n) {
		errorOrDestroy(this, new ERR_METHOD_NOT_IMPLEMENTED("_read()"));
	};
	Readable.prototype.pipe = function(dest, pipeOpts) {
		var src = this;
		var state = this._readableState;
		switch (state.pipesCount) {
			case 0:
				state.pipes = dest;
				break;
			case 1:
				state.pipes = [state.pipes, dest];
				break;
			default: state.pipes.push(dest);
		}
		state.pipesCount += 1;
		debug("pipe count=%d opts=%j", state.pipesCount, pipeOpts);
		var endFn = (!pipeOpts || pipeOpts.end !== false) && dest !== process$1.stdout && dest !== process$1.stderr ? onend : unpipe;
		if (state.endEmitted) process$1.nextTick(endFn);
		else src.once("end", endFn);
		dest.on("unpipe", onunpipe);
		function onunpipe(readable, unpipeInfo) {
			debug("onunpipe");
			if (readable === src) {
				if (unpipeInfo && unpipeInfo.hasUnpiped === false) {
					unpipeInfo.hasUnpiped = true;
					cleanup();
				}
			}
		}
		function onend() {
			debug("onend");
			dest.end();
		}
		var ondrain = pipeOnDrain(src);
		dest.on("drain", ondrain);
		var cleanedUp = false;
		function cleanup() {
			debug("cleanup");
			dest.removeListener("close", onclose);
			dest.removeListener("finish", onfinish);
			dest.removeListener("drain", ondrain);
			dest.removeListener("error", onerror);
			dest.removeListener("unpipe", onunpipe);
			src.removeListener("end", onend);
			src.removeListener("end", unpipe);
			src.removeListener("data", ondata);
			cleanedUp = true;
			if (state.awaitDrain && (!dest._writableState || dest._writableState.needDrain)) ondrain();
		}
		src.on("data", ondata);
		function ondata(chunk) {
			debug("ondata");
			var ret = dest.write(chunk);
			debug("dest.write", ret);
			if (ret === false) {
				if ((state.pipesCount === 1 && state.pipes === dest || state.pipesCount > 1 && indexOf(state.pipes, dest) !== -1) && !cleanedUp) {
					debug("false write response, pause", state.awaitDrain);
					state.awaitDrain++;
				}
				src.pause();
			}
		}
		function onerror(er) {
			debug("onerror", er);
			unpipe();
			dest.removeListener("error", onerror);
			if (EElistenerCount(dest, "error") === 0) errorOrDestroy(dest, er);
		}
		prependListener(dest, "error", onerror);
		function onclose() {
			dest.removeListener("finish", onfinish);
			unpipe();
		}
		dest.once("close", onclose);
		function onfinish() {
			debug("onfinish");
			dest.removeListener("close", onclose);
			unpipe();
		}
		dest.once("finish", onfinish);
		function unpipe() {
			debug("unpipe");
			src.unpipe(dest);
		}
		dest.emit("pipe", src);
		if (!state.flowing) {
			debug("pipe resume");
			src.resume();
		}
		return dest;
	};
	function pipeOnDrain(src) {
		return function pipeOnDrainFunctionResult() {
			var state = src._readableState;
			debug("pipeOnDrain", state.awaitDrain);
			if (state.awaitDrain) state.awaitDrain--;
			if (state.awaitDrain === 0 && EElistenerCount(src, "data")) {
				state.flowing = true;
				flow(src);
			}
		};
	}
	Readable.prototype.unpipe = function(dest) {
		var state = this._readableState;
		var unpipeInfo = { hasUnpiped: false };
		if (state.pipesCount === 0) return this;
		if (state.pipesCount === 1) {
			if (dest && dest !== state.pipes) return this;
			if (!dest) dest = state.pipes;
			state.pipes = null;
			state.pipesCount = 0;
			state.flowing = false;
			if (dest) dest.emit("unpipe", this, unpipeInfo);
			return this;
		}
		if (!dest) {
			var dests = state.pipes;
			var len = state.pipesCount;
			state.pipes = null;
			state.pipesCount = 0;
			state.flowing = false;
			for (var i = 0; i < len; i++) dests[i].emit("unpipe", this, { hasUnpiped: false });
			return this;
		}
		var index = indexOf(state.pipes, dest);
		if (index === -1) return this;
		state.pipes.splice(index, 1);
		state.pipesCount -= 1;
		if (state.pipesCount === 1) state.pipes = state.pipes[0];
		dest.emit("unpipe", this, unpipeInfo);
		return this;
	};
	Readable.prototype.on = function(ev, fn) {
		var res = Stream.prototype.on.call(this, ev, fn);
		var state = this._readableState;
		if (ev === "data") {
			state.readableListening = this.listenerCount("readable") > 0;
			if (state.flowing !== false) this.resume();
		} else if (ev === "readable") {
			if (!state.endEmitted && !state.readableListening) {
				state.readableListening = state.needReadable = true;
				state.flowing = false;
				state.emittedReadable = false;
				debug("on readable", state.length, state.reading);
				if (state.length) emitReadable(this);
				else if (!state.reading) process$1.nextTick(nReadingNextTick, this);
			}
		}
		return res;
	};
	Readable.prototype.addListener = Readable.prototype.on;
	Readable.prototype.removeListener = function(ev, fn) {
		var res = Stream.prototype.removeListener.call(this, ev, fn);
		if (ev === "readable") process$1.nextTick(updateReadableListening, this);
		return res;
	};
	Readable.prototype.removeAllListeners = function(ev) {
		var res = Stream.prototype.removeAllListeners.apply(this, arguments);
		if (ev === "readable" || ev === void 0) process$1.nextTick(updateReadableListening, this);
		return res;
	};
	function updateReadableListening(self) {
		var state = self._readableState;
		state.readableListening = self.listenerCount("readable") > 0;
		if (state.resumeScheduled && !state.paused) state.flowing = true;
		else if (self.listenerCount("data") > 0) self.resume();
	}
	function nReadingNextTick(self) {
		debug("readable nexttick read 0");
		self.read(0);
	}
	Readable.prototype.resume = function() {
		var state = this._readableState;
		if (!state.flowing) {
			debug("resume");
			state.flowing = !state.readableListening;
			resume(this, state);
		}
		state.paused = false;
		return this;
	};
	function resume(stream, state) {
		if (!state.resumeScheduled) {
			state.resumeScheduled = true;
			process$1.nextTick(resume_, stream, state);
		}
	}
	function resume_(stream, state) {
		debug("resume", state.reading);
		if (!state.reading) stream.read(0);
		state.resumeScheduled = false;
		stream.emit("resume");
		flow(stream);
		if (state.flowing && !state.reading) stream.read(0);
	}
	Readable.prototype.pause = function() {
		debug("call pause flowing=%j", this._readableState.flowing);
		if (this._readableState.flowing !== false) {
			debug("pause");
			this._readableState.flowing = false;
			this.emit("pause");
		}
		this._readableState.paused = true;
		return this;
	};
	function flow(stream) {
		var state = stream._readableState;
		debug("flow", state.flowing);
		while (state.flowing && stream.read() !== null);
	}
	Readable.prototype.wrap = function(stream) {
		var _this = this;
		var state = this._readableState;
		var paused = false;
		stream.on("end", function() {
			debug("wrapped end");
			if (state.decoder && !state.ended) {
				var chunk = state.decoder.end();
				if (chunk && chunk.length) _this.push(chunk);
			}
			_this.push(null);
		});
		stream.on("data", function(chunk) {
			debug("wrapped data");
			if (state.decoder) chunk = state.decoder.write(chunk);
			if (state.objectMode && (chunk === null || chunk === void 0)) return;
			else if (!state.objectMode && (!chunk || !chunk.length)) return;
			if (!_this.push(chunk)) {
				paused = true;
				stream.pause();
			}
		});
		for (var i in stream) if (this[i] === void 0 && typeof stream[i] === "function") this[i] = function methodWrap(method) {
			return function methodWrapReturnFunction() {
				return stream[method].apply(stream, arguments);
			};
		}(i);
		for (var n = 0; n < kProxyEvents.length; n++) stream.on(kProxyEvents[n], this.emit.bind(this, kProxyEvents[n]));
		this._read = function(n) {
			debug("wrapped _read", n);
			if (paused) {
				paused = false;
				stream.resume();
			}
		};
		return this;
	};
	if (typeof Symbol === "function") Readable.prototype[Symbol.asyncIterator] = function() {
		if (createReadableStreamAsyncIterator === void 0) createReadableStreamAsyncIterator = require_async_iterator();
		return createReadableStreamAsyncIterator(this);
	};
	Object.defineProperty(Readable.prototype, "readableHighWaterMark", {
		enumerable: false,
		get: function get() {
			return this._readableState.highWaterMark;
		}
	});
	Object.defineProperty(Readable.prototype, "readableBuffer", {
		enumerable: false,
		get: function get() {
			return this._readableState && this._readableState.buffer;
		}
	});
	Object.defineProperty(Readable.prototype, "readableFlowing", {
		enumerable: false,
		get: function get() {
			return this._readableState.flowing;
		},
		set: function set(state) {
			if (this._readableState) this._readableState.flowing = state;
		}
	});
	Readable._fromList = fromList;
	Object.defineProperty(Readable.prototype, "readableLength", {
		enumerable: false,
		get: function get() {
			return this._readableState.length;
		}
	});
	function fromList(n, state) {
		if (state.length === 0) return null;
		var ret;
		if (state.objectMode) ret = state.buffer.shift();
		else if (!n || n >= state.length) {
			if (state.decoder) ret = state.buffer.join("");
			else if (state.buffer.length === 1) ret = state.buffer.first();
			else ret = state.buffer.concat(state.length);
			state.buffer.clear();
		} else ret = state.buffer.consume(n, state.decoder);
		return ret;
	}
	function endReadable(stream) {
		var state = stream._readableState;
		debug("endReadable", state.endEmitted);
		if (!state.endEmitted) {
			state.ended = true;
			process$1.nextTick(endReadableNT, state, stream);
		}
	}
	function endReadableNT(state, stream) {
		debug("endReadableNT", state.endEmitted, state.length);
		if (!state.endEmitted && state.length === 0) {
			state.endEmitted = true;
			stream.readable = false;
			stream.emit("end");
			if (state.autoDestroy) {
				var wState = stream._writableState;
				if (!wState || wState.autoDestroy && wState.finished) stream.destroy();
			}
		}
	}
	if (typeof Symbol === "function") Readable.from = function(iterable, opts) {
		if (from === void 0) from = require_from_browser();
		return from(Readable, iterable, opts);
	};
	function indexOf(xs, x) {
		for (var i = 0, l = xs.length; i < l; i++) if (xs[i] === x) return i;
		return -1;
	}
}));
var require__stream_transform = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = Transform;
	var _require$codes = require_errors_browser().codes, ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED, ERR_MULTIPLE_CALLBACK = _require$codes.ERR_MULTIPLE_CALLBACK, ERR_TRANSFORM_ALREADY_TRANSFORMING = _require$codes.ERR_TRANSFORM_ALREADY_TRANSFORMING, ERR_TRANSFORM_WITH_LENGTH_0 = _require$codes.ERR_TRANSFORM_WITH_LENGTH_0;
	var Duplex = require__stream_duplex();
	require_inherits_browser()(Transform, Duplex);
	function afterTransform(er, data) {
		var ts = this._transformState;
		ts.transforming = false;
		var cb = ts.writecb;
		if (cb === null) return this.emit("error", new ERR_MULTIPLE_CALLBACK());
		ts.writechunk = null;
		ts.writecb = null;
		if (data != null) this.push(data);
		cb(er);
		var rs = this._readableState;
		rs.reading = false;
		if (rs.needReadable || rs.length < rs.highWaterMark) this._read(rs.highWaterMark);
	}
	function Transform(options) {
		if (!(this instanceof Transform)) return new Transform(options);
		Duplex.call(this, options);
		this._transformState = {
			afterTransform: afterTransform.bind(this),
			needTransform: false,
			transforming: false,
			writecb: null,
			writechunk: null,
			writeencoding: null
		};
		this._readableState.needReadable = true;
		this._readableState.sync = false;
		if (options) {
			if (typeof options.transform === "function") this._transform = options.transform;
			if (typeof options.flush === "function") this._flush = options.flush;
		}
		this.on("prefinish", prefinish);
	}
	function prefinish() {
		var _this = this;
		if (typeof this._flush === "function" && !this._readableState.destroyed) this._flush(function(er, data) {
			done(_this, er, data);
		});
		else done(this, null, null);
	}
	Transform.prototype.push = function(chunk, encoding) {
		this._transformState.needTransform = false;
		return Duplex.prototype.push.call(this, chunk, encoding);
	};
	Transform.prototype._transform = function(chunk, encoding, cb) {
		cb(new ERR_METHOD_NOT_IMPLEMENTED("_transform()"));
	};
	Transform.prototype._write = function(chunk, encoding, cb) {
		var ts = this._transformState;
		ts.writecb = cb;
		ts.writechunk = chunk;
		ts.writeencoding = encoding;
		if (!ts.transforming) {
			var rs = this._readableState;
			if (ts.needTransform || rs.needReadable || rs.length < rs.highWaterMark) this._read(rs.highWaterMark);
		}
	};
	Transform.prototype._read = function(n) {
		var ts = this._transformState;
		if (ts.writechunk !== null && !ts.transforming) {
			ts.transforming = true;
			this._transform(ts.writechunk, ts.writeencoding, ts.afterTransform);
		} else ts.needTransform = true;
	};
	Transform.prototype._destroy = function(err, cb) {
		Duplex.prototype._destroy.call(this, err, function(err2) {
			cb(err2);
		});
	};
	function done(stream, er, data) {
		if (er) return stream.emit("error", er);
		if (data != null) stream.push(data);
		if (stream._writableState.length) throw new ERR_TRANSFORM_WITH_LENGTH_0();
		if (stream._transformState.transforming) throw new ERR_TRANSFORM_ALREADY_TRANSFORMING();
		return stream.push(null);
	}
}));
var require__stream_passthrough = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = PassThrough;
	var Transform = require__stream_transform();
	require_inherits_browser()(PassThrough, Transform);
	function PassThrough(options) {
		if (!(this instanceof PassThrough)) return new PassThrough(options);
		Transform.call(this, options);
	}
	PassThrough.prototype._transform = function(chunk, encoding, cb) {
		cb(null, chunk);
	};
}));
var require_pipeline = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var eos;
	function once(callback) {
		var called = false;
		return function() {
			if (called) return;
			called = true;
			callback.apply(void 0, arguments);
		};
	}
	var _require$codes = require_errors_browser().codes, ERR_MISSING_ARGS = _require$codes.ERR_MISSING_ARGS, ERR_STREAM_DESTROYED = _require$codes.ERR_STREAM_DESTROYED;
	function noop(err) {
		if (err) throw err;
	}
	function isRequest(stream) {
		return stream.setHeader && typeof stream.abort === "function";
	}
	function destroyer(stream, reading, writing, callback) {
		callback = once(callback);
		var closed = false;
		stream.on("close", function() {
			closed = true;
		});
		if (eos === void 0) eos = require_end_of_stream();
		eos(stream, {
			readable: reading,
			writable: writing
		}, function(err) {
			if (err) return callback(err);
			closed = true;
			callback();
		});
		var destroyed = false;
		return function(err) {
			if (closed) return;
			if (destroyed) return;
			destroyed = true;
			if (isRequest(stream)) return stream.abort();
			if (typeof stream.destroy === "function") return stream.destroy();
			callback(err || new ERR_STREAM_DESTROYED("pipe"));
		};
	}
	function call(fn) {
		fn();
	}
	function pipe(from, to) {
		return from.pipe(to);
	}
	function popCallback(streams) {
		if (!streams.length) return noop;
		if (typeof streams[streams.length - 1] !== "function") return noop;
		return streams.pop();
	}
	function pipeline() {
		for (var _len = arguments.length, streams = new Array(_len), _key = 0; _key < _len; _key++) streams[_key] = arguments[_key];
		var callback = popCallback(streams);
		if (Array.isArray(streams[0])) streams = streams[0];
		if (streams.length < 2) throw new ERR_MISSING_ARGS("streams");
		var error;
		var destroys = streams.map(function(stream, i) {
			var reading = i < streams.length - 1;
			return destroyer(stream, reading, i > 0, function(err) {
				if (!error) error = err;
				if (err) destroys.forEach(call);
				if (reading) return;
				destroys.forEach(call);
				callback(error);
			});
		});
		return streams.reduce(pipe);
	}
	module.exports = pipeline;
}));
var require_stream_browserify = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = Stream;
	var EE = require_events().EventEmitter;
	require_inherits_browser()(Stream, EE);
	Stream.Readable = require__stream_readable();
	Stream.Writable = require__stream_writable();
	Stream.Duplex = require__stream_duplex();
	Stream.Transform = require__stream_transform();
	Stream.PassThrough = require__stream_passthrough();
	Stream.finished = require_end_of_stream();
	Stream.pipeline = require_pipeline();
	Stream.Stream = Stream;
	function Stream() {
		EE.call(this);
	}
	Stream.prototype.pipe = function(dest, options) {
		var source = this;
		function ondata(chunk) {
			if (dest.writable) {
				if (false === dest.write(chunk) && source.pause) source.pause();
			}
		}
		source.on("data", ondata);
		function ondrain() {
			if (source.readable && source.resume) source.resume();
		}
		dest.on("drain", ondrain);
		if (!dest._isStdio && (!options || options.end !== false)) {
			source.on("end", onend);
			source.on("close", onclose);
		}
		var didOnEnd = false;
		function onend() {
			if (didOnEnd) return;
			didOnEnd = true;
			dest.end();
		}
		function onclose() {
			if (didOnEnd) return;
			didOnEnd = true;
			if (typeof dest.destroy === "function") dest.destroy();
		}
		function onerror(er) {
			cleanup();
			if (EE.listenerCount(this, "error") === 0) throw er;
		}
		source.on("error", onerror);
		dest.on("error", onerror);
		function cleanup() {
			source.removeListener("data", ondata);
			dest.removeListener("drain", ondrain);
			source.removeListener("end", onend);
			source.removeListener("close", onclose);
			source.removeListener("error", onerror);
			dest.removeListener("error", onerror);
			source.removeListener("end", cleanup);
			source.removeListener("close", cleanup);
			dest.removeListener("close", cleanup);
		}
		source.on("end", cleanup);
		source.on("close", cleanup);
		dest.on("close", cleanup);
		dest.emit("pipe", source);
		return dest;
	};
}));
var require_sax = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function(sax) {
		sax.parser = function(strict, opt) {
			return new SAXParser(strict, opt);
		};
		sax.SAXParser = SAXParser;
		sax.SAXStream = SAXStream;
		sax.createStream = createStream;
		sax.MAX_BUFFER_LENGTH = 65536;
		var buffers = [
			"comment",
			"sgmlDecl",
			"textNode",
			"tagName",
			"doctype",
			"procInstName",
			"procInstBody",
			"entity",
			"attribName",
			"attribValue",
			"cdata",
			"script"
		];
		sax.EVENTS = [
			"text",
			"processinginstruction",
			"sgmldeclaration",
			"doctype",
			"comment",
			"opentagstart",
			"attribute",
			"opentag",
			"closetag",
			"opencdata",
			"cdata",
			"closecdata",
			"error",
			"end",
			"ready",
			"script",
			"opennamespace",
			"closenamespace"
		];
		function SAXParser(strict, opt) {
			if (!(this instanceof SAXParser)) return new SAXParser(strict, opt);
			var parser = this;
			clearBuffers(parser);
			parser.q = parser.c = "";
			parser.bufferCheckPosition = sax.MAX_BUFFER_LENGTH;
			parser.opt = opt || {};
			parser.opt.lowercase = parser.opt.lowercase || parser.opt.lowercasetags;
			parser.looseCase = parser.opt.lowercase ? "toLowerCase" : "toUpperCase";
			parser.tags = [];
			parser.closed = parser.closedRoot = parser.sawRoot = false;
			parser.tag = parser.error = null;
			parser.strict = !!strict;
			parser.noscript = !!(strict || parser.opt.noscript);
			parser.state = S.BEGIN;
			parser.strictEntities = parser.opt.strictEntities;
			parser.ENTITIES = parser.strictEntities ? Object.create(sax.XML_ENTITIES) : Object.create(sax.ENTITIES);
			parser.attribList = [];
			if (parser.opt.xmlns) parser.ns = Object.create(rootNS);
			parser.trackPosition = parser.opt.position !== false;
			if (parser.trackPosition) parser.position = parser.line = parser.column = 0;
			emit(parser, "onready");
		}
		if (!Object.create) Object.create = function(o) {
			function F() {}
			F.prototype = o;
			return new F();
		};
		if (!Object.keys) Object.keys = function(o) {
			var a = [];
			for (var i in o) if (o.hasOwnProperty(i)) a.push(i);
			return a;
		};
		function checkBufferLength(parser) {
			var maxAllowed = Math.max(sax.MAX_BUFFER_LENGTH, 10);
			var maxActual = 0;
			for (var i = 0, l = buffers.length; i < l; i++) {
				var len = parser[buffers[i]].length;
				if (len > maxAllowed) switch (buffers[i]) {
					case "textNode":
						closeText(parser);
						break;
					case "cdata":
						emitNode(parser, "oncdata", parser.cdata);
						parser.cdata = "";
						break;
					case "script":
						emitNode(parser, "onscript", parser.script);
						parser.script = "";
						break;
					default: error(parser, "Max buffer length exceeded: " + buffers[i]);
				}
				maxActual = Math.max(maxActual, len);
			}
			parser.bufferCheckPosition = sax.MAX_BUFFER_LENGTH - maxActual + parser.position;
		}
		function clearBuffers(parser) {
			for (var i = 0, l = buffers.length; i < l; i++) parser[buffers[i]] = "";
		}
		function flushBuffers(parser) {
			closeText(parser);
			if (parser.cdata !== "") {
				emitNode(parser, "oncdata", parser.cdata);
				parser.cdata = "";
			}
			if (parser.script !== "") {
				emitNode(parser, "onscript", parser.script);
				parser.script = "";
			}
		}
		SAXParser.prototype = {
			end: function() {
				end(this);
			},
			write,
			resume: function() {
				this.error = null;
				return this;
			},
			close: function() {
				return this.write(null);
			},
			flush: function() {
				flushBuffers(this);
			}
		};
		var Stream;
		try {
			Stream = require_stream_browserify().Stream;
		} catch (ex) {
			Stream = function() {};
		}
		var streamWraps = sax.EVENTS.filter(function(ev) {
			return ev !== "error" && ev !== "end";
		});
		function createStream(strict, opt) {
			return new SAXStream(strict, opt);
		}
		function SAXStream(strict, opt) {
			if (!(this instanceof SAXStream)) return new SAXStream(strict, opt);
			Stream.apply(this);
			this._parser = new SAXParser(strict, opt);
			this.writable = true;
			this.readable = true;
			var me = this;
			this._parser.onend = function() {
				me.emit("end");
			};
			this._parser.onerror = function(er) {
				me.emit("error", er);
				me._parser.error = null;
			};
			this._decoder = null;
			streamWraps.forEach(function(ev) {
				Object.defineProperty(me, "on" + ev, {
					get: function() {
						return me._parser["on" + ev];
					},
					set: function(h) {
						if (!h) {
							me.removeAllListeners(ev);
							me._parser["on" + ev] = h;
							return h;
						}
						me.on(ev, h);
					},
					enumerable: true,
					configurable: false
				});
			});
		}
		SAXStream.prototype = Object.create(Stream.prototype, { constructor: { value: SAXStream } });
		SAXStream.prototype.write = function(data) {
			if (typeof Buffer === "function" && typeof Buffer.isBuffer === "function" && Buffer.isBuffer(data)) {
				if (!this._decoder) {
					var SD = require_string_decoder().StringDecoder;
					this._decoder = new SD("utf8");
				}
				data = this._decoder.write(data);
			}
			this._parser.write(data.toString());
			this.emit("data", data);
			return true;
		};
		SAXStream.prototype.end = function(chunk) {
			if (chunk && chunk.length) this.write(chunk);
			this._parser.end();
			return true;
		};
		SAXStream.prototype.on = function(ev, handler) {
			var me = this;
			if (!me._parser["on" + ev] && streamWraps.indexOf(ev) !== -1) me._parser["on" + ev] = function() {
				var args = arguments.length === 1 ? [arguments[0]] : Array.apply(null, arguments);
				args.splice(0, 0, ev);
				me.emit.apply(me, args);
			};
			return Stream.prototype.on.call(me, ev, handler);
		};
		var CDATA = "[CDATA[";
		var DOCTYPE = "DOCTYPE";
		var XML_NAMESPACE = "http://www.w3.org/XML/1998/namespace";
		var XMLNS_NAMESPACE = "http://www.w3.org/2000/xmlns/";
		var rootNS = {
			xml: XML_NAMESPACE,
			xmlns: XMLNS_NAMESPACE
		};
		var nameStart = /[:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;
		var nameBody = /[:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u00B7\u0300-\u036F\u203F-\u2040.\d-]/;
		var entityStart = /[#:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;
		var entityBody = /[#:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u00B7\u0300-\u036F\u203F-\u2040.\d-]/;
		function isWhitespace(c) {
			return c === " " || c === "\n" || c === "\r" || c === "	";
		}
		function isQuote(c) {
			return c === "\"" || c === "'";
		}
		function isAttribEnd(c) {
			return c === ">" || isWhitespace(c);
		}
		function isMatch(regex, c) {
			return regex.test(c);
		}
		function notMatch(regex, c) {
			return !isMatch(regex, c);
		}
		var S = 0;
		sax.STATE = {
			BEGIN: S++,
			BEGIN_WHITESPACE: S++,
			TEXT: S++,
			TEXT_ENTITY: S++,
			OPEN_WAKA: S++,
			SGML_DECL: S++,
			SGML_DECL_QUOTED: S++,
			DOCTYPE: S++,
			DOCTYPE_QUOTED: S++,
			DOCTYPE_DTD: S++,
			DOCTYPE_DTD_QUOTED: S++,
			COMMENT_STARTING: S++,
			COMMENT: S++,
			COMMENT_ENDING: S++,
			COMMENT_ENDED: S++,
			CDATA: S++,
			CDATA_ENDING: S++,
			CDATA_ENDING_2: S++,
			PROC_INST: S++,
			PROC_INST_BODY: S++,
			PROC_INST_ENDING: S++,
			OPEN_TAG: S++,
			OPEN_TAG_SLASH: S++,
			ATTRIB: S++,
			ATTRIB_NAME: S++,
			ATTRIB_NAME_SAW_WHITE: S++,
			ATTRIB_VALUE: S++,
			ATTRIB_VALUE_QUOTED: S++,
			ATTRIB_VALUE_CLOSED: S++,
			ATTRIB_VALUE_UNQUOTED: S++,
			ATTRIB_VALUE_ENTITY_Q: S++,
			ATTRIB_VALUE_ENTITY_U: S++,
			CLOSE_TAG: S++,
			CLOSE_TAG_SAW_WHITE: S++,
			SCRIPT: S++,
			SCRIPT_ENDING: S++
		};
		sax.XML_ENTITIES = {
			"amp": "&",
			"gt": ">",
			"lt": "<",
			"quot": "\"",
			"apos": "'"
		};
		sax.ENTITIES = {
			"amp": "&",
			"gt": ">",
			"lt": "<",
			"quot": "\"",
			"apos": "'",
			"AElig": 198,
			"Aacute": 193,
			"Acirc": 194,
			"Agrave": 192,
			"Aring": 197,
			"Atilde": 195,
			"Auml": 196,
			"Ccedil": 199,
			"ETH": 208,
			"Eacute": 201,
			"Ecirc": 202,
			"Egrave": 200,
			"Euml": 203,
			"Iacute": 205,
			"Icirc": 206,
			"Igrave": 204,
			"Iuml": 207,
			"Ntilde": 209,
			"Oacute": 211,
			"Ocirc": 212,
			"Ograve": 210,
			"Oslash": 216,
			"Otilde": 213,
			"Ouml": 214,
			"THORN": 222,
			"Uacute": 218,
			"Ucirc": 219,
			"Ugrave": 217,
			"Uuml": 220,
			"Yacute": 221,
			"aacute": 225,
			"acirc": 226,
			"aelig": 230,
			"agrave": 224,
			"aring": 229,
			"atilde": 227,
			"auml": 228,
			"ccedil": 231,
			"eacute": 233,
			"ecirc": 234,
			"egrave": 232,
			"eth": 240,
			"euml": 235,
			"iacute": 237,
			"icirc": 238,
			"igrave": 236,
			"iuml": 239,
			"ntilde": 241,
			"oacute": 243,
			"ocirc": 244,
			"ograve": 242,
			"oslash": 248,
			"otilde": 245,
			"ouml": 246,
			"szlig": 223,
			"thorn": 254,
			"uacute": 250,
			"ucirc": 251,
			"ugrave": 249,
			"uuml": 252,
			"yacute": 253,
			"yuml": 255,
			"copy": 169,
			"reg": 174,
			"nbsp": 160,
			"iexcl": 161,
			"cent": 162,
			"pound": 163,
			"curren": 164,
			"yen": 165,
			"brvbar": 166,
			"sect": 167,
			"uml": 168,
			"ordf": 170,
			"laquo": 171,
			"not": 172,
			"shy": 173,
			"macr": 175,
			"deg": 176,
			"plusmn": 177,
			"sup1": 185,
			"sup2": 178,
			"sup3": 179,
			"acute": 180,
			"micro": 181,
			"para": 182,
			"middot": 183,
			"cedil": 184,
			"ordm": 186,
			"raquo": 187,
			"frac14": 188,
			"frac12": 189,
			"frac34": 190,
			"iquest": 191,
			"times": 215,
			"divide": 247,
			"OElig": 338,
			"oelig": 339,
			"Scaron": 352,
			"scaron": 353,
			"Yuml": 376,
			"fnof": 402,
			"circ": 710,
			"tilde": 732,
			"Alpha": 913,
			"Beta": 914,
			"Gamma": 915,
			"Delta": 916,
			"Epsilon": 917,
			"Zeta": 918,
			"Eta": 919,
			"Theta": 920,
			"Iota": 921,
			"Kappa": 922,
			"Lambda": 923,
			"Mu": 924,
			"Nu": 925,
			"Xi": 926,
			"Omicron": 927,
			"Pi": 928,
			"Rho": 929,
			"Sigma": 931,
			"Tau": 932,
			"Upsilon": 933,
			"Phi": 934,
			"Chi": 935,
			"Psi": 936,
			"Omega": 937,
			"alpha": 945,
			"beta": 946,
			"gamma": 947,
			"delta": 948,
			"epsilon": 949,
			"zeta": 950,
			"eta": 951,
			"theta": 952,
			"iota": 953,
			"kappa": 954,
			"lambda": 955,
			"mu": 956,
			"nu": 957,
			"xi": 958,
			"omicron": 959,
			"pi": 960,
			"rho": 961,
			"sigmaf": 962,
			"sigma": 963,
			"tau": 964,
			"upsilon": 965,
			"phi": 966,
			"chi": 967,
			"psi": 968,
			"omega": 969,
			"thetasym": 977,
			"upsih": 978,
			"piv": 982,
			"ensp": 8194,
			"emsp": 8195,
			"thinsp": 8201,
			"zwnj": 8204,
			"zwj": 8205,
			"lrm": 8206,
			"rlm": 8207,
			"ndash": 8211,
			"mdash": 8212,
			"lsquo": 8216,
			"rsquo": 8217,
			"sbquo": 8218,
			"ldquo": 8220,
			"rdquo": 8221,
			"bdquo": 8222,
			"dagger": 8224,
			"Dagger": 8225,
			"bull": 8226,
			"hellip": 8230,
			"permil": 8240,
			"prime": 8242,
			"Prime": 8243,
			"lsaquo": 8249,
			"rsaquo": 8250,
			"oline": 8254,
			"frasl": 8260,
			"euro": 8364,
			"image": 8465,
			"weierp": 8472,
			"real": 8476,
			"trade": 8482,
			"alefsym": 8501,
			"larr": 8592,
			"uarr": 8593,
			"rarr": 8594,
			"darr": 8595,
			"harr": 8596,
			"crarr": 8629,
			"lArr": 8656,
			"uArr": 8657,
			"rArr": 8658,
			"dArr": 8659,
			"hArr": 8660,
			"forall": 8704,
			"part": 8706,
			"exist": 8707,
			"empty": 8709,
			"nabla": 8711,
			"isin": 8712,
			"notin": 8713,
			"ni": 8715,
			"prod": 8719,
			"sum": 8721,
			"minus": 8722,
			"lowast": 8727,
			"radic": 8730,
			"prop": 8733,
			"infin": 8734,
			"ang": 8736,
			"and": 8743,
			"or": 8744,
			"cap": 8745,
			"cup": 8746,
			"int": 8747,
			"there4": 8756,
			"sim": 8764,
			"cong": 8773,
			"asymp": 8776,
			"ne": 8800,
			"equiv": 8801,
			"le": 8804,
			"ge": 8805,
			"sub": 8834,
			"sup": 8835,
			"nsub": 8836,
			"sube": 8838,
			"supe": 8839,
			"oplus": 8853,
			"otimes": 8855,
			"perp": 8869,
			"sdot": 8901,
			"lceil": 8968,
			"rceil": 8969,
			"lfloor": 8970,
			"rfloor": 8971,
			"lang": 9001,
			"rang": 9002,
			"loz": 9674,
			"spades": 9824,
			"clubs": 9827,
			"hearts": 9829,
			"diams": 9830
		};
		Object.keys(sax.ENTITIES).forEach(function(key) {
			var e = sax.ENTITIES[key];
			var s = typeof e === "number" ? String.fromCharCode(e) : e;
			sax.ENTITIES[key] = s;
		});
		for (var s in sax.STATE) sax.STATE[sax.STATE[s]] = s;
		S = sax.STATE;
		function emit(parser, event, data) {
			parser[event] && parser[event](data);
		}
		function emitNode(parser, nodeType, data) {
			if (parser.textNode) closeText(parser);
			emit(parser, nodeType, data);
		}
		function closeText(parser) {
			parser.textNode = textopts(parser.opt, parser.textNode);
			if (parser.textNode) emit(parser, "ontext", parser.textNode);
			parser.textNode = "";
		}
		function textopts(opt, text) {
			if (opt.trim) text = text.trim();
			if (opt.normalize) text = text.replace(/\s+/g, " ");
			return text;
		}
		function error(parser, er) {
			closeText(parser);
			if (parser.trackPosition) er += "\nLine: " + parser.line + "\nColumn: " + parser.column + "\nChar: " + parser.c;
			er = new Error(er);
			parser.error = er;
			emit(parser, "onerror", er);
			return parser;
		}
		function end(parser) {
			if (parser.sawRoot && !parser.closedRoot) strictFail(parser, "Unclosed root tag");
			if (parser.state !== S.BEGIN && parser.state !== S.BEGIN_WHITESPACE && parser.state !== S.TEXT) error(parser, "Unexpected end");
			closeText(parser);
			parser.c = "";
			parser.closed = true;
			emit(parser, "onend");
			SAXParser.call(parser, parser.strict, parser.opt);
			return parser;
		}
		function strictFail(parser, message) {
			if (typeof parser !== "object" || !(parser instanceof SAXParser)) throw new Error("bad call to strictFail");
			if (parser.strict) error(parser, message);
		}
		function newTag(parser) {
			if (!parser.strict) parser.tagName = parser.tagName[parser.looseCase]();
			var parent = parser.tags[parser.tags.length - 1] || parser;
			var tag = parser.tag = {
				name: parser.tagName,
				attributes: {}
			};
			if (parser.opt.xmlns) tag.ns = parent.ns;
			parser.attribList.length = 0;
			emitNode(parser, "onopentagstart", tag);
		}
		function qname(name, attribute) {
			var qualName = name.indexOf(":") < 0 ? ["", name] : name.split(":");
			var prefix = qualName[0];
			var local = qualName[1];
			if (attribute && name === "xmlns") {
				prefix = "xmlns";
				local = "";
			}
			return {
				prefix,
				local
			};
		}
		function attrib(parser) {
			if (!parser.strict) parser.attribName = parser.attribName[parser.looseCase]();
			if (parser.attribList.indexOf(parser.attribName) !== -1 || parser.tag.attributes.hasOwnProperty(parser.attribName)) {
				parser.attribName = parser.attribValue = "";
				return;
			}
			if (parser.opt.xmlns) {
				var qn = qname(parser.attribName, true);
				var prefix = qn.prefix;
				var local = qn.local;
				if (prefix === "xmlns") if (local === "xml" && parser.attribValue !== XML_NAMESPACE) strictFail(parser, "xml: prefix must be bound to " + XML_NAMESPACE + "\nActual: " + parser.attribValue);
				else if (local === "xmlns" && parser.attribValue !== XMLNS_NAMESPACE) strictFail(parser, "xmlns: prefix must be bound to " + XMLNS_NAMESPACE + "\nActual: " + parser.attribValue);
				else {
					var tag = parser.tag;
					var parent = parser.tags[parser.tags.length - 1] || parser;
					if (tag.ns === parent.ns) tag.ns = Object.create(parent.ns);
					tag.ns[local] = parser.attribValue;
				}
				parser.attribList.push([parser.attribName, parser.attribValue]);
			} else {
				parser.tag.attributes[parser.attribName] = parser.attribValue;
				emitNode(parser, "onattribute", {
					name: parser.attribName,
					value: parser.attribValue
				});
			}
			parser.attribName = parser.attribValue = "";
		}
		function openTag(parser, selfClosing) {
			if (parser.opt.xmlns) {
				var tag = parser.tag;
				var qn = qname(parser.tagName);
				tag.prefix = qn.prefix;
				tag.local = qn.local;
				tag.uri = tag.ns[qn.prefix] || "";
				if (tag.prefix && !tag.uri) {
					strictFail(parser, "Unbound namespace prefix: " + JSON.stringify(parser.tagName));
					tag.uri = qn.prefix;
				}
				var parent = parser.tags[parser.tags.length - 1] || parser;
				if (tag.ns && parent.ns !== tag.ns) Object.keys(tag.ns).forEach(function(p) {
					emitNode(parser, "onopennamespace", {
						prefix: p,
						uri: tag.ns[p]
					});
				});
				for (var i = 0, l = parser.attribList.length; i < l; i++) {
					var nv = parser.attribList[i];
					var name = nv[0];
					var value = nv[1];
					var qualName = qname(name, true);
					var prefix = qualName.prefix;
					var local = qualName.local;
					var uri = prefix === "" ? "" : tag.ns[prefix] || "";
					var a = {
						name,
						value,
						prefix,
						local,
						uri
					};
					if (prefix && prefix !== "xmlns" && !uri) {
						strictFail(parser, "Unbound namespace prefix: " + JSON.stringify(prefix));
						a.uri = prefix;
					}
					parser.tag.attributes[name] = a;
					emitNode(parser, "onattribute", a);
				}
				parser.attribList.length = 0;
			}
			parser.tag.isSelfClosing = !!selfClosing;
			parser.sawRoot = true;
			parser.tags.push(parser.tag);
			emitNode(parser, "onopentag", parser.tag);
			if (!selfClosing) {
				if (!parser.noscript && parser.tagName.toLowerCase() === "script") parser.state = S.SCRIPT;
				else parser.state = S.TEXT;
				parser.tag = null;
				parser.tagName = "";
			}
			parser.attribName = parser.attribValue = "";
			parser.attribList.length = 0;
		}
		function closeTag(parser) {
			if (!parser.tagName) {
				strictFail(parser, "Weird empty close tag.");
				parser.textNode += "</>";
				parser.state = S.TEXT;
				return;
			}
			if (parser.script) {
				if (parser.tagName !== "script") {
					parser.script += "</" + parser.tagName + ">";
					parser.tagName = "";
					parser.state = S.SCRIPT;
					return;
				}
				emitNode(parser, "onscript", parser.script);
				parser.script = "";
			}
			var t = parser.tags.length;
			var tagName = parser.tagName;
			if (!parser.strict) tagName = tagName[parser.looseCase]();
			var closeTo = tagName;
			while (t--) if (parser.tags[t].name !== closeTo) strictFail(parser, "Unexpected close tag");
			else break;
			if (t < 0) {
				strictFail(parser, "Unmatched closing tag: " + parser.tagName);
				parser.textNode += "</" + parser.tagName + ">";
				parser.state = S.TEXT;
				return;
			}
			parser.tagName = tagName;
			var s = parser.tags.length;
			while (s-- > t) {
				var tag = parser.tag = parser.tags.pop();
				parser.tagName = parser.tag.name;
				emitNode(parser, "onclosetag", parser.tagName);
				var x = {};
				for (var i in tag.ns) x[i] = tag.ns[i];
				var parent = parser.tags[parser.tags.length - 1] || parser;
				if (parser.opt.xmlns && tag.ns !== parent.ns) Object.keys(tag.ns).forEach(function(p) {
					var n = tag.ns[p];
					emitNode(parser, "onclosenamespace", {
						prefix: p,
						uri: n
					});
				});
			}
			if (t === 0) parser.closedRoot = true;
			parser.tagName = parser.attribValue = parser.attribName = "";
			parser.attribList.length = 0;
			parser.state = S.TEXT;
		}
		function parseEntity(parser) {
			var entity = parser.entity;
			var entityLC = entity.toLowerCase();
			var num;
			var numStr = "";
			if (parser.ENTITIES[entity]) return parser.ENTITIES[entity];
			if (parser.ENTITIES[entityLC]) return parser.ENTITIES[entityLC];
			entity = entityLC;
			if (entity.charAt(0) === "#") if (entity.charAt(1) === "x") {
				entity = entity.slice(2);
				num = parseInt(entity, 16);
				numStr = num.toString(16);
			} else {
				entity = entity.slice(1);
				num = parseInt(entity, 10);
				numStr = num.toString(10);
			}
			entity = entity.replace(/^0+/, "");
			if (isNaN(num) || numStr.toLowerCase() !== entity) {
				strictFail(parser, "Invalid character entity");
				return "&" + parser.entity + ";";
			}
			return String.fromCodePoint(num);
		}
		function beginWhiteSpace(parser, c) {
			if (c === "<") {
				parser.state = S.OPEN_WAKA;
				parser.startTagPosition = parser.position;
			} else if (!isWhitespace(c)) {
				strictFail(parser, "Non-whitespace before first tag.");
				parser.textNode = c;
				parser.state = S.TEXT;
			}
		}
		function charAt(chunk, i) {
			var result = "";
			if (i < chunk.length) result = chunk.charAt(i);
			return result;
		}
		function write(chunk) {
			var parser = this;
			if (this.error) throw this.error;
			if (parser.closed) return error(parser, "Cannot write after close. Assign an onready handler.");
			if (chunk === null) return end(parser);
			if (typeof chunk === "object") chunk = chunk.toString();
			var i = 0;
			var c = "";
			while (true) {
				c = charAt(chunk, i++);
				parser.c = c;
				if (!c) break;
				if (parser.trackPosition) {
					parser.position++;
					if (c === "\n") {
						parser.line++;
						parser.column = 0;
					} else parser.column++;
				}
				switch (parser.state) {
					case S.BEGIN:
						parser.state = S.BEGIN_WHITESPACE;
						if (c === "﻿") continue;
						beginWhiteSpace(parser, c);
						continue;
					case S.BEGIN_WHITESPACE:
						beginWhiteSpace(parser, c);
						continue;
					case S.TEXT:
						if (parser.sawRoot && !parser.closedRoot) {
							var starti = i - 1;
							while (c && c !== "<" && c !== "&") {
								c = charAt(chunk, i++);
								if (c && parser.trackPosition) {
									parser.position++;
									if (c === "\n") {
										parser.line++;
										parser.column = 0;
									} else parser.column++;
								}
							}
							parser.textNode += chunk.substring(starti, i - 1);
						}
						if (c === "<" && !(parser.sawRoot && parser.closedRoot && !parser.strict)) {
							parser.state = S.OPEN_WAKA;
							parser.startTagPosition = parser.position;
						} else {
							if (!isWhitespace(c) && (!parser.sawRoot || parser.closedRoot)) strictFail(parser, "Text data outside of root node.");
							if (c === "&") parser.state = S.TEXT_ENTITY;
							else parser.textNode += c;
						}
						continue;
					case S.SCRIPT:
						if (c === "<") parser.state = S.SCRIPT_ENDING;
						else parser.script += c;
						continue;
					case S.SCRIPT_ENDING:
						if (c === "/") parser.state = S.CLOSE_TAG;
						else {
							parser.script += "<" + c;
							parser.state = S.SCRIPT;
						}
						continue;
					case S.OPEN_WAKA:
						if (c === "!") {
							parser.state = S.SGML_DECL;
							parser.sgmlDecl = "";
						} else if (isWhitespace(c)) {} else if (isMatch(nameStart, c)) {
							parser.state = S.OPEN_TAG;
							parser.tagName = c;
						} else if (c === "/") {
							parser.state = S.CLOSE_TAG;
							parser.tagName = "";
						} else if (c === "?") {
							parser.state = S.PROC_INST;
							parser.procInstName = parser.procInstBody = "";
						} else {
							strictFail(parser, "Unencoded <");
							if (parser.startTagPosition + 1 < parser.position) {
								var pad = parser.position - parser.startTagPosition;
								c = new Array(pad).join(" ") + c;
							}
							parser.textNode += "<" + c;
							parser.state = S.TEXT;
						}
						continue;
					case S.SGML_DECL:
						if ((parser.sgmlDecl + c).toUpperCase() === CDATA) {
							emitNode(parser, "onopencdata");
							parser.state = S.CDATA;
							parser.sgmlDecl = "";
							parser.cdata = "";
						} else if (parser.sgmlDecl + c === "--") {
							parser.state = S.COMMENT;
							parser.comment = "";
							parser.sgmlDecl = "";
						} else if ((parser.sgmlDecl + c).toUpperCase() === DOCTYPE) {
							parser.state = S.DOCTYPE;
							if (parser.doctype || parser.sawRoot) strictFail(parser, "Inappropriately located doctype declaration");
							parser.doctype = "";
							parser.sgmlDecl = "";
						} else if (c === ">") {
							emitNode(parser, "onsgmldeclaration", parser.sgmlDecl);
							parser.sgmlDecl = "";
							parser.state = S.TEXT;
						} else if (isQuote(c)) {
							parser.state = S.SGML_DECL_QUOTED;
							parser.sgmlDecl += c;
						} else parser.sgmlDecl += c;
						continue;
					case S.SGML_DECL_QUOTED:
						if (c === parser.q) {
							parser.state = S.SGML_DECL;
							parser.q = "";
						}
						parser.sgmlDecl += c;
						continue;
					case S.DOCTYPE:
						if (c === ">") {
							parser.state = S.TEXT;
							emitNode(parser, "ondoctype", parser.doctype);
							parser.doctype = true;
						} else {
							parser.doctype += c;
							if (c === "[") parser.state = S.DOCTYPE_DTD;
							else if (isQuote(c)) {
								parser.state = S.DOCTYPE_QUOTED;
								parser.q = c;
							}
						}
						continue;
					case S.DOCTYPE_QUOTED:
						parser.doctype += c;
						if (c === parser.q) {
							parser.q = "";
							parser.state = S.DOCTYPE;
						}
						continue;
					case S.DOCTYPE_DTD:
						parser.doctype += c;
						if (c === "]") parser.state = S.DOCTYPE;
						else if (isQuote(c)) {
							parser.state = S.DOCTYPE_DTD_QUOTED;
							parser.q = c;
						}
						continue;
					case S.DOCTYPE_DTD_QUOTED:
						parser.doctype += c;
						if (c === parser.q) {
							parser.state = S.DOCTYPE_DTD;
							parser.q = "";
						}
						continue;
					case S.COMMENT:
						if (c === "-") parser.state = S.COMMENT_ENDING;
						else parser.comment += c;
						continue;
					case S.COMMENT_ENDING:
						if (c === "-") {
							parser.state = S.COMMENT_ENDED;
							parser.comment = textopts(parser.opt, parser.comment);
							if (parser.comment) emitNode(parser, "oncomment", parser.comment);
							parser.comment = "";
						} else {
							parser.comment += "-" + c;
							parser.state = S.COMMENT;
						}
						continue;
					case S.COMMENT_ENDED:
						if (c !== ">") {
							strictFail(parser, "Malformed comment");
							parser.comment += "--" + c;
							parser.state = S.COMMENT;
						} else parser.state = S.TEXT;
						continue;
					case S.CDATA:
						if (c === "]") parser.state = S.CDATA_ENDING;
						else parser.cdata += c;
						continue;
					case S.CDATA_ENDING:
						if (c === "]") parser.state = S.CDATA_ENDING_2;
						else {
							parser.cdata += "]" + c;
							parser.state = S.CDATA;
						}
						continue;
					case S.CDATA_ENDING_2:
						if (c === ">") {
							if (parser.cdata) emitNode(parser, "oncdata", parser.cdata);
							emitNode(parser, "onclosecdata");
							parser.cdata = "";
							parser.state = S.TEXT;
						} else if (c === "]") parser.cdata += "]";
						else {
							parser.cdata += "]]" + c;
							parser.state = S.CDATA;
						}
						continue;
					case S.PROC_INST:
						if (c === "?") parser.state = S.PROC_INST_ENDING;
						else if (isWhitespace(c)) parser.state = S.PROC_INST_BODY;
						else parser.procInstName += c;
						continue;
					case S.PROC_INST_BODY:
						if (!parser.procInstBody && isWhitespace(c)) continue;
						else if (c === "?") parser.state = S.PROC_INST_ENDING;
						else parser.procInstBody += c;
						continue;
					case S.PROC_INST_ENDING:
						if (c === ">") {
							emitNode(parser, "onprocessinginstruction", {
								name: parser.procInstName,
								body: parser.procInstBody
							});
							parser.procInstName = parser.procInstBody = "";
							parser.state = S.TEXT;
						} else {
							parser.procInstBody += "?" + c;
							parser.state = S.PROC_INST_BODY;
						}
						continue;
					case S.OPEN_TAG:
						if (isMatch(nameBody, c)) parser.tagName += c;
						else {
							newTag(parser);
							if (c === ">") openTag(parser);
							else if (c === "/") parser.state = S.OPEN_TAG_SLASH;
							else {
								if (!isWhitespace(c)) strictFail(parser, "Invalid character in tag name");
								parser.state = S.ATTRIB;
							}
						}
						continue;
					case S.OPEN_TAG_SLASH:
						if (c === ">") {
							openTag(parser, true);
							closeTag(parser);
						} else {
							strictFail(parser, "Forward-slash in opening tag not followed by >");
							parser.state = S.ATTRIB;
						}
						continue;
					case S.ATTRIB:
						if (isWhitespace(c)) continue;
						else if (c === ">") openTag(parser);
						else if (c === "/") parser.state = S.OPEN_TAG_SLASH;
						else if (isMatch(nameStart, c)) {
							parser.attribName = c;
							parser.attribValue = "";
							parser.state = S.ATTRIB_NAME;
						} else strictFail(parser, "Invalid attribute name");
						continue;
					case S.ATTRIB_NAME:
						if (c === "=") parser.state = S.ATTRIB_VALUE;
						else if (c === ">") {
							strictFail(parser, "Attribute without value");
							parser.attribValue = parser.attribName;
							attrib(parser);
							openTag(parser);
						} else if (isWhitespace(c)) parser.state = S.ATTRIB_NAME_SAW_WHITE;
						else if (isMatch(nameBody, c)) parser.attribName += c;
						else strictFail(parser, "Invalid attribute name");
						continue;
					case S.ATTRIB_NAME_SAW_WHITE:
						if (c === "=") parser.state = S.ATTRIB_VALUE;
						else if (isWhitespace(c)) continue;
						else {
							strictFail(parser, "Attribute without value");
							parser.tag.attributes[parser.attribName] = "";
							parser.attribValue = "";
							emitNode(parser, "onattribute", {
								name: parser.attribName,
								value: ""
							});
							parser.attribName = "";
							if (c === ">") openTag(parser);
							else if (isMatch(nameStart, c)) {
								parser.attribName = c;
								parser.state = S.ATTRIB_NAME;
							} else {
								strictFail(parser, "Invalid attribute name");
								parser.state = S.ATTRIB;
							}
						}
						continue;
					case S.ATTRIB_VALUE:
						if (isWhitespace(c)) continue;
						else if (isQuote(c)) {
							parser.q = c;
							parser.state = S.ATTRIB_VALUE_QUOTED;
						} else {
							strictFail(parser, "Unquoted attribute value");
							parser.state = S.ATTRIB_VALUE_UNQUOTED;
							parser.attribValue = c;
						}
						continue;
					case S.ATTRIB_VALUE_QUOTED:
						if (c !== parser.q) {
							if (c === "&") parser.state = S.ATTRIB_VALUE_ENTITY_Q;
							else parser.attribValue += c;
							continue;
						}
						attrib(parser);
						parser.q = "";
						parser.state = S.ATTRIB_VALUE_CLOSED;
						continue;
					case S.ATTRIB_VALUE_CLOSED:
						if (isWhitespace(c)) parser.state = S.ATTRIB;
						else if (c === ">") openTag(parser);
						else if (c === "/") parser.state = S.OPEN_TAG_SLASH;
						else if (isMatch(nameStart, c)) {
							strictFail(parser, "No whitespace between attributes");
							parser.attribName = c;
							parser.attribValue = "";
							parser.state = S.ATTRIB_NAME;
						} else strictFail(parser, "Invalid attribute name");
						continue;
					case S.ATTRIB_VALUE_UNQUOTED:
						if (!isAttribEnd(c)) {
							if (c === "&") parser.state = S.ATTRIB_VALUE_ENTITY_U;
							else parser.attribValue += c;
							continue;
						}
						attrib(parser);
						if (c === ">") openTag(parser);
						else parser.state = S.ATTRIB;
						continue;
					case S.CLOSE_TAG:
						if (!parser.tagName) if (isWhitespace(c)) continue;
						else if (notMatch(nameStart, c)) if (parser.script) {
							parser.script += "</" + c;
							parser.state = S.SCRIPT;
						} else strictFail(parser, "Invalid tagname in closing tag.");
						else parser.tagName = c;
						else if (c === ">") closeTag(parser);
						else if (isMatch(nameBody, c)) parser.tagName += c;
						else if (parser.script) {
							parser.script += "</" + parser.tagName;
							parser.tagName = "";
							parser.state = S.SCRIPT;
						} else {
							if (!isWhitespace(c)) strictFail(parser, "Invalid tagname in closing tag");
							parser.state = S.CLOSE_TAG_SAW_WHITE;
						}
						continue;
					case S.CLOSE_TAG_SAW_WHITE:
						if (isWhitespace(c)) continue;
						if (c === ">") closeTag(parser);
						else strictFail(parser, "Invalid characters in closing tag");
						continue;
					case S.TEXT_ENTITY:
					case S.ATTRIB_VALUE_ENTITY_Q:
					case S.ATTRIB_VALUE_ENTITY_U:
						var returnState;
						var buffer;
						switch (parser.state) {
							case S.TEXT_ENTITY:
								returnState = S.TEXT;
								buffer = "textNode";
								break;
							case S.ATTRIB_VALUE_ENTITY_Q:
								returnState = S.ATTRIB_VALUE_QUOTED;
								buffer = "attribValue";
								break;
							case S.ATTRIB_VALUE_ENTITY_U:
								returnState = S.ATTRIB_VALUE_UNQUOTED;
								buffer = "attribValue";
						}
						if (c === ";") {
							parser[buffer] += parseEntity(parser);
							parser.entity = "";
							parser.state = returnState;
						} else if (isMatch(parser.entity.length ? entityBody : entityStart, c)) parser.entity += c;
						else {
							strictFail(parser, "Invalid character in entity name");
							parser[buffer] += "&" + parser.entity + c;
							parser.entity = "";
							parser.state = returnState;
						}
						continue;
					default: throw new Error(parser, "Unknown state: " + parser.state);
				}
			}
			if (parser.position >= parser.bufferCheckPosition) checkBufferLength(parser);
			return parser;
		}
		/*! http://mths.be/fromcodepoint v0.1.0 by @mathias */
		/* istanbul ignore next */
		if (!String.fromCodePoint) (function() {
			var stringFromCharCode = String.fromCharCode;
			var floor = Math.floor;
			var fromCodePoint = function() {
				var MAX_SIZE = 16384;
				var codeUnits = [];
				var highSurrogate;
				var lowSurrogate;
				var index = -1;
				var length = arguments.length;
				if (!length) return "";
				var result = "";
				while (++index < length) {
					var codePoint = Number(arguments[index]);
					if (!isFinite(codePoint) || codePoint < 0 || codePoint > 1114111 || floor(codePoint) !== codePoint) throw RangeError("Invalid code point: " + codePoint);
					if (codePoint <= 65535) codeUnits.push(codePoint);
					else {
						codePoint -= 65536;
						highSurrogate = (codePoint >> 10) + 55296;
						lowSurrogate = codePoint % 1024 + 56320;
						codeUnits.push(highSurrogate, lowSurrogate);
					}
					if (index + 1 === length || codeUnits.length > MAX_SIZE) {
						result += stringFromCharCode.apply(null, codeUnits);
						codeUnits.length = 0;
					}
				}
				return result;
			};
			/* istanbul ignore next */
			if (Object.defineProperty) Object.defineProperty(String, "fromCodePoint", {
				value: fromCodePoint,
				configurable: true,
				writable: true
			});
			else String.fromCodePoint = fromCodePoint;
		})();
	})(typeof exports === "undefined" ? exports.sax = {} : exports);
}));
var require_array_helper = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = { isArray: function(value) {
		if (Array.isArray) return Array.isArray(value);
		return Object.prototype.toString.call(value) === "[object Array]";
	} };
}));
var require_options_helper = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var isArray = require_array_helper().isArray;
	module.exports = {
		copyOptions: function(options) {
			var key, copy = {};
			for (key in options) if (options.hasOwnProperty(key)) copy[key] = options[key];
			return copy;
		},
		ensureFlagExists: function(item, options) {
			if (!(item in options) || typeof options[item] !== "boolean") options[item] = false;
		},
		ensureSpacesExists: function(options) {
			if (!("spaces" in options) || typeof options.spaces !== "number" && typeof options.spaces !== "string") options.spaces = 0;
		},
		ensureAlwaysArrayExists: function(options) {
			if (!("alwaysArray" in options) || typeof options.alwaysArray !== "boolean" && !isArray(options.alwaysArray)) options.alwaysArray = false;
		},
		ensureKeyExists: function(key, options) {
			if (!(key + "Key" in options) || typeof options[key + "Key"] !== "string") options[key + "Key"] = options.compact ? "_" + key : key;
		},
		checkFnExists: function(key, options) {
			return key + "Fn" in options;
		}
	};
}));
var require_xml2js = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var sax = require_sax();
	var expat = {
		on: function() {},
		parse: function() {}
	};
	var helper = require_options_helper();
	var isArray = require_array_helper().isArray;
	var options;
	var pureJsParser = true;
	var currentElement;
	function validateOptions(userOptions) {
		options = helper.copyOptions(userOptions);
		helper.ensureFlagExists("ignoreDeclaration", options);
		helper.ensureFlagExists("ignoreInstruction", options);
		helper.ensureFlagExists("ignoreAttributes", options);
		helper.ensureFlagExists("ignoreText", options);
		helper.ensureFlagExists("ignoreComment", options);
		helper.ensureFlagExists("ignoreCdata", options);
		helper.ensureFlagExists("ignoreDoctype", options);
		helper.ensureFlagExists("compact", options);
		helper.ensureFlagExists("alwaysChildren", options);
		helper.ensureFlagExists("addParent", options);
		helper.ensureFlagExists("trim", options);
		helper.ensureFlagExists("nativeType", options);
		helper.ensureFlagExists("nativeTypeAttributes", options);
		helper.ensureFlagExists("sanitize", options);
		helper.ensureFlagExists("instructionHasAttributes", options);
		helper.ensureFlagExists("captureSpacesBetweenElements", options);
		helper.ensureAlwaysArrayExists(options);
		helper.ensureKeyExists("declaration", options);
		helper.ensureKeyExists("instruction", options);
		helper.ensureKeyExists("attributes", options);
		helper.ensureKeyExists("text", options);
		helper.ensureKeyExists("comment", options);
		helper.ensureKeyExists("cdata", options);
		helper.ensureKeyExists("doctype", options);
		helper.ensureKeyExists("type", options);
		helper.ensureKeyExists("name", options);
		helper.ensureKeyExists("elements", options);
		helper.ensureKeyExists("parent", options);
		helper.checkFnExists("doctype", options);
		helper.checkFnExists("instruction", options);
		helper.checkFnExists("cdata", options);
		helper.checkFnExists("comment", options);
		helper.checkFnExists("text", options);
		helper.checkFnExists("instructionName", options);
		helper.checkFnExists("elementName", options);
		helper.checkFnExists("attributeName", options);
		helper.checkFnExists("attributeValue", options);
		helper.checkFnExists("attributes", options);
		return options;
	}
	function nativeType(value) {
		var nValue = Number(value);
		if (!isNaN(nValue)) return nValue;
		var bValue = value.toLowerCase();
		if (bValue === "true") return true;
		else if (bValue === "false") return false;
		return value;
	}
	function addField(type, value) {
		var key;
		if (options.compact) {
			if (!currentElement[options[type + "Key"]] && (isArray(options.alwaysArray) ? options.alwaysArray.indexOf(options[type + "Key"]) !== -1 : options.alwaysArray)) currentElement[options[type + "Key"]] = [];
			if (currentElement[options[type + "Key"]] && !isArray(currentElement[options[type + "Key"]])) currentElement[options[type + "Key"]] = [currentElement[options[type + "Key"]]];
			if (type + "Fn" in options && typeof value === "string") value = options[type + "Fn"](value, currentElement);
			if (type === "instruction" && ("instructionFn" in options || "instructionNameFn" in options)) {
				for (key in value) if (value.hasOwnProperty(key)) if ("instructionFn" in options) value[key] = options.instructionFn(value[key], key, currentElement);
				else {
					var temp = value[key];
					delete value[key];
					value[options.instructionNameFn(key, temp, currentElement)] = temp;
				}
			}
			if (isArray(currentElement[options[type + "Key"]])) currentElement[options[type + "Key"]].push(value);
			else currentElement[options[type + "Key"]] = value;
		} else {
			if (!currentElement[options.elementsKey]) currentElement[options.elementsKey] = [];
			var element = {};
			element[options.typeKey] = type;
			if (type === "instruction") {
				for (key in value) if (value.hasOwnProperty(key)) break;
				element[options.nameKey] = "instructionNameFn" in options ? options.instructionNameFn(key, value, currentElement) : key;
				if (options.instructionHasAttributes) {
					element[options.attributesKey] = value[key][options.attributesKey];
					if ("instructionFn" in options) element[options.attributesKey] = options.instructionFn(element[options.attributesKey], key, currentElement);
				} else {
					if ("instructionFn" in options) value[key] = options.instructionFn(value[key], key, currentElement);
					element[options.instructionKey] = value[key];
				}
			} else {
				if (type + "Fn" in options) value = options[type + "Fn"](value, currentElement);
				element[options[type + "Key"]] = value;
			}
			if (options.addParent) element[options.parentKey] = currentElement;
			currentElement[options.elementsKey].push(element);
		}
	}
	function manipulateAttributes(attributes) {
		if ("attributesFn" in options && attributes) attributes = options.attributesFn(attributes, currentElement);
		if ((options.trim || "attributeValueFn" in options || "attributeNameFn" in options || options.nativeTypeAttributes) && attributes) {
			var key;
			for (key in attributes) if (attributes.hasOwnProperty(key)) {
				if (options.trim) attributes[key] = attributes[key].trim();
				if (options.nativeTypeAttributes) attributes[key] = nativeType(attributes[key]);
				if ("attributeValueFn" in options) attributes[key] = options.attributeValueFn(attributes[key], key, currentElement);
				if ("attributeNameFn" in options) {
					var temp = attributes[key];
					delete attributes[key];
					attributes[options.attributeNameFn(key, attributes[key], currentElement)] = temp;
				}
			}
		}
		return attributes;
	}
	function onInstruction(instruction) {
		var attributes = {};
		if (instruction.body && (instruction.name.toLowerCase() === "xml" || options.instructionHasAttributes)) {
			var attrsRegExp = /([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|(\w+))\s*/g;
			var match;
			while ((match = attrsRegExp.exec(instruction.body)) !== null) attributes[match[1]] = match[2] || match[3] || match[4];
			attributes = manipulateAttributes(attributes);
		}
		if (instruction.name.toLowerCase() === "xml") {
			if (options.ignoreDeclaration) return;
			currentElement[options.declarationKey] = {};
			if (Object.keys(attributes).length) currentElement[options.declarationKey][options.attributesKey] = attributes;
			if (options.addParent) currentElement[options.declarationKey][options.parentKey] = currentElement;
		} else {
			if (options.ignoreInstruction) return;
			if (options.trim) instruction.body = instruction.body.trim();
			var value = {};
			if (options.instructionHasAttributes && Object.keys(attributes).length) {
				value[instruction.name] = {};
				value[instruction.name][options.attributesKey] = attributes;
			} else value[instruction.name] = instruction.body;
			addField("instruction", value);
		}
	}
	function onStartElement(name, attributes) {
		var element;
		if (typeof name === "object") {
			attributes = name.attributes;
			name = name.name;
		}
		attributes = manipulateAttributes(attributes);
		if ("elementNameFn" in options) name = options.elementNameFn(name, currentElement);
		if (options.compact) {
			element = {};
			if (!options.ignoreAttributes && attributes && Object.keys(attributes).length) {
				element[options.attributesKey] = {};
				var key;
				for (key in attributes) if (attributes.hasOwnProperty(key)) element[options.attributesKey][key] = attributes[key];
			}
			if (!(name in currentElement) && (isArray(options.alwaysArray) ? options.alwaysArray.indexOf(name) !== -1 : options.alwaysArray)) currentElement[name] = [];
			if (currentElement[name] && !isArray(currentElement[name])) currentElement[name] = [currentElement[name]];
			if (isArray(currentElement[name])) currentElement[name].push(element);
			else currentElement[name] = element;
		} else {
			if (!currentElement[options.elementsKey]) currentElement[options.elementsKey] = [];
			element = {};
			element[options.typeKey] = "element";
			element[options.nameKey] = name;
			if (!options.ignoreAttributes && attributes && Object.keys(attributes).length) element[options.attributesKey] = attributes;
			if (options.alwaysChildren) element[options.elementsKey] = [];
			currentElement[options.elementsKey].push(element);
		}
		element[options.parentKey] = currentElement;
		currentElement = element;
	}
	function onText(text) {
		if (options.ignoreText) return;
		if (!text.trim() && !options.captureSpacesBetweenElements) return;
		if (options.trim) text = text.trim();
		if (options.nativeType) text = nativeType(text);
		if (options.sanitize) text = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
		addField("text", text);
	}
	function onComment(comment) {
		if (options.ignoreComment) return;
		if (options.trim) comment = comment.trim();
		addField("comment", comment);
	}
	function onEndElement(name) {
		var parentElement = currentElement[options.parentKey];
		if (!options.addParent) delete currentElement[options.parentKey];
		currentElement = parentElement;
	}
	function onCdata(cdata) {
		if (options.ignoreCdata) return;
		if (options.trim) cdata = cdata.trim();
		addField("cdata", cdata);
	}
	function onDoctype(doctype) {
		if (options.ignoreDoctype) return;
		doctype = doctype.replace(/^ /, "");
		if (options.trim) doctype = doctype.trim();
		addField("doctype", doctype);
	}
	function onError(error) {
		error.note = error;
	}
	module.exports = function(xml, userOptions) {
		var parser = pureJsParser ? sax.parser(true, {}) : parser = new expat.Parser("UTF-8");
		var result = {};
		currentElement = result;
		options = validateOptions(userOptions);
		if (pureJsParser) {
			parser.opt = { strictEntities: true };
			parser.onopentag = onStartElement;
			parser.ontext = onText;
			parser.oncomment = onComment;
			parser.onclosetag = onEndElement;
			parser.onerror = onError;
			parser.oncdata = onCdata;
			parser.ondoctype = onDoctype;
			parser.onprocessinginstruction = onInstruction;
		} else {
			parser.on("startElement", onStartElement);
			parser.on("text", onText);
			parser.on("comment", onComment);
			parser.on("endElement", onEndElement);
			parser.on("error", onError);
		}
		if (pureJsParser) parser.write(xml).close();
		else if (!parser.parse(xml)) throw new Error("XML parsing error: " + parser.getError());
		if (result[options.elementsKey]) {
			var temp = result[options.elementsKey];
			delete result[options.elementsKey];
			result[options.elementsKey] = temp;
			delete result.text;
		}
		return result;
	};
}));
var require_xml2json = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var helper = require_options_helper();
	var xml2js = require_xml2js();
	function validateOptions(userOptions) {
		var options = helper.copyOptions(userOptions);
		helper.ensureSpacesExists(options);
		return options;
	}
	module.exports = function(xml, userOptions) {
		var options = validateOptions(userOptions), js = xml2js(xml, options), json, parentKey = "compact" in options && options.compact ? "_parent" : "parent";
		if ("addParent" in options && options.addParent) json = JSON.stringify(js, function(k, v) {
			return k === parentKey ? "_" : v;
		}, options.spaces);
		else json = JSON.stringify(js, null, options.spaces);
		return json.replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
	};
}));
var require_js2xml = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var helper = require_options_helper();
	var isArray = require_array_helper().isArray;
	var currentElement, currentElementName;
	function validateOptions(userOptions) {
		var options = helper.copyOptions(userOptions);
		helper.ensureFlagExists("ignoreDeclaration", options);
		helper.ensureFlagExists("ignoreInstruction", options);
		helper.ensureFlagExists("ignoreAttributes", options);
		helper.ensureFlagExists("ignoreText", options);
		helper.ensureFlagExists("ignoreComment", options);
		helper.ensureFlagExists("ignoreCdata", options);
		helper.ensureFlagExists("ignoreDoctype", options);
		helper.ensureFlagExists("compact", options);
		helper.ensureFlagExists("indentText", options);
		helper.ensureFlagExists("indentCdata", options);
		helper.ensureFlagExists("indentAttributes", options);
		helper.ensureFlagExists("indentInstruction", options);
		helper.ensureFlagExists("fullTagEmptyElement", options);
		helper.ensureFlagExists("noQuotesForNativeAttributes", options);
		helper.ensureSpacesExists(options);
		if (typeof options.spaces === "number") options.spaces = Array(options.spaces + 1).join(" ");
		helper.ensureKeyExists("declaration", options);
		helper.ensureKeyExists("instruction", options);
		helper.ensureKeyExists("attributes", options);
		helper.ensureKeyExists("text", options);
		helper.ensureKeyExists("comment", options);
		helper.ensureKeyExists("cdata", options);
		helper.ensureKeyExists("doctype", options);
		helper.ensureKeyExists("type", options);
		helper.ensureKeyExists("name", options);
		helper.ensureKeyExists("elements", options);
		helper.checkFnExists("doctype", options);
		helper.checkFnExists("instruction", options);
		helper.checkFnExists("cdata", options);
		helper.checkFnExists("comment", options);
		helper.checkFnExists("text", options);
		helper.checkFnExists("instructionName", options);
		helper.checkFnExists("elementName", options);
		helper.checkFnExists("attributeName", options);
		helper.checkFnExists("attributeValue", options);
		helper.checkFnExists("attributes", options);
		helper.checkFnExists("fullTagEmptyElement", options);
		return options;
	}
	function writeIndentation(options, depth, firstLine) {
		return (!firstLine && options.spaces ? "\n" : "") + Array(depth + 1).join(options.spaces);
	}
	function writeAttributes(attributes, options, depth) {
		if (options.ignoreAttributes) return "";
		if ("attributesFn" in options) attributes = options.attributesFn(attributes, currentElementName, currentElement);
		var key, attr, attrName, quote, result = [];
		for (key in attributes) if (attributes.hasOwnProperty(key) && attributes[key] !== null && attributes[key] !== void 0) {
			quote = options.noQuotesForNativeAttributes && typeof attributes[key] !== "string" ? "" : "\"";
			attr = "" + attributes[key];
			attr = attr.replace(/"/g, "&quot;");
			attrName = "attributeNameFn" in options ? options.attributeNameFn(key, attr, currentElementName, currentElement) : key;
			result.push(options.spaces && options.indentAttributes ? writeIndentation(options, depth + 1, false) : " ");
			result.push(attrName + "=" + quote + ("attributeValueFn" in options ? options.attributeValueFn(attr, key, currentElementName, currentElement) : attr) + quote);
		}
		if (attributes && Object.keys(attributes).length && options.spaces && options.indentAttributes) result.push(writeIndentation(options, depth, false));
		return result.join("");
	}
	function writeDeclaration(declaration, options, depth) {
		currentElement = declaration;
		currentElementName = "xml";
		return options.ignoreDeclaration ? "" : "<?xml" + writeAttributes(declaration[options.attributesKey], options, depth) + "?>";
	}
	function writeInstruction(instruction, options, depth) {
		if (options.ignoreInstruction) return "";
		var key;
		for (key in instruction) if (instruction.hasOwnProperty(key)) break;
		var instructionName = "instructionNameFn" in options ? options.instructionNameFn(key, instruction[key], currentElementName, currentElement) : key;
		if (typeof instruction[key] === "object") {
			currentElement = instruction;
			currentElementName = instructionName;
			return "<?" + instructionName + writeAttributes(instruction[key][options.attributesKey], options, depth) + "?>";
		} else {
			var instructionValue = instruction[key] ? instruction[key] : "";
			if ("instructionFn" in options) instructionValue = options.instructionFn(instructionValue, key, currentElementName, currentElement);
			return "<?" + instructionName + (instructionValue ? " " + instructionValue : "") + "?>";
		}
	}
	function writeComment(comment, options) {
		return options.ignoreComment ? "" : "<!--" + ("commentFn" in options ? options.commentFn(comment, currentElementName, currentElement) : comment) + "-->";
	}
	function writeCdata(cdata, options) {
		return options.ignoreCdata ? "" : "<![CDATA[" + ("cdataFn" in options ? options.cdataFn(cdata, currentElementName, currentElement) : cdata.replace("]]>", "]]]]><![CDATA[>")) + "]]>";
	}
	function writeDoctype(doctype, options) {
		return options.ignoreDoctype ? "" : "<!DOCTYPE " + ("doctypeFn" in options ? options.doctypeFn(doctype, currentElementName, currentElement) : doctype) + ">";
	}
	function writeText(text, options) {
		if (options.ignoreText) return "";
		text = "" + text;
		text = text.replace(/&amp;/g, "&");
		text = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
		return "textFn" in options ? options.textFn(text, currentElementName, currentElement) : text;
	}
	function hasContent(element, options) {
		var i;
		if (element.elements && element.elements.length) for (i = 0; i < element.elements.length; ++i) switch (element.elements[i][options.typeKey]) {
			case "text":
				if (options.indentText) return true;
				break;
			case "cdata":
				if (options.indentCdata) return true;
				break;
			case "instruction":
				if (options.indentInstruction) return true;
				break;
			case "doctype":
			case "comment":
			case "element": return true;
			default: return true;
		}
		return false;
	}
	function writeElement(element, options, depth) {
		currentElement = element;
		currentElementName = element.name;
		var xml = [], elementName = "elementNameFn" in options ? options.elementNameFn(element.name, element) : element.name;
		xml.push("<" + elementName);
		if (element[options.attributesKey]) xml.push(writeAttributes(element[options.attributesKey], options, depth));
		var withClosingTag = element[options.elementsKey] && element[options.elementsKey].length || element[options.attributesKey] && element[options.attributesKey]["xml:space"] === "preserve";
		if (!withClosingTag) if ("fullTagEmptyElementFn" in options) withClosingTag = options.fullTagEmptyElementFn(element.name, element);
		else withClosingTag = options.fullTagEmptyElement;
		if (withClosingTag) {
			xml.push(">");
			if (element[options.elementsKey] && element[options.elementsKey].length) {
				xml.push(writeElements(element[options.elementsKey], options, depth + 1));
				currentElement = element;
				currentElementName = element.name;
			}
			xml.push(options.spaces && hasContent(element, options) ? "\n" + Array(depth + 1).join(options.spaces) : "");
			xml.push("</" + elementName + ">");
		} else xml.push("/>");
		return xml.join("");
	}
	function writeElements(elements, options, depth, firstLine) {
		return elements.reduce(function(xml, element) {
			var indent = writeIndentation(options, depth, firstLine && !xml);
			switch (element.type) {
				case "element": return xml + indent + writeElement(element, options, depth);
				case "comment": return xml + indent + writeComment(element[options.commentKey], options);
				case "doctype": return xml + indent + writeDoctype(element[options.doctypeKey], options);
				case "cdata": return xml + (options.indentCdata ? indent : "") + writeCdata(element[options.cdataKey], options);
				case "text": return xml + (options.indentText ? indent : "") + writeText(element[options.textKey], options);
				case "instruction":
					var instruction = {};
					instruction[element[options.nameKey]] = element[options.attributesKey] ? element : element[options.instructionKey];
					return xml + (options.indentInstruction ? indent : "") + writeInstruction(instruction, options, depth);
			}
		}, "");
	}
	function hasContentCompact(element, options, anyContent) {
		var key;
		for (key in element) if (element.hasOwnProperty(key)) switch (key) {
			case options.parentKey:
			case options.attributesKey: break;
			case options.textKey:
				if (options.indentText || anyContent) return true;
				break;
			case options.cdataKey:
				if (options.indentCdata || anyContent) return true;
				break;
			case options.instructionKey:
				if (options.indentInstruction || anyContent) return true;
				break;
			case options.doctypeKey:
			case options.commentKey: return true;
			default: return true;
		}
		return false;
	}
	function writeElementCompact(element, name, options, depth, indent) {
		currentElement = element;
		currentElementName = name;
		var elementName = "elementNameFn" in options ? options.elementNameFn(name, element) : name;
		if (typeof element === "undefined" || element === null || element === "") return "fullTagEmptyElementFn" in options && options.fullTagEmptyElementFn(name, element) || options.fullTagEmptyElement ? "<" + elementName + "></" + elementName + ">" : "<" + elementName + "/>";
		var xml = [];
		if (name) {
			xml.push("<" + elementName);
			if (typeof element !== "object") {
				xml.push(">" + writeText(element, options) + "</" + elementName + ">");
				return xml.join("");
			}
			if (element[options.attributesKey]) xml.push(writeAttributes(element[options.attributesKey], options, depth));
			var withClosingTag = hasContentCompact(element, options, true) || element[options.attributesKey] && element[options.attributesKey]["xml:space"] === "preserve";
			if (!withClosingTag) if ("fullTagEmptyElementFn" in options) withClosingTag = options.fullTagEmptyElementFn(name, element);
			else withClosingTag = options.fullTagEmptyElement;
			if (withClosingTag) xml.push(">");
			else {
				xml.push("/>");
				return xml.join("");
			}
		}
		xml.push(writeElementsCompact(element, options, depth + 1, false));
		currentElement = element;
		currentElementName = name;
		if (name) xml.push((indent ? writeIndentation(options, depth, false) : "") + "</" + elementName + ">");
		return xml.join("");
	}
	function writeElementsCompact(element, options, depth, firstLine) {
		var i, key, nodes, xml = [];
		for (key in element) if (element.hasOwnProperty(key)) {
			nodes = isArray(element[key]) ? element[key] : [element[key]];
			for (i = 0; i < nodes.length; ++i) {
				switch (key) {
					case options.declarationKey:
						xml.push(writeDeclaration(nodes[i], options, depth));
						break;
					case options.instructionKey:
						xml.push((options.indentInstruction ? writeIndentation(options, depth, firstLine) : "") + writeInstruction(nodes[i], options, depth));
						break;
					case options.attributesKey:
					case options.parentKey: break;
					case options.textKey:
						xml.push((options.indentText ? writeIndentation(options, depth, firstLine) : "") + writeText(nodes[i], options));
						break;
					case options.cdataKey:
						xml.push((options.indentCdata ? writeIndentation(options, depth, firstLine) : "") + writeCdata(nodes[i], options));
						break;
					case options.doctypeKey:
						xml.push(writeIndentation(options, depth, firstLine) + writeDoctype(nodes[i], options));
						break;
					case options.commentKey:
						xml.push(writeIndentation(options, depth, firstLine) + writeComment(nodes[i], options));
						break;
					default: xml.push(writeIndentation(options, depth, firstLine) + writeElementCompact(nodes[i], key, options, depth, hasContentCompact(nodes[i], options)));
				}
				firstLine = firstLine && !xml.length;
			}
		}
		return xml.join("");
	}
	module.exports = function(js, options) {
		options = validateOptions(options);
		var xml = [];
		currentElement = js;
		currentElementName = "_root_";
		if (options.compact) xml.push(writeElementsCompact(js, options, 0, true));
		else {
			if (js[options.declarationKey]) xml.push(writeDeclaration(js[options.declarationKey], options, 0));
			if (js[options.elementsKey] && js[options.elementsKey].length) xml.push(writeElements(js[options.elementsKey], options, 0, !xml.length));
		}
		return xml.join("");
	};
}));
var require_json2xml = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var js2xml = require_js2xml();
	module.exports = function(json, options) {
		if (json instanceof Buffer) json = json.toString();
		var js = null;
		if (typeof json === "string") try {
			js = JSON.parse(json);
		} catch (e) {
			throw new Error("The JSON structure is invalid");
		}
		else js = json;
		return js2xml(js, options);
	};
}));
var import_lib = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		xml2js: require_xml2js(),
		xml2json: require_xml2json(),
		js2xml: require_js2xml(),
		json2xml: require_json2xml()
	};
})))();
/**
* Converts an xml-js Element into an XmlComponent tree.
*
* This function recursively processes XML elements in JSON format (from xml-js)
* and creates a tree of ImportedXmlComponent objects that match the structure
* of the original XML.
*
* @param element - The XML element in JSON representation from xml-js
* @returns An ImportedXmlComponent tree, text string, or undefined
*
* @example
* ```typescript
* const xmlElement = xml2js('<w:p><w:r><w:t>Hello</w:t></w:r></w:p>');
* const component = convertToXmlComponent(xmlElement);
* ```
*/
var convertToXmlComponent = (element) => {
	switch (element.type) {
		case void 0:
		case "element":
			const xmlComponent = new ImportedXmlComponent(element.name, element.attributes);
			const childElements = element.elements || [];
			for (const childElm of childElements) {
				const child = convertToXmlComponent(childElm);
				if (child !== void 0) xmlComponent.push(child);
			}
			return xmlComponent;
		case "text": return element.text;
		default: return;
	}
};
/**
* Internal attribute component for imported XML elements.
* @internal
*/
var ImportedXmlComponentAttributes = class extends XmlAttributeComponent {};
/**
* XML component representing imported XML content.
*
* ImportedXmlComponent allows you to parse XML strings and incorporate them
* into the document structure. This is particularly useful when working with
* templates or when you need to include pre-existing XML fragments.
*
* @example
* ```typescript
* // Parse XML string into component tree
* const component = ImportedXmlComponent.fromXmlString(
*   '<w:p><w:r><w:t>Hello World</w:t></w:r></w:p>'
* );
*
* // Manually create an imported component
* const element = new ImportedXmlComponent("w:customElement", { "w:val": "value" });
* element.push(new ImportedXmlComponent("w:child"));
* ```
*/
var ImportedXmlComponent = class extends XmlComponent {
	/**
	* Parses an XML string and converts it to an ImportedXmlComponent tree.
	*
	* This static method is the primary way to import external XML content.
	* It uses xml-js to parse the XML string into a JSON representation,
	* then converts that into a tree of XmlComponent objects.
	*
	* @param importedContent - The XML content as a string
	* @returns An ImportedXmlComponent representing the parsed XML
	*
	* @example
	* ```typescript
	* const xml = '<w:p><w:r><w:t>Hello</w:t></w:r></w:p>';
	* const component = ImportedXmlComponent.fromXmlString(xml);
	* ```
	*/
	static fromXmlString(importedContent) {
		return convertToXmlComponent((0, import_lib.xml2js)(importedContent, { compact: false }));
	}
	/**
	* Creates an ImportedXmlComponent.
	*
	* @param rootKey - The XML element name
	* @param _attr - Optional attributes for the root element
	*/
	constructor(rootKey, _attr) {
		super(rootKey);
		if (_attr) this.root.push(new ImportedXmlComponentAttributes(_attr));
	}
	/**
	* Adds a child component or text to this element.
	*
	* @param xmlComponent - The child component or text string to add
	*/
	push(xmlComponent) {
		this.root.push(xmlComponent);
	}
};
/**
* Represents attributes for imported root elements.
*
* This class is used internally to handle attributes on root elements
* that are being imported from external XML. It passes through the
* attributes without transformation.
*
* @example
* ```typescript
* const attrs = new ImportedRootElementAttributes({
*   "xmlns:w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
* });
* ```
*/
var ImportedRootElementAttributes = class extends XmlComponent {
	/**
	* Creates an ImportedRootElementAttributes component.
	*
	* @param _attr - The attributes object to pass through
	*/
	constructor(_attr) {
		super("");
		_defineProperty(this, "_attr", void 0);
		this._attr = _attr;
	}
	/**
	* Prepares the attributes for XML serialization.
	*
	* @param _ - Context (unused)
	* @returns Object with _attr key containing the raw attributes
	*/
	prepForXml(_) {
		return { _attr: this._attr };
	}
};
/**
* Initializable XML Component module.
*
* This module provides a base class for XML components that can be initialized
* from another component's state, useful for component reuse and composition.
*
* @module
*/
/**
* XML component that can be initialized from another component.
*
* InitializableXmlComponent extends XmlComponent to support copying the internal
* state (root array) from another component. This is useful when you need to
* create a new component that shares or extends the children of an existing component.
*
* @example
* ```typescript
* class MyElement extends InitializableXmlComponent {
*   constructor(init?: MyElement) {
*     super("w:myElement", init);
*     // If init is provided, this.root is copied from init
*     // Otherwise, this.root is an empty array
*   }
* }
*
* const element1 = new MyElement();
* element1.addChildElement(new TextRun("Hello"));
*
* const element2 = new MyElement(element1);
* // element2 now has the same children as element1
* ```
*/
var InitializableXmlComponent = class extends XmlComponent {
	/**
	* Creates a new InitializableXmlComponent.
	*
	* @param rootKey - The XML element name
	* @param initComponent - Optional component to copy children from
	*/
	constructor(rootKey, initComponent) {
		super(rootKey);
		if (initComponent) this.root = initComponent.root;
	}
};
/**
* Validates and converts a number to an integer (decimal number).
*
* Reference: ST_DecimalNumber in OOXML specification
*
* @param val - The number to validate and convert
* @returns The floored integer value
* @throws Error if the value is NaN
*
* @example
* ```typescript
* const num = decimalNumber(10.7); // Returns 10
* const negative = decimalNumber(-5.3); // Returns -5
* ```
*/
var decimalNumber = (val) => {
	if (isNaN(val)) throw new Error(`Invalid value '${val}' specified. Must be an integer.`);
	return Math.floor(val);
};
/**
* Validates and converts a number to a positive integer (unsigned decimal number).
*
* Reference: ST_UnsignedDecimalNumber in OOXML specification
*
* @param val - The number to validate and convert
* @returns The floored positive integer value
* @throws Error if the value is NaN or negative
*
* @example
* ```typescript
* const num = unsignedDecimalNumber(10.7); // Returns 10
* const invalid = unsignedDecimalNumber(-5); // Throws Error
* ```
*/
var unsignedDecimalNumber = (val) => {
	const value = decimalNumber(val);
	if (value < 0) throw new Error(`Invalid value '${val}' specified. Must be a positive integer.`);
	return value;
};
/**
* Validates and normalizes a hexadecimal binary value.
*
* The xsd:hexBinary type represents binary data as a sequence of binary octets
* using hexadecimal encoding, where each binary octet is a two-character
* hexadecimal number. Both lowercase and uppercase letters A-F are permitted.
*
* @param val - The hexadecimal string to validate
* @param length - The expected length in bytes (not characters)
* @returns The validated hexadecimal string
* @throws Error if the value is not a valid hex string of the expected length
*
* @example
* ```typescript
* hexBinary("0FB8", 2); // Valid: 2 bytes = 4 characters
* hexBinary("ABC", 2); // Invalid: wrong length
* ```
*/
var hexBinary = (val, length) => {
	const expectedLength = length * 2;
	if (val.length !== expectedLength || isNaN(Number(`0x${val}`))) throw new Error(`Invalid hex value '${val}'. Expected ${expectedLength} digit hex value`);
	return val;
};
/**
* Validates a single-byte hexadecimal number (1 byte / 2 characters).
*
* Reference: ST_UcharHexNumber in OOXML specification
*
* @param val - The hexadecimal string to validate
* @returns The validated hexadecimal string
* @throws Error if the value is not a valid 2-character hex string
*
* @example
* ```typescript
* const hex = uCharHexNumber("FF"); // Valid
* ```
*/
var uCharHexNumber = (val) => hexBinary(val, 1);
/**
* Normalizes a universal measure value by parsing and reformatting.
*
* Ensures the numeric portion is properly formatted while preserving the unit.
*
* Reference: ST_UniversalMeasure in OOXML specification
*
* @param val - The universal measure string to normalize
* @returns The normalized universal measure
*
* @example
* ```typescript
* const measure = universalMeasureValue("10.500mm"); // Returns "10.5mm"
* ```
*/
var universalMeasureValue = (val) => {
	const unit = val.slice(-2);
	const amount = val.substring(0, val.length - 2);
	return `${Number(amount)}${unit}`;
};
/**
* Validates and normalizes a positive universal measure value.
*
* Reference: ST_PositiveUniversalMeasure in OOXML specification
*
* @param val - The positive universal measure string to validate
* @returns The normalized positive universal measure
* @throws Error if the value is negative
*
* @example
* ```typescript
* const measure = positiveUniversalMeasureValue("10.5mm"); // Valid
* const invalid = positiveUniversalMeasureValue("-5mm"); // Throws Error
* ```
*/
var positiveUniversalMeasureValue = (val) => {
	const value = universalMeasureValue(val);
	if (parseFloat(value) < 0) throw new Error(`Invalid value '${value}' specified. Expected a positive number.`);
	return value;
};
/**
* Validates and normalizes a hexadecimal color value.
*
* Accepts either "auto" or a 6-character RGB hex value (with or without # prefix).
* The # prefix is commonly used but technically invalid in OOXML, so it is stripped
* for strict compliance.
*
* Reference: ST_HexColor in OOXML specification
*
* @param val - The color value to validate ("auto" or hex color)
* @returns The normalized color value
* @throws Error if the hex color is invalid
*
* @example
* ```typescript
* const color1 = hexColorValue("auto"); // Returns "auto"
* const color2 = hexColorValue("FF0000"); // Returns "FF0000"
* const color3 = hexColorValue("#00FF00"); // Returns "00FF00" (# stripped)
* ```
*/
var hexColorValue = (val) => {
	if (val === "auto") return val;
	return hexBinary(val.charAt(0) === "#" ? val.substring(1) : val, 3);
};
/**
* Validates a signed TWIP measurement value.
*
* Accepts either a universal measure string or a numeric TWIP value.
*
* Reference: ST_SignedTwipsMeasure in OOXML specification
*
* @param val - The measurement value (universal measure or number)
* @returns The normalized measurement value
*
* @example
* ```typescript
* const measure1 = signedTwipsMeasureValue("10mm");
* const measure2 = signedTwipsMeasureValue(1440); // 1 inch in TWIP
* ```
*/
var signedTwipsMeasureValue = (val) => typeof val === "string" ? universalMeasureValue(val) : decimalNumber(val);
/**
* Validates a half-point (HPS) measurement value.
*
* Accepts either a positive universal measure string or a positive number.
* HPS (half-points) are commonly used for font sizes.
*
* Reference: ST_HpsMeasure in OOXML specification
*
* @param val - The measurement value (positive universal measure or number)
* @returns The normalized measurement value
*
* @example
* ```typescript
* const fontSize1 = hpsMeasureValue("12pt");
* const fontSize2 = hpsMeasureValue(24); // 12pt in half-points
* ```
*/
var hpsMeasureValue = (val) => typeof val === "string" ? positiveUniversalMeasureValue(val) : unsignedDecimalNumber(val);
/**
* Validates a positive TWIP measurement value.
*
* Accepts either a positive universal measure string or a positive number.
*
* Reference: ST_TwipsMeasure in OOXML specification
*
* @param val - The measurement value (positive universal measure or number)
* @returns The normalized measurement value
*
* @example
* ```typescript
* const width1 = twipsMeasureValue("25.4mm");
* const width2 = twipsMeasureValue(1440); // 1 inch in TWIP
* ```
*/
var twipsMeasureValue = (val) => typeof val === "string" ? positiveUniversalMeasureValue(val) : unsignedDecimalNumber(val);
/**
* Normalizes a percentage value by parsing and reformatting.
*
* Reference: ST_Percentage in OOXML specification
*
* @param val - The percentage string to normalize
* @returns The normalized percentage
*
* @example
* ```typescript
* const percent = percentageValue("50.000%"); // Returns "50%"
* ```
*/
var percentageValue = (val) => {
	const percent = val.substring(0, val.length - 1);
	return `${Number(percent)}%`;
};
/**
* Validates a measurement value that can be expressed as a number, percentage, or universal measure.
*
* Reference: ST_MeasurementOrPercent in OOXML specification
*
* @param val - The measurement value (number, percentage, or universal measure)
* @returns The normalized measurement value
*
* @example
* ```typescript
* const measure1 = measurementOrPercentValue(100); // Unqualified number
* const measure2 = measurementOrPercentValue("50%"); // Percentage
* const measure3 = measurementOrPercentValue("10mm"); // Universal measure
* ```
*/
var measurementOrPercentValue = (val) => {
	if (typeof val === "number") return decimalNumber(val);
	if (val.slice(-1) === "%") return percentageValue(val);
	return universalMeasureValue(val);
};
/**
* Validates an eighth-point measurement value.
*
* Eighth-points are used for fine-grained measurements in text formatting.
*
* Reference: ST_EighthPointMeasure in OOXML specification
*
* @param val - The measurement value in eighth-points
* @returns The validated positive integer value
*
* @example
* ```typescript
* const measure = eighthPointMeasureValue(16); // 2 points
* ```
*/
var eighthPointMeasureValue = unsignedDecimalNumber;
/**
* Validates a point measurement value.
*
* Reference: ST_PointMeasure in OOXML specification
*
* @param val - The measurement value in points
* @returns The validated positive integer value
*
* @example
* ```typescript
* const fontSize = pointMeasureValue(12); // 12pt
* ```
*/
var pointMeasureValue = unsignedDecimalNumber;
/**
* Converts a JavaScript Date object to an ISO 8601 date-time string.
*
* The format is CCYY-MM-DDThh:mm:ss.sssZ where T is a literal and Z indicates UTC.
* This matches the xsd:dateTime format required by OOXML.
*
* Reference: ST_DateTime in OOXML specification
*
* @param val - The Date object to convert
* @returns An ISO 8601 formatted date-time string
*
* @example
* ```typescript
* const now = new Date();
* const timestamp = dateTimeValue(now); // Returns "2024-01-15T10:30:00.000Z"
* ```
*/
var dateTimeValue = (val) => val.toISOString();
/**
* Simple XML element types for common WordprocessingML patterns.
*
* This module provides reusable element classes for common XML patterns in OOXML,
* such as boolean elements, string values, number values, and empty elements.
* These are building blocks used throughout the library.
*
* @module
*/
/**
* XML element representing a boolean on/off value (CT_OnOff).
*
* This element type is used throughout WordprocessingML to represent boolean properties.
* A value of true (or 1) means the property is enabled. A value of false (or 0) means
* it is explicitly disabled. When the value is true, the attribute is often omitted.
*
* OOXML Reference:
* ```xml
* <xsd:complexType name="CT_OnOff">
*   <xsd:attribute name="val" type="s:ST_OnOff"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Bold enabled (w:val omitted when true)
* new OnOffElement("w:b", true);
* // Generates: <w:b/>
*
* // Bold explicitly disabled
* new OnOffElement("w:b", false);
* // Generates: <w:b w:val="false"/>
* ```
*/
var OnOffElement = class extends XmlComponent {
	/**
	* Creates an OnOffElement.
	*
	* @param name - The XML element name (e.g., "w:b", "w:i")
	* @param val - The boolean value (defaults to true)
	*/
	constructor(name, val = true) {
		super(name);
		if (val !== true) this.root.push(new Attributes({ val }));
	}
};
/**
* XML element representing a half-point size measurement (CT_HpsMeasure).
*
* HpsMeasure elements are used for font sizes and other measurements in WordprocessingML.
* Values can be specified as numbers (interpreted as half-points) or with explicit units.
*
* OOXML Reference:
* ```xml
* <xsd:complexType name="CT_HpsMeasure">
*   <xsd:attribute name="val" type="ST_HpsMeasure" use="required"/>
* </xsd:complexType>
*
* <xsd:simpleType name="ST_HpsMeasure">
*   <xsd:union memberTypes="s:ST_UnsignedDecimalNumber s:ST_PositiveUniversalMeasure" />
* </xsd:simpleType>
* ```
*
* @example
* ```typescript
* // Font size of 24 half-points (12pt)
* new HpsMeasureElement("w:sz", 24);
* // Generates: <w:sz w:val="24"/>
*
* // Using explicit units
* new HpsMeasureElement("w:sz", "12pt");
* ```
*/
var HpsMeasureElement = class extends XmlComponent {
	/**
	* Creates an HpsMeasureElement.
	*
	* @param name - The XML element name
	* @param val - The measurement value (number in half-points or string with units)
	*/
	constructor(name, val) {
		super(name);
		this.root.push(new Attributes({ val: hpsMeasureValue(val) }));
	}
};
/**
* XML element representing an empty element (CT_Empty).
*
* EmptyElement creates self-closing XML tags with no attributes or content.
*
* OOXML Reference:
* ```xml
* <xsd:complexType name="CT_Empty"/>
* ```
*
* @example
* ```typescript
* new EmptyElement("w:noProof");
* // Generates: <w:noProof/>
* ```
*/
var EmptyElement = class extends XmlComponent {};
/**
* XML element with a string value attribute (CT_String).
*
* StringValueElement creates elements with a single "w:val" attribute
* containing a string value.
*
* OOXML Reference:
* ```xml
* <xsd:complexType name="CT_String">
*   <xsd:attribute name="val" type="s:ST_String" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new StringValueElement("w:style", "Heading1");
* // Generates: <w:style w:val="Heading1"/>
* ```
*/
var StringValueElement = class extends XmlComponent {
	/**
	* Creates a StringValueElement.
	*
	* @param name - The XML element name
	* @param val - The string value
	*/
	constructor(name, val) {
		super(name);
		this.root.push(new Attributes({ val }));
	}
};
/**
* Creates a string element using the builder pattern.
*
* This is an alternative to StringValueElement that uses BuilderElement
* for more explicit attribute naming.
*
* @param name - The XML element name
* @param value - The string value
* @returns An XmlComponent with the string value
*
* @example
* ```typescript
* createStringElement("w:pStyle", "Heading1");
* // Generates: <w:pStyle w:val="Heading1"/>
* ```
*/
var createStringElement = (name, value) => new BuilderElement({
	name,
	attributes: { value: {
		key: "w:val",
		value
	} }
});
/**
* XML element with a numeric value attribute.
*
* NumberValueElement creates elements with a single "w:val" attribute
* containing a numeric value.
*
* @example
* ```typescript
* new NumberValueElement("w:ilvl", 2);
* // Generates: <w:ilvl w:val="2"/>
* ```
*/
var NumberValueElement = class extends XmlComponent {
	/**
	* Creates a NumberValueElement.
	*
	* @param name - The XML element name
	* @param val - The numeric value
	*/
	constructor(name, val) {
		super(name);
		this.root.push(new Attributes({ val }));
	}
};
/**
* XML element containing text content.
*
* StringContainer creates elements with text content (not attributes).
* This is used for elements where the value is the text node content
* rather than an attribute.
*
* @example
* ```typescript
* new StringContainer("w:author", "John Doe");
* // Generates: <w:author>John Doe</w:author>
* ```
*/
var StringContainer = class extends XmlComponent {
	/**
	* Creates a StringContainer.
	*
	* @param name - The XML element name
	* @param val - The text content
	*/
	constructor(name, val) {
		super(name);
		this.root.push(val);
	}
};
/**
* Flexible XML element builder with explicit attribute and child configuration.
*
* BuilderElement provides a structured way to create XML elements with typed
* attributes and children. It uses the NextAttributeComponent pattern for
* explicit attribute key-value mapping.
*
* @example
* ```typescript
* // Element with attributes
* new BuilderElement({
*   name: "w:spacing",
*   attributes: {
*     before: { key: "w:before", value: 240 },
*     after: { key: "w:after", value: 120 }
*   }
* });
* // Generates: <w:spacing w:before="240" w:after="120"/>
*
* // Element with children
* new BuilderElement({
*   name: "w:pPr",
*   children: [
*     new StringValueElement("w:pStyle", "Heading1")
*   ]
* });
* ```
*/
var BuilderElement = class extends XmlComponent {
	/**
	* Creates a BuilderElement with the specified configuration.
	*
	* @param config - Element configuration
	* @param config.name - The XML element name
	* @param config.attributes - Optional attributes with explicit key-value pairs
	* @param config.children - Optional child elements
	*/
	constructor({ name, attributes, children }) {
		super(name);
		if (attributes) this.root.push(new NextAttributeComponent(attributes));
		if (children) this.root.push(...children);
	}
};
/**
* Paragraph and table alignment module for WordprocessingML documents.
*
* This module provides justification (alignment) options for paragraphs and tables.
*
* Reference: http://officeopenxml.com/WPalignment.php
*
* @see http://officeopenxml.com/WPtableAlignment.php
* @see http://www.datypic.com/sc/ooxml/t-w_ST_Jc.html
*
* @module
*/
/**
* Paragraph justification (alignment) types.
*
* Specifies the horizontal alignment of text within a paragraph.
*
* Reference: http://officeopenxml.com/WPalignment.php
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_Jc">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="start"/>
*     <xsd:enumeration value="center"/>
*     <xsd:enumeration value="end"/>
*     <xsd:enumeration value="both"/>
*     <xsd:enumeration value="mediumKashida"/>
*     <xsd:enumeration value="distribute"/>
*     <xsd:enumeration value="numTab"/>
*     <xsd:enumeration value="highKashida"/>
*     <xsd:enumeration value="lowKashida"/>
*     <xsd:enumeration value="thaiDistribute"/>
*     <xsd:enumeration value="left"/>
*     <xsd:enumeration value="right"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var AlignmentType = {
	/** Align Start */
	START: "start",
	/** Align Center */
	CENTER: "center",
	/** End */
	END: "end",
	/** Justified */
	BOTH: "both",
	/** Medium Kashida Length */
	MEDIUM_KASHIDA: "mediumKashida",
	/** Distribute All Characters Equally */
	DISTRIBUTE: "distribute",
	/** Align to List Tab */
	NUM_TAB: "numTab",
	/** Widest Kashida Length */
	HIGH_KASHIDA: "highKashida",
	/** Low Kashida Length */
	LOW_KASHIDA: "lowKashida",
	/** Thai Language Justification */
	THAI_DISTRIBUTE: "thaiDistribute",
	/** Align Left */
	LEFT: "left",
	/** Align Right */
	RIGHT: "right",
	/** Justified */
	JUSTIFIED: "both"
};
/**
* Creates paragraph alignment (justification) element for a WordprocessingML document.
*
* The jc element specifies the horizontal alignment of all text in the paragraph.
*
* Reference: http://officeopenxml.com/WPalignment.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Jc">
*   <xsd:attribute name="val" type="ST_Jc" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   alignment: AlignmentType.CENTER,
*   children: [new TextRun("Centered text")],
* });
* ```
*/
var createAlignment = (type) => new BuilderElement({
	name: "w:jc",
	attributes: { val: {
		key: "w:val",
		value: type
	} }
});
/**
* Border module for WordprocessingML documents.
*
* Borders are used in multiple contexts (paragraphs, tables, table cells, sections)
* and share the same CT_Border type definition. This module provides the createBorderElement
* factory function and BorderStyle constants used throughout the document structure.
*
* Reference: http://officeopenxml.com/WPborders.php
*
* @see http://officeopenxml.com/WPtableBorders.php
* @see http://officeopenxml.com/WPtableCellProperties-Borders.php
* @see http://officeopenxml.com/WPsectionBorders.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Border">
*   <xsd:attribute name="val" type="ST_Border" use="required"/>
*   <xsd:attribute name="color" type="ST_HexColor" use="optional" default="auto"/>
*   <xsd:attribute name="themeColor" type="ST_ThemeColor" use="optional"/>
*   <xsd:attribute name="themeTint" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="themeShade" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="sz" type="ST_EighthPointMeasure" use="optional"/>
*   <xsd:attribute name="space" type="ST_PointMeasure" use="optional" default="0"/>
*   <xsd:attribute name="shadow" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="frame" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Creates a border element for a WordprocessingML document.
*
* Used to create border specifications for paragraphs, tables, table cells,
* and sections. The element name is specified to create different border
* types (top, bottom, left, right, etc.).
*
* @example
* ```typescript
* // Create a top border
* createBorderElement("w:top", {
*   style: BorderStyle.SINGLE,
*   color: "FF0000",
*   size: 24,
*   space: 1,
* });
* ```
*/
var createBorderElement = (elementName, { color, size, space, style }) => new BuilderElement({
	name: elementName,
	attributes: {
		style: {
			key: "w:val",
			value: style
		},
		color: {
			key: "w:color",
			value: color === void 0 ? void 0 : hexColorValue(color)
		},
		size: {
			key: "w:sz",
			value: size === void 0 ? void 0 : eighthPointMeasureValue(size)
		},
		space: {
			key: "w:space",
			value: space === void 0 ? void 0 : pointMeasureValue(space)
		}
	}
});
/**
* Table borders are defined with the <w:tblBorders> element. Child elements of this element specify the kinds of `border`:
*
* `bottom`, `end` (`right` in the previous version of the standard), `insideH`, `insideV`, `start` (`left` in the previous version of the standard), and `top`.
*
* Reference: http://officeopenxml.com/WPtableBorders.php
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_Border">
*     <xsd:restriction base="xsd:string">
*          <xsd:enumeration value="single"/>
*          <xsd:enumeration value="dashDotStroked"/>
*          <xsd:enumeration value="dashed"/>
*          <xsd:enumeration value="dashSmallGap"/>
*          <xsd:enumeration value="dotDash"/>
*          <xsd:enumeration value="dotDotDash"/>
*          <xsd:enumeration value="dotted"/>
*          <xsd:enumeration value="double"/>
*          <xsd:enumeration value="doubleWave"/>
*          <xsd:enumeration value="inset"/>
*          <xsd:enumeration value="nil"/>
*          <xsd:enumeration value="none"/>
*          <xsd:enumeration value="outset"/>
*          <xsd:enumeration value="thick"/>
*          <xsd:enumeration value="thickThinLargeGap"/>
*          <xsd:enumeration value="thickThinMediumGap"/>
*          <xsd:enumeration value="thickThinSmallGap"/>
*          <xsd:enumeration value="thinThickLargeGap"/>
*          <xsd:enumeration value="thinThickMediumGap"/>
*          <xsd:enumeration value="thinThickSmallGap"/>
*          <xsd:enumeration value="thinThickThinLargeGap"/>
*          <xsd:enumeration value="thinThickThinMediumGap"/>
*          <xsd:enumeration value="thinThickThinSmallGap"/>
*          <xsd:enumeration value="threeDEmboss"/>
*          <xsd:enumeration value="threeDEngrave"/>
*          <xsd:enumeration value="triple"/>
*          <xsd:enumeration value="wave"/>
*     </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var BorderStyle = {
	/** a single line */
	SINGLE: "single",
	/** a line with a series of alternating thin and thick strokes */
	DASH_DOT_STROKED: "dashDotStroked",
	/** a dashed line */
	DASHED: "dashed",
	/** a dashed line with small gaps */
	DASH_SMALL_GAP: "dashSmallGap",
	/** a line with alternating dots and dashes */
	DOT_DASH: "dotDash",
	/** a line with a repeating dot - dot - dash sequence */
	DOT_DOT_DASH: "dotDotDash",
	/** a dotted line */
	DOTTED: "dotted",
	/** a double line */
	DOUBLE: "double",
	/** a double wavy line */
	DOUBLE_WAVE: "doubleWave",
	/** an inset set of lines */
	INSET: "inset",
	/** no border */
	NIL: "nil",
	/** no border */
	NONE: "none",
	/** an outset set of lines */
	OUTSET: "outset",
	/** a single line */
	THICK: "thick",
	/** a thick line contained within a thin line with a large-sized intermediate gap */
	THICK_THIN_LARGE_GAP: "thickThinLargeGap",
	/** a thick line contained within a thin line with a medium-sized intermediate gap */
	THICK_THIN_MEDIUM_GAP: "thickThinMediumGap",
	/** a thick line contained within a thin line with a small intermediate gap */
	THICK_THIN_SMALL_GAP: "thickThinSmallGap",
	/** a thin line contained within a thick line with a large-sized intermediate gap */
	THIN_THICK_LARGE_GAP: "thinThickLargeGap",
	/** a thick line contained within a thin line with a medium-sized intermediate gap */
	THIN_THICK_MEDIUM_GAP: "thinThickMediumGap",
	/** a thick line contained within a thin line with a small intermediate gap */
	THIN_THICK_SMALL_GAP: "thinThickSmallGap",
	/** a thin-thick-thin line with a large gap */
	THIN_THICK_THIN_LARGE_GAP: "thinThickThinLargeGap",
	/** a thin-thick-thin line with a medium gap */
	THIN_THICK_THIN_MEDIUM_GAP: "thinThickThinMediumGap",
	/** a thin-thick-thin line with a small gap */
	THIN_THICK_THIN_SMALL_GAP: "thinThickThinSmallGap",
	/** a three-staged gradient line, getting darker towards the paragraph */
	THREE_D_EMBOSS: "threeDEmboss",
	/** a three-staged gradient like, getting darker away from the paragraph */
	THREE_D_ENGRAVE: "threeDEngrave",
	/** a triple line */
	TRIPLE: "triple",
	/** a wavy line */
	WAVE: "wave"
};
/**
* Paragraph border module for WordprocessingML documents.
*
* This module provides border options for paragraphs.
*
* Reference: http://officeopenxml.com/WPborders.php
*
* @module
*/
/**
* Represents paragraph borders in a WordprocessingML document.
*
* The pBdr element specifies borders that surround the paragraph.
*
* Reference: http://officeopenxml.com/WPborders.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PBdr">
*   <xsd:sequence>
*     <xsd:element name="top" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="left" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="bottom" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="right" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="between" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="bar" type="CT_Border" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   border: {
*     top: { style: BorderStyle.SINGLE, size: 6, color: "FF0000" },
*     bottom: { style: BorderStyle.SINGLE, size: 6, color: "FF0000" },
*   },
*   children: [new TextRun("Paragraph with top and bottom borders")],
* });
* ```
*/
var Border = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:pBdr");
		if (options.top) this.root.push(createBorderElement("w:top", options.top));
		if (options.bottom) this.root.push(createBorderElement("w:bottom", options.bottom));
		if (options.left) this.root.push(createBorderElement("w:left", options.left));
		if (options.right) this.root.push(createBorderElement("w:right", options.right));
		if (options.between) this.root.push(createBorderElement("w:between", options.between));
	}
};
/**
* Represents a thematic break (horizontal rule) in a WordprocessingML document.
*
* Creates a horizontal line across the paragraph using a bottom border.
*
* Reference: http://officeopenxml.com/WPborders.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PBdr">
*   <xsd:sequence>
*     <xsd:element name="bottom" type="CT_Border" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   thematicBreak: true,
*   children: [new TextRun("Paragraph with horizontal rule below")],
* });
* ```
*/
var ThematicBreak = class extends XmlComponent {
	constructor() {
		super("w:pBdr");
		const bottom = createBorderElement("w:bottom", {
			color: "auto",
			space: 1,
			style: BorderStyle.SINGLE,
			size: 6
		});
		this.root.push(bottom);
	}
};
/**
* Paragraph indentation module for WordprocessingML documents.
*
* This module provides indentation options for paragraphs including left, right,
* hanging, and first line indentation.
*
* Reference: http://officeopenxml.com/WPindentation.php
*
* @module
*/
/**
* Creates paragraph indentation element for a WordprocessingML document.
*
* The ind element specifies the indentation of the paragraph from the margins.
*
* Reference: http://officeopenxml.com/WPindentation.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Ind">
*   <xsd:attribute name="start" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="startChars" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="end" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="endChars" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="left" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="leftChars" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="right" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="rightChars" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="hanging" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="hangingChars" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="firstLine" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="firstLineChars" type="ST_DecimalNumber" use="optional"/>
* </xsd:complexType>
* ```
*/
var createIndent = ({ start, end, left, right, hanging, firstLine, firstLineChars }) => new BuilderElement({
	name: "w:ind",
	attributes: {
		start: {
			key: "w:start",
			value: start === void 0 ? void 0 : signedTwipsMeasureValue(start)
		},
		end: {
			key: "w:end",
			value: end === void 0 ? void 0 : signedTwipsMeasureValue(end)
		},
		left: {
			key: "w:left",
			value: left === void 0 ? void 0 : signedTwipsMeasureValue(left)
		},
		right: {
			key: "w:right",
			value: right === void 0 ? void 0 : signedTwipsMeasureValue(right)
		},
		hanging: {
			key: "w:hanging",
			value: hanging === void 0 ? void 0 : twipsMeasureValue(hanging)
		},
		firstLine: {
			key: "w:firstLine",
			value: firstLine === void 0 ? void 0 : twipsMeasureValue(firstLine)
		},
		firstLineChars: {
			key: "w:firstLineChars",
			value: firstLineChars === void 0 ? void 0 : decimalNumber(firstLineChars)
		}
	}
});
/**
* Break module for WordprocessingML documents.
*
* This module provides support for line breaks within a run. A break element
* represents a line break (line feed) within text content.
*
* Reference: http://officeopenxml.com/WPtextSpecialContent-break.php
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Br">
*   <xsd:attribute name="type" type="ST_BrType" use="optional"/>
*   <xsd:attribute name="clear" type="ST_BrClear" use="optional"/>
* </xsd:complexType>
*
* <xsd:simpleType name="ST_BrType">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="page"/>
*     <xsd:enumeration value="column"/>
*     <xsd:enumeration value="textWrapping"/>
*   </xsd:restriction>
* </xsd:simpleType>
*
* <xsd:simpleType name="ST_BrClear">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="none"/>
*     <xsd:enumeration value="left"/>
*     <xsd:enumeration value="right"/>
*     <xsd:enumeration value="all"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @module
*/
/**
* Creates a line break element for a WordprocessingML document.
*
* The Break element inserts a line break (carriage return/line feed) within a run.
* This forces text to continue on the next line without starting a new paragraph.
*
* Reference: http://officeopenxml.com/WPtextSpecialContent-break.php
*
* @example
* ```typescript
* // Add line breaks in a run
* new Run({
*   children: [
*     "First line",
*     createBreak(),
*     "Second line",
*     createBreak(),
*     "Third line",
*   ],
* });
* ```
*/
var createBreak = () => new BuilderElement({ name: "w:br" });
/**
* Field module for WordprocessingML documents.
*
* This module provides support for complex fields, which are regions of text
* that can contain dynamic content such as page numbers, dates, or mail merge fields.
* Fields are delimited by field character elements (begin, separate, end).
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @module
*/
/**
* Field character types that delimit field regions.
*
* @internal
*/
var FieldCharacterType = {
	BEGIN: "begin",
	END: "end",
	SEPARATE: "separate"
};
/**
* Creates a field character element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_FldChar">
*   <xsd:sequence>
*     <xsd:element name="fldData" type="CT_Text" minOccurs="0"/>
*     <xsd:element name="ffData" type="CT_FFData" minOccurs="0"/>
*     <xsd:element name="numberingChange" type="CT_TrackChangeNumbering" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="fldCharType" type="ST_FldCharType" use="required"/>
*   <xsd:attribute name="fldLock" type="s:ST_OnOff"/>
*   <xsd:attribute name="dirty" type="s:ST_OnOff"/>
* </xsd:complexType>
* ```
* @internal
*/
var createFieldChar = (type, dirty) => new BuilderElement({
	name: "w:fldChar",
	attributes: {
		type: {
			key: "w:fldCharType",
			value: type
		},
		dirty: {
			key: "w:dirty",
			value: dirty
		}
	}
});
/**
* Creates the beginning of a complex field.
*
* The Begin element marks the start of a field. A field consists of a begin character,
* field instructions, an optional separate character, field result, and an end character.
*/
var createBegin = (dirty) => createFieldChar(FieldCharacterType.BEGIN, dirty);
/**
* Creates the separator between field code and field result in a complex field.
*
* The Separate element divides the field code (instructions) from the field result
* (the computed value).
*/
var createSeparate = (dirty) => createFieldChar(FieldCharacterType.SEPARATE, dirty);
/**
* Creates the end of a complex field.
*
* The End element marks the end of a field. Every field that begins with a Begin
* element must be terminated with an End element.
*/
var createEnd = (dirty) => createFieldChar(FieldCharacterType.END, dirty);
/**
* Space type module for WordprocessingML documents.
*
* This module provides the xml:space attribute values for
* controlling whitespace handling in text elements.
*
* @module
*/
/**
* XML space handling modes.
*
* Controls how whitespace is handled in text elements.
*
* @example
* ```typescript
* // Preserve whitespace (spaces, newlines)
* SpaceType.PRESERVE;
*
* // Default whitespace handling
* SpaceType.DEFAULT;
* ```
*
* @publicApi
*/
var SpaceType = {
	DEFAULT: "default",
	PRESERVE: "preserve"
};
/**
* Represents text element attributes.
*
* Used to set the xml:space attribute which controls
* whitespace preservation in text content.
*
* @example
* ```typescript
* new TextAttributes({ space: SpaceType.PRESERVE });
* ```
*
* @internal
*/
var TextAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { space: "xml:space" });
	}
};
/**
* Page number field instruction module for WordprocessingML documents.
*
* This module provides field instruction elements for displaying
* page numbers, page counts, and section information.
*
* Reference: http://officeopenxml.com/WPfields.php
*
* @module
*/
/**
* Represents a PAGE field instruction.
*
* Displays the current page number in the document.
*
* @example
* ```typescript
* new Run({ children: [new Begin(true), new Page(), new End()] });
* ```
*
* @internal
*/
var Page = class extends XmlComponent {
	constructor() {
		super("w:instrText");
		this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
		this.root.push("PAGE");
	}
};
/**
* Represents a NUMPAGES field instruction.
*
* Displays the total number of pages in the document.
*
* @internal
*/
var NumberOfPages = class extends XmlComponent {
	constructor() {
		super("w:instrText");
		this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
		this.root.push("NUMPAGES");
	}
};
/**
* Represents a SECTIONPAGES field instruction.
*
* Displays the total number of pages in the current section.
*
* @internal
*/
var NumberOfPagesSection = class extends XmlComponent {
	constructor() {
		super("w:instrText");
		this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
		this.root.push("SECTIONPAGES");
	}
};
/**
* Represents a SECTION field instruction.
*
* Displays the current section number.
*
* @internal
*/
var CurrentSection = class extends XmlComponent {
	constructor() {
		super("w:instrText");
		this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
		this.root.push("SECTION");
	}
};
/**
* Shading module for WordprocessingML documents.
*
* Shading is used to apply background colors and patterns to paragraphs,
* table cells, and text runs. The shading type is identical in all places.
*
* Reference: http://officeopenxml.com/WPshading.php
*
* @see http://officeopenxml.com/WPtableShading.php
* @see http://officeopenxml.com/WPtableCellProperties-Shading.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Shd">
*   <xsd:attribute name="val" type="ST_Shd" use="required"/>
*   <xsd:attribute name="color" type="ST_HexColor" use="optional"/>
*   <xsd:attribute name="themeColor" type="ST_ThemeColor" use="optional"/>
*   <xsd:attribute name="themeTint" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="themeShade" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="fill" type="ST_HexColor" use="optional"/>
*   <xsd:attribute name="themeFill" type="ST_ThemeColor" use="optional"/>
*   <xsd:attribute name="themeFillTint" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="themeFillShade" type="ST_UcharHexNumber" use="optional"/>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Creates a shading element for a WordprocessingML document.
*
* The shd element specifies the shading applied to the paragraph,
* table cell, or text run.
*
* Reference: http://officeopenxml.com/WPshading.php
*/
var createShading = ({ fill, color, type }) => new BuilderElement({
	name: "w:shd",
	attributes: {
		fill: {
			key: "w:fill",
			value: fill === void 0 ? void 0 : hexColorValue(fill)
		},
		color: {
			key: "w:color",
			value: color === void 0 ? void 0 : hexColorValue(color)
		},
		type: {
			key: "w:val",
			value: type
		}
	}
});
/**
* Shading pattern types.
*
* Specifies the pattern used for shading. The pattern combines the fill
* color and the pattern color.
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_Shd">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="nil"/>
*     <xsd:enumeration value="clear"/>
*     <xsd:enumeration value="solid"/>
*     <xsd:enumeration value="horzStripe"/>
*     <xsd:enumeration value="vertStripe"/>
*     <xsd:enumeration value="reverseDiagStripe"/>
*     <xsd:enumeration value="diagStripe"/>
*     <xsd:enumeration value="horzCross"/>
*     <xsd:enumeration value="diagCross"/>
*     <!-- ... percent values ... -->
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var ShadingType = {
	/** Clear shading - no pattern, fill color only */
	CLEAR: "clear",
	DIAGONAL_CROSS: "diagCross",
	DIAGONAL_STRIPE: "diagStripe",
	HORIZONTAL_CROSS: "horzCross",
	HORIZONTAL_STRIPE: "horzStripe",
	NIL: "nil",
	PERCENT_5: "pct5",
	PERCENT_10: "pct10",
	PERCENT_12: "pct12",
	PERCENT_15: "pct15",
	PERCENT_20: "pct20",
	PERCENT_25: "pct25",
	PERCENT_30: "pct30",
	PERCENT_35: "pct35",
	PERCENT_37: "pct37",
	PERCENT_40: "pct40",
	PERCENT_45: "pct45",
	PERCENT_50: "pct50",
	PERCENT_55: "pct55",
	PERCENT_60: "pct60",
	PERCENT_62: "pct62",
	PERCENT_65: "pct65",
	PERCENT_70: "pct70",
	PERCENT_75: "pct75",
	PERCENT_80: "pct80",
	PERCENT_85: "pct85",
	PERCENT_87: "pct87",
	PERCENT_90: "pct90",
	PERCENT_95: "pct95",
	REVERSE_DIAGONAL_STRIPE: "reverseDiagStripe",
	SOLID: "solid",
	THIN_DIAGONAL_CROSS: "thinDiagCross",
	THIN_DIAGONAL_STRIPE: "thinDiagStripe",
	THIN_HORIZONTAL_CROSS: "thinHorzCross",
	THIN_REVERSE_DIAGONAL_STRIPE: "thinReverseDiagStripe",
	THIN_VERTICAL_STRIPE: "thinVertStripe",
	VERTICAL_STRIPE: "vertStripe"
};
/**
* Track Revision module for WordprocessingML documents.
*
* This module provides support for tracking document revisions
* (insertions, deletions, and formatting changes).
*
* Reference: http://officeopenxml.com/WPtrackChanges.php
*
* @module
*/
/**
* Attributes for a tracked change element.
*
* Represents the common attributes (id, author, date) that appear on track change
* elements such as insertions (w:ins) and deletions (w:del). These attributes
* are part of the CT_TrackChange complex type in OOXML.
*
* Reference: http://officeopenxml.com/WPtrackChanges.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TrackChange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_Markup">
*       <xsd:attribute name="author" type="s:ST_String" use="required"/>
*       <xsd:attribute name="date" type="ST_DateTime" use="optional"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_Markup">
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @internal
*/
var ChangeAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			id: "w:id",
			author: "w:author",
			date: "w:date"
		});
	}
};
var DeletionTrackChange = class extends XmlComponent {
	constructor(options) {
		super("w:del");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
var InsertionTrackChange = class extends XmlComponent {
	constructor(options) {
		super("w:ins");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
/**
* Emphasis mark module for WordprocessingML run properties.
*
* This module provides support for East Asian emphasis marks, which are
* characters placed above or below text to emphasize it.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @module
*/
/**
* Emphasis mark types.
*
* Defines the types of emphasis marks that can be applied to text.
* Emphasis marks are commonly used in East Asian typography.
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_Em">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="none"/>
*     <xsd:enumeration value="dot"/>
*     <xsd:enumeration value="comma"/>
*     <xsd:enumeration value="circle"/>
*     <xsd:enumeration value="underDot"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var EmphasisMarkType = { 
/** Dot emphasis mark */
DOT: "dot" };
/**
* Creates an emphasis mark element for a WordprocessingML document.
*
* Emphasis marks are characters (typically dots or circles) placed above or below
* text to emphasize it. This is commonly used in East Asian typography.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Em">
*   <xsd:attribute name="val" type="ST_Em" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Apply dot emphasis mark
* createEmphasisMark(EmphasisMarkType.DOT);
*
* // Default to dot
* createEmphasisMark();
* ```
*/
var createEmphasisMark = (emphasisMarkType = EmphasisMarkType.DOT) => new BuilderElement({
	name: "w:em",
	attributes: { val: {
		key: "w:val",
		value: emphasisMarkType
	} }
});
/**
* Run formatting module for WordprocessingML documents.
*
* This module provides character-level formatting elements including
* spacing, color, and highlighting.
*
* Reference: http://officeopenxml.com/WPtextFormatting.php
*
* @module
*/
/**
* Represents character spacing (tracking) in a run.
*
* Adjusts the space between characters in the text.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SignedTwipsMeasure">
*   <xsd:attribute name="val" type="ST_SignedTwipsMeasure" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new CharacterSpacing(20); // 20 twips (1 point)
* new CharacterSpacing("0.5pt"); // Half point
* ```
*
* @internal
*/
var CharacterSpacing = class extends XmlComponent {
	constructor(value) {
		super("w:spacing");
		this.root.push(new Attributes({ val: signedTwipsMeasureValue(value) }));
	}
};
/**
* Represents text color in a run.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Color">
*   <xsd:attribute name="val" type="ST_HexColor" use="required"/>
*   <xsd:attribute name="themeColor" type="ST_ThemeColor" use="optional"/>
*   <xsd:attribute name="themeTint" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="themeShade" type="ST_UcharHexNumber" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Color("FF0000"); // Red text
* new Color("auto"); // Automatic color
* ```
*
* @internal
*/
var Color = class extends XmlComponent {
	constructor(color) {
		super("w:color");
		this.root.push(new Attributes({ val: hexColorValue(color) }));
	}
};
/**
* Represents text highlighting in a run.
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_HighlightColor">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="black"/>
*     <xsd:enumeration value="blue"/>
*     <xsd:enumeration value="cyan"/>
*     <xsd:enumeration value="green"/>
*     <xsd:enumeration value="magenta"/>
*     <xsd:enumeration value="red"/>
*     <xsd:enumeration value="yellow"/>
*     <xsd:enumeration value="white"/>
*     <xsd:enumeration value="darkBlue"/>
*     <xsd:enumeration value="darkCyan"/>
*     <xsd:enumeration value="darkGreen"/>
*     <xsd:enumeration value="darkMagenta"/>
*     <xsd:enumeration value="darkRed"/>
*     <xsd:enumeration value="darkYellow"/>
*     <xsd:enumeration value="darkGray"/>
*     <xsd:enumeration value="lightGray"/>
*     <xsd:enumeration value="none"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @example
* ```typescript
* new Highlight("yellow"); // Yellow highlight
* new Highlight("cyan"); // Cyan highlight
* ```
*
* @internal
*/
var Highlight = class extends XmlComponent {
	constructor(color) {
		super("w:highlight");
		this.root.push(new Attributes({ val: color }));
	}
};
/**
* Represents text highlighting for complex scripts.
*
* Used for highlighting text in complex script languages
* (e.g., Arabic, Hebrew, Thai).
*
* @internal
*/
var HighlightComplexScript = class extends XmlComponent {
	constructor(color) {
		super("w:highlightCs");
		this.root.push(new Attributes({ val: color }));
	}
};
/**
* Language module for WordprocessingML run properties.
*
* This module provides support for specifying the language of text content,
* which affects spell checking, grammar checking, and hyphenation.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @module
*/
/**
* Creates a language component for run properties.
*
* This function creates a language element that specifies the language for text content.
* The language setting affects spell checking, grammar checking, and hyphenation.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @param options - Language options for different text types
* @returns XmlComponent representing the language element
*
* @example
* ```typescript
* // Set language for English (US)
* createLanguageComponent({ value: "en-US" });
*
* // Set different languages for different scripts
* createLanguageComponent({
*   value: "en-US",
*   eastAsia: "ja-JP",
*   bidirectional: "ar-SA",
* });
* ```
*/
var createLanguageComponent = (options) => new BuilderElement({
	name: "w:lang",
	attributes: {
		value: {
			key: "w:val",
			value: options.value
		},
		eastAsia: {
			key: "w:eastAsia",
			value: options.eastAsia
		},
		bidirectional: {
			key: "w:bidi",
			value: options.bidirectional
		}
	}
});
/**
* Run fonts module for WordprocessingML documents.
*
* This module provides support for specifying fonts for different character sets
* within a run. Fonts can be specified separately for ASCII, complex script (CS),
* East Asian, and high ANSI character ranges.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @module
*/
/**
* Creates font settings for a run in a WordprocessingML document.
*
* The rFonts element specifies which fonts should be used for different character
* ranges in a run. This allows documents to use different fonts for ASCII, complex
* script, East Asian, and high ANSI characters.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Fonts">
*   <xsd:attribute name="hint" type="ST_Hint"/>
*   <xsd:attribute name="ascii" type="s:ST_String"/>
*   <xsd:attribute name="hAnsi" type="s:ST_String"/>
*   <xsd:attribute name="eastAsia" type="s:ST_String"/>
*   <xsd:attribute name="cs" type="s:ST_String"/>
*   <xsd:attribute name="asciiTheme" type="ST_Theme"/>
*   <xsd:attribute name="hAnsiTheme" type="ST_Theme"/>
*   <xsd:attribute name="eastAsiaTheme" type="ST_Theme"/>
*   <xsd:attribute name="cstheme" type="ST_Theme"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Use same font for all character sets
* createRunFonts("Arial");
*
* // Specify different fonts for different character sets
* createRunFonts({
*   ascii: "Arial",
*   eastAsia: "MS Mincho",
*   cs: "Arial",
*   hAnsi: "Arial",
* });
* ```
*/
var createRunFonts = (nameOrAttrs, hint) => {
	if (typeof nameOrAttrs === "string") {
		const name = nameOrAttrs;
		return new BuilderElement({
			name: "w:rFonts",
			attributes: {
				ascii: {
					key: "w:ascii",
					value: name
				},
				cs: {
					key: "w:cs",
					value: name
				},
				eastAsia: {
					key: "w:eastAsia",
					value: name
				},
				hAnsi: {
					key: "w:hAnsi",
					value: name
				},
				hint: {
					key: "w:hint",
					value: hint
				}
			}
		});
	}
	const attrs = nameOrAttrs;
	return new BuilderElement({
		name: "w:rFonts",
		attributes: {
			ascii: {
				key: "w:ascii",
				value: attrs.ascii
			},
			cs: {
				key: "w:cs",
				value: attrs.cs
			},
			eastAsia: {
				key: "w:eastAsia",
				value: attrs.eastAsia
			},
			hAnsi: {
				key: "w:hAnsi",
				value: attrs.hAnsi
			},
			hint: {
				key: "w:hint",
				value: attrs.hint
			}
		}
	});
};
/**
* Subscript and superscript module for WordprocessingML documents.
*
* This module provides vertical alignment elements for subscript
* and superscript text formatting.
*
* Reference: http://officeopenxml.com/WPtextFormatting.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_VerticalAlignRun">
*   <xsd:attribute name="val" type="ST_VerticalAlignRun" use="required"/>
* </xsd:complexType>
* <xsd:simpleType name="ST_VerticalAlignRun">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="baseline"/>
*     <xsd:enumeration value="superscript"/>
*     <xsd:enumeration value="subscript"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @module
*/
/**
* Creates a vertical alignment run element.
* @internal
*/
var createVerticalAlignRun = (type) => new BuilderElement({
	name: "w:vertAlign",
	attributes: { val: {
		key: "w:val",
		value: type
	} }
});
/**
* Creates superscript text formatting.
*
* Raises text above the baseline, commonly used for exponents
* and ordinal indicators.
*/
var createSuperScript = () => createVerticalAlignRun("superscript");
/**
* Creates subscript text formatting.
*
* Lowers text below the baseline, commonly used for chemical
* formulas and footnote references.
*/
var createSubScript = () => createVerticalAlignRun("subscript");
/**
* Underline module for WordprocessingML documents.
*
* This module provides support for underlining text with various styles and colors.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @module
*/
/**
* Underline style types for text.
*
* Defines the various underline patterns that can be applied to text runs.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_Underline">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="single"/>
*     <xsd:enumeration value="words"/>
*     <xsd:enumeration value="double"/>
*     <xsd:enumeration value="thick"/>
*     <xsd:enumeration value="dotted"/>
*     <xsd:enumeration value="dottedHeavy"/>
*     <xsd:enumeration value="dash"/>
*     <xsd:enumeration value="dashedHeavy"/>
*     <xsd:enumeration value="dashLong"/>
*     <xsd:enumeration value="dashLongHeavy"/>
*     <xsd:enumeration value="dotDash"/>
*     <xsd:enumeration value="dashDotHeavy"/>
*     <xsd:enumeration value="dotDotDash"/>
*     <xsd:enumeration value="dashDotDotHeavy"/>
*     <xsd:enumeration value="wave"/>
*     <xsd:enumeration value="wavyHeavy"/>
*     <xsd:enumeration value="wavyDouble"/>
*     <xsd:enumeration value="none"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var UnderlineType = {
	/** Single underline */
	SINGLE: "single",
	/** Underline words only (not spaces) */
	WORDS: "words",
	/** Double underline */
	DOUBLE: "double",
	/** Thick single underline */
	THICK: "thick",
	/** Dotted underline */
	DOTTED: "dotted",
	/** Heavy dotted underline */
	DOTTEDHEAVY: "dottedHeavy",
	/** Dashed underline */
	DASH: "dash",
	/** Heavy dashed underline */
	DASHEDHEAVY: "dashedHeavy",
	/** Long dashed underline */
	DASHLONG: "dashLong",
	/** Heavy long dashed underline */
	DASHLONGHEAVY: "dashLongHeavy",
	/** Dot-dash underline */
	DOTDASH: "dotDash",
	/** Heavy dot-dash underline */
	DASHDOTHEAVY: "dashDotHeavy",
	/** Dot-dot-dash underline */
	DOTDOTDASH: "dotDotDash",
	/** Heavy dot-dot-dash underline */
	DASHDOTDOTHEAVY: "dashDotDotHeavy",
	/** Wave underline */
	WAVE: "wave",
	/** Heavy wave underline */
	WAVYHEAVY: "wavyHeavy",
	/** Double wave underline */
	WAVYDOUBLE: "wavyDouble",
	/** No underline */
	NONE: "none"
};
/**
* Creates underline formatting for a run in a WordprocessingML document.
*
* The u element specifies the style and optional color of underline
* formatting applied to text.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Underline">
*   <xsd:attribute name="val" type="ST_Underline" use="required"/>
*   <xsd:attribute name="color" type="ST_HexColor"/>
*   <xsd:attribute name="themeColor" type="ST_ThemeColor"/>
*   <xsd:attribute name="themeTint" type="ST_UcharHexNumber"/>
*   <xsd:attribute name="themeShade" type="ST_UcharHexNumber"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Simple single underline
* createUnderline();
*
* // Double underline
* createUnderline(UnderlineType.DOUBLE);
*
* // Red wavy underline
* createUnderline(UnderlineType.WAVE, "FF0000");
* ```
*/
var createUnderline = (underlineType = UnderlineType.SINGLE, color) => new BuilderElement({
	name: "w:u",
	attributes: {
		val: {
			key: "w:val",
			value: underlineType
		},
		color: {
			key: "w:color",
			value: color === void 0 ? void 0 : hexColorValue(color)
		}
	}
});
/**
* Represents run properties (rPr) in a WordprocessingML document.
*
* Run properties specify all character-level formatting applied to text,
* such as bold, italic, font, size, color, underline, and other text effects.
*
* Reference: http://officeopenxml.com/WPtextFormatting.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_RPr">
*   <xsd:sequence>
*     <xsd:group ref="EG_RPrContent" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* The EG_RPrBase group includes elements like rStyle, rFonts, b, bCs, i, iCs,
* caps, smallCaps, strike, dstrike, outline, shadow, emboss, imprint, noProof,
* snapToGrid, vanish, color, spacing, w, kern, position, sz, szCs, highlight,
* u, effect, bdr, shd, vertAlign, rtl, em, lang, and more.
*/
var RunProperties = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:rPr");
		if (!options) return;
		if (options.style) this.push(new StringValueElement("w:rStyle", options.style));
		if (options.font) if (typeof options.font === "string") this.push(createRunFonts(options.font));
		else if ("name" in options.font) this.push(createRunFonts(options.font.name, options.font.hint));
		else this.push(createRunFonts(options.font));
		if (options.bold !== void 0) this.push(new OnOffElement("w:b", options.bold));
		if (options.boldComplexScript === void 0 && options.bold !== void 0 || options.boldComplexScript) {
			var _options$boldComplexS;
			this.push(new OnOffElement("w:bCs", (_options$boldComplexS = options.boldComplexScript) !== null && _options$boldComplexS !== void 0 ? _options$boldComplexS : options.bold));
		}
		if (options.italics !== void 0) this.push(new OnOffElement("w:i", options.italics));
		if (options.italicsComplexScript === void 0 && options.italics !== void 0 || options.italicsComplexScript) {
			var _options$italicsCompl;
			this.push(new OnOffElement("w:iCs", (_options$italicsCompl = options.italicsComplexScript) !== null && _options$italicsCompl !== void 0 ? _options$italicsCompl : options.italics));
		}
		if (options.smallCaps !== void 0) this.push(new OnOffElement("w:smallCaps", options.smallCaps));
		else if (options.allCaps !== void 0) this.push(new OnOffElement("w:caps", options.allCaps));
		if (options.strike !== void 0) this.push(new OnOffElement("w:strike", options.strike));
		if (options.doubleStrike !== void 0) this.push(new OnOffElement("w:dstrike", options.doubleStrike));
		if (options.emboss !== void 0) this.push(new OnOffElement("w:emboss", options.emboss));
		if (options.imprint !== void 0) this.push(new OnOffElement("w:imprint", options.imprint));
		if (options.noProof !== void 0) this.push(new OnOffElement("w:noProof", options.noProof));
		if (options.snapToGrid !== void 0) this.push(new OnOffElement("w:snapToGrid", options.snapToGrid));
		if (options.vanish) this.push(new OnOffElement("w:vanish", options.vanish));
		if (options.color) this.push(new Color(options.color));
		if (options.characterSpacing) this.push(new CharacterSpacing(options.characterSpacing));
		if (options.scale !== void 0) this.push(new NumberValueElement("w:w", options.scale));
		if (options.kern) this.push(new HpsMeasureElement("w:kern", options.kern));
		if (options.position) this.push(new StringValueElement("w:position", options.position));
		if (options.size !== void 0) this.push(new HpsMeasureElement("w:sz", options.size));
		const szCs = options.sizeComplexScript === void 0 || options.sizeComplexScript === true ? options.size : options.sizeComplexScript;
		if (szCs) this.push(new HpsMeasureElement("w:szCs", szCs));
		if (options.highlight) this.push(new Highlight(options.highlight));
		const highlightCs = options.highlightComplexScript === void 0 || options.highlightComplexScript === true ? options.highlight : options.highlightComplexScript;
		if (highlightCs) this.push(new HighlightComplexScript(highlightCs));
		if (options.underline) this.push(createUnderline(options.underline.type, options.underline.color));
		if (options.effect) this.push(new StringValueElement("w:effect", options.effect));
		if (options.border) this.push(createBorderElement("w:bdr", options.border));
		if (options.shading) this.push(createShading(options.shading));
		if (options.subScript) this.push(createSubScript());
		if (options.superScript) this.push(createSuperScript());
		if (options.rightToLeft !== void 0) this.push(new OnOffElement("w:rtl", options.rightToLeft));
		if (options.emphasisMark) this.push(createEmphasisMark(options.emphasisMark.type));
		if (options.language) this.push(createLanguageComponent(options.language));
		if (options.specVanish) this.push(new OnOffElement("w:specVanish", options.vanish));
		if (options.math) this.push(new OnOffElement("w:oMath", options.math));
		if (options.revision) this.push(new RunPropertiesChange(options.revision));
	}
	push(item) {
		this.root.push(item);
	}
};
var ParagraphRunProperties = class extends RunProperties {
	constructor(options) {
		super(options);
		if (options === null || options === void 0 ? void 0 : options.insertion) this.push(new InsertionTrackChange(options.insertion));
		if (options === null || options === void 0 ? void 0 : options.deletion) this.push(new DeletionTrackChange(options.deletion));
	}
};
/**
* Represents a run properties change element for revision tracking.
*
* This element is used to track changes to run properties when revision
* tracking is enabled in the document.
*/
var RunPropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:rPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.addChildElement(new RunProperties(options));
	}
};
/**
* Text module for WordprocessingML run content.
*
* This module provides the Text class for text content within runs.
*
* @module
*/
/**
* Represents a text element within a run.
*
* Text is the container for actual character content in a Word document.
* It corresponds to the `<w:t>` element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Text">
*   <xsd:simpleContent>
*     <xsd:extension base="s:ST_String">
*       <xsd:attribute ref="xml:space" use="optional"/>
*     </xsd:extension>
*   </xsd:simpleContent>
* </xsd:complexType>
* ```
*/
var Text = class extends XmlComponent {
	constructor(options) {
		super("w:t");
		if (typeof options === "string") {
			this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
			this.root.push(options);
		} else {
			var _options$space;
			this.root.push(new TextAttributes({ space: (_options$space = options.space) !== null && _options$space !== void 0 ? _options$space : SpaceType.DEFAULT }));
			this.root.push(options.text);
		}
	}
};
/**
* Constants for page number field types.
*
* These values are used to insert dynamic page number fields into a document.
*
* Reference: http://officeopenxml.com/WPfields.php
*
* @publicApi
*/
var PageNumber = {
	/** Inserts the current page number */
	CURRENT: "CURRENT",
	/** Inserts the total number of pages in the document */
	TOTAL_PAGES: "TOTAL_PAGES",
	/** Inserts the total number of pages in the current section */
	TOTAL_PAGES_IN_SECTION: "TOTAL_PAGES_IN_SECTION",
	/** Inserts the current section number */
	CURRENT_SECTION: "SECTION"
};
/**
* Represents a run of text with uniform formatting in a WordprocessingML document.
*
* A run is the lowest level unit of text in a paragraph. All content within a run
* shares the same formatting properties (bold, italic, font, size, etc.).
*
* Reference: http://officeopenxml.com/WPtext.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_R">
*   <xsd:sequence>
*     <xsd:group ref="EG_RPr" minOccurs="0"/>
*     <xsd:group ref="EG_RunInnerContent" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="rsidRPr" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidDel" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidR" type="ST_LongHexNumber"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Simple run with text
* new Run({ text: "Hello World" });
*
* // Bold and italic run
* new Run({ text: "Formatted", bold: true, italics: true });
*
* // Run with page number
* new Run({ children: [PageNumber.CURRENT] });
* ```
*/
var Run = class extends XmlComponent {
	constructor(options) {
		super("w:r");
		_defineProperty(this, "properties", void 0);
		this.properties = new RunProperties(options);
		this.root.push(this.properties);
		if (options.break) for (let i = 0; i < options.break; i++) this.root.push(createBreak());
		if (options.children) for (const child of options.children) {
			if (typeof child === "string") {
				switch (child) {
					case PageNumber.CURRENT:
						this.root.push(createBegin());
						this.root.push(new Page());
						this.root.push(createSeparate());
						this.root.push(createEnd());
						break;
					case PageNumber.TOTAL_PAGES:
						this.root.push(createBegin());
						this.root.push(new NumberOfPages());
						this.root.push(createSeparate());
						this.root.push(createEnd());
						break;
					case PageNumber.TOTAL_PAGES_IN_SECTION:
						this.root.push(createBegin());
						this.root.push(new NumberOfPagesSection());
						this.root.push(createSeparate());
						this.root.push(createEnd());
						break;
					case PageNumber.CURRENT_SECTION:
						this.root.push(createBegin());
						this.root.push(new CurrentSection());
						this.root.push(createSeparate());
						this.root.push(createEnd());
						break;
					default: this.root.push(new Text(child));
				}
				continue;
			}
			this.root.push(child);
		}
		else if (options.text !== void 0) this.root.push(new Text(options.text));
	}
};
/**
* Represents a text run in a WordprocessingML document.
*
* TextRun is a convenience class that extends Run, allowing you to pass
* either a string or full run options. This is the most common way to
* add text content to a paragraph.
*
* Reference: http://officeopenxml.com/WPtext.php
*
* @publicApi
*
* @example
* ```typescript
* // Simple text
* new TextRun("Hello World");
*
* // Formatted text
* new TextRun({ text: "Bold Text", bold: true });
* ```
*/
var TextRun = class extends Run {
	constructor(options) {
		super(typeof options === "string" ? { text: options } : options);
	}
};
var require_minimalistic_assert = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = assert;
	function assert(val, msg) {
		if (!val) throw new Error(msg || "Assertion failed");
	}
	assert.equal = function assertEqual(l, r, msg) {
		if (l != r) throw new Error(msg || "Assertion failed: " + l + " != " + r);
	};
}));
var require_utils = /* @__PURE__ */ __commonJSMin(((exports) => {
	var assert = require_minimalistic_assert();
	exports.inherits = require_inherits_browser();
	function isSurrogatePair(msg, i) {
		if ((msg.charCodeAt(i) & 64512) !== 55296) return false;
		if (i < 0 || i + 1 >= msg.length) return false;
		return (msg.charCodeAt(i + 1) & 64512) === 56320;
	}
	function toArray(msg, enc) {
		if (Array.isArray(msg)) return msg.slice();
		if (!msg) return [];
		var res = [];
		if (typeof msg === "string") {
			if (!enc) {
				var p = 0;
				for (var i = 0; i < msg.length; i++) {
					var c = msg.charCodeAt(i);
					if (c < 128) res[p++] = c;
					else if (c < 2048) {
						res[p++] = c >> 6 | 192;
						res[p++] = c & 63 | 128;
					} else if (isSurrogatePair(msg, i)) {
						c = 65536 + ((c & 1023) << 10) + (msg.charCodeAt(++i) & 1023);
						res[p++] = c >> 18 | 240;
						res[p++] = c >> 12 & 63 | 128;
						res[p++] = c >> 6 & 63 | 128;
						res[p++] = c & 63 | 128;
					} else {
						res[p++] = c >> 12 | 224;
						res[p++] = c >> 6 & 63 | 128;
						res[p++] = c & 63 | 128;
					}
				}
			} else if (enc === "hex") {
				msg = msg.replace(/[^a-z0-9]+/gi, "");
				if (msg.length % 2 !== 0) msg = "0" + msg;
				for (i = 0; i < msg.length; i += 2) res.push(parseInt(msg[i] + msg[i + 1], 16));
			}
		} else for (i = 0; i < msg.length; i++) res[i] = msg[i] | 0;
		return res;
	}
	exports.toArray = toArray;
	function toHex(msg) {
		var res = "";
		for (var i = 0; i < msg.length; i++) res += zero2(msg[i].toString(16));
		return res;
	}
	exports.toHex = toHex;
	function htonl(w) {
		return (w >>> 24 | w >>> 8 & 65280 | w << 8 & 16711680 | (w & 255) << 24) >>> 0;
	}
	exports.htonl = htonl;
	function toHex32(msg, endian) {
		var res = "";
		for (var i = 0; i < msg.length; i++) {
			var w = msg[i];
			if (endian === "little") w = htonl(w);
			res += zero8(w.toString(16));
		}
		return res;
	}
	exports.toHex32 = toHex32;
	function zero2(word) {
		if (word.length === 1) return "0" + word;
		else return word;
	}
	exports.zero2 = zero2;
	function zero8(word) {
		if (word.length === 7) return "0" + word;
		else if (word.length === 6) return "00" + word;
		else if (word.length === 5) return "000" + word;
		else if (word.length === 4) return "0000" + word;
		else if (word.length === 3) return "00000" + word;
		else if (word.length === 2) return "000000" + word;
		else if (word.length === 1) return "0000000" + word;
		else return word;
	}
	exports.zero8 = zero8;
	function join32(msg, start, end, endian) {
		var len = end - start;
		assert(len % 4 === 0);
		var res = new Array(len / 4);
		for (var i = 0, k = start; i < res.length; i++, k += 4) {
			var w;
			if (endian === "big") w = msg[k] << 24 | msg[k + 1] << 16 | msg[k + 2] << 8 | msg[k + 3];
			else w = msg[k + 3] << 24 | msg[k + 2] << 16 | msg[k + 1] << 8 | msg[k];
			res[i] = w >>> 0;
		}
		return res;
	}
	exports.join32 = join32;
	function split32(msg, endian) {
		var res = new Array(msg.length * 4);
		for (var i = 0, k = 0; i < msg.length; i++, k += 4) {
			var m = msg[i];
			if (endian === "big") {
				res[k] = m >>> 24;
				res[k + 1] = m >>> 16 & 255;
				res[k + 2] = m >>> 8 & 255;
				res[k + 3] = m & 255;
			} else {
				res[k + 3] = m >>> 24;
				res[k + 2] = m >>> 16 & 255;
				res[k + 1] = m >>> 8 & 255;
				res[k] = m & 255;
			}
		}
		return res;
	}
	exports.split32 = split32;
	function rotr32(w, b) {
		return w >>> b | w << 32 - b;
	}
	exports.rotr32 = rotr32;
	function rotl32(w, b) {
		return w << b | w >>> 32 - b;
	}
	exports.rotl32 = rotl32;
	function sum32(a, b) {
		return a + b >>> 0;
	}
	exports.sum32 = sum32;
	function sum32_3(a, b, c) {
		return a + b + c >>> 0;
	}
	exports.sum32_3 = sum32_3;
	function sum32_4(a, b, c, d) {
		return a + b + c + d >>> 0;
	}
	exports.sum32_4 = sum32_4;
	function sum32_5(a, b, c, d, e) {
		return a + b + c + d + e >>> 0;
	}
	exports.sum32_5 = sum32_5;
	function sum64(buf, pos, ah, al) {
		var bh = buf[pos];
		var lo = al + buf[pos + 1] >>> 0;
		buf[pos] = (lo < al ? 1 : 0) + ah + bh >>> 0;
		buf[pos + 1] = lo;
	}
	exports.sum64 = sum64;
	function sum64_hi(ah, al, bh, bl) {
		return (al + bl >>> 0 < al ? 1 : 0) + ah + bh >>> 0;
	}
	exports.sum64_hi = sum64_hi;
	function sum64_lo(ah, al, bh, bl) {
		return al + bl >>> 0;
	}
	exports.sum64_lo = sum64_lo;
	function sum64_4_hi(ah, al, bh, bl, ch, cl, dh, dl) {
		var carry = 0;
		var lo = al;
		lo = lo + bl >>> 0;
		carry += lo < al ? 1 : 0;
		lo = lo + cl >>> 0;
		carry += lo < cl ? 1 : 0;
		lo = lo + dl >>> 0;
		carry += lo < dl ? 1 : 0;
		return ah + bh + ch + dh + carry >>> 0;
	}
	exports.sum64_4_hi = sum64_4_hi;
	function sum64_4_lo(ah, al, bh, bl, ch, cl, dh, dl) {
		return al + bl + cl + dl >>> 0;
	}
	exports.sum64_4_lo = sum64_4_lo;
	function sum64_5_hi(ah, al, bh, bl, ch, cl, dh, dl, eh, el) {
		var carry = 0;
		var lo = al;
		lo = lo + bl >>> 0;
		carry += lo < al ? 1 : 0;
		lo = lo + cl >>> 0;
		carry += lo < cl ? 1 : 0;
		lo = lo + dl >>> 0;
		carry += lo < dl ? 1 : 0;
		lo = lo + el >>> 0;
		carry += lo < el ? 1 : 0;
		return ah + bh + ch + dh + eh + carry >>> 0;
	}
	exports.sum64_5_hi = sum64_5_hi;
	function sum64_5_lo(ah, al, bh, bl, ch, cl, dh, dl, eh, el) {
		return al + bl + cl + dl + el >>> 0;
	}
	exports.sum64_5_lo = sum64_5_lo;
	function rotr64_hi(ah, al, num) {
		return (al << 32 - num | ah >>> num) >>> 0;
	}
	exports.rotr64_hi = rotr64_hi;
	function rotr64_lo(ah, al, num) {
		return (ah << 32 - num | al >>> num) >>> 0;
	}
	exports.rotr64_lo = rotr64_lo;
	function shr64_hi(ah, al, num) {
		return ah >>> num;
	}
	exports.shr64_hi = shr64_hi;
	function shr64_lo(ah, al, num) {
		return (ah << 32 - num | al >>> num) >>> 0;
	}
	exports.shr64_lo = shr64_lo;
}));
var require_common$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
	var utils = require_utils();
	var assert = require_minimalistic_assert();
	function BlockHash() {
		this.pending = null;
		this.pendingTotal = 0;
		this.blockSize = this.constructor.blockSize;
		this.outSize = this.constructor.outSize;
		this.hmacStrength = this.constructor.hmacStrength;
		this.padLength = this.constructor.padLength / 8;
		this.endian = "big";
		this._delta8 = this.blockSize / 8;
		this._delta32 = this.blockSize / 32;
	}
	exports.BlockHash = BlockHash;
	BlockHash.prototype.update = function update(msg, enc) {
		msg = utils.toArray(msg, enc);
		if (!this.pending) this.pending = msg;
		else this.pending = this.pending.concat(msg);
		this.pendingTotal += msg.length;
		if (this.pending.length >= this._delta8) {
			msg = this.pending;
			var r = msg.length % this._delta8;
			this.pending = msg.slice(msg.length - r, msg.length);
			if (this.pending.length === 0) this.pending = null;
			msg = utils.join32(msg, 0, msg.length - r, this.endian);
			for (var i = 0; i < msg.length; i += this._delta32) this._update(msg, i, i + this._delta32);
		}
		return this;
	};
	BlockHash.prototype.digest = function digest(enc) {
		this.update(this._pad());
		assert(this.pending === null);
		return this._digest(enc);
	};
	BlockHash.prototype._pad = function pad() {
		var len = this.pendingTotal;
		var bytes = this._delta8;
		var k = bytes - (len + this.padLength) % bytes;
		var res = new Array(k + this.padLength);
		res[0] = 128;
		for (var i = 1; i < k; i++) res[i] = 0;
		len <<= 3;
		if (this.endian === "big") {
			for (var t = 8; t < this.padLength; t++) res[i++] = 0;
			res[i++] = 0;
			res[i++] = 0;
			res[i++] = 0;
			res[i++] = 0;
			res[i++] = len >>> 24 & 255;
			res[i++] = len >>> 16 & 255;
			res[i++] = len >>> 8 & 255;
			res[i++] = len & 255;
		} else {
			res[i++] = len & 255;
			res[i++] = len >>> 8 & 255;
			res[i++] = len >>> 16 & 255;
			res[i++] = len >>> 24 & 255;
			res[i++] = 0;
			res[i++] = 0;
			res[i++] = 0;
			res[i++] = 0;
			for (t = 8; t < this.padLength; t++) res[i++] = 0;
		}
		return res;
	};
}));
var require_common = /* @__PURE__ */ __commonJSMin(((exports) => {
	var rotr32 = require_utils().rotr32;
	function ft_1(s, x, y, z) {
		if (s === 0) return ch32(x, y, z);
		if (s === 1 || s === 3) return p32(x, y, z);
		if (s === 2) return maj32(x, y, z);
	}
	exports.ft_1 = ft_1;
	function ch32(x, y, z) {
		return x & y ^ ~x & z;
	}
	exports.ch32 = ch32;
	function maj32(x, y, z) {
		return x & y ^ x & z ^ y & z;
	}
	exports.maj32 = maj32;
	function p32(x, y, z) {
		return x ^ y ^ z;
	}
	exports.p32 = p32;
	function s0_256(x) {
		return rotr32(x, 2) ^ rotr32(x, 13) ^ rotr32(x, 22);
	}
	exports.s0_256 = s0_256;
	function s1_256(x) {
		return rotr32(x, 6) ^ rotr32(x, 11) ^ rotr32(x, 25);
	}
	exports.s1_256 = s1_256;
	function g0_256(x) {
		return rotr32(x, 7) ^ rotr32(x, 18) ^ x >>> 3;
	}
	exports.g0_256 = g0_256;
	function g1_256(x) {
		return rotr32(x, 17) ^ rotr32(x, 19) ^ x >>> 10;
	}
	exports.g1_256 = g1_256;
}));
var require__1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var utils = require_utils();
	var common = require_common$1();
	var shaCommon = require_common();
	var rotl32 = utils.rotl32;
	var sum32 = utils.sum32;
	var sum32_5 = utils.sum32_5;
	var ft_1 = shaCommon.ft_1;
	var BlockHash = common.BlockHash;
	var sha1_K = [
		1518500249,
		1859775393,
		2400959708,
		3395469782
	];
	function SHA1() {
		if (!(this instanceof SHA1)) return new SHA1();
		BlockHash.call(this);
		this.h = [
			1732584193,
			4023233417,
			2562383102,
			271733878,
			3285377520
		];
		this.W = new Array(80);
	}
	utils.inherits(SHA1, BlockHash);
	module.exports = SHA1;
	SHA1.blockSize = 512;
	SHA1.outSize = 160;
	SHA1.hmacStrength = 80;
	SHA1.padLength = 64;
	SHA1.prototype._update = function _update(msg, start) {
		var W = this.W;
		for (var i = 0; i < 16; i++) W[i] = msg[start + i];
		for (; i < W.length; i++) W[i] = rotl32(W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16], 1);
		var a = this.h[0];
		var b = this.h[1];
		var c = this.h[2];
		var d = this.h[3];
		var e = this.h[4];
		for (i = 0; i < W.length; i++) {
			var s = ~~(i / 20);
			var t = sum32_5(rotl32(a, 5), ft_1(s, b, c, d), e, W[i], sha1_K[s]);
			e = d;
			d = c;
			c = rotl32(b, 30);
			b = a;
			a = t;
		}
		this.h[0] = sum32(this.h[0], a);
		this.h[1] = sum32(this.h[1], b);
		this.h[2] = sum32(this.h[2], c);
		this.h[3] = sum32(this.h[3], d);
		this.h[4] = sum32(this.h[4], e);
	};
	SHA1.prototype._digest = function digest(enc) {
		if (enc === "hex") return utils.toHex32(this.h, "big");
		else return utils.split32(this.h, "big");
	};
}));
var require__256 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var utils = require_utils();
	var common = require_common$1();
	var shaCommon = require_common();
	var assert = require_minimalistic_assert();
	var sum32 = utils.sum32;
	var sum32_4 = utils.sum32_4;
	var sum32_5 = utils.sum32_5;
	var ch32 = shaCommon.ch32;
	var maj32 = shaCommon.maj32;
	var s0_256 = shaCommon.s0_256;
	var s1_256 = shaCommon.s1_256;
	var g0_256 = shaCommon.g0_256;
	var g1_256 = shaCommon.g1_256;
	var BlockHash = common.BlockHash;
	var sha256_K = [
		1116352408,
		1899447441,
		3049323471,
		3921009573,
		961987163,
		1508970993,
		2453635748,
		2870763221,
		3624381080,
		310598401,
		607225278,
		1426881987,
		1925078388,
		2162078206,
		2614888103,
		3248222580,
		3835390401,
		4022224774,
		264347078,
		604807628,
		770255983,
		1249150122,
		1555081692,
		1996064986,
		2554220882,
		2821834349,
		2952996808,
		3210313671,
		3336571891,
		3584528711,
		113926993,
		338241895,
		666307205,
		773529912,
		1294757372,
		1396182291,
		1695183700,
		1986661051,
		2177026350,
		2456956037,
		2730485921,
		2820302411,
		3259730800,
		3345764771,
		3516065817,
		3600352804,
		4094571909,
		275423344,
		430227734,
		506948616,
		659060556,
		883997877,
		958139571,
		1322822218,
		1537002063,
		1747873779,
		1955562222,
		2024104815,
		2227730452,
		2361852424,
		2428436474,
		2756734187,
		3204031479,
		3329325298
	];
	function SHA256() {
		if (!(this instanceof SHA256)) return new SHA256();
		BlockHash.call(this);
		this.h = [
			1779033703,
			3144134277,
			1013904242,
			2773480762,
			1359893119,
			2600822924,
			528734635,
			1541459225
		];
		this.k = sha256_K;
		this.W = new Array(64);
	}
	utils.inherits(SHA256, BlockHash);
	module.exports = SHA256;
	SHA256.blockSize = 512;
	SHA256.outSize = 256;
	SHA256.hmacStrength = 192;
	SHA256.padLength = 64;
	SHA256.prototype._update = function _update(msg, start) {
		var W = this.W;
		for (var i = 0; i < 16; i++) W[i] = msg[start + i];
		for (; i < W.length; i++) W[i] = sum32_4(g1_256(W[i - 2]), W[i - 7], g0_256(W[i - 15]), W[i - 16]);
		var a = this.h[0];
		var b = this.h[1];
		var c = this.h[2];
		var d = this.h[3];
		var e = this.h[4];
		var f = this.h[5];
		var g = this.h[6];
		var h = this.h[7];
		assert(this.k.length === W.length);
		for (i = 0; i < W.length; i++) {
			var T1 = sum32_5(h, s1_256(e), ch32(e, f, g), this.k[i], W[i]);
			var T2 = sum32(s0_256(a), maj32(a, b, c));
			h = g;
			g = f;
			f = e;
			e = sum32(d, T1);
			d = c;
			c = b;
			b = a;
			a = sum32(T1, T2);
		}
		this.h[0] = sum32(this.h[0], a);
		this.h[1] = sum32(this.h[1], b);
		this.h[2] = sum32(this.h[2], c);
		this.h[3] = sum32(this.h[3], d);
		this.h[4] = sum32(this.h[4], e);
		this.h[5] = sum32(this.h[5], f);
		this.h[6] = sum32(this.h[6], g);
		this.h[7] = sum32(this.h[7], h);
	};
	SHA256.prototype._digest = function digest(enc) {
		if (enc === "hex") return utils.toHex32(this.h, "big");
		else return utils.split32(this.h, "big");
	};
}));
var require__224 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var utils = require_utils();
	var SHA256 = require__256();
	function SHA224() {
		if (!(this instanceof SHA224)) return new SHA224();
		SHA256.call(this);
		this.h = [
			3238371032,
			914150663,
			812702999,
			4144912697,
			4290775857,
			1750603025,
			1694076839,
			3204075428
		];
	}
	utils.inherits(SHA224, SHA256);
	module.exports = SHA224;
	SHA224.blockSize = 512;
	SHA224.outSize = 224;
	SHA224.hmacStrength = 192;
	SHA224.padLength = 64;
	SHA224.prototype._digest = function digest(enc) {
		if (enc === "hex") return utils.toHex32(this.h.slice(0, 7), "big");
		else return utils.split32(this.h.slice(0, 7), "big");
	};
}));
var require__512 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var utils = require_utils();
	var common = require_common$1();
	var assert = require_minimalistic_assert();
	var rotr64_hi = utils.rotr64_hi;
	var rotr64_lo = utils.rotr64_lo;
	var shr64_hi = utils.shr64_hi;
	var shr64_lo = utils.shr64_lo;
	var sum64 = utils.sum64;
	var sum64_hi = utils.sum64_hi;
	var sum64_lo = utils.sum64_lo;
	var sum64_4_hi = utils.sum64_4_hi;
	var sum64_4_lo = utils.sum64_4_lo;
	var sum64_5_hi = utils.sum64_5_hi;
	var sum64_5_lo = utils.sum64_5_lo;
	var BlockHash = common.BlockHash;
	var sha512_K = [
		1116352408,
		3609767458,
		1899447441,
		602891725,
		3049323471,
		3964484399,
		3921009573,
		2173295548,
		961987163,
		4081628472,
		1508970993,
		3053834265,
		2453635748,
		2937671579,
		2870763221,
		3664609560,
		3624381080,
		2734883394,
		310598401,
		1164996542,
		607225278,
		1323610764,
		1426881987,
		3590304994,
		1925078388,
		4068182383,
		2162078206,
		991336113,
		2614888103,
		633803317,
		3248222580,
		3479774868,
		3835390401,
		2666613458,
		4022224774,
		944711139,
		264347078,
		2341262773,
		604807628,
		2007800933,
		770255983,
		1495990901,
		1249150122,
		1856431235,
		1555081692,
		3175218132,
		1996064986,
		2198950837,
		2554220882,
		3999719339,
		2821834349,
		766784016,
		2952996808,
		2566594879,
		3210313671,
		3203337956,
		3336571891,
		1034457026,
		3584528711,
		2466948901,
		113926993,
		3758326383,
		338241895,
		168717936,
		666307205,
		1188179964,
		773529912,
		1546045734,
		1294757372,
		1522805485,
		1396182291,
		2643833823,
		1695183700,
		2343527390,
		1986661051,
		1014477480,
		2177026350,
		1206759142,
		2456956037,
		344077627,
		2730485921,
		1290863460,
		2820302411,
		3158454273,
		3259730800,
		3505952657,
		3345764771,
		106217008,
		3516065817,
		3606008344,
		3600352804,
		1432725776,
		4094571909,
		1467031594,
		275423344,
		851169720,
		430227734,
		3100823752,
		506948616,
		1363258195,
		659060556,
		3750685593,
		883997877,
		3785050280,
		958139571,
		3318307427,
		1322822218,
		3812723403,
		1537002063,
		2003034995,
		1747873779,
		3602036899,
		1955562222,
		1575990012,
		2024104815,
		1125592928,
		2227730452,
		2716904306,
		2361852424,
		442776044,
		2428436474,
		593698344,
		2756734187,
		3733110249,
		3204031479,
		2999351573,
		3329325298,
		3815920427,
		3391569614,
		3928383900,
		3515267271,
		566280711,
		3940187606,
		3454069534,
		4118630271,
		4000239992,
		116418474,
		1914138554,
		174292421,
		2731055270,
		289380356,
		3203993006,
		460393269,
		320620315,
		685471733,
		587496836,
		852142971,
		1086792851,
		1017036298,
		365543100,
		1126000580,
		2618297676,
		1288033470,
		3409855158,
		1501505948,
		4234509866,
		1607167915,
		987167468,
		1816402316,
		1246189591
	];
	function SHA512() {
		if (!(this instanceof SHA512)) return new SHA512();
		BlockHash.call(this);
		this.h = [
			1779033703,
			4089235720,
			3144134277,
			2227873595,
			1013904242,
			4271175723,
			2773480762,
			1595750129,
			1359893119,
			2917565137,
			2600822924,
			725511199,
			528734635,
			4215389547,
			1541459225,
			327033209
		];
		this.k = sha512_K;
		this.W = new Array(160);
	}
	utils.inherits(SHA512, BlockHash);
	module.exports = SHA512;
	SHA512.blockSize = 1024;
	SHA512.outSize = 512;
	SHA512.hmacStrength = 192;
	SHA512.padLength = 128;
	SHA512.prototype._prepareBlock = function _prepareBlock(msg, start) {
		var W = this.W;
		for (var i = 0; i < 32; i++) W[i] = msg[start + i];
		for (; i < W.length; i += 2) {
			var c0_hi = g1_512_hi(W[i - 4], W[i - 3]);
			var c0_lo = g1_512_lo(W[i - 4], W[i - 3]);
			var c1_hi = W[i - 14];
			var c1_lo = W[i - 13];
			var c2_hi = g0_512_hi(W[i - 30], W[i - 29]);
			var c2_lo = g0_512_lo(W[i - 30], W[i - 29]);
			var c3_hi = W[i - 32];
			var c3_lo = W[i - 31];
			W[i] = sum64_4_hi(c0_hi, c0_lo, c1_hi, c1_lo, c2_hi, c2_lo, c3_hi, c3_lo);
			W[i + 1] = sum64_4_lo(c0_hi, c0_lo, c1_hi, c1_lo, c2_hi, c2_lo, c3_hi, c3_lo);
		}
	};
	SHA512.prototype._update = function _update(msg, start) {
		this._prepareBlock(msg, start);
		var W = this.W;
		var ah = this.h[0];
		var al = this.h[1];
		var bh = this.h[2];
		var bl = this.h[3];
		var ch = this.h[4];
		var cl = this.h[5];
		var dh = this.h[6];
		var dl = this.h[7];
		var eh = this.h[8];
		var el = this.h[9];
		var fh = this.h[10];
		var fl = this.h[11];
		var gh = this.h[12];
		var gl = this.h[13];
		var hh = this.h[14];
		var hl = this.h[15];
		assert(this.k.length === W.length);
		for (var i = 0; i < W.length; i += 2) {
			var c0_hi = hh;
			var c0_lo = hl;
			var c1_hi = s1_512_hi(eh, el);
			var c1_lo = s1_512_lo(eh, el);
			var c2_hi = ch64_hi(eh, el, fh, fl, gh, gl);
			var c2_lo = ch64_lo(eh, el, fh, fl, gh, gl);
			var c3_hi = this.k[i];
			var c3_lo = this.k[i + 1];
			var c4_hi = W[i];
			var c4_lo = W[i + 1];
			var T1_hi = sum64_5_hi(c0_hi, c0_lo, c1_hi, c1_lo, c2_hi, c2_lo, c3_hi, c3_lo, c4_hi, c4_lo);
			var T1_lo = sum64_5_lo(c0_hi, c0_lo, c1_hi, c1_lo, c2_hi, c2_lo, c3_hi, c3_lo, c4_hi, c4_lo);
			c0_hi = s0_512_hi(ah, al);
			c0_lo = s0_512_lo(ah, al);
			c1_hi = maj64_hi(ah, al, bh, bl, ch, cl);
			c1_lo = maj64_lo(ah, al, bh, bl, ch, cl);
			var T2_hi = sum64_hi(c0_hi, c0_lo, c1_hi, c1_lo);
			var T2_lo = sum64_lo(c0_hi, c0_lo, c1_hi, c1_lo);
			hh = gh;
			hl = gl;
			gh = fh;
			gl = fl;
			fh = eh;
			fl = el;
			eh = sum64_hi(dh, dl, T1_hi, T1_lo);
			el = sum64_lo(dl, dl, T1_hi, T1_lo);
			dh = ch;
			dl = cl;
			ch = bh;
			cl = bl;
			bh = ah;
			bl = al;
			ah = sum64_hi(T1_hi, T1_lo, T2_hi, T2_lo);
			al = sum64_lo(T1_hi, T1_lo, T2_hi, T2_lo);
		}
		sum64(this.h, 0, ah, al);
		sum64(this.h, 2, bh, bl);
		sum64(this.h, 4, ch, cl);
		sum64(this.h, 6, dh, dl);
		sum64(this.h, 8, eh, el);
		sum64(this.h, 10, fh, fl);
		sum64(this.h, 12, gh, gl);
		sum64(this.h, 14, hh, hl);
	};
	SHA512.prototype._digest = function digest(enc) {
		if (enc === "hex") return utils.toHex32(this.h, "big");
		else return utils.split32(this.h, "big");
	};
	function ch64_hi(xh, xl, yh, yl, zh) {
		var r = xh & yh ^ ~xh & zh;
		if (r < 0) r += 4294967296;
		return r;
	}
	function ch64_lo(xh, xl, yh, yl, zh, zl) {
		var r = xl & yl ^ ~xl & zl;
		if (r < 0) r += 4294967296;
		return r;
	}
	function maj64_hi(xh, xl, yh, yl, zh) {
		var r = xh & yh ^ xh & zh ^ yh & zh;
		if (r < 0) r += 4294967296;
		return r;
	}
	function maj64_lo(xh, xl, yh, yl, zh, zl) {
		var r = xl & yl ^ xl & zl ^ yl & zl;
		if (r < 0) r += 4294967296;
		return r;
	}
	function s0_512_hi(xh, xl) {
		var c0_hi = rotr64_hi(xh, xl, 28);
		var c1_hi = rotr64_hi(xl, xh, 2);
		var c2_hi = rotr64_hi(xl, xh, 7);
		var r = c0_hi ^ c1_hi ^ c2_hi;
		if (r < 0) r += 4294967296;
		return r;
	}
	function s0_512_lo(xh, xl) {
		var c0_lo = rotr64_lo(xh, xl, 28);
		var c1_lo = rotr64_lo(xl, xh, 2);
		var c2_lo = rotr64_lo(xl, xh, 7);
		var r = c0_lo ^ c1_lo ^ c2_lo;
		if (r < 0) r += 4294967296;
		return r;
	}
	function s1_512_hi(xh, xl) {
		var c0_hi = rotr64_hi(xh, xl, 14);
		var c1_hi = rotr64_hi(xh, xl, 18);
		var c2_hi = rotr64_hi(xl, xh, 9);
		var r = c0_hi ^ c1_hi ^ c2_hi;
		if (r < 0) r += 4294967296;
		return r;
	}
	function s1_512_lo(xh, xl) {
		var c0_lo = rotr64_lo(xh, xl, 14);
		var c1_lo = rotr64_lo(xh, xl, 18);
		var c2_lo = rotr64_lo(xl, xh, 9);
		var r = c0_lo ^ c1_lo ^ c2_lo;
		if (r < 0) r += 4294967296;
		return r;
	}
	function g0_512_hi(xh, xl) {
		var c0_hi = rotr64_hi(xh, xl, 1);
		var c1_hi = rotr64_hi(xh, xl, 8);
		var c2_hi = shr64_hi(xh, xl, 7);
		var r = c0_hi ^ c1_hi ^ c2_hi;
		if (r < 0) r += 4294967296;
		return r;
	}
	function g0_512_lo(xh, xl) {
		var c0_lo = rotr64_lo(xh, xl, 1);
		var c1_lo = rotr64_lo(xh, xl, 8);
		var c2_lo = shr64_lo(xh, xl, 7);
		var r = c0_lo ^ c1_lo ^ c2_lo;
		if (r < 0) r += 4294967296;
		return r;
	}
	function g1_512_hi(xh, xl) {
		var c0_hi = rotr64_hi(xh, xl, 19);
		var c1_hi = rotr64_hi(xl, xh, 29);
		var c2_hi = shr64_hi(xh, xl, 6);
		var r = c0_hi ^ c1_hi ^ c2_hi;
		if (r < 0) r += 4294967296;
		return r;
	}
	function g1_512_lo(xh, xl) {
		var c0_lo = rotr64_lo(xh, xl, 19);
		var c1_lo = rotr64_lo(xl, xh, 29);
		var c2_lo = shr64_lo(xh, xl, 6);
		var r = c0_lo ^ c1_lo ^ c2_lo;
		if (r < 0) r += 4294967296;
		return r;
	}
}));
var require__384 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var utils = require_utils();
	var SHA512 = require__512();
	function SHA384() {
		if (!(this instanceof SHA384)) return new SHA384();
		SHA512.call(this);
		this.h = [
			3418070365,
			3238371032,
			1654270250,
			914150663,
			2438529370,
			812702999,
			355462360,
			4144912697,
			1731405415,
			4290775857,
			2394180231,
			1750603025,
			3675008525,
			1694076839,
			1203062813,
			3204075428
		];
	}
	utils.inherits(SHA384, SHA512);
	module.exports = SHA384;
	SHA384.blockSize = 1024;
	SHA384.outSize = 384;
	SHA384.hmacStrength = 192;
	SHA384.padLength = 128;
	SHA384.prototype._digest = function digest(enc) {
		if (enc === "hex") return utils.toHex32(this.h.slice(0, 12), "big");
		else return utils.split32(this.h.slice(0, 12), "big");
	};
}));
var require_sha = /* @__PURE__ */ __commonJSMin(((exports) => {
	exports.sha1 = require__1();
	exports.sha224 = require__224();
	exports.sha256 = require__256();
	exports.sha384 = require__384();
	exports.sha512 = require__512();
}));
var require_ripemd = /* @__PURE__ */ __commonJSMin(((exports) => {
	var utils = require_utils();
	var common = require_common$1();
	var rotl32 = utils.rotl32;
	var sum32 = utils.sum32;
	var sum32_3 = utils.sum32_3;
	var sum32_4 = utils.sum32_4;
	var BlockHash = common.BlockHash;
	function RIPEMD160() {
		if (!(this instanceof RIPEMD160)) return new RIPEMD160();
		BlockHash.call(this);
		this.h = [
			1732584193,
			4023233417,
			2562383102,
			271733878,
			3285377520
		];
		this.endian = "little";
	}
	utils.inherits(RIPEMD160, BlockHash);
	exports.ripemd160 = RIPEMD160;
	RIPEMD160.blockSize = 512;
	RIPEMD160.outSize = 160;
	RIPEMD160.hmacStrength = 192;
	RIPEMD160.padLength = 64;
	RIPEMD160.prototype._update = function update(msg, start) {
		var A = this.h[0];
		var B = this.h[1];
		var C = this.h[2];
		var D = this.h[3];
		var E = this.h[4];
		var Ah = A;
		var Bh = B;
		var Ch = C;
		var Dh = D;
		var Eh = E;
		for (var j = 0; j < 80; j++) {
			var T = sum32(rotl32(sum32_4(A, f(j, B, C, D), msg[r[j] + start], K(j)), s[j]), E);
			A = E;
			E = D;
			D = rotl32(C, 10);
			C = B;
			B = T;
			T = sum32(rotl32(sum32_4(Ah, f(79 - j, Bh, Ch, Dh), msg[rh[j] + start], Kh(j)), sh[j]), Eh);
			Ah = Eh;
			Eh = Dh;
			Dh = rotl32(Ch, 10);
			Ch = Bh;
			Bh = T;
		}
		T = sum32_3(this.h[1], C, Dh);
		this.h[1] = sum32_3(this.h[2], D, Eh);
		this.h[2] = sum32_3(this.h[3], E, Ah);
		this.h[3] = sum32_3(this.h[4], A, Bh);
		this.h[4] = sum32_3(this.h[0], B, Ch);
		this.h[0] = T;
	};
	RIPEMD160.prototype._digest = function digest(enc) {
		if (enc === "hex") return utils.toHex32(this.h, "little");
		else return utils.split32(this.h, "little");
	};
	function f(j, x, y, z) {
		if (j <= 15) return x ^ y ^ z;
		else if (j <= 31) return x & y | ~x & z;
		else if (j <= 47) return (x | ~y) ^ z;
		else if (j <= 63) return x & z | y & ~z;
		else return x ^ (y | ~z);
	}
	function K(j) {
		if (j <= 15) return 0;
		else if (j <= 31) return 1518500249;
		else if (j <= 47) return 1859775393;
		else if (j <= 63) return 2400959708;
		else return 2840853838;
	}
	function Kh(j) {
		if (j <= 15) return 1352829926;
		else if (j <= 31) return 1548603684;
		else if (j <= 47) return 1836072691;
		else if (j <= 63) return 2053994217;
		else return 0;
	}
	var r = [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		12,
		13,
		14,
		15,
		7,
		4,
		13,
		1,
		10,
		6,
		15,
		3,
		12,
		0,
		9,
		5,
		2,
		14,
		11,
		8,
		3,
		10,
		14,
		4,
		9,
		15,
		8,
		1,
		2,
		7,
		0,
		6,
		13,
		11,
		5,
		12,
		1,
		9,
		11,
		10,
		0,
		8,
		12,
		4,
		13,
		3,
		7,
		15,
		14,
		5,
		6,
		2,
		4,
		0,
		5,
		9,
		7,
		12,
		2,
		10,
		14,
		1,
		3,
		8,
		11,
		6,
		15,
		13
	];
	var rh = [
		5,
		14,
		7,
		0,
		9,
		2,
		11,
		4,
		13,
		6,
		15,
		8,
		1,
		10,
		3,
		12,
		6,
		11,
		3,
		7,
		0,
		13,
		5,
		10,
		14,
		15,
		8,
		12,
		4,
		9,
		1,
		2,
		15,
		5,
		1,
		3,
		7,
		14,
		6,
		9,
		11,
		8,
		12,
		2,
		10,
		0,
		4,
		13,
		8,
		6,
		4,
		1,
		3,
		11,
		15,
		0,
		5,
		12,
		2,
		13,
		9,
		7,
		10,
		14,
		12,
		15,
		10,
		4,
		1,
		5,
		8,
		7,
		6,
		2,
		13,
		14,
		0,
		3,
		9,
		11
	];
	var s = [
		11,
		14,
		15,
		12,
		5,
		8,
		7,
		9,
		11,
		13,
		14,
		15,
		6,
		7,
		9,
		8,
		7,
		6,
		8,
		13,
		11,
		9,
		7,
		15,
		7,
		12,
		15,
		9,
		11,
		7,
		13,
		12,
		11,
		13,
		6,
		7,
		14,
		9,
		13,
		15,
		14,
		8,
		13,
		6,
		5,
		12,
		7,
		5,
		11,
		12,
		14,
		15,
		14,
		15,
		9,
		8,
		9,
		14,
		5,
		6,
		8,
		6,
		5,
		12,
		9,
		15,
		5,
		11,
		6,
		8,
		13,
		12,
		5,
		12,
		13,
		14,
		11,
		8,
		5,
		6
	];
	var sh = [
		8,
		9,
		9,
		11,
		13,
		15,
		15,
		5,
		7,
		7,
		8,
		11,
		14,
		14,
		12,
		6,
		9,
		13,
		15,
		7,
		12,
		8,
		9,
		11,
		7,
		7,
		12,
		7,
		6,
		15,
		13,
		11,
		9,
		7,
		15,
		11,
		8,
		6,
		6,
		14,
		12,
		13,
		5,
		14,
		13,
		13,
		7,
		5,
		15,
		5,
		8,
		11,
		14,
		14,
		6,
		14,
		6,
		9,
		12,
		9,
		12,
		5,
		15,
		8,
		8,
		5,
		12,
		9,
		12,
		5,
		14,
		6,
		8,
		13,
		6,
		5,
		15,
		13,
		11,
		11
	];
}));
var require_hmac = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var utils = require_utils();
	var assert = require_minimalistic_assert();
	function Hmac(hash, key, enc) {
		if (!(this instanceof Hmac)) return new Hmac(hash, key, enc);
		this.Hash = hash;
		this.blockSize = hash.blockSize / 8;
		this.outSize = hash.outSize / 8;
		this.inner = null;
		this.outer = null;
		this._init(utils.toArray(key, enc));
	}
	module.exports = Hmac;
	Hmac.prototype._init = function init(key) {
		if (key.length > this.blockSize) key = new this.Hash().update(key).digest();
		assert(key.length <= this.blockSize);
		for (var i = key.length; i < this.blockSize; i++) key.push(0);
		for (i = 0; i < key.length; i++) key[i] ^= 54;
		this.inner = new this.Hash().update(key);
		for (i = 0; i < key.length; i++) key[i] ^= 106;
		this.outer = new this.Hash().update(key);
	};
	Hmac.prototype.update = function update(msg, enc) {
		this.inner.update(msg, enc);
		return this;
	};
	Hmac.prototype.digest = function digest(enc) {
		this.outer.update(this.inner.digest());
		return this.outer.digest(enc);
	};
}));
var import_hash = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports) => {
	var hash = exports;
	hash.utils = require_utils();
	hash.common = require_common$1();
	hash.sha = require_sha();
	hash.ripemd = require_ripemd();
	hash.hmac = require_hmac();
	hash.sha1 = hash.sha.sha1;
	hash.sha256 = hash.sha.sha256;
	hash.sha224 = hash.sha.sha224;
	hash.sha384 = hash.sha.sha384;
	hash.sha512 = hash.sha.sha512;
	hash.ripemd160 = hash.ripemd.ripemd160;
})))(), 1);
var urlAlphabet = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict";
var customAlphabet = (alphabet, defaultSize = 21) => {
	return (size = defaultSize) => {
		let id = "";
		let i = size | 0;
		while (i--) id += alphabet[Math.random() * alphabet.length | 0];
		return id;
	};
};
var nanoid = (size = 21) => {
	let id = "";
	let i = size | 0;
	while (i--) id += urlAlphabet[Math.random() * 64 | 0];
	return id;
};
/**
* Convenience utility functions for unit conversion and unique ID generation.
*
* This module provides:
* - Unit conversion functions (millimeters/inches to TWIP)
* - Unique ID generators for various document elements
* - Hash and UUID generation utilities
*
* @module
*/
/**
* Converts millimeters to TWIP (twentieths of a point).
*
* TWIP is a common unit in Office Open XML where 1 inch = 1440 TWIP.
*
* @param millimeters - The measurement in millimeters to convert
* @returns The equivalent measurement in TWIP
*
* @example
* ```typescript
* const width = convertMillimetersToTwip(25.4); // Returns 1440 (1 inch)
* ```
*
* @publicApi
*/
var convertMillimetersToTwip = (millimeters) => Math.floor(millimeters / 25.4 * 72 * 20);
/**
* Converts inches to TWIP (twentieths of a point).
*
* TWIP is a common unit in Office Open XML where 1 inch = 1440 TWIP.
*
* @param inches - The measurement in inches to convert
* @returns The equivalent measurement in TWIP
*
* @example
* ```typescript
* const width = convertInchesToTwip(1); // Returns 1440
* ```
*
* @publicApi
*/
var convertInchesToTwip = (inches) => Math.floor(inches * 72 * 20);
/**
* Creates a unique numeric ID generator with sequential numbering.
*
* @param initial - The initial value to start counting from (default: 0)
* @returns A function that returns incrementing numbers on each call
*
* @example
* ```typescript
* const idGen = uniqueNumericIdCreator(10);
* console.log(idGen()); // 11
* console.log(idGen()); // 12
* console.log(idGen()); // 13
* ```
*/
var uniqueNumericIdCreator = (initial = 0) => {
	let currentCount = initial;
	return () => ++currentCount;
};
/**
* Creates a unique numeric ID generator for abstract numbering definitions.
*
* Abstract numbering definitions define the appearance and behavior of lists.
*
* @returns A function that generates sequential IDs starting from 1
*
* @example
* ```typescript
* const idGen = abstractNumUniqueNumericIdGen();
* const id = idGen(); // Returns 1
* ```
*/
var abstractNumUniqueNumericIdGen = () => uniqueNumericIdCreator();
/**
* Creates a unique numeric ID generator for concrete numbering instances.
*
* Concrete numbering instances reference abstract numbering definitions and are
* used to apply numbering to paragraphs. Initial value is 1 because ID 1 is
* reserved for "default-bullet-numbering".
*
* @returns A function that generates sequential IDs starting from 2
*
* @example
* ```typescript
* const idGen = concreteNumUniqueNumericIdGen();
* const id = idGen(); // Returns 2 (1 is reserved)
* ```
*/
var concreteNumUniqueNumericIdGen = () => uniqueNumericIdCreator(1);
/**
* Creates a unique numeric ID generator for document properties.
*
* @returns A function that generates sequential IDs starting from 1
*
* @example
* ```typescript
* const idGen = docPropertiesUniqueNumericIdGen();
* const id = idGen(); // Returns 1
* ```
*/
var docPropertiesUniqueNumericIdGen = () => uniqueNumericIdCreator();
/**
* Creates a unique numeric ID generator for bookmarks.
*
* Bookmarks are used to mark specific locations in a document for navigation
* and cross-referencing.
*
* @returns A function that generates sequential IDs starting from 1
*
* @example
* ```typescript
* const idGen = bookmarkUniqueNumericIdGen();
* const id = idGen(); // Returns 1
* ```
*/
var bookmarkUniqueNumericIdGen = () => uniqueNumericIdCreator();
/**
* Generates a unique lowercase alphanumeric ID using nanoid.
*
* The ID is suitable for use as a relationship ID or other unique identifier
* within a document.
*
* @returns A unique lowercase string ID
*/
var uniqueId = () => nanoid().toLowerCase();
/**
* Generates a SHA-1 hash of the provided data.
*
* Useful for generating deterministic IDs based on content, such as for
* image references or revision tracking.
*
* @param data - The data to hash (Buffer, string, Uint8Array, or ArrayBuffer)
* @returns A hexadecimal string representation of the SHA-1 hash
*
* @example
* ```typescript
* const hash = hashedId("Hello World"); // Returns "0a4d55a8d778e5022fab701977c5d840bbc486d0"
* ```
*/
var hashedId = (data) => import_hash.default.sha1().update(data instanceof ArrayBuffer ? new Uint8Array(data) : data).digest("hex");
/**
* Generates a random hexadecimal string of specified length.
*
* @param count - The number of hexadecimal characters to generate
* @returns A random hexadecimal string
*/
var generateUuidPart = (count) => customAlphabet("1234567890abcdef", count)();
/**
* Generates a UUID v4-style unique identifier.
*
* The UUID follows the format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
*
* @returns A UUID string
*
* @example
* ```typescript
* const uuid = uniqueUuid(); // Returns "a3bb189e-8bf9-3888-9912-ace4e6543002"
* ```
*/
var uniqueUuid = () => `${generateUuidPart(8)}-${generateUuidPart(4)}-${generateUuidPart(4)}-${generateUuidPart(4)}-${generateUuidPart(12)}`;
/**
* Encode a string to UTF-8 bytes.
*
* This is used to pre-encode XML content before passing to JSZip,
* which avoids a bug where JSZip's string chunking can split UTF-16
* surrogate pairs for characters above U+FFFF (like emoji).
*
* The copy via `new Uint8Array()` ensures the returned array uses the
* current module's Uint8Array constructor, avoiding cross-realm issues
* in test environments (jsdom) where TextEncoder returns a different
* realm's Uint8Array that fails JSZip's instanceof checks.
*
* @see https://github.com/Stuk/jszip/pull/963
*/
var encodeUtf8 = (str) => new Uint8Array(new TextEncoder().encode(str));
/**
* Horizontal Relative Positioning.
*
* Specifies the horizontal base from which the drawing position is calculated.
*
* Reference: https://www.datypic.com/sc/ooxml/t-wp_ST_RelFromH.html
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_RelFromH">
*   <xsd:restriction base="xsd:token">
*     <xsd:enumeration value="margin"/>
*     <xsd:enumeration value="page"/>
*     <xsd:enumeration value="column"/>
*     <xsd:enumeration value="character"/>
*     <xsd:enumeration value="leftMargin"/>
*     <xsd:enumeration value="rightMargin"/>
*     <xsd:enumeration value="insideMargin"/>
*     <xsd:enumeration value="outsideMargin"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var HorizontalPositionRelativeFrom = {
	/**
	* ## Character
	*
	* Specifies that the horizontal positioning shall be relative to the position of the anchor within its run content.
	*/
	CHARACTER: "character",
	/**
	* ## Column
	*
	* Specifies that the horizontal positioning shall be relative to the extents of the column which contains its anchor.
	*/
	COLUMN: "column",
	/**
	* ## Inside Margin
	*
	* Specifies that the horizontal positioning shall be relative to the inside margin of the current page (the left margin on odd pages, right on even pages).
	*/
	INSIDE_MARGIN: "insideMargin",
	/**
	* ## Left Margin
	*
	* Specifies that the horizontal positioning shall be relative to the left margin of the page.
	*/
	LEFT_MARGIN: "leftMargin",
	/**
	* ## Page Margin
	*
	* Specifies that the horizontal positioning shall be relative to the page margins.
	*/
	MARGIN: "margin",
	/**
	* ## Outside Margin
	*
	* Specifies that the horizontal positioning shall be relative to the outside margin of the current page (the right margin on odd pages, left on even pages).
	*/
	OUTSIDE_MARGIN: "outsideMargin",
	/**
	* ## Page Edge
	*
	* Specifies that the horizontal positioning shall be relative to the edge of the page.
	*/
	PAGE: "page",
	/**
	* ## Right Margin
	*
	* Specifies that the horizontal positioning shall be relative to the right margin of the page.
	*/
	RIGHT_MARGIN: "rightMargin"
};
/**
* Vertical Relative Positioning.
*
* Specifies the vertical base from which the drawing position is calculated.
*
* Reference: https://www.datypic.com/sc/ooxml/t-wp_ST_RelFromV.html
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_RelFromV">
*   <xsd:restriction base="xsd:token">
*     <xsd:enumeration value="margin"/>
*     <xsd:enumeration value="page"/>
*     <xsd:enumeration value="paragraph"/>
*     <xsd:enumeration value="line"/>
*     <xsd:enumeration value="topMargin"/>
*     <xsd:enumeration value="bottomMargin"/>
*     <xsd:enumeration value="insideMargin"/>
*     <xsd:enumeration value="outsideMargin"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var VerticalPositionRelativeFrom = {
	/**
	* ## Bottom Margin
	*
	* Specifies that the vertical positioning shall be relative to the bottom margin of the current page.
	*/
	BOTTOM_MARGIN: "bottomMargin",
	/**
	* ## Inside Margin
	*
	* Specifies that the vertical positioning shall be relative to the inside margin of the current page.
	*/
	INSIDE_MARGIN: "insideMargin",
	/**
	* ## Line
	*
	* Specifies that the vertical positioning shall be relative to the line containing the anchor character.
	*/
	LINE: "line",
	/**
	* ## Page Margin
	*
	* Specifies that the vertical positioning shall be relative to the page margins.
	*/
	MARGIN: "margin",
	/**
	* ## Outside Margin
	*
	* Specifies that the vertical positioning shall be relative to the outside margin of the current page.
	*/
	OUTSIDE_MARGIN: "outsideMargin",
	/**
	* ## Page Edge
	*
	* Specifies that the vertical positioning shall be relative to the edge of the page.
	*/
	PAGE: "page",
	/**
	* ## Paragraph
	*
	* Specifies that the vertical positioning shall be relative to the paragraph which contains the drawing anchor.
	*/
	PARAGRAPH: "paragraph",
	/**
	* ## Top Margin
	*
	* Specifies that the vertical positioning shall be relative to the top margin of the current page.
	*/
	TOP_MARGIN: "topMargin"
};
/**
* # Simple Positioning Coordinates
*
* This element specifies the coordinates at which a DrawingML object shall be positioned relative to the top-left edge of its page, when the `simplePos` attribute is specified on the <anchor> element (§5.5.2.3).
*
* References:
* - https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_simplePos_topic_ID0E5K6OB.html
* - http://officeopenxml.com/drwPicFloating-position.php
*
* ## XSD Schema
*
* ```xml
* <xsd:complexType name="CT_Point2D">
*   <xsd:attribute name="x" type="ST_Coordinate" use="required"/>
*   <xsd:attribute name="y" type="ST_Coordinate" use="required"/>
* </xsd:complexType>
* ```
*/
var createSimplePos = () => new BuilderElement({
	name: "wp:simplePos",
	attributes: {
		x: {
			key: "x",
			value: 0
		},
		y: {
			key: "y",
			value: 0
		}
	}
});
/**
* # Relative Horizontal/Vertical Alignment
*
* This element specifies how a DrawingML object shall be horizontally/vertically aligned relative to the horizontal/vertical alignment base defined by the parent element. Once an alignment base is defined, this element shall determine how the DrawingML object shall be aligned relative to that location.
*
* References:
* - https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_align_topic_ID0EYZZOB.html
* - https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_align_topic_ID0ET4ZOB.html
* - http://officeopenxml.com/drwPicFloating-position.php
*/
var createAlign = (value) => new BuilderElement({
	name: "wp:align",
	children: [value]
});
/**
* # Absolute Position Offset
*
* This element specifies an absolute measurement for the positioning of a floating DrawingML object within a WordprocessingML document. This measurement shall be calculated relative to the top left edge of the positioning base specified by the parent element's `relativeFrom` attribute.
*
* References:
* - https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_posOffset_topic_ID0EMG6OB.html
* - http://officeopenxml.com/drwPicFloating-position.php
*/
var createPositionOffset = (offsetValue) => new BuilderElement({
	name: "wp:posOffset",
	children: [offsetValue.toString()]
});
/**
* Horizontal position module for floating drawings in WordprocessingML documents.
*
* This module provides horizontal positioning for floating drawing objects,
* specifying the horizontal placement relative to a base element.
*
* Reference: http://officeopenxml.com/drwPicFloating-position.php
*
* @module
*/
/**
* Creates a horizontal position element for floating drawings.
*
* The positionH element specifies the horizontal positioning of a floating
* object relative to a base element (page, margin, column, etc.).
*
* Reference: https://www.datypic.com/sc/ooxml/e-wp_positionH-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PosH">
*   <xsd:choice>
*     <xsd:element name="align" type="ST_AlignH"/>
*     <xsd:element name="posOffset" type="ST_PositionOffset"/>
*   </xsd:choice>
*   <xsd:attribute name="relativeFrom" type="ST_RelFromH" use="required"/>
* </xsd:complexType>
* ```
*
* @param options - Horizontal position configuration
* @returns The positionH XML element
*
* @example
* ```typescript
* // Align to the left of the page
* createHorizontalPosition({
*   relative: HorizontalPositionRelativeFrom.PAGE,
*   align: HorizontalPositionAlign.LEFT,
* });
*
* // Offset from the margin
* createHorizontalPosition({
*   relative: HorizontalPositionRelativeFrom.MARGIN,
*   offset: 914400, // 1 inch in EMUs
* });
* ```
*/
var createHorizontalPosition = ({ relative, align, offset }) => new BuilderElement({
	name: "wp:positionH",
	attributes: { relativeFrom: {
		key: "relativeFrom",
		value: relative !== null && relative !== void 0 ? relative : HorizontalPositionRelativeFrom.PAGE
	} },
	children: [(() => {
		if (align) return createAlign(align);
		else if (offset !== void 0) return createPositionOffset(offset);
		else throw new Error("There is no configuration provided for floating position (Align or offset)");
	})()]
});
/**
* Vertical position module for floating drawings in WordprocessingML documents.
*
* This module provides vertical positioning for floating drawing objects,
* specifying the vertical placement relative to a base element.
*
* Reference: http://officeopenxml.com/drwPicFloating-position.php
*
* @module
*/
/**
* Creates a vertical position element for floating drawings.
*
* The positionV element specifies the vertical positioning of a floating
* object relative to a base element (page, margin, paragraph, line, etc.).
*
* Reference: https://www.datypic.com/sc/ooxml/e-wp_positionV-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PosV">
*   <xsd:choice>
*     <xsd:element name="align" type="ST_AlignV"/>
*     <xsd:element name="posOffset" type="ST_PositionOffset"/>
*   </xsd:choice>
*   <xsd:attribute name="relativeFrom" type="ST_RelFromV" use="required"/>
* </xsd:complexType>
* ```
*
* @param options - Vertical position configuration
* @returns The positionV XML element
*
* @example
* ```typescript
* // Align to the top of the page
* createVerticalPosition({
*   relative: VerticalPositionRelativeFrom.PAGE,
*   align: VerticalPositionAlign.TOP,
* });
*
* // Offset from the paragraph
* createVerticalPosition({
*   relative: VerticalPositionRelativeFrom.PARAGRAPH,
*   offset: 457200, // 0.5 inch in EMUs
* });
* ```
*/
var createVerticalPosition = ({ relative, align, offset }) => new BuilderElement({
	name: "wp:positionV",
	attributes: { relativeFrom: {
		key: "relativeFrom",
		value: relative !== null && relative !== void 0 ? relative : VerticalPositionRelativeFrom.PAGE
	} },
	children: [(() => {
		if (align) return createAlign(align);
		else if (offset !== void 0) return createPositionOffset(offset);
		else throw new Error("There is no configuration provided for floating position (Align or offset)");
	})()]
});
var createBodyProperties = (options = {}) => {
	var _options$margins, _options$margins2, _options$margins3, _options$margins4;
	return new BuilderElement({
		name: "wps:bodyPr",
		attributes: {
			lIns: {
				key: "lIns",
				value: (_options$margins = options.margins) === null || _options$margins === void 0 ? void 0 : _options$margins.left
			},
			rIns: {
				key: "rIns",
				value: (_options$margins2 = options.margins) === null || _options$margins2 === void 0 ? void 0 : _options$margins2.right
			},
			tIns: {
				key: "tIns",
				value: (_options$margins3 = options.margins) === null || _options$margins3 === void 0 ? void 0 : _options$margins3.top
			},
			bIns: {
				key: "bIns",
				value: (_options$margins4 = options.margins) === null || _options$margins4 === void 0 ? void 0 : _options$margins4.bottom
			},
			anchor: {
				key: "anchor",
				value: options.verticalAnchor
			}
		},
		children: [...options.noAutoFit ? [new OnOffElement("a:noAutofit", options.noAutoFit)] : []]
	});
};
var createNonVisualShapeProperties = (options = { txBox: "1" }) => new BuilderElement({
	name: "wps:cNvSpPr",
	attributes: { txBox: {
		key: "txBox",
		value: options.txBox
	} }
});
var createTextBoxContent = (children) => new BuilderElement({
	name: "w:txbxContent",
	children: [...children]
});
var createWpsTextBox = (children) => new BuilderElement({
	name: "wps:txbx",
	children: [createTextBoxContent(children)]
});
/**
* Extents attributes for DrawingML shapes.
*
* This module defines the width and height attributes for shape extents.
*
* @module
*/
/**
* Attributes for shape extents (size).
*
* Defines the width (cx) and height (cy) in EMUs.
*
* ## XSD Schema
* ```xml
* <xsd:attribute name="cx" type="ST_PositiveCoordinate" use="required"/>
* <xsd:attribute name="cy" type="ST_PositiveCoordinate" use="required"/>
* ```
*
* @internal
*/
var ExtentsAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			cx: "cx",
			cy: "cy"
		});
	}
};
/**
* Extents (size) element for DrawingML shapes.
*
* This module defines the size of a shape or picture in EMUs.
*
* Reference: http://officeopenxml.com/drwSp-size.php
*
* @module
*/
/**
* Represents the extents (size) of a DrawingML shape.
*
* Defines the width and height of the shape in English Metric Units (EMUs).
* One EMU equals 1/914,400 of an inch.
*
* Reference: http://officeopenxml.com/drwSp-size.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PositiveSize2D">
*   <xsd:attribute name="cx" type="ST_PositiveCoordinate" use="required"/>
*   <xsd:attribute name="cy" type="ST_PositiveCoordinate" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a 1-inch by 1-inch shape
* const extents = new Extents(914400, 914400);
* ```
*/
var Extents = class extends XmlComponent {
	constructor(x, y) {
		super("a:ext");
		_defineProperty(this, "attributes", void 0);
		this.attributes = new ExtentsAttributes({
			cx: x,
			cy: y
		});
		this.root.push(this.attributes);
	}
};
/**
* Offset attributes for DrawingML shapes.
*
* This module defines the x and y coordinate attributes for shape offset.
*
* @module
*/
/**
* Attributes for shape offset (position).
*
* Defines the x and y coordinates in EMUs.
*
* ## XSD Schema
* ```xml
* <xsd:attribute name="x" type="ST_Coordinate" use="required"/>
* <xsd:attribute name="y" type="ST_Coordinate" use="required"/>
* ```
*
* @internal
*/
var OffsetAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			x: "x",
			y: "y"
		});
	}
};
/**
* Offset (position) element for DrawingML shapes.
*
* This module defines the position of a shape or picture in EMUs.
*
* Reference: http://officeopenxml.com/drwSp-size.php
*
* @module
*/
/**
* Represents the offset (position) of a DrawingML shape.
*
* Defines the x and y coordinates of the shape's position in
* English Metric Units (EMUs). One EMU equals 1/914,400 of an inch.
*
* Reference: http://officeopenxml.com/drwSp-size.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Point2D">
*   <xsd:attribute name="x" type="ST_Coordinate" use="required"/>
*   <xsd:attribute name="y" type="ST_Coordinate" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const offset = new Offset();
* ```
*/
var Offset = class extends XmlComponent {
	constructor(x, y) {
		super("a:off");
		this.root.push(new OffsetAttributes({
			x: x !== null && x !== void 0 ? x : 0,
			y: y !== null && y !== void 0 ? y : 0
		}));
	}
};
/**
* Attributes for 2D transformation.
*
* Defines flip and rotation properties.
*/
var FormAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			flipVertical: "flipV",
			flipHorizontal: "flipH",
			rotation: "rot"
		});
	}
};
/**
* Represents a 2D transformation for DrawingML objects.
*
* This element defines how a shape or picture is positioned, sized,
* rotated, and flipped within the document.
*
* Reference: http://officeopenxml.com/drwSp-size.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Transform2D">
*   <xsd:sequence>
*     <xsd:element name="off" type="CT_Point2D" minOccurs="0"/>
*     <xsd:element name="ext" type="CT_PositiveSize2D" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="rot" type="ST_Angle" use="optional"/>
*   <xsd:attribute name="flipH" type="xsd:boolean" use="optional"/>
*   <xsd:attribute name="flipV" type="xsd:boolean" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const form = new Form({
*   emus: { x: 914400, y: 914400 },
*   flip: { horizontal: true, vertical: false },
*   rotation: 450000 // 7.5 degrees
* });
* ```
*/
var Form = class extends XmlComponent {
	constructor(options) {
		var _options$flip, _options$flip2, _options$offset, _options$offset2;
		super("a:xfrm");
		_defineProperty(this, "extents", void 0);
		_defineProperty(this, "offset", void 0);
		this.root.push(new FormAttributes({
			flipVertical: (_options$flip = options.flip) === null || _options$flip === void 0 ? void 0 : _options$flip.vertical,
			flipHorizontal: (_options$flip2 = options.flip) === null || _options$flip2 === void 0 ? void 0 : _options$flip2.horizontal,
			rotation: options.rotation
		}));
		this.offset = new Offset((_options$offset = options.offset) === null || _options$offset === void 0 || (_options$offset = _options$offset.emus) === null || _options$offset === void 0 ? void 0 : _options$offset.x, (_options$offset2 = options.offset) === null || _options$offset2 === void 0 || (_options$offset2 = _options$offset2.emus) === null || _options$offset2 === void 0 ? void 0 : _options$offset2.y);
		this.extents = new Extents(options.emus.x, options.emus.y);
		this.root.push(this.offset);
		this.root.push(this.extents);
	}
};
/**
* No fill element for DrawingML shapes.
*
* This module provides the no-fill option for outline and shape fills.
*
* @module
*/
/**
* Creates a no-fill element.
*
* Specifies that the outline or shape should have no fill applied.
*
* ## XSD Schema
* ```xml
* <xsd:element name="noFill" type="CT_Empty"/>
* ```
*
* @example
* ```typescript
* const noFill = createNoFill();
* ```
*/
var createNoFill = () => new BuilderElement({ name: "a:noFill" });
/**
* RGB color element for DrawingML shapes.
*
* This module provides RGB color support for solid fills.
*
* @module
*/
/**
* Creates an sRGB color element.
*
* Specifies a color using RGB hex values.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SRgbColor">
*   <xsd:sequence>
*     <xsd:group ref="EG_ColorTransform" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="val" type="s:ST_HexColorRGB" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const redColor = createSolidRgbColor({ value: "FF0000" });
* const blueColor = createSolidRgbColor({ value: "0000FF" });
* ```
*/
var createSolidRgbColor = (options) => new BuilderElement({
	name: "a:srgbClr",
	attributes: { value: {
		key: "val",
		value: options.value
	} }
});
/**
* Scheme color element for DrawingML shapes.
*
* This module provides scheme-based color support for solid fills,
* allowing colors to be defined using theme color schemes.
*
* @module
*/
/**
* Creates a scheme color element.
*
* Specifies a color using a theme color scheme reference.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SchemeColor">
*   <xsd:sequence>
*     <xsd:group ref="EG_ColorTransform" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="val" type="ST_SchemeColorVal" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const accentColor = createSchemeColor({ value: SchemeColor.ACCENT1 });
* const bgColor = createSchemeColor({ value: SchemeColor.BG1 });
* ```
*/
var createSchemeColor = (options) => new BuilderElement({
	name: "a:schemeClr",
	attributes: { value: {
		key: "val",
		value: options.value
	} }
});
/**
* Solid fill element for DrawingML shapes.
*
* This module provides solid fill support for outlines and shapes,
* supporting both RGB and scheme-based colors.
*
* @module
*/
/**
* Creates a solid fill element.
*
* Specifies a solid color fill using either RGB or scheme colors.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SolidColorFillProperties">
*   <xsd:sequence>
*     <xsd:group ref="EG_ColorChoice" minOccurs="0"/>
*     <xsd:group ref="EG_EffectProperties" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // RGB solid fill
* const fill = createSolidFill({
*   type: "rgb",
*   value: "FF0000"
* });
*
* // Scheme solid fill
* const schemeFill = createSolidFill({
*   type: "scheme",
*   value: SchemeColor.ACCENT1
* });
* ```
*/
var createSolidFill = (options) => new BuilderElement({
	name: "a:solidFill",
	children: [options.type === "rgb" ? createSolidRgbColor(options) : createSchemeColor(options)]
});
/**
* Outline (line) properties for DrawingML shapes.
*
* This module provides support for configuring outline properties including
* width, cap style, compound line types, and fill properties.
*
* Reference: http://officeopenxml.com/drwSp-outline.php
*
* @module
*/
/**
* Creates an outline element for DrawingML shapes.
*
* The outline element specifies the line properties for the shape border,
* including width, cap style, compound line type, alignment, and fill.
*
* Reference: http://officeopenxml.com/drwSp-outline.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_LineProperties">
*   <xsd:sequence>
*     <xsd:group ref="EG_FillProperties" minOccurs="0"/>
*     <xsd:group ref="EG_LineDashProperties" minOccurs="0"/>
*     <xsd:group ref="EG_LineJoinProperties" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="w" use="optional" type="a:ST_LineWidth"/>
*   <xsd:attribute name="cap" use="optional" type="ST_LineCap"/>
*   <xsd:attribute name="cmpd" use="optional" type="ST_CompoundLine"/>
*   <xsd:attribute name="algn" use="optional" type="ST_PenAlignment"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create outline with RGB color
* const outline = createOutline({
*   width: 9525,
*   cap: "ROUND",
*   type: "solidFill",
*   solidFillType: "rgb",
*   value: "FF0000"
* });
* ```
*/
var createOutline = (options) => new BuilderElement({
	name: "a:ln",
	attributes: {
		width: {
			key: "w",
			value: options.width
		},
		cap: {
			key: "cap",
			value: options.cap
		},
		compoundLine: {
			key: "cmpd",
			value: options.compoundLine
		},
		align: {
			key: "algn",
			value: options.align
		}
	},
	children: [options.type === "noFill" ? createNoFill() : options.solidFillType === "rgb" ? createSolidFill({
		type: "rgb",
		value: options.value
	}) : createSolidFill({
		type: "scheme",
		value: options.value
	})]
});
/**
* Adjustment values module for preset geometries.
*
* This module provides adjustment value lists that can modify the appearance
* of preset shape geometries.
*
* Reference: http://officeopenxml.com/drwSp-prstGeom.php
*
* @module
*/
/**
* Represents a list of adjustment values for preset geometry.
*
* This element contains a list of shape adjust values that modify the
* appearance of a preset geometric shape. When empty, default values are used.
*
* Reference: http://officeopenxml.com/drwSp-prstGeom.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_GeomGuideList">
*   <xsd:sequence>
*     <xsd:element name="gd" type="CT_GeomGuide" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const avLst = new AdjustmentValues();
* ```
*/
var AdjustmentValues = class extends XmlComponent {
	constructor() {
		super("a:avLst");
	}
};
/**
* Preset geometry attributes for DrawingML shapes.
*
* This module defines the shape type attribute for preset geometries.
*
* @module
*/
/**
* Attributes for preset geometry.
*
* Defines the shape type identifier for a preset geometry.
*
* ## XSD Schema
* ```xml
* <xsd:attribute name="prst" type="ST_ShapeType" use="required"/>
* ```
*
* @internal
*/
var PresetGeometryAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { prst: "prst" });
	}
};
/**
* Preset geometry module for DrawingML shapes.
*
* This module provides predefined shape geometries that can be applied
* to pictures and shapes without requiring custom path definitions.
*
* Reference: http://officeopenxml.com/drwSp-prstGeom.php
*
* @module
*/
/**
* Represents a preset geometry for a DrawingML shape.
*
* This element specifies when a preset geometric shape should be used instead
* of a custom geometry. It includes a shape preset identifier and optional
* adjustment values that modify the base shape.
*
* Reference: http://officeopenxml.com/drwSp-prstGeom.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PresetGeometry2D">
*   <xsd:sequence>
*     <xsd:element name="avLst" type="CT_GeomGuideList" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="prst" type="ST_ShapeType" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const geometry = new PresetGeometry();
* ```
*/
var PresetGeometry = class extends XmlComponent {
	constructor() {
		super("a:prstGeom");
		this.root.push(new PresetGeometryAttributes({ prst: "rect" }));
		this.root.push(new AdjustmentValues());
	}
};
/**
* Shape properties attributes for DrawingML.
*
* This module defines attributes for shape properties.
*
* @module
*/
/**
* Attributes for shape properties.
*
* Defines optional attributes such as black and white mode.
*
* ## XSD Schema
* ```xml
* <xsd:attribute name="bwMode" type="ST_BlackWhiteMode" use="optional"/>
* ```
*
* @internal
*/
var ShapePropertiesAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { bwMode: "bwMode" });
	}
};
/**
* Represents shape properties for a DrawingML picture.
*
* This element defines the visual formatting of a picture, including
* its transform (size, position, rotation, flip), geometry preset,
* and outline properties.
*
* Reference: http://officeopenxml.com/drwSp-SpPr.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_ShapeProperties">
*   <xsd:sequence>
*     <xsd:element name="xfrm" type="CT_Transform2D" minOccurs="0"/>
*     <xsd:group ref="EG_Geometry" minOccurs="0"/>
*     <xsd:group ref="EG_FillProperties" minOccurs="0"/>
*     <xsd:element name="ln" type="CT_LineProperties" minOccurs="0"/>
*     <xsd:group ref="EG_EffectProperties" minOccurs="0"/>
*     <xsd:element name="scene3d" type="CT_Scene3D" minOccurs="0"/>
*     <xsd:element name="sp3d" type="CT_Shape3D" minOccurs="0"/>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="bwMode" type="ST_BlackWhiteMode" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const shapeProps = new ShapeProperties({
*   transform: {
*     emus: { x: 914400, y: 914400 },
*     flip: { horizontal: false, vertical: false },
*     rotation: 0
*   },
*   outline: {
*     width: 9525,
*     type: "solidFill",
*     solidFillType: "rgb",
*     value: "FF0000"
*   }
* });
* ```
*/
var ShapeProperties = class extends XmlComponent {
	constructor({ element, outline, solidFill, transform }) {
		super(`${element}:spPr`);
		_defineProperty(this, "form", void 0);
		this.root.push(new ShapePropertiesAttributes({ bwMode: "auto" }));
		this.form = new Form(transform);
		this.root.push(this.form);
		this.root.push(new PresetGeometry());
		if (outline) {
			this.root.push(createNoFill());
			this.root.push(createOutline(outline));
		}
		if (solidFill) this.root.push(createSolidFill(solidFill));
	}
};
var createWpsShape = (options) => new BuilderElement({
	name: "wps:wsp",
	children: [
		createNonVisualShapeProperties(options.nonVisualProperties),
		new ShapeProperties({
			element: "wps",
			transform: options.transformation,
			outline: options.outline,
			solidFill: options.solidFill
		}),
		createWpsTextBox(options.children),
		createBodyProperties(options.bodyProperties)
	]
});
/**
* Graphic data attributes module.
*
* This module defines the URI attribute that identifies the type
* of graphical content within a graphicData element.
*
* @module
*/
/**
* XML attributes component for graphic data.
*
* The URI attribute identifies the schema namespace of the content
* stored in the graphicData element. For pictures, this is typically
* "http://schemas.openxmlformats.org/drawingml/2006/picture".
*
* @internal
*/
var GraphicDataAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { uri: "uri" });
	}
};
/**
* Creates an SVG blip element for embedding SVG images.
*
* This element is a Microsoft Office extension that allows SVG images
* to be referenced within a blip.
*
* @param mediaData - The media data containing the SVG image information
* @returns An XML component representing the SVG blip element
* @internal
*/
var createSvgBlip = (mediaData) => new BuilderElement({
	name: "asvg:svgBlip",
	attributes: {
		asvg: {
			key: "xmlns:asvg",
			value: "http://schemas.microsoft.com/office/drawing/2016/SVG/main"
		},
		embed: {
			key: "r:embed",
			value: `rId{${mediaData.fileName}}`
		}
	}
});
/**
* Creates an extension element for SVG support.
*
* This element wraps the SVG blip extension with the appropriate URI
* to identify it as an SVG extension.
*
* @param mediaData - The media data containing the SVG image information
* @returns An XML component representing the extension element
* @internal
*/
var createExtention = (mediaData) => new BuilderElement({
	name: "a:ext",
	attributes: { uri: {
		key: "uri",
		value: "{96DAC541-7B7A-43D3-8B79-37D633B846F1}"
	} },
	children: [createSvgBlip(mediaData)]
});
/**
* Creates an extension list for SVG images.
*
* This element contains the extensions needed to embed SVG images
* within a blip. It wraps the SVG-specific extension elements.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_OfficeArtExtensionList">
*   <xsd:sequence>
*     <xsd:element name="ext" type="CT_OfficeArtExtension" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @param mediaData - The media data containing the SVG image information
* @returns An XML component representing the extension list
*/
var createExtentionList = (mediaData) => new BuilderElement({
	name: "a:extLst",
	children: [createExtention(mediaData)]
});
/**
* Creates a blip element for an image.
*
* A blip references the actual image data stored in the document package
* through a relationship ID. For SVG images, it includes extensions that
* reference the SVG data.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Blip">
*   <xsd:sequence>
*     <xsd:choice minOccurs="0" maxOccurs="unbounded">
*       <xsd:element name="alphaBiLevel" type="CT_AlphaBiLevelEffect"/>
*       <xsd:element name="alphaCeiling" type="CT_AlphaCeilingEffect"/>
*       <xsd:element name="alphaFloor" type="CT_AlphaFloorEffect"/>
*       <xsd:element name="alphaInv" type="CT_AlphaInverseEffect"/>
*       <xsd:element name="alphaMod" type="CT_AlphaModulateEffect"/>
*       <xsd:element name="alphaModFix" type="CT_AlphaModulateFixedEffect"/>
*       <xsd:element name="alphaRepl" type="CT_AlphaReplaceEffect"/>
*       <xsd:element name="biLevel" type="CT_BiLevelEffect"/>
*       <xsd:element name="blur" type="CT_BlurEffect"/>
*       <xsd:element name="clrChange" type="CT_ColorChangeEffect"/>
*       <xsd:element name="clrRepl" type="CT_ColorReplaceEffect"/>
*       <xsd:element name="duotone" type="CT_DuotoneEffect"/>
*       <xsd:element name="fillOverlay" type="CT_FillOverlayEffect"/>
*       <xsd:element name="grayscl" type="CT_GrayscaleEffect"/>
*       <xsd:element name="hsl" type="CT_HSLEffect"/>
*       <xsd:element name="lum" type="CT_LuminanceEffect"/>
*       <xsd:element name="tint" type="CT_TintEffect"/>
*     </xsd:choice>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute ref="r:embed"/>
*   <xsd:attribute ref="r:link"/>
*   <xsd:attribute name="cstate" type="ST_BlipCompression"/>
* </xsd:complexType>
* ```
*
* @param mediaData - The media data containing the image information
* @returns An XML component representing the blip element
*/
var createBlip = (mediaData) => new BuilderElement({
	name: "a:blip",
	attributes: {
		embed: {
			key: "r:embed",
			value: `rId{${mediaData.type === "svg" ? mediaData.fallback.fileName : mediaData.fileName}}`
		},
		cstate: {
			key: "cstate",
			value: "none"
		}
	},
	children: mediaData.type === "svg" ? [createExtentionList(mediaData)] : []
});
/**
* Source rectangle module for blip fills.
*
* This module defines the portion of an image to use when filling a shape.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* @module
*/
/**
* Represents a source rectangle for blip fills.
*
* This element specifies a portion of the blip (image) to use as the fill.
* When not specified with attributes, it indicates the entire blip should be used.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_RelativeRect">
*   <xsd:attribute name="l" type="ST_Percentage" use="optional" default="0"/>
*   <xsd:attribute name="t" type="ST_Percentage" use="optional" default="0"/>
*   <xsd:attribute name="r" type="ST_Percentage" use="optional" default="0"/>
*   <xsd:attribute name="b" type="ST_Percentage" use="optional" default="0"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const srcRect = new SourceRectangle();
* ```
*/
var SourceRectangle = class extends XmlComponent {
	constructor() {
		super("a:srcRect");
	}
};
/**
* Stretch fill module for blip fills.
*
* This module defines how images are stretched to fill shapes.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* @module
*/
/**
* Represents a fill rectangle for stretch fill mode.
*
* This element specifies the rectangular area of the shape to which
* the blip fill should be stretched.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_RelativeRect">
*   <xsd:attribute name="l" type="ST_Percentage" use="optional" default="0"/>
*   <xsd:attribute name="t" type="ST_Percentage" use="optional" default="0"/>
*   <xsd:attribute name="r" type="ST_Percentage" use="optional" default="0"/>
*   <xsd:attribute name="b" type="ST_Percentage" use="optional" default="0"/>
* </xsd:complexType>
* ```
*/
var FillRectangle = class extends XmlComponent {
	constructor() {
		super("a:fillRect");
	}
};
/**
* Represents a stretch fill mode for blip fills.
*
* This element specifies that the blip (image) should be stretched to fill
* the entire shape. The stretch fill is one of the fill mode properties
* that determines how an image is applied to a shape.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_StretchInfoProperties">
*   <xsd:sequence>
*     <xsd:element name="fillRect" type="CT_RelativeRect" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const stretch = new Stretch();
* ```
*/
var Stretch = class extends XmlComponent {
	constructor() {
		super("a:stretch");
		this.root.push(new FillRectangle());
	}
};
/**
* Represents a blip fill for pictures in DrawingML.
*
* This element specifies the type of fill used for a picture. It contains the blip (image)
* reference, an optional source rectangle, and the fill mode (typically stretch).
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_BlipFillProperties">
*   <xsd:sequence>
*     <xsd:element name="blip" type="CT_Blip" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="srcRect" type="CT_RelativeRect" minOccurs="0" maxOccurs="1"/>
*     <xsd:group ref="EG_FillModeProperties" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="dpi" type="xsd:unsignedInt" use="optional"/>
*   <xsd:attribute name="rotWithShape" type="xsd:boolean" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const blipFill = new BlipFill(mediaData);
* ```
*/
var BlipFill = class extends XmlComponent {
	constructor(mediaData) {
		super("pic:blipFill");
		this.root.push(createBlip(mediaData));
		this.root.push(new SourceRectangle());
		this.root.push(new Stretch());
	}
};
/**
* Picture locks attributes module.
*
* This module defines the attributes that control locking behavior
* for picture elements.
*
* @module
*/
/**
* Attributes for picture locking properties.
*
* Defines the XML attributes that control which operations are forbidden
* on a picture element.
*
* @internal
*/
var PicLocksAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			noChangeAspect: "noChangeAspect",
			noChangeArrowheads: "noChangeArrowheads"
		});
	}
};
/**
* Picture locks module.
*
* This module provides locking settings for pictures that control
* which operations are allowed on the picture element.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* @module
*/
/**
* Represents picture locking properties in DrawingML.
*
* This element specifies all locking properties for a picture. These properties
* inform the generating application about which operations are forbidden on the
* parent picture object.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PictureLocking">
*   <xsd:sequence>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="noGrp" type="xsd:boolean" use="optional" default="false"/>
*   <xsd:attribute name="noSelect" type="xsd:boolean" use="optional" default="false"/>
*   <xsd:attribute name="noRot" type="xsd:boolean" use="optional" default="false"/>
*   <xsd:attribute name="noChangeAspect" type="xsd:boolean" use="optional" default="false"/>
*   <xsd:attribute name="noMove" type="xsd:boolean" use="optional" default="false"/>
*   <xsd:attribute name="noResize" type="xsd:boolean" use="optional" default="false"/>
*   <xsd:attribute name="noEditPoints" type="xsd:boolean" use="optional" default="false"/>
*   <xsd:attribute name="noAdjustHandles" type="xsd:boolean" use="optional" default="false"/>
*   <xsd:attribute name="noChangeArrowheads" type="xsd:boolean" use="optional" default="false"/>
*   <xsd:attribute name="noChangeShapeType" type="xsd:boolean" use="optional" default="false"/>
*   <xsd:attribute name="noCrop" type="xsd:boolean" use="optional" default="false"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const locks = new PicLocks();
* ```
*/
var PicLocks = class extends XmlComponent {
	constructor() {
		super("a:picLocks");
		this.root.push(new PicLocksAttributes({
			noChangeAspect: 1,
			noChangeArrowheads: 1
		}));
	}
};
/**
* Child non-visual picture properties module.
*
* This module provides picture-specific non-visual properties including
* locking settings that control operations on the picture.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* @module
*/
/**
* Represents non-visual picture drawing properties.
*
* This element specifies the non-visual properties specific to a picture.
* These properties include picture-specific locking settings that control
* which operations are allowed on the picture.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_NonVisualPictureProperties">
*   <xsd:sequence>
*     <xsd:element name="picLocks" type="CT_PictureLocking" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="preferRelativeResize" type="xsd:boolean" use="optional" default="true"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const cNvPicPr = new ChildNonVisualProperties();
* ```
*/
var ChildNonVisualProperties = class extends XmlComponent {
	constructor() {
		super("pic:cNvPicPr");
		this.root.push(new PicLocks());
	}
};
/**
* Child elements for document properties.
*
* This module provides hyperlink elements that can be attached to
* drawing elements for interactive behavior.
*
* @module
*/
/**
* Creates a click hyperlink element for a drawing.
*
* This element defines what happens when a user clicks on a drawing element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Hyperlink">
*   <xsd:group ref="EG_PContent" minOccurs="0" maxOccurs="unbounded"/>
*   <xsd:attribute name="tgtFrame" type="s:ST_String"/>
*   <xsd:attribute name="tooltip" type="s:ST_String"/>
*   <xsd:attribute name="docLocation" type="s:ST_String"/>
*   <xsd:attribute name="history" type="s:ST_OnOff"/>
*   <xsd:attribute name="anchor" type="s:ST_String"/>
*   <xsd:attribute ref="r:id"/>
* </xsd:complexType>
* ```
*
* @param linkId - The relationship ID for the hyperlink target
* @param hasXmlNs - Whether to include the XML namespace declaration
* @returns An XML component representing the click hyperlink
*/
var createHyperlinkClick = (linkId, hasXmlNs) => new BuilderElement({
	name: "a:hlinkClick",
	attributes: _objectSpread2(_objectSpread2({}, hasXmlNs ? { xmlns: {
		key: "xmlns:a",
		value: "http://schemas.openxmlformats.org/drawingml/2006/main"
	} } : {}), {}, { id: {
		key: "r:id",
		value: `rId${linkId}`
	} })
});
/**
* Non-visual properties attributes module.
*
* This module defines the attributes for non-visual drawing properties
* including ID, name, and description.
*
* @module
*/
/**
* Attributes for non-visual drawing properties.
*
* Defines the identification and descriptive attributes for DrawingML objects.
*
* @internal
*/
var NonVisualPropertiesAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			id: "id",
			name: "name",
			descr: "descr"
		});
	}
};
/**
* Non-visual drawing properties module.
*
* This module provides basic metadata for drawing elements including
* ID, name, description, and hyperlink support.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* @module
*/
/**
* Represents non-visual drawing properties for pictures.
*
* This element specifies non-visual properties for a DrawingML object.
* These include identification, naming, description, and hyperlink properties.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_NonVisualDrawingProps">
*   <xsd:sequence>
*     <xsd:element name="hlinkClick" type="CT_Hyperlink" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="hlinkHover" type="CT_Hyperlink" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="id" type="ST_DrawingElementId" use="required"/>
*   <xsd:attribute name="name" type="xsd:string" use="required"/>
*   <xsd:attribute name="descr" type="xsd:string" use="optional" default=""/>
*   <xsd:attribute name="hidden" type="xsd:boolean" use="optional" default="false"/>
*   <xsd:attribute name="title" type="xsd:string" use="optional" default=""/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const cNvPr = new NonVisualProperties();
* ```
*/
var NonVisualProperties = class extends XmlComponent {
	constructor() {
		super("pic:cNvPr");
		this.root.push(new NonVisualPropertiesAttributes({
			id: 0,
			name: "",
			descr: ""
		}));
	}
	prepForXml(context) {
		for (let i = context.stack.length - 1; i >= 0; i--) {
			const element = context.stack[i];
			if (!(element instanceof ConcreteHyperlink)) continue;
			this.root.push(createHyperlinkClick(element.linkId, false));
			break;
		}
		return super.prepForXml(context);
	}
};
/**
* Non-visual picture properties module.
*
* This module provides metadata and locking settings for pictures
* that don't affect their visual appearance.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* @module
*/
/**
* Represents non-visual picture properties.
*
* This element specifies non-visual properties for a picture. These properties
* include metadata like name, description, and locking settings that don't affect
* the visual appearance of the picture.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PictureNonVisual">
*   <xsd:sequence>
*     <xsd:element name="cNvPr" type="a:CT_NonVisualDrawingProps" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="cNvPicPr" type="a:CT_NonVisualPictureProperties" minOccurs="1" maxOccurs="1"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const nvPicPr = new NonVisualPicProperties();
* ```
*/
var NonVisualPicProperties = class extends XmlComponent {
	constructor() {
		super("pic:nvPicPr");
		this.root.push(new NonVisualProperties());
		this.root.push(new ChildNonVisualProperties());
	}
};
/**
* Picture attributes module.
*
* This module defines the XML namespace attribute for picture elements.
*
* @module
*/
/**
* Attributes for picture elements.
*
* Defines the XML namespace declaration for picture elements in DrawingML.
*
* @internal
*/
var PicAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { xmlns: "xmlns:pic" });
	}
};
/**
* Represents a picture element in DrawingML.
*
* A picture contains non-visual properties, image data (blip fill),
* and shape properties that define how the image is displayed.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Picture">
*   <xsd:sequence>
*     <xsd:element name="nvPicPr" type="CT_PictureNonVisual"/>
*     <xsd:element name="blipFill" type="CT_BlipFillProperties"/>
*     <xsd:element name="spPr" type="a:CT_ShapeProperties"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const pic = new Pic({
*   mediaData: imageData,
*   transform: { emus: { x: 914400, y: 914400 } },
*   outline: { color: "000000", width: 9525 }
* });
* ```
*/
var Pic = class extends XmlComponent {
	constructor({ mediaData, transform, outline }) {
		super("pic:pic");
		this.root.push(new PicAttributes({ xmlns: "http://schemas.openxmlformats.org/drawingml/2006/picture" }));
		this.root.push(new NonVisualPicProperties());
		this.root.push(new BlipFill(mediaData));
		this.root.push(new ShapeProperties({
			element: "pic",
			transform,
			outline
		}));
	}
};
var createGroupProperties = (transform) => new BuilderElement({
	name: "wpg:grpSpPr",
	children: [new Form(transform)]
});
var createNonVisualGroupProperties = () => new BuilderElement({ name: "wpg:cNvGrpSpPr" });
var createWpgGroup = (options) => new BuilderElement({
	name: "wpg:wgp",
	children: [
		createNonVisualGroupProperties(),
		createGroupProperties(options.transformation),
		...options.children
	]
});
/**
* Represents graphical data within a DrawingML graphic element.
*
* GraphicData contains the actual picture, chart, or other graphical
* content referenced by a graphic element. It uses a URI to identify
* the type of content being stored.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_GraphicalObjectData">
*   <xsd:sequence>
*     <xsd:any minOccurs="0" maxOccurs="unbounded" processContents="strict"/>
*   </xsd:sequence>
*   <xsd:attribute name="uri" type="xsd:token" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const graphicData = new GraphicData({
*   mediaData: imageData,
*   transform: transformation,
*   outline: { color: "000000", width: 9525 }
* });
* ```
*/
var GraphicData = class extends XmlComponent {
	constructor({ mediaData, transform, outline, solidFill }) {
		super("a:graphicData");
		if (mediaData.type === "wps") {
			this.root.push(new GraphicDataAttributes({ uri: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape" }));
			const wps = createWpsShape(_objectSpread2(_objectSpread2({}, mediaData.data), {}, {
				transformation: transform,
				outline,
				solidFill
			}));
			this.root.push(wps);
		} else if (mediaData.type === "wpg") {
			this.root.push(new GraphicDataAttributes({ uri: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" }));
			const wpg = createWpgGroup({
				children: mediaData.children.map((child) => {
					if (child.type === "wps") return createWpsShape(_objectSpread2(_objectSpread2({}, child.data), {}, {
						transformation: child.transformation,
						outline: child.outline,
						solidFill: child.solidFill
					}));
					else return new Pic({
						mediaData: child,
						transform: child.transformation,
						outline: child.outline
					});
				}),
				transformation: transform
			});
			this.root.push(wpg);
		} else {
			this.root.push(new GraphicDataAttributes({ uri: "http://schemas.openxmlformats.org/drawingml/2006/picture" }));
			const pic = new Pic({
				mediaData,
				transform,
				outline
			});
			this.root.push(pic);
		}
	}
};
/**
* Attributes for the graphic element.
* @internal
*/
var GraphicAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { a: "xmlns:a" });
	}
};
/**
* Represents a graphic element in DrawingML.
*
* Graphic is the container for graphical content such as
* pictures, shapes, and charts within a drawing.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_GraphicalObject">
*   <xsd:sequence>
*     <xsd:element name="graphicData" type="CT_GraphicalObjectData"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const graphic = new Graphic({
*   mediaData: imageData,
*   transform: transformation,
*   outline: { color: "FF0000", width: 9525 }
* });
* ```
*/
var Graphic = class extends XmlComponent {
	constructor({ mediaData, transform, outline, solidFill }) {
		super("a:graphic");
		_defineProperty(this, "data", void 0);
		this.root.push(new GraphicAttributes({ a: "http://schemas.openxmlformats.org/drawingml/2006/main" }));
		this.data = new GraphicData({
			mediaData,
			transform,
			outline,
			solidFill
		});
		this.root.push(this.data);
	}
};
/**
* Enumeration of text wrapping types for floating drawings.
*
* Reference: http://officeopenxml.com/drwPicFloating-textWrap.php
*
* @publicApi
*/
var TextWrappingType = {
	NONE: 0,
	SQUARE: 1,
	TIGHT: 2,
	TOP_AND_BOTTOM: 3
};
/**
* Enumeration of text wrapping sides for floating drawings.
*
* Specifies on which side(s) text can wrap around the drawing.
*
* Reference: http://officeopenxml.com/drwPicFloating-textWrap.php
*
* @publicApi
*/
var TextWrappingSide = {
	/** Text wraps on both sides of the drawing */
	BOTH_SIDES: "bothSides",
	/** Text wraps only on the left side */
	LEFT: "left",
	/** Text wraps only on the right side */
	RIGHT: "right",
	/** Text wraps on the side with more space */
	LARGEST: "largest"
};
/**
* Wrap None module for DrawingML text wrapping.
*
* This module provides no text wrapping for floating drawings
* where text does not wrap around the drawing.
*
* Reference: http://officeopenxml.com/drwPicFloating-textWrap.php
*
* @module
*/
/**
* Creates no text wrapping for a floating drawing.
*
* WrapNone causes text to flow behind or in front of the drawing
* without wrapping around it.
*
* Reference: http://officeopenxml.com/drwPicFloating-textWrap.php
*/
var createWrapNone = () => new BuilderElement({ name: "wp:wrapNone" });
/**
* Wrap Square module for DrawingML text wrapping.
*
* This module provides square text wrapping for floating drawings
* where text wraps around a rectangular bounding box.
*
* Reference: http://officeopenxml.com/drwPicFloating-textWrap.php
*
* @module
*/
/**
* Creates square text wrapping for a floating drawing.
*
* WrapSquare causes text to wrap around the rectangular bounding box
* of the drawing on the specified side(s).
*
* Reference: http://officeopenxml.com/drwPicFloating-textWrap.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_WrapSquare">
*   <xsd:sequence>
*     <xsd:element name="effectExtent" type="CT_EffectExtent" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="wrapText" type="ST_WrapText" use="required"/>
*   <xsd:attribute name="distT" type="ST_WrapDistance"/>
*   <xsd:attribute name="distB" type="ST_WrapDistance"/>
*   <xsd:attribute name="distL" type="ST_WrapDistance"/>
*   <xsd:attribute name="distR" type="ST_WrapDistance"/>
* </xsd:complexType>
* ```
*/
var createWrapSquare = (textWrapping, margins = {
	top: 0,
	bottom: 0,
	left: 0,
	right: 0
}) => new BuilderElement({
	name: "wp:wrapSquare",
	attributes: {
		wrapText: {
			key: "wrapText",
			value: textWrapping.side || TextWrappingSide.BOTH_SIDES
		},
		distT: {
			key: "distT",
			value: margins.top
		},
		distB: {
			key: "distB",
			value: margins.bottom
		},
		distL: {
			key: "distL",
			value: margins.left
		},
		distR: {
			key: "distR",
			value: margins.right
		}
	}
});
/**
* Wrap Tight module for DrawingML text wrapping.
*
* This module provides tight text wrapping for floating drawings
* where text wraps closely around the image shape.
*
* Reference: http://officeopenxml.com/drwPicFloating-textWrap.php
*
* @module
*/
/**
* Creates tight text wrapping for a floating drawing.
*
* WrapTight causes text to wrap closely around the contours
* of the drawing rather than its rectangular bounding box.
*
* Reference: http://officeopenxml.com/drwPicFloating-textWrap.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_WrapTight">
*   <xsd:sequence>
*     <xsd:element name="wrapPolygon" type="CT_WrapPath"/>
*   </xsd:sequence>
*   <xsd:attribute name="wrapText" type="ST_WrapText" use="required"/>
*   <xsd:attribute name="distL" type="ST_WrapDistance"/>
*   <xsd:attribute name="distR" type="ST_WrapDistance"/>
* </xsd:complexType>
* ```
*/
var createWrapTight = (margins = {
	top: 0,
	bottom: 0
}) => new BuilderElement({
	name: "wp:wrapTight",
	attributes: {
		distT: {
			key: "distT",
			value: margins.top
		},
		distB: {
			key: "distB",
			value: margins.bottom
		}
	}
});
/**
* Wrap Top and Bottom module for DrawingML text wrapping.
*
* This module provides top-and-bottom text wrapping for floating drawings
* where text appears above and below the drawing but not beside it.
*
* Reference: http://officeopenxml.com/drwPicFloating-textWrap.php
*
* @module
*/
/**
* Creates top-and-bottom text wrapping for a floating drawing.
*
* WrapTopAndBottom causes text to appear above and below the drawing
* without wrapping beside it, creating a line break effect.
*
* Reference: http://officeopenxml.com/drwPicFloating-textWrap.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_WrapTopBottom">
*   <xsd:sequence>
*     <xsd:element name="effectExtent" type="CT_EffectExtent" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="distT" type="ST_WrapDistance"/>
*   <xsd:attribute name="distB" type="ST_WrapDistance"/>
* </xsd:complexType>
* ```
*/
var createWrapTopAndBottom = (margins = {
	top: 0,
	bottom: 0
}) => new BuilderElement({
	name: "wp:wrapTopAndBottom",
	attributes: {
		distT: {
			key: "distT",
			value: margins.top
		},
		distB: {
			key: "distB",
			value: margins.bottom
		}
	}
});
/**
* Document Properties module for DrawingML elements.
*
* This module provides non-visual properties for drawing elements,
* including name, description, and accessibility information.
*
* Reference: https://c-rex.net/projects/samples/ooxml/e1/Part4/OOXML_P4_DOCX_docPr_topic_ID0ES32OB.html
*
* @module
*/
/**
* Represents non-visual drawing properties in a WordprocessingML document.
*
* DocProperties contains metadata about a drawing element such as
* its name, description (alt text), and title for accessibility.
*
* Reference: https://c-rex.net/projects/samples/ooxml/e1/Part4/OOXML_P4_DOCX_docPr_topic_ID0ES32OB.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_NonVisualDrawingProps">
*   <xsd:sequence>
*     <xsd:element name="hlinkClick" type="CT_Hyperlink" minOccurs="0"/>
*     <xsd:element name="hlinkHover" type="CT_Hyperlink" minOccurs="0"/>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="id" type="ST_DrawingElementId" use="required"/>
*   <xsd:attribute name="name" type="xsd:string" use="required"/>
*   <xsd:attribute name="descr" type="xsd:string"/>
*   <xsd:attribute name="hidden" type="xsd:boolean"/>
* </xsd:complexType>
* ```
*/
var DocProperties = class extends XmlComponent {
	constructor({ name, description, title, id } = {
		name: "",
		description: "",
		title: ""
	}) {
		super("wp:docPr");
		_defineProperty(this, "docPropertiesUniqueNumericId", docPropertiesUniqueNumericIdGen());
		const attributes = {
			id: {
				key: "id",
				value: id !== null && id !== void 0 ? id : this.docPropertiesUniqueNumericId()
			},
			name: {
				key: "name",
				value: name
			}
		};
		if (description !== null && description !== void 0) attributes.description = {
			key: "descr",
			value: description
		};
		if (title !== null && title !== void 0) attributes.title = {
			key: "title",
			value: title
		};
		this.root.push(new NextAttributeComponent(attributes));
	}
	prepForXml(context) {
		for (let i = context.stack.length - 1; i >= 0; i--) {
			const element = context.stack[i];
			if (!(element instanceof ConcreteHyperlink)) continue;
			this.root.push(createHyperlinkClick(element.linkId, true));
			break;
		}
		return super.prepForXml(context);
	}
};
/**
* Effect extent for DrawingML objects.
*
* This module provides support for defining additional extent to compensate
* for drawing effects applied to objects.
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_effectExtent_topic_ID0E5O3OB.html
*
* @module
*/
/**
* Creates an effect extent element.
*
* This element specifies the additional extent which shall be added to each
* edge of the image (top, bottom, left, right) in order to compensate for any
* drawing effects applied to the DrawingML object.
*
* The extent element specifies the size of the actual DrawingML object; however,
* an object may have effects applied which change its overall size. This element
* accounts for that additional space.
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_effectExtent_topic_ID0E5O3OB.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_EffectExtent">
*   <xsd:attribute name="l" type="a:ST_Coordinate" use="required"/>
*   <xsd:attribute name="t" type="a:ST_Coordinate" use="required"/>
*   <xsd:attribute name="r" type="a:ST_Coordinate" use="required"/>
*   <xsd:attribute name="b" type="a:ST_Coordinate" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const effectExtent = createEffectExtent({
*   top: 0,
*   right: 0,
*   bottom: 0,
*   left: 0
* });
* ```
*/
var createEffectExtent = ({ top, right, bottom, left }) => new BuilderElement({
	name: "wp:effectExtent",
	attributes: {
		top: {
			key: "t",
			value: top
		},
		right: {
			key: "r",
			value: right
		},
		bottom: {
			key: "b",
			value: bottom
		},
		left: {
			key: "l",
			value: left
		}
	}
});
/**
* Extent (size) for DrawingML objects.
*
* This module provides support for defining the size of DrawingML objects
* in inline drawings.
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_extent_topic_ID0EQB4OB.html
*
* @module
*/
/**
* Creates an extent element for inline drawings.
*
* This element specifies the extents of the parent DrawingML object within
* the document (i.e. its final height and width).
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_extent_topic_ID0EQB4OB.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PositiveSize2D">
*   <xsd:attribute name="cx" type="ST_PositiveCoordinate" use="required"/>
*   <xsd:attribute name="cy" type="ST_PositiveCoordinate" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a 1-inch by 1-inch extent
* const extent = createExtent({
*   x: 914400,
*   y: 914400
* });
* ```
*/
var createExtent = ({ x, y }) => new BuilderElement({
	name: "wp:extent",
	attributes: {
		x: {
			key: "cx",
			value: x
		},
		y: {
			key: "cy",
			value: y
		}
	}
});
/**
* Attributes for graphic frame locking properties.
*
* Defines the XML attributes that control which operations are forbidden
* on a graphic frame element.
*/
var GraphicFrameLockAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			xmlns: "xmlns:a",
			noChangeAspect: "noChangeAspect"
		});
	}
};
/**
* Represents graphic frame locking properties in DrawingML.
*
* This element specifies all locking properties for a graphic frame. These properties
* inform the generating application about which operations are forbidden on the parent
* graphic frame.
*
* Reference: http://officeopenxml.com/drwPic.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_GraphicalObjectFrameLocking">
*   <xsd:sequence>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="noGrp" type="xsd:boolean" use="optional"/>
*   <xsd:attribute name="noDrilldown" type="xsd:boolean" use="optional"/>
*   <xsd:attribute name="noSelect" type="xsd:boolean" use="optional"/>
*   <xsd:attribute name="noChangeAspect" type="xsd:boolean" use="optional"/>
*   <xsd:attribute name="noMove" type="xsd:boolean" use="optional"/>
*   <xsd:attribute name="noResize" type="xsd:boolean" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const locks = new GraphicFrameLocks();
* ```
*/
var GraphicFrameLocks = class extends XmlComponent {
	constructor() {
		super("a:graphicFrameLocks");
		this.root.push(new GraphicFrameLockAttributes({
			xmlns: "http://schemas.openxmlformats.org/drawingml/2006/main",
			noChangeAspect: 1
		}));
	}
};
/**
* # Common DrawingML Non-Visual Properties
*
* This element specifies common non-visual DrawingML object properties for the parent DrawingML object. These properties are specified as child elements of this element.
*
* References:
* - https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_cNvGraphicFramePr_topic_ID0E6U2OB.html
*
* ## XSD Schema
*
* ```xml
* <xsd:complexType name="CT_NonVisualGraphicFrameProperties">
*   <xsd:sequence>
*     <xsd:element name="graphicFrameLocks" type="CT_GraphicalObjectFrameLocking" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createGraphicFrameProperties = () => new BuilderElement({
	name: "wp:cNvGraphicFramePr",
	children: [new GraphicFrameLocks()]
});
/**
* Anchor attributes module for DrawingML floating elements.
*
* This module defines the attributes for anchored/floating drawings,
* controlling positioning, z-order, and wrapping behavior.
*
* @module
*/
/**
* XML attributes component for anchored drawings.
*
* Maps the IAnchorAttributes to XML attribute names for the wp:anchor element.
*
* @internal
*/
var AnchorAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			distT: "distT",
			distB: "distB",
			distL: "distL",
			distR: "distR",
			allowOverlap: "allowOverlap",
			behindDoc: "behindDoc",
			layoutInCell: "layoutInCell",
			locked: "locked",
			relativeHeight: "relativeHeight",
			simplePos: "simplePos"
		});
	}
};
/**
* Represents an anchored/floating drawing in a WordprocessingML document.
*
* Anchored drawings can be positioned relative to the page, margin, column,
* paragraph, character, or line. They support text wrapping options.
*
* Reference: http://officeopenxml.com/drwPicFloating.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Anchor">
*   <xsd:sequence>
*     <xsd:element name="simplePos" type="a:CT_Point2D"/>
*     <xsd:element name="positionH" type="CT_PosH"/>
*     <xsd:element name="positionV" type="CT_PosV"/>
*     <xsd:element name="extent" type="a:CT_PositiveSize2D"/>
*     <xsd:element name="effectExtent" type="CT_EffectExtent" minOccurs="0"/>
*     <xsd:group ref="EG_WrapType"/>
*     <xsd:element name="docPr" type="a:CT_NonVisualDrawingProps"/>
*     <xsd:element name="cNvGraphicFramePr" type="a:CT_NonVisualGraphicFrameProperties" minOccurs="0"/>
*     <xsd:element ref="a:graphic"/>
*   </xsd:sequence>
*   <xsd:attribute name="distT" type="ST_WrapDistance"/>
*   <xsd:attribute name="distB" type="ST_WrapDistance"/>
*   <xsd:attribute name="distL" type="ST_WrapDistance"/>
*   <xsd:attribute name="distR" type="ST_WrapDistance"/>
*   <xsd:attribute name="simplePos" type="xsd:boolean"/>
*   <xsd:attribute name="relativeHeight" type="xsd:unsignedInt" use="required"/>
*   <xsd:attribute name="behindDoc" type="xsd:boolean" use="required"/>
*   <xsd:attribute name="locked" type="xsd:boolean" use="required"/>
*   <xsd:attribute name="layoutInCell" type="xsd:boolean" use="required"/>
*   <xsd:attribute name="hidden" type="xsd:boolean"/>
*   <xsd:attribute name="allowOverlap" type="xsd:boolean" use="required"/>
* </xsd:complexType>
* ```
*/
var Anchor = class extends XmlComponent {
	constructor({ mediaData, transform, drawingOptions }) {
		super("wp:anchor");
		const floating = _objectSpread2({
			allowOverlap: true,
			behindDocument: false,
			lockAnchor: false,
			layoutInCell: true,
			verticalPosition: {},
			horizontalPosition: {}
		}, drawingOptions.floating);
		this.root.push(new AnchorAttributes({
			distT: floating.margins ? floating.margins.top || 0 : 0,
			distB: floating.margins ? floating.margins.bottom || 0 : 0,
			distL: floating.margins ? floating.margins.left || 0 : 0,
			distR: floating.margins ? floating.margins.right || 0 : 0,
			simplePos: "0",
			allowOverlap: floating.allowOverlap === true ? "1" : "0",
			behindDoc: floating.behindDocument === true ? "1" : "0",
			locked: floating.lockAnchor === true ? "1" : "0",
			layoutInCell: floating.layoutInCell === true ? "1" : "0",
			relativeHeight: floating.zIndex ? floating.zIndex : transform.emus.y
		}));
		this.root.push(createSimplePos());
		this.root.push(createHorizontalPosition(floating.horizontalPosition));
		this.root.push(createVerticalPosition(floating.verticalPosition));
		this.root.push(createExtent({
			x: transform.emus.x,
			y: transform.emus.y
		}));
		this.root.push(createEffectExtent({
			top: 0,
			right: 0,
			bottom: 0,
			left: 0
		}));
		if (drawingOptions.floating !== void 0 && drawingOptions.floating.wrap !== void 0) switch (drawingOptions.floating.wrap.type) {
			case TextWrappingType.SQUARE:
				this.root.push(createWrapSquare(drawingOptions.floating.wrap, drawingOptions.floating.margins));
				break;
			case TextWrappingType.TIGHT:
				this.root.push(createWrapTight(drawingOptions.floating.margins));
				break;
			case TextWrappingType.TOP_AND_BOTTOM:
				this.root.push(createWrapTopAndBottom(drawingOptions.floating.margins));
				break;
			case TextWrappingType.NONE:
			default: this.root.push(createWrapNone());
		}
		else this.root.push(createWrapNone());
		this.root.push(new DocProperties(drawingOptions.docProperties));
		this.root.push(createGraphicFrameProperties());
		this.root.push(new Graphic({
			mediaData,
			transform,
			outline: drawingOptions.outline,
			solidFill: drawingOptions.solidFill
		}));
	}
};
var createInline = ({ mediaData, transform, docProperties, outline, solidFill }) => {
	var _outline$width, _outline$width2, _outline$width3, _outline$width4;
	return new BuilderElement({
		name: "wp:inline",
		attributes: {
			distanceTop: {
				key: "distT",
				value: 0
			},
			distanceBottom: {
				key: "distB",
				value: 0
			},
			distanceLeft: {
				key: "distL",
				value: 0
			},
			distanceRight: {
				key: "distR",
				value: 0
			}
		},
		children: [
			createExtent({
				x: transform.emus.x,
				y: transform.emus.y
			}),
			createEffectExtent(outline ? {
				top: ((_outline$width = outline.width) !== null && _outline$width !== void 0 ? _outline$width : 9525) * 2,
				right: ((_outline$width2 = outline.width) !== null && _outline$width2 !== void 0 ? _outline$width2 : 9525) * 2,
				bottom: ((_outline$width3 = outline.width) !== null && _outline$width3 !== void 0 ? _outline$width3 : 9525) * 2,
				left: ((_outline$width4 = outline.width) !== null && _outline$width4 !== void 0 ? _outline$width4 : 9525) * 2
			} : {
				top: 0,
				right: 0,
				bottom: 0,
				left: 0
			}),
			new DocProperties(docProperties),
			createGraphicFrameProperties(),
			new Graphic({
				mediaData,
				transform,
				outline,
				solidFill
			})
		]
	});
};
/**
* Represents a drawing element in a WordprocessingML document.
*
* Drawings can be either inline (positioned as part of the text flow) or
* anchored (positioned relative to the page, column, or paragraph).
*
* Reference: http://officeopenxml.com/drwOverview.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Drawing">
*   <xsd:choice minOccurs="1" maxOccurs="unbounded">
*     <xsd:element ref="wp:anchor" minOccurs="0"/>
*     <xsd:element ref="wp:inline" minOccurs="0"/>
*   </xsd:choice>
* </xsd:complexType>
* ```
*/
var Drawing = class extends XmlComponent {
	constructor(imageData, drawingOptions = {}) {
		super("w:drawing");
		if (!drawingOptions.floating) this.root.push(createInline({
			mediaData: imageData,
			transform: imageData.transformation,
			docProperties: drawingOptions.docProperties,
			outline: drawingOptions.outline,
			solidFill: drawingOptions.solidFill
		}));
		else this.root.push(new Anchor({
			mediaData: imageData,
			transform: imageData.transformation,
			drawingOptions
		}));
	}
};
var convertDataURIToBinary = (dataURI) => {
	const base64Index = dataURI.indexOf(";base64,");
	const base64IndexWithOffset = base64Index === -1 ? 0 : base64Index + 8;
	return new Uint8Array(atob(dataURI.substring(base64IndexWithOffset)).split("").map((c) => c.charCodeAt(0)));
};
var standardizeData = (data) => typeof data === "string" ? convertDataURIToBinary(data) : data;
var createImageData = (options, key) => ({
	data: standardizeData(options.data),
	fileName: key,
	transformation: {
		pixels: {
			x: Math.round(options.transformation.width),
			y: Math.round(options.transformation.height)
		},
		emus: {
			x: Math.round(options.transformation.width * 9525),
			y: Math.round(options.transformation.height * 9525)
		},
		flip: options.transformation.flip,
		rotation: options.transformation.rotation ? options.transformation.rotation * 6e4 : void 0
	}
});
/**
* Represents an image in a WordprocessingML document.
*
* ImageRun embeds an image within a run, supporting various formats
* including JPG, PNG, GIF, BMP, and SVG. Optionally wraps the run in
* `<w:ins>` or `<w:del>` for track-change insertion/deletion markup.
*
* Reference: http://officeopenxml.com/drwPicInline.php
*
* @publicApi
*
* @example
* ```typescript
* new ImageRun({
*   data: fs.readFileSync("./image.png"),
*   transformation: {
*     width: 100,
*     height: 100,
*   },
*   type: "png",
* });
* ```
*/
var ImageRun = class extends XmlComponent {
	constructor(options) {
		var _super = (..._args) => (super(..._args), _defineProperty(this, "imageData", void 0), this);
		const key = `${hashedId(options.data)}.${options.type}`;
		const imageData = options.type === "svg" ? _objectSpread2(_objectSpread2({ type: options.type }, createImageData(options, key)), {}, { fallback: _objectSpread2({ type: options.fallback.type }, createImageData(_objectSpread2(_objectSpread2({}, options.fallback), {}, { transformation: options.transformation }), `${hashedId(options.fallback.data)}.${options.fallback.type}`)) }) : _objectSpread2({ type: options.type }, createImageData(options, key));
		const drawing = new Drawing(imageData, {
			floating: options.floating,
			docProperties: options.altText,
			outline: options.outline
		});
		const run = new Run({ children: [drawing] });
		if (options.insertion) {
			_super("w:ins");
			this.root.push(new ChangeAttributes({
				id: options.insertion.id,
				author: options.insertion.author,
				date: options.insertion.date
			}));
			this.addChildElement(run);
		} else if (options.deletion) {
			_super("w:del");
			this.root.push(new ChangeAttributes({
				id: options.deletion.id,
				author: options.deletion.author,
				date: options.deletion.date
			}));
			this.addChildElement(run);
		} else {
			_super("w:r");
			this.root.push(new RunProperties({}));
			this.root.push(drawing);
		}
		this.imageData = imageData;
	}
	prepForXml(context) {
		context.file.Media.addImage(this.imageData.fileName, this.imageData);
		if (this.imageData.type === "svg") context.file.Media.addImage(this.imageData.fallback.fileName, this.imageData.fallback);
		return super.prepForXml(context);
	}
};
/**
* Attributes for the Relationships element.
*
* Defines the XML namespace for the relationships part.
*
* @example
* ```typescript
* new RelationshipsAttributes({
*   xmlns: "http://schemas.openxmlformats.org/package/2006/relationships"
* });
* ```
*/
var RelationshipsAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { xmlns: "xmlns" });
	}
};
/**
* Target mode types for relationships.
*
* Indicates whether a relationship target is external to the package.
*/
var TargetModeType = { 
/** Target is external to the package (e.g., hyperlink to a URL) */
EXTERNAL: "External" };
/**
* Creates a single relationship between parts in an OPC package.
*
* A relationship defines a typed connection from a source part to a target part,
* identified by a unique ID within the relationships collection.
*
* @example
* ```typescript
* // Internal relationship to an image
* createRelationship("rId1", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", "media/image1.png");
*
* // External relationship to a hyperlink
* createRelationship("rId2", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", "https://example.com", TargetModeType.EXTERNAL);
* ```
*/
var createRelationship = (id, type, target, targetMode) => new BuilderElement({
	name: "Relationship",
	attributes: {
		id: {
			key: "Id",
			value: id
		},
		type: {
			key: "Type",
			value: type
		},
		target: {
			key: "Target",
			value: target
		},
		targetMode: {
			key: "TargetMode",
			value: targetMode
		}
	}
});
/**
* Relationships module for Open Packaging Conventions.
*
* This module provides support for managing relationships between
* parts in an OPC package (DOCX file).
*
* Reference: http://officeopenxml.com/anatomyofOOXML.php
*
* @module
*/
/**
* Represents a collection of relationships in an OPC package.
*
* Relationships define connections between package parts, such as
* linking the main document to its headers, footers, images, etc.
*
* Reference: http://officeopenxml.com/anatomyofOOXML.php
*
* @example
* ```typescript
* const relationships = new Relationships();
* relationships.addRelationship(
*   1,
*   "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
*   "media/image1.png"
* );
* ```
*/
var Relationships = class extends XmlComponent {
	constructor() {
		super("Relationships");
		this.root.push(new RelationshipsAttributes({ xmlns: "http://schemas.openxmlformats.org/package/2006/relationships" }));
	}
	/**
	* Creates a new relationship to another part in the package.
	*
	* @param id - Unique identifier for this relationship (will be prefixed with "rId")
	* @param type - Relationship type URI (e.g., image, header, hyperlink)
	* @param target - Path to the target part
	* @param targetMode - Optional mode indicating if target is external
	*/
	addRelationship(id, type, target, targetMode) {
		this.root.push(createRelationship(`rId${id}`, type, target, targetMode));
	}
	/**
	* Gets the count of relationships in this collection.
	* Excludes the attributes element from the count.
	*/
	get RelationshipCount() {
		return this.root.length - 1;
	}
};
/**
* @internal
*/
var CommentAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			id: "w:id",
			initials: "w:initials",
			author: "w:author",
			date: "w:date"
		});
	}
};
/**
* @internal
*/
var RootCommentsAttributes = class extends XmlAttributeComponent {
	constructor(..._args3) {
		super(..._args3);
		_defineProperty(this, "xmlKeys", {
			"xmlns:cx": "xmlns:cx",
			"xmlns:cx1": "xmlns:cx1",
			"xmlns:cx2": "xmlns:cx2",
			"xmlns:cx3": "xmlns:cx3",
			"xmlns:cx4": "xmlns:cx4",
			"xmlns:cx5": "xmlns:cx5",
			"xmlns:cx6": "xmlns:cx6",
			"xmlns:cx7": "xmlns:cx7",
			"xmlns:cx8": "xmlns:cx8",
			"xmlns:mc": "xmlns:mc",
			"xmlns:aink": "xmlns:aink",
			"xmlns:am3d": "xmlns:am3d",
			"xmlns:o": "xmlns:o",
			"xmlns:r": "xmlns:r",
			"xmlns:m": "xmlns:m",
			"xmlns:v": "xmlns:v",
			"xmlns:wp14": "xmlns:wp14",
			"xmlns:wp": "xmlns:wp",
			"xmlns:w10": "xmlns:w10",
			"xmlns:w": "xmlns:w",
			"xmlns:w14": "xmlns:w14",
			"xmlns:w15": "xmlns:w15",
			"xmlns:w16cex": "xmlns:w16cex",
			"xmlns:w16cid": "xmlns:w16cid",
			"xmlns:w16": "xmlns:w16",
			"xmlns:w16sdtdh": "xmlns:w16sdtdh",
			"xmlns:w16se": "xmlns:w16se",
			"xmlns:wpg": "xmlns:wpg",
			"xmlns:wpi": "xmlns:wpi",
			"xmlns:wne": "xmlns:wne",
			"xmlns:wps": "xmlns:wps"
		});
	}
};
/**
* Represents a single comment in a WordprocessingML document.
*
* Contains the actual content of a comment, including author information
* and the comment text (typically paragraphs).
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Comment">
*   <xsd:sequence>
*     <xsd:group ref="EG_BlockLevelElts" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="initials" type="s:ST_String"/>
*   <xsd:attribute name="author" type="s:ST_String"/>
*   <xsd:attribute name="date" type="s:ST_DateTime"/>
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Comment({
*   id: 0,
*   author: "John Doe",
*   initials: "JD",
*   children: [new Paragraph("This is a comment")],
* });
* ```
*/
var Comment = class extends XmlComponent {
	constructor({ id, initials, author, date = /* @__PURE__ */ new Date(), children }, paraId) {
		super("w:comment");
		_defineProperty(this, "paraId", void 0);
		this.paraId = paraId;
		this.root.push(new CommentAttributes({
			id,
			initials,
			author,
			date: date.toISOString()
		}));
		for (const child of children) this.root.push(child);
	}
	/**
	* Serializes this comment to XML, injecting w14:paraId and w14:textId into the last
	* paragraph when threading is active. These attributes link the comment to its
	* corresponding w15:commentEx entry in commentsExtended.xml.
	*/
	prepForXml(context) {
		const result = super.prepForXml(context);
		if (!result || !this.paraId) return result;
		const commentChildren = result["w:comment"];
		if (!Array.isArray(commentChildren)) return result;
		for (let i = commentChildren.length - 1; i >= 0; i--) {
			const child = commentChildren[i];
			if (child && typeof child === "object" && "w:p" in child) {
				const pChildren = child["w:p"];
				if (Array.isArray(pChildren)) pChildren.unshift({ _attr: {
					"w14:paraId": this.paraId,
					"w14:textId": this.paraId
				} });
				break;
			}
		}
		return result;
	}
};
/**
* Converts a comment ID to a deterministic 8-character uppercase hex paraId.
*/
var commentIdToParaId = (id) => (id + 1).toString(16).toUpperCase().padStart(8, "0");
/**
* Represents the comments container in a WordprocessingML document.
*
* This is the root element for the comments.xml file that stores all
* comment definitions in the document. When any comment uses `parentId`,
* threading is activated and thread data is generated for commentsExtended.xml.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="comments" type="CT_Comments"/>
* <xsd:complexType name="CT_Comments">
*   <xsd:sequence>
*     <xsd:element name="comment" type="CT_Comment" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Comments({
*   children: [
*     {
*       id: 0,
*       author: "John Doe",
*       children: [new Paragraph("First comment")],
*     },
*     {
*       id: 1,
*       author: "Jane Smith",
*       parentId: 0,
*       children: [new Paragraph("Reply to first comment")],
*     },
*   ],
* });
* ```
*/
var Comments = class extends XmlComponent {
	constructor({ children }) {
		super("w:comments");
		_defineProperty(this, "relationships", void 0);
		_defineProperty(this, "threadData", void 0);
		this.root.push(new RootCommentsAttributes({
			"xmlns:cx": "http://schemas.microsoft.com/office/drawing/2014/chartex",
			"xmlns:cx1": "http://schemas.microsoft.com/office/drawing/2015/9/8/chartex",
			"xmlns:cx2": "http://schemas.microsoft.com/office/drawing/2015/10/21/chartex",
			"xmlns:cx3": "http://schemas.microsoft.com/office/drawing/2016/5/9/chartex",
			"xmlns:cx4": "http://schemas.microsoft.com/office/drawing/2016/5/10/chartex",
			"xmlns:cx5": "http://schemas.microsoft.com/office/drawing/2016/5/11/chartex",
			"xmlns:cx6": "http://schemas.microsoft.com/office/drawing/2016/5/12/chartex",
			"xmlns:cx7": "http://schemas.microsoft.com/office/drawing/2016/5/13/chartex",
			"xmlns:cx8": "http://schemas.microsoft.com/office/drawing/2016/5/14/chartex",
			"xmlns:mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
			"xmlns:aink": "http://schemas.microsoft.com/office/drawing/2016/ink",
			"xmlns:am3d": "http://schemas.microsoft.com/office/drawing/2017/model3d",
			"xmlns:o": "urn:schemas-microsoft-com:office:office",
			"xmlns:r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			"xmlns:m": "http://schemas.openxmlformats.org/officeDocument/2006/math",
			"xmlns:v": "urn:schemas-microsoft-com:vml",
			"xmlns:wp14": "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			"xmlns:wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			"xmlns:w10": "urn:schemas-microsoft-com:office:word",
			"xmlns:w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			"xmlns:w14": "http://schemas.microsoft.com/office/word/2010/wordml",
			"xmlns:w15": "http://schemas.microsoft.com/office/word/2012/wordml",
			"xmlns:w16cex": "http://schemas.microsoft.com/office/word/2018/wordml/cex",
			"xmlns:w16cid": "http://schemas.microsoft.com/office/word/2016/wordml/cid",
			"xmlns:w16": "http://schemas.microsoft.com/office/word/2018/wordml",
			"xmlns:w16sdtdh": "http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash",
			"xmlns:w16se": "http://schemas.microsoft.com/office/word/2015/wordml/symex",
			"xmlns:wpg": "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			"xmlns:wpi": "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			"xmlns:wne": "http://schemas.microsoft.com/office/word/2006/wordml",
			"xmlns:wps": "http://schemas.microsoft.com/office/word/2010/wordprocessingShape"
		}));
		if (children.some((child) => child.parentId !== void 0)) {
			const idToParaId = new Map(children.map((child) => [child.id, commentIdToParaId(child.id)]));
			for (const child of children) this.root.push(new Comment(child, idToParaId.get(child.id)));
			this.threadData = children.map((child) => ({
				paraId: idToParaId.get(child.id),
				parentParaId: child.parentId !== void 0 ? idToParaId.get(child.parentId) : void 0,
				done: child.resolved
			}));
		} else for (const child of children) this.root.push(new Comment(child));
		this.relationships = new Relationships();
	}
	get Relationships() {
		return this.relationships;
	}
	/** Thread data for commentsExtended.xml, or undefined when no comments use parentId. */
	get ThreadData() {
		return this.threadData;
	}
};
/**
* CommentsExtended module for WordprocessingML documents.
*
* Generates word/commentsExtended.xml which stores comment reply threading
* relationships using w15:commentEx elements.
*
* Reference: ISO/IEC 29500 + Microsoft wml-2012.xsd
*
* @module
*/
/**
* @internal
*/
var CommentsExtendedAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			"xmlns:wpc": "xmlns:wpc",
			"xmlns:mc": "xmlns:mc",
			"xmlns:w15": "xmlns:w15",
			"mc:Ignorable": "mc:Ignorable"
		});
	}
};
/**
* @internal
*/
var CommentExAttributes = class extends XmlAttributeComponent {
	constructor(..._args2) {
		super(..._args2);
		_defineProperty(this, "xmlKeys", {
			paraId: "w15:paraId",
			paraIdParent: "w15:paraIdParent",
			done: "w15:done"
		});
	}
};
/**
* @internal
*/
var CommentEx = class extends XmlComponent {
	constructor(options) {
		super("w15:commentEx");
		this.root.push(new CommentExAttributes({
			paraId: options.paraId,
			paraIdParent: options.parentParaId,
			done: options.done !== void 0 ? options.done ? "1" : "0" : void 0
		}));
	}
};
/**
* Represents the commentsExtended part (word/commentsExtended.xml).
*
* Contains w15:commentEx elements that define comment reply threading
* and resolved status.
*
* ## XSD Schema (wml-2012.xsd)
* ```xml
* <xsd:complexType name="CT_CommentsEx">
*   <xsd:sequence>
*     <xsd:element name="commentEx" type="CT_CommentEx" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var CommentsExtended = class extends XmlComponent {
	constructor(threadData) {
		super("w15:commentsEx");
		this.root.push(new CommentsExtendedAttributes({
			"xmlns:wpc": "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			"xmlns:mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
			"xmlns:w15": "http://schemas.microsoft.com/office/word/2012/wordml",
			"mc:Ignorable": "w15"
		}));
		for (const data of threadData) this.root.push(new CommentEx(data));
	}
};
/**
* Represents a reference to an endnote.
*
* Used within endnote content to refer back to the endnote marker.
*/
var EndnoteReference = class extends EmptyElement {
	constructor() {
		super("w:endnoteRef");
	}
};
/**
* Represents a page break before setting for paragraph properties.
*
* When applied to a paragraph, ensures the paragraph begins on a new page.
*
* Reference: http://officeopenxml.com/WPparagraphProperties.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_OnOff">
*   <xsd:attribute name="val" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   pageBreakBefore: true,
*   children: [new TextRun("This text starts on a new page")],
* });
* ```
*/
var PageBreakBefore = class extends XmlComponent {
	constructor() {
		super("w:pageBreakBefore");
	}
};
/**
* Paragraph spacing module for WordprocessingML documents.
*
* This module provides spacing options for paragraphs including space before,
* space after, and line spacing.
*
* Reference: http://officeopenxml.com/WPspacing.php
*
* @module
*/
/**
* Line spacing rule types.
*
* Specifies how the line height is calculated.
*
* @publicApi
*/
var LineRuleType = {
	/** Line spacing is at least the specified value */
	AT_LEAST: "atLeast",
	/** Line spacing is exactly the specified value */
	EXACTLY: "exactly",
	/** Line spacing is exactly the specified value (alias for EXACTLY) */
	EXACT: "exact",
	/** Line spacing is automatically determined based on content */
	AUTO: "auto"
};
/**
* Creates paragraph spacing element for a WordprocessingML document.
*
* The spacing element specifies the spacing between lines and paragraphs.
*
* Reference: http://officeopenxml.com/WPspacing.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Spacing">
*   <xsd:attribute name="before" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="beforeLines" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="beforeAutospacing" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="after" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="afterLines" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="afterAutospacing" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="line" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="lineRule" type="ST_LineSpacingRule" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   spacing: {
*     before: 200,
*     after: 200,
*     line: 360,
*     lineRule: LineRuleType.AT_LEAST,
*   },
*   children: [new TextRun("Paragraph with custom spacing")],
* });
* ```
*/
var createSpacing = ({ after, before, line, lineRule, beforeAutoSpacing, afterAutoSpacing }) => new BuilderElement({
	name: "w:spacing",
	attributes: {
		after: {
			key: "w:after",
			value: after
		},
		before: {
			key: "w:before",
			value: before
		},
		line: {
			key: "w:line",
			value: line
		},
		lineRule: {
			key: "w:lineRule",
			value: lineRule
		},
		beforeAutoSpacing: {
			key: "w:beforeAutospacing",
			value: beforeAutoSpacing
		},
		afterAutoSpacing: {
			key: "w:afterAutospacing",
			value: afterAutoSpacing
		}
	}
});
/**
* Paragraph style module for WordprocessingML documents.
*
* This module provides paragraph style references including heading levels.
*
* @module
*/
/**
* Built-in heading level styles.
*
* These are the standard heading styles available in Word documents.
*
* @publicApi
*/
var HeadingLevel = {
	/** Heading 1 style */
	HEADING_1: "Heading1",
	/** Heading 2 style */
	HEADING_2: "Heading2",
	/** Heading 3 style */
	HEADING_3: "Heading3",
	/** Heading 4 style */
	HEADING_4: "Heading4",
	/** Heading 5 style */
	HEADING_5: "Heading5",
	/** Heading 6 style */
	HEADING_6: "Heading6",
	/** Title style */
	TITLE: "Title"
};
/**
* Creates a paragraph style reference for a WordprocessingML document.
*
* The pStyle element specifies the paragraph style to apply to the paragraph.
*
* Reference: http://officeopenxml.com/WPstyle.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_String">
*   <xsd:attribute name="val" type="s:ST_String" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Using a built-in heading style
* new Paragraph({
*   style: HeadingLevel.HEADING_1,
*   children: [new TextRun("Chapter 1")],
* });
*
* // Using a custom style
* new Paragraph({
*   style: "MyCustomStyle",
*   children: [new TextRun("Styled text")],
* });
* ```
*/
var createParagraphStyle = (styleId) => new BuilderElement({
	name: "w:pStyle",
	attributes: { val: {
		key: "w:val",
		value: styleId
	} }
});
/**
* Tab stop module for WordprocessingML documents.
*
* This module provides tab stop definitions for paragraphs.
*
* Reference: http://officeopenxml.com/WPtab.php
*
* @module
*/
/**
* Tab stop alignment types.
*
* Specifies the type of tab stop and how text aligns to it.
*
* @publicApi
*/
var TabStopType = {
	/** Left-aligned tab stop */
	LEFT: "left",
	/** Right-aligned tab stop */
	RIGHT: "right",
	/** Center-aligned tab stop */
	CENTER: "center",
	/** Bar tab stop - inserts a vertical bar at the position */
	BAR: "bar",
	/** Clears a tab stop at the specified position */
	CLEAR: "clear",
	/** Decimal-aligned tab stop - aligns on decimal point */
	DECIMAL: "decimal",
	/** End-aligned tab stop (right-to-left equivalent) */
	END: "end",
	/** List tab stop for numbered lists */
	NUM: "num",
	/** Start-aligned tab stop (left-to-right equivalent) */
	START: "start"
};
/**
* Creates a single tab stop item element.
*
* Reference: http://officeopenxml.com/WPtab.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TabStop">
*   <xsd:attribute name="val" type="ST_TabJc" use="required"/>
*   <xsd:attribute name="leader" type="ST_TabTlc" use="optional"/>
*   <xsd:attribute name="pos" type="ST_SignedTwipsMeasure" use="required"/>
* </xsd:complexType>
* ```
*/
var createTabStopItem = ({ type, position, leader }) => new BuilderElement({
	name: "w:tab",
	attributes: {
		val: {
			key: "w:val",
			value: type
		},
		pos: {
			key: "w:pos",
			value: position
		},
		leader: {
			key: "w:leader",
			value: leader
		}
	}
});
/**
* Creates a collection of tab stops for a WordprocessingML document.
*
* Tab stops define the positions where text will align when a tab character is used.
*
* Reference: http://officeopenxml.com/WPtab.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Tabs">
*   <xsd:sequence>
*     <xsd:element name="tab" type="CT_TabStop" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   tabStops: [
*     { type: TabStopType.LEFT, position: 2000 },
*     { type: TabStopType.CENTER, position: 4000 },
*     { type: TabStopType.RIGHT, position: TabStopPosition.MAX, leader: LeaderType.DOT },
*   ],
*   children: [new TextRun("Text\twith\ttabs")],
* });
* ```
*/
var createTabStop = (tabDefinitions) => new BuilderElement({
	name: "w:tabs",
	children: tabDefinitions.map((tabDefinition) => createTabStopItem(tabDefinition))
});
/**
* Numbering properties module for WordprocessingML documents.
*
* This module provides numbering and list properties for paragraphs.
*
* @module
*/
/**
* Represents numbering properties for a paragraph.
*
* The numPr element specifies the numbering definition instance and level
* for the paragraph, enabling numbered and bulleted lists.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_NumPr">
*   <xsd:sequence>
*     <xsd:element name="ilvl" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="numId" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="numberingChange" type="CT_TrackChangeNumbering" minOccurs="0"/>
*     <xsd:element name="ins" type="CT_TrackChange" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a bulleted list item at level 0
* new Paragraph({
*   numbering: {
*     reference: "my-bullet-list",
*     level: 0,
*   },
*   children: [new TextRun("First item")],
* });
*
* // Create a numbered list item at level 1
* new Paragraph({
*   numbering: {
*     reference: "my-numbered-list",
*     level: 1,
*   },
*   children: [new TextRun("Nested item")],
* });
* ```
*/
var NumberProperties = class extends XmlComponent {
	constructor(numberId, indentLevel) {
		super("w:numPr");
		this.root.push(new IndentLevel(indentLevel));
		this.root.push(new NumberId(numberId));
	}
};
/**
* Represents the indentation level (ilvl) for a numbered or bulleted list.
*
* The ilvl element specifies the list level (0-9) for the paragraph.
*
* @internal
*/
var IndentLevel = class extends XmlComponent {
	constructor(level) {
		super("w:ilvl");
		if (level > 9) throw new Error("Level cannot be greater than 9. Read more here: https://answers.microsoft.com/en-us/msoffice/forum/all/does-word-support-more-than-9-list-levels/d130fdcd-1781-446d-8c84-c6c79124e4d7");
		this.root.push(new Attributes({ val: level }));
	}
};
/**
* Represents the numbering definition ID (numId) for a numbered or bulleted list.
*
* The numId element specifies which numbering definition to use for the paragraph.
*
* @internal
*/
var NumberId = class extends XmlComponent {
	constructor(id) {
		super("w:numId");
		this.root.push(new Attributes({ val: typeof id === "string" ? `{${id}}` : id }));
	}
};
/**
* FileChild module for WordprocessingML documents.
*
* FileChild is the base class for block-level elements that can appear
* in the document body, such as paragraphs and tables.
*
* @module
*/
/**
* Base class for document body children.
*
* FileChild represents a block-level element that can be added directly
* to the document body. Examples include Paragraph and Table.
*/
var FileChild = class extends XmlComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(
			this,
			/** Marker property identifying this as a FileChild */
			"fileChild",
			Symbol()
		);
	}
};
/**
* Hyperlink attributes module for WordprocessingML documents.
*
* This module provides attribute components for hyperlink elements.
*
* Reference: http://officeopenxml.com/WPhyperlink.php
*
* @module
*/
/**
* Attributes for the hyperlink element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Hyperlink">
*   <xsd:group ref="EG_PContent" minOccurs="0" maxOccurs="unbounded"/>
*   <xsd:attribute name="tgtFrame" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="tooltip" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="docLocation" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="history" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="anchor" type="s:ST_String" use="optional"/>
*   <xsd:attribute ref="r:id"/>
* </xsd:complexType>
* ```
*/
var HyperlinkAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			id: "r:id",
			history: "w:history",
			anchor: "w:anchor"
		});
	}
};
/**
* Represents a concrete hyperlink in a WordprocessingML document.
*
* This class is the low-level implementation of hyperlinks used internally.
* Use InternalHyperlink or ExternalHyperlink for creating hyperlinks in documents.
*
* Reference: http://officeopenxml.com/WPhyperlink.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="hyperlink" type="CT_Hyperlink"/>
*
* <xsd:complexType name="CT_Hyperlink">
*   <xsd:group ref="EG_PContent" minOccurs="0" maxOccurs="unbounded"/>
*   <xsd:attribute name="tgtFrame" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="tooltip" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="docLocation" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="history" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="anchor" type="s:ST_String" use="optional"/>
*   <xsd:attribute ref="r:id"/>
* </xsd:complexType>
* ```
*/
var ConcreteHyperlink = class extends XmlComponent {
	constructor(children, relationshipId, anchor) {
		super("w:hyperlink");
		_defineProperty(this, "linkId", void 0);
		this.linkId = relationshipId;
		const attributes = new HyperlinkAttributes({
			history: 1,
			anchor: anchor ? anchor : void 0,
			id: !anchor ? `rId${this.linkId}` : void 0
		});
		this.root.push(attributes);
		children.forEach((child) => {
			this.root.push(child);
		});
	}
};
/**
* Represents an external hyperlink to a URL outside the document.
*
* External hyperlinks create a relationship to an external resource (URL).
* The relationship is created during document preparation and the hyperlink
* is converted to a ConcreteHyperlink with the relationship ID.
*
* Reference: http://officeopenxml.com/WPhyperlink.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:element name="hyperlink" type="CT_Hyperlink"/>
*
* <xsd:complexType name="CT_Hyperlink">
*   <xsd:group ref="EG_PContent" minOccurs="0" maxOccurs="unbounded"/>
*   <xsd:attribute ref="r:id"/>
*   <xsd:attribute name="history" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new ExternalHyperlink({
*   children: [new TextRun({ text: "Visit Example", style: "Hyperlink" })],
*   link: "https://example.com",
* });
* ```
*/
var ExternalHyperlink = class extends XmlComponent {
	constructor(options) {
		super("w:externalHyperlink");
		_defineProperty(this, "options", void 0);
		this.options = options;
	}
};
/**
* Bookmark attributes module for WordprocessingML documents.
*
* This module provides attribute components for bookmark start and end elements.
*
* Reference: http://officeopenxml.com/WPbookmark.php
*
* @module
*/
/**
* Attributes for the bookmark start element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Bookmark">
*   <xsd:complexContent>
*     <xsd:extension base="CT_BookmarkRange">
*       <xsd:attribute name="name" type="s:ST_String" use="required"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_BookmarkRange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_MarkupRange">
*       <xsd:attribute name="colFirst" type="ST_DecimalNumber" use="optional"/>
*       <xsd:attribute name="colLast" type="ST_DecimalNumber" use="optional"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_MarkupRange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_Markup">
*       <xsd:attribute name="displacedByCustomXml" type="ST_DisplacedByCustomXml" use="optional"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_Markup">
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*/
var BookmarkStartAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			id: "w:id",
			name: "w:name"
		});
	}
};
/**
* Attributes for the bookmark end element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_MarkupRange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_Markup">
*       <xsd:attribute name="displacedByCustomXml" type="ST_DisplacedByCustomXml" use="optional"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_Markup">
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*/
var BookmarkEndAttributes = class extends XmlAttributeComponent {
	constructor(..._args2) {
		super(..._args2);
		_defineProperty(this, "xmlKeys", { id: "w:id" });
	}
};
/**
* Bookmark module for WordprocessingML documents.
*
* Bookmarks are used to identify a location or selection of text within a document.
* They can be used as targets for hyperlinks.
*
* Reference: http://officeopenxml.com/WPbookmark.php
*
* @module
*/
/**
* Represents a bookmark in a WordprocessingML document.
*
* A bookmark identifies a location or range of content that can be referenced
* elsewhere, such as from a hyperlink or table of contents. The bookmark consists
* of a start marker, content, and an end marker.
*
* Reference: http://officeopenxml.com/WPbookmark.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:element name="bookmarkStart" type="CT_Bookmark"/>
* <xsd:element name="bookmarkEnd" type="CT_MarkupRange"/>
*
* <xsd:complexType name="CT_Bookmark">
*   <xsd:complexContent>
*     <xsd:extension base="CT_BookmarkRange">
*       <xsd:attribute name="name" type="s:ST_String" use="required"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a bookmark around a heading
* new Bookmark({
*   id: "section1",
*   children: [new TextRun("Section 1 Heading")],
* });
*
* // Link to the bookmark from elsewhere
* new InternalHyperlink({
*   children: [new TextRun("Go to Section 1")],
*   anchor: "section1",
* });
* ```
*/
var Bookmark = class {
	constructor(options) {
		_defineProperty(this, "bookmarkUniqueNumericId", bookmarkUniqueNumericIdGen());
		_defineProperty(this, "start", void 0);
		_defineProperty(this, "children", void 0);
		_defineProperty(this, "end", void 0);
		const linkId = this.bookmarkUniqueNumericId();
		this.start = new BookmarkStart(options.id, linkId);
		this.children = options.children;
		this.end = new BookmarkEnd(linkId);
	}
};
/**
* Represents the start marker of a bookmark range.
*
* This element marks the beginning of a bookmarked region in the document.
* It must be paired with a corresponding BookmarkEnd element with the same id.
*
* Reference: http://officeopenxml.com/WPbookmark.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="bookmarkStart" type="CT_Bookmark"/>
*
* <xsd:complexType name="CT_Bookmark">
*   <xsd:complexContent>
*     <xsd:extension base="CT_BookmarkRange">
*       <xsd:attribute name="name" type="s:ST_String" use="required"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new BookmarkStart("myBookmark", 1);
* ```
*/
var BookmarkStart = class extends XmlComponent {
	constructor(id, linkId) {
		super("w:bookmarkStart");
		const attributes = new BookmarkStartAttributes({
			name: id,
			id: linkId
		});
		this.root.push(attributes);
	}
};
/**
* Represents the end marker of a bookmark range.
*
* This element marks the end of a bookmarked region in the document.
* It must be paired with a corresponding BookmarkStart element with the same id.
*
* Reference: http://officeopenxml.com/WPbookmark.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="bookmarkEnd" type="CT_MarkupRange"/>
*
* <xsd:complexType name="CT_MarkupRange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_Markup">
*       <xsd:attribute name="displacedByCustomXml" type="ST_DisplacedByCustomXml" use="optional"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new BookmarkEnd(1);
* ```
*/
var BookmarkEnd = class extends XmlComponent {
	constructor(linkId) {
		super("w:bookmarkEnd");
		const attributes = new BookmarkEndAttributes({ id: linkId });
		this.root.push(attributes);
	}
};
/**
* Outline level module for WordprocessingML documents.
*
* This module provides the outline level element which specifies
* the outline level of a paragraph for document outline/TOC purposes.
*
* Reference: http://officeopenxml.com/WPparagraph.php
*
* @module
*/
/**
* Creates an outline level element for a paragraph.
*
* The outline level determines the paragraph's position in the document
* outline and affects table of contents generation. Level 0 corresponds
* to Heading 1, level 1 to Heading 2, etc.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_DecimalNumber">
*   <xsd:attribute name="val" type="xsd:integer" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set outline level to 0 (Heading 1)
* createOutlineLevel(0);
*
* // Set outline level to 2 (Heading 3)
* createOutlineLevel(2);
* ```
*/
var createOutlineLevel = (level) => new BuilderElement({
	name: "w:outlineLvl",
	attributes: { val: {
		key: "w:val",
		value: level
	} }
});
/**
* Creates a font relationship element for embedding fonts.
*/
var createFontRelationship = ({ id, fontKey, subsetted }, name) => new BuilderElement({
	name,
	attributes: _objectSpread2({ id: {
		key: "r:id",
		value: id
	} }, fontKey ? { fontKey: {
		key: "w:fontKey",
		value: `{${fontKey}}`
	} } : {}),
	children: [...subsetted ? [new OnOffElement("w:subsetted", subsetted)] : []]
});
/**
* Creates a font element with the specified options.
*
* This function builds a complete font definition including optional embedded font files,
* font signature, character set, and other font properties.
*
* Reference: http://www.datypic.com/sc/ooxml/e-w_font-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Font">
*   <xsd:sequence>
*     <xsd:element name="altName" type="CT_String" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="panose1" type="CT_Panose" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="charset" type="CT_Charset" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="family" type="CT_FontFamily" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="notTrueType" type="CT_OnOff" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="pitch" type="CT_Pitch" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="sig" type="CT_FontSig" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="embedRegular" type="CT_FontRel" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="embedBold" type="CT_FontRel" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="embedItalic" type="CT_FontRel" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="embedBoldItalic" type="CT_FontRel" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="name" type="s:ST_String" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const font = createFont({
*   name: "Arial",
*   family: "swiss",
*   pitch: "variable",
*   charset: CharacterSet.ANSI
* });
* ```
*/
var createFont = ({ name, altName, panose1, charset, family, notTrueType, pitch, sig, embedRegular, embedBold, embedItalic, embedBoldItalic }) => new BuilderElement({
	name: "w:font",
	attributes: { name: {
		key: "w:name",
		value: name
	} },
	children: [
		...altName ? [createStringElement("w:altName", altName)] : [],
		...panose1 ? [createStringElement("w:panose1", panose1)] : [],
		...charset ? [createStringElement("w:charset", charset)] : [],
		...family ? [createStringElement("w:family", family)] : [],
		...notTrueType ? [new OnOffElement("w:notTrueType", notTrueType)] : [],
		...pitch ? [createStringElement("w:pitch", pitch)] : [],
		...sig ? [new BuilderElement({
			name: "w:sig",
			attributes: {
				usb0: {
					key: "w:usb0",
					value: sig.usb0
				},
				usb1: {
					key: "w:usb1",
					value: sig.usb1
				},
				usb2: {
					key: "w:usb2",
					value: sig.usb2
				},
				usb3: {
					key: "w:usb3",
					value: sig.usb3
				},
				csb0: {
					key: "w:csb0",
					value: sig.csb0
				},
				csb1: {
					key: "w:csb1",
					value: sig.csb1
				}
			}
		})] : [],
		...embedRegular ? [createFontRelationship(embedRegular, "w:embedRegular")] : [],
		...embedBold ? [createFontRelationship(embedBold, "w:embedBold")] : [],
		...embedItalic ? [createFontRelationship(embedItalic, "w:embedItalic")] : [],
		...embedBoldItalic ? [createFontRelationship(embedBoldItalic, "w:embedBoldItalic")] : []
	]
});
/**
* Creates a regular embedded font with default settings.
*
* This helper function creates a font definition with standard font signature
* values that work for most common fonts. The signature specifies Unicode
* and code page ranges supported by the font.
*
* @param options - Font creation options
* @param options.name - Font name
* @param options.index - Font relationship index
* @param options.fontKey - Unique font key (GUID) for obfuscation
* @param options.characterSet - Optional character set identifier
*
* @returns XmlComponent representing the font definition
*
* @example
* ```typescript
* const font = createRegularFont({
*   name: "Arial",
*   index: 1,
*   fontKey: "12345678-1234-1234-1234-123456789012"
* });
* ```
*/
var createRegularFont = ({ name, index, fontKey, characterSet }) => createFont({
	name,
	sig: {
		usb0: "E0002AFF",
		usb1: "C000247B",
		usb2: "00000009",
		usb3: "00000000",
		csb0: "000001FF",
		csb1: "00000000"
	},
	charset: characterSet,
	family: "auto",
	pitch: "variable",
	embedRegular: {
		fontKey,
		id: `rId${index}`
	}
});
/**
* Font Table module for WordprocessingML documents.
*
* This module provides support for embedding fonts in the document.
*
* Reference: http://www.datypic.com/sc/ooxml/e-w_fonts.html
*
* @module
*/
/**
* Creates a font table element containing embedded fonts.
*
* The font table allows custom fonts to be embedded in the document
* so they display correctly even if not installed on the viewer's system.
*
* Reference: http://www.datypic.com/sc/ooxml/e-w_fonts.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_FontsList">
*   <xsd:sequence>
*     <xsd:element name="font" type="CT_Font" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createFontTable = (fonts) => new BuilderElement({
	name: "w:fonts",
	attributes: {
		mc: {
			key: "xmlns:mc",
			value: "http://schemas.openxmlformats.org/markup-compatibility/2006"
		},
		r: {
			key: "xmlns:r",
			value: "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
		},
		w: {
			key: "xmlns:w",
			value: "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
		},
		w14: {
			key: "xmlns:w14",
			value: "http://schemas.microsoft.com/office/word/2010/wordml"
		},
		w15: {
			key: "xmlns:w15",
			value: "http://schemas.microsoft.com/office/word/2012/wordml"
		},
		w16cex: {
			key: "xmlns:w16cex",
			value: "http://schemas.microsoft.com/office/word/2018/wordml/cex"
		},
		w16cid: {
			key: "xmlns:w16cid",
			value: "http://schemas.microsoft.com/office/word/2016/wordml/cid"
		},
		w16: {
			key: "xmlns:w16",
			value: "http://schemas.microsoft.com/office/word/2018/wordml"
		},
		w16sdtdh: {
			key: "xmlns:w16sdtdh",
			value: "http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
		},
		w16se: {
			key: "xmlns:w16se",
			value: "http://schemas.microsoft.com/office/word/2015/wordml/symex"
		},
		Ignorable: {
			key: "mc:Ignorable",
			value: "w14 w15 w16se w16cid w16 w16cex w16sdtdh"
		}
	},
	children: fonts.map((font, i) => createRegularFont({
		name: font.name,
		index: i + 1,
		fontKey: font.fontKey,
		characterSet: font.characterSet
	}))
});
/**
* Wrapper class for managing the font table and its relationships.
*
* Creates a font table with embedded font files and manages the relationships
* required for font embedding. Each font is assigned a unique key for obfuscation.
*
* @example
* ```typescript
* const fontWrapper = new FontWrapper([
*   { name: "CustomFont", data: fontBuffer }
* ]);
* ```
*/
var FontWrapper = class {
	constructor(options) {
		_defineProperty(this, "options", void 0);
		_defineProperty(this, "fontTable", void 0);
		_defineProperty(this, "relationships", void 0);
		_defineProperty(this, "fontOptionsWithKey", []);
		this.options = options;
		this.fontOptionsWithKey = options.map((o) => _objectSpread2(_objectSpread2({}, o), {}, { fontKey: uniqueUuid() }));
		this.fontTable = createFontTable(this.fontOptionsWithKey);
		this.relationships = new Relationships();
		for (let i = 0; i < options.length; i++) this.relationships.addRelationship(i + 1, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/font", `fonts/font${i + 1}.odttf`);
	}
	get View() {
		return this.fontTable;
	}
	get Relationships() {
		return this.relationships;
	}
};
/**
* Word wrap module for WordprocessingML documents.
*
* This module provides word wrap settings for paragraphs.
*
* Reference: http://officeopenxml.com/WPalignment.php
*
* @see http://officeopenxml.com/WPtableAlignment.php
*
* @module
*/
/**
* Creates word wrap settings element for a WordprocessingML document.
*
* The wordWrap element specifies whether word wrap should be disabled
* for the paragraph.
*/
var createWordWrap = () => new BuilderElement({
	name: "w:wordWrap",
	attributes: { val: {
		key: "w:val",
		value: 0
	} }
});
/**
* Creates a frame properties XML component for paragraph text frames.
*
* Frames allow paragraphs to be positioned absolutely on the page with text wrapping.
* They support both coordinate-based and alignment-based positioning, along with
* drop cap effects and various text wrapping options.
*
* Reference: http://officeopenxml.com/WPparagraph-textFrames.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_FramePr">
*   <xsd:attribute name="dropCap" type="ST_DropCap" use="optional"/>
*   <xsd:attribute name="lines" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="w" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="h" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="vSpace" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="hSpace" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="wrap" type="ST_Wrap" use="optional"/>
*   <xsd:attribute name="hAnchor" type="ST_HAnchor" use="optional"/>
*   <xsd:attribute name="vAnchor" type="ST_VAnchor" use="optional"/>
*   <xsd:attribute name="x" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="xAlign" type="s:ST_XAlign" use="optional"/>
*   <xsd:attribute name="y" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="yAlign" type="s:ST_YAlign" use="optional"/>
*   <xsd:attribute name="hRule" type="ST_HeightRule" use="optional"/>
*   <xsd:attribute name="anchorLock" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Frame with absolute positioning
* createFrameProperties({
*   type: "absolute",
*   position: { x: 1440, y: 1440 }, // 1 inch from anchor
*   width: 2880, // 2 inches
*   height: 1440, // 1 inch
*   anchor: {
*     horizontal: FrameAnchorType.PAGE,
*     vertical: FrameAnchorType.PAGE,
*   },
*   wrap: FrameWrap.AROUND,
* });
*
* // Frame with alignment positioning and drop cap
* createFrameProperties({
*   type: "alignment",
*   alignment: {
*     x: HorizontalPositionAlign.LEFT,
*     y: VerticalPositionAlign.TOP,
*   },
*   width: 1440,
*   height: 1440,
*   anchor: {
*     horizontal: FrameAnchorType.TEXT,
*     vertical: FrameAnchorType.TEXT,
*   },
*   dropCap: DropCapType.DROP,
*   lines: 3,
* });
* ```
*
* @param options - Frame positioning and formatting options
* @returns XmlComponent representing the frame properties element
*/
var createFrameProperties = (options) => {
	var _options$space, _options$space2;
	return new BuilderElement({
		name: "w:framePr",
		attributes: {
			anchorLock: {
				key: "w:anchorLock",
				value: options.anchorLock
			},
			dropCap: {
				key: "w:dropCap",
				value: options.dropCap
			},
			width: {
				key: "w:w",
				value: options.width
			},
			height: {
				key: "w:h",
				value: options.height
			},
			x: {
				key: "w:x",
				value: options.position ? options.position.x : void 0
			},
			y: {
				key: "w:y",
				value: options.position ? options.position.y : void 0
			},
			anchorHorizontal: {
				key: "w:hAnchor",
				value: options.anchor.horizontal
			},
			anchorVertical: {
				key: "w:vAnchor",
				value: options.anchor.vertical
			},
			spaceHorizontal: {
				key: "w:hSpace",
				value: (_options$space = options.space) === null || _options$space === void 0 ? void 0 : _options$space.horizontal
			},
			spaceVertical: {
				key: "w:vSpace",
				value: (_options$space2 = options.space) === null || _options$space2 === void 0 ? void 0 : _options$space2.vertical
			},
			rule: {
				key: "w:hRule",
				value: options.rule
			},
			alignmentX: {
				key: "w:xAlign",
				value: options.alignment ? options.alignment.x : void 0
			},
			alignmentY: {
				key: "w:yAlign",
				value: options.alignment ? options.alignment.y : void 0
			},
			lines: {
				key: "w:lines",
				value: options.lines
			},
			wrap: {
				key: "w:wrap",
				value: options.wrap
			}
		}
	});
};
/**
* Paragraph properties module for WordprocessingML documents.
*
* This module provides the paragraph properties (pPr) element which specifies
* the formatting applied to a paragraph.
*
* Reference: http://officeopenxml.com/WPparagraphProperties.php
*
* @see https://c-rex.net/projects/samples/ooxml/e1/Part4/OOXML_P4_DOCX_suppressLineNumbers_topic_ID0ECJAO.html
*
* @module
*/
/**
* Represents paragraph properties (pPr) in a WordprocessingML document.
*
* The paragraph properties element specifies all formatting applied to a paragraph,
* including alignment, spacing, indentation, borders, numbering, and style references.
*
* Reference: http://officeopenxml.com/WPparagraphProperties.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PPr">
*   <xsd:complexContent>
*     <xsd:extension base="CT_PPrBase">
*       <xsd:sequence>
*         <xsd:element name="rPr" type="CT_ParaRPr" minOccurs="0"/>
*         <xsd:element name="sectPr" type="CT_SectPr" minOccurs="0"/>
*         <xsd:element name="pPrChange" type="CT_PPrChange" minOccurs="0"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* The base type CT_PPrBase contains:
* ```xml
* <xsd:complexType name="CT_PPrBase">
*   <xsd:sequence>
*     <xsd:element name="pStyle" type="CT_String" minOccurs="0"/>
*     <xsd:element name="keepNext" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="keepLines" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="pageBreakBefore" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="framePr" type="CT_FramePr" minOccurs="0"/>
*     <xsd:element name="widowControl" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="numPr" type="CT_NumPr" minOccurs="0"/>
*     <xsd:element name="suppressLineNumbers" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="pBdr" type="CT_PBdr" minOccurs="0"/>
*     <xsd:element name="shd" type="CT_Shd" minOccurs="0"/>
*     <xsd:element name="tabs" type="CT_Tabs" minOccurs="0"/>
*     <xsd:element name="suppressAutoHyphens" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="kinsoku" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="wordWrap" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="overflowPunct" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="topLinePunct" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="autoSpaceDE" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="autoSpaceDN" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="bidi" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="adjustRightInd" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="snapToGrid" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="spacing" type="CT_Spacing" minOccurs="0"/>
*     <xsd:element name="ind" type="CT_Ind" minOccurs="0"/>
*     <xsd:element name="contextualSpacing" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="mirrorIndents" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="suppressOverlap" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="jc" type="CT_Jc" minOccurs="0"/>
*     <xsd:element name="textDirection" type="CT_TextDirection" minOccurs="0"/>
*     <xsd:element name="textAlignment" type="CT_TextAlignment" minOccurs="0"/>
*     <xsd:element name="textboxTightWrap" type="CT_TextboxTightWrap" minOccurs="0"/>
*     <xsd:element name="outlineLvl" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="divId" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="cnfStyle" type="CT_Cnf" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Basic paragraph with alignment
* new ParagraphProperties({
*   alignment: AlignmentType.CENTER,
* });
*
* // Formatted paragraph with spacing and indentation
* new ParagraphProperties({
*   alignment: AlignmentType.JUSTIFIED,
*   spacing: { before: 200, after: 200, line: 360 },
*   indent: { left: 720, right: 720 },
* });
*
* // Heading with outline level
* new ParagraphProperties({
*   heading: HeadingLevel.HEADING_1,
*   outlineLevel: 0,
*   keepNext: true,
* });
*
* // Numbered list item
* new ParagraphProperties({
*   numbering: {
*     reference: "my-numbering",
*     level: 0,
*     instance: 0,
*   },
* });
*
* // Paragraph with borders and shading
* new ParagraphProperties({
*   border: {
*     top: { style: BorderStyle.SINGLE, size: 6, color: "000000" },
*     bottom: { style: BorderStyle.SINGLE, size: 6, color: "000000" },
*   },
*   shading: { fill: "EEEEEE" },
* });
* ```
*/
var ParagraphProperties = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:pPr", options === null || options === void 0 ? void 0 : options.includeIfEmpty);
		_defineProperty(this, "numberingReferences", []);
		if (!options) return this;
		if (options.heading) this.push(createParagraphStyle(options.heading));
		if (options.bullet) this.push(createParagraphStyle("ListParagraph"));
		if (options.numbering) {
			if (!options.style && !options.heading) {
				if (!options.numbering.custom) this.push(createParagraphStyle("ListParagraph"));
			}
		}
		if (options.style) this.push(createParagraphStyle(options.style));
		if (options.keepNext !== void 0) this.push(new OnOffElement("w:keepNext", options.keepNext));
		if (options.keepLines !== void 0) this.push(new OnOffElement("w:keepLines", options.keepLines));
		if (options.pageBreakBefore) this.push(new PageBreakBefore());
		if (options.frame) this.push(createFrameProperties(options.frame));
		if (options.widowControl !== void 0) this.push(new OnOffElement("w:widowControl", options.widowControl));
		if (options.bullet) this.push(new NumberProperties(1, options.bullet.level));
		if (options.numbering) {
			var _options$numbering$in, _options$numbering$in2;
			this.numberingReferences.push({
				reference: options.numbering.reference,
				instance: (_options$numbering$in = options.numbering.instance) !== null && _options$numbering$in !== void 0 ? _options$numbering$in : 0
			});
			this.push(new NumberProperties(`${options.numbering.reference}-${(_options$numbering$in2 = options.numbering.instance) !== null && _options$numbering$in2 !== void 0 ? _options$numbering$in2 : 0}`, options.numbering.level));
		} else if (options.numbering === false) this.push(new NumberProperties(0, 0));
		if (options.border) this.push(new Border(options.border));
		if (options.thematicBreak) this.push(new ThematicBreak());
		if (options.shading) this.push(createShading(options.shading));
		if (options.wordWrap) this.push(createWordWrap());
		if (options.overflowPunctuation) this.push(new OnOffElement("w:overflowPunct", options.overflowPunctuation));
		/**
		* FIX: Multitab support for Libre Writer
		* Ensure there is only one w:tabs tag with multiple w:tab
		*/
		const tabDefinitions = [
			...options.rightTabStop !== void 0 ? [{
				type: TabStopType.RIGHT,
				position: options.rightTabStop
			}] : [],
			...options.tabStops ? options.tabStops : [],
			...options.leftTabStop !== void 0 ? [{
				type: TabStopType.LEFT,
				position: options.leftTabStop
			}] : []
		];
		if (tabDefinitions.length > 0) this.push(createTabStop(tabDefinitions));
		/**
		*  FIX - END
		*/
		if (options.bidirectional !== void 0) this.push(new OnOffElement("w:bidi", options.bidirectional));
		if (options.spacing) this.push(createSpacing(options.spacing));
		if (options.indent) this.push(createIndent(options.indent));
		if (options.contextualSpacing !== void 0) this.push(new OnOffElement("w:contextualSpacing", options.contextualSpacing));
		if (options.alignment) this.push(createAlignment(options.alignment));
		if (options.outlineLevel !== void 0) this.push(createOutlineLevel(options.outlineLevel));
		if (options.suppressLineNumbers !== void 0) this.push(new OnOffElement("w:suppressLineNumbers", options.suppressLineNumbers));
		if (options.autoSpaceEastAsianText !== void 0) this.push(new OnOffElement("w:autoSpaceDN", options.autoSpaceEastAsianText));
		if (options.run) this.push(new ParagraphRunProperties(options.run));
		if (options.revision) this.push(new ParagraphPropertiesChange(options.revision));
	}
	/**
	* Adds a property element to the paragraph properties.
	*
	* @param item - The XML component to add to the paragraph properties
	*/
	push(item) {
		this.root.push(item);
	}
	/**
	* Prepares the paragraph properties for XML serialization.
	*
	* This method creates concrete numbering instances for any numbering references
	* before the properties are converted to XML.
	*
	* @param context - The XML context containing document and file information
	* @returns The prepared XML object, or undefined if the component should be ignored
	*/
	prepForXml(context) {
		if (!(context.viewWrapper instanceof FontWrapper)) for (const reference of this.numberingReferences) context.file.Numbering.createConcreteNumberingInstance(reference.reference, reference.instance);
		return super.prepForXml(context);
	}
};
var ParagraphPropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:pPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.root.push(new ParagraphProperties(_objectSpread2(_objectSpread2({}, options), {}, { includeIfEmpty: true })));
	}
};
/**
* Paragraph module for WordprocessingML documents.
*
* Reference: http://officeopenxml.com/WPparagraph.php
*
* @module
*/
/**
* Represents a paragraph in a WordprocessingML document.
*
* A paragraph is the primary unit of block-level content in a document and can contain
* various inline elements such as text runs, images, hyperlinks, and bookmarks.
*
* Reference: http://officeopenxml.com/WPparagraph.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_P">
*   <xsd:sequence>
*     <xsd:element name="pPr" type="CT_PPr" minOccurs="0"/>
*     <xsd:group ref="EG_PContent" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="rsidRPr" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidR" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidDel" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidP" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidRDefault" type="ST_LongHexNumber"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Simple paragraph with text
* new Paragraph("Hello World");
*
* // Paragraph with options
* new Paragraph({
*   children: [new TextRun("Hello"), new TextRun({ text: "World", bold: true })],
*   alignment: AlignmentType.CENTER,
* });
* ```
*/
var Paragraph = class extends FileChild {
	constructor(options) {
		super("w:p");
		_defineProperty(this, "properties", void 0);
		if (typeof options === "string") {
			this.properties = new ParagraphProperties({});
			this.root.push(this.properties);
			this.root.push(new TextRun(options));
			return this;
		}
		this.properties = new ParagraphProperties(options);
		this.root.push(this.properties);
		if (options.text) this.root.push(new TextRun(options.text));
		if (options.children) for (const child of options.children) {
			if (child instanceof Bookmark) {
				this.root.push(child.start);
				for (const textRun of child.children) this.root.push(textRun);
				this.root.push(child.end);
				continue;
			}
			this.root.push(child);
		}
	}
	prepForXml(context) {
		for (const element of this.root) if (element instanceof ExternalHyperlink) {
			const index = this.root.indexOf(element);
			const concreteHyperlink = new ConcreteHyperlink(element.options.children, uniqueId());
			context.viewWrapper.Relationships.addRelationship(concreteHyperlink.linkId, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", element.options.link, TargetModeType.EXTERNAL);
			this.root[index] = concreteHyperlink;
		}
		return super.prepForXml(context);
	}
	addRunToFront(run) {
		this.root.splice(1, 0, run);
		return this;
	}
};
/**
* Office Math module for WordprocessingML documents.
*
* This module provides support for mathematical equations and expressions
* using Office MathML (OMML).
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_oMath-1.html
*
* @module
*/
/**
* Represents a mathematical equation in a WordprocessingML document.
*
* Math is the container for Office MathML (OMML) content, supporting
* fractions, radicals, integrals, sums, scripts, and more.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_oMath-1.html
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_OMath">
*   <xsd:sequence>
*     <xsd:group ref="EG_OMathElements" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Math({
*   children: [
*     new MathFraction({
*       numerator: [new MathRun("a")],
*       denominator: [new MathRun("b")],
*     }),
*   ],
* });
* ```
*/
var Math$1 = class extends XmlComponent {
	constructor(options) {
		super("m:oMath");
		for (const child of options.children) this.root.push(child);
	}
};
/**
* Math Text module for Office MathML.
*
* This module provides the MathText class for text content within math runs.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_t-1.html
*
* @module
*/
/**
* Represents text content within a math run.
*
* MathText is the leaf element containing actual text characters
* within a MathRun. It corresponds to the `<m:t>` element.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_t-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Text">
*   <xsd:simpleContent>
*     <xsd:extension base="s:ST_String">
*       <xsd:attribute ref="xml:space" use="optional"/>
*     </xsd:extension>
*   </xsd:simpleContent>
* </xsd:complexType>
* ```
*/
var MathText = class extends XmlComponent {
	constructor(text) {
		super("m:t");
		this.root.push(text);
	}
};
/**
* Math Run module for Office MathML.
*
* This module provides the MathRun class for text content within math equations.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_r-1.html
*
* @module
*/
/**
* Represents a run of text within a math equation.
*
* MathRun is the container for text content in Office MathML,
* similar to how Run contains text in regular paragraphs.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_r-1.html
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_R">
*   <xsd:sequence>
*     <xsd:element name="rPr" type="CT_RPR" minOccurs="0"/>
*     <xsd:group ref="EG_ScriptStyle" minOccurs="0"/>
*     <xsd:choice minOccurs="0" maxOccurs="unbounded">
*       <xsd:element ref="w:br"/>
*       <xsd:element name="t" type="CT_Text"/>
*     </xsd:choice>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new MathRun("x + y");
* ```
*/
var MathRun = class extends XmlComponent {
	constructor(text) {
		super("m:r");
		this.root.push(new MathText(text));
	}
};
/**
* Math Denominator module for Office MathML fractions.
*
* This module provides the denominator element for fractions.
*
* @module
*/
/**
* Represents the denominator (bottom part) of a fraction.
*
* @internal
*/
var MathDenominator = class extends XmlComponent {
	constructor(children) {
		super("m:den");
		for (const child of children) this.root.push(child);
	}
};
/**
* Math Numerator module for Office MathML fractions.
*
* This module provides the numerator element for fractions.
*
* @module
*/
/**
* Represents the numerator (top part) of a fraction.
*
* @internal
*/
var MathNumerator = class extends XmlComponent {
	constructor(children) {
		super("m:num");
		for (const child of children) this.root.push(child);
	}
};
/**
* Math Fraction module for Office MathML.
*
* This module provides the MathFraction class for fraction expressions.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_f-1.html
*
* @module
*/
/**
* Represents a fraction in a math equation.
*
* MathFraction displays a numerator over a denominator with a fraction bar.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_f-1.html
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_F">
*   <xsd:sequence>
*     <xsd:element name="fPr" type="CT_FPr" minOccurs="0"/>
*     <xsd:element name="num" type="CT_OMathArg"/>
*     <xsd:element name="den" type="CT_OMathArg"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new MathFraction({
*   numerator: [new MathRun("a + b")],
*   denominator: [new MathRun("c")],
* });
* ```
*/
var MathFraction = class extends XmlComponent {
	constructor(options) {
		super("m:f");
		this.root.push(new MathNumerator(options.numerator));
		this.root.push(new MathDenominator(options.denominator));
	}
};
/**
* Math Base module for Office MathML.
*
* This module provides the base element (m:e) that contains
* the primary content of math structures.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_e-1.html
*
* @module
*/
/**
* Creates a math base element.
*
* The math base (m:e) is used within math structures like fractions,
* radicals, and n-ary operators to contain the primary expression.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_e-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_OMathArg">
*   <xsd:sequence>
*     <xsd:element name="argPr" type="CT_OMathArgPr" minOccurs="0"/>
*     <xsd:group ref="EG_OMathMathElements" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="ctrlPr" type="CT_CtrlPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createMathBase = ({ children }) => new BuilderElement({
	name: "m:e",
	children
});
/**
* Math SubScript Element module for Office MathML.
*
* This module provides the subscript element for n-ary operators and other structures.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sub-3.html
*
* @module
*/
/**
* Creates a subscript element for math structures.
*
* This element contains the subscript content, used in n-ary operators,
* script objects, and other structures that support subscripts.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sub-3.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_OMathArg">
*   <xsd:sequence>
*     <xsd:element name="argPr" type="CT_OMathArgPr" minOccurs="0"/>
*     <xsd:group ref="EG_OMathMathElements" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="ctrlPr" type="CT_CtrlPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createMathSubScriptElement = ({ children }) => new BuilderElement({
	name: "m:sub",
	children
});
/**
* Math SuperScript Element module for Office MathML.
*
* This module provides the superscript element for n-ary operators and other structures.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sup-3.html
*
* @module
*/
/**
* Creates a superscript element for math structures.
*
* This element contains the superscript content, used in n-ary operators,
* script objects, and other structures that support superscripts.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sup-3.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_OMathArg">
*   <xsd:sequence>
*     <xsd:element name="argPr" type="CT_OMathArgPr" minOccurs="0"/>
*     <xsd:group ref="EG_OMathMathElements" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="ctrlPr" type="CT_CtrlPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createMathSuperScriptElement = ({ children }) => new BuilderElement({
	name: "m:sup",
	children
});
/**
* Math SuperScript Properties module for Office MathML.
*
* This module provides properties for superscript structures.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSupPr-1.html
*
* @module
*/
/**
* Creates properties for a superscript structure.
*
* This element specifies properties for the superscript object.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSupPr-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SSupPr">
*   <xsd:sequence>
*     <xsd:element name="ctrlPr" type="CT_CtrlPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createMathSuperScriptProperties = () => new BuilderElement({ name: "m:sSupPr" });
/**
* Math SuperScript module for Office MathML.
*
* This module provides the MathSuperScript class for superscript expressions.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSup-1.html
*
* @module
*/
/**
* Represents a superscript expression in a math equation.
*
* MathSuperScript displays a base with an exponent, like x².
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSup-1.html
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SSup">
*   <xsd:sequence>
*     <xsd:element name="sSupPr" type="CT_SSupPr" minOccurs="0"/>
*     <xsd:element name="e" type="CT_OMathArg"/>
*     <xsd:element name="sup" type="CT_OMathArg"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // x squared
* new MathSuperScript({
*   children: [new MathRun("x")],
*   superScript: [new MathRun("2")],
* });
* ```
*/
var MathSuperScript = class extends XmlComponent {
	constructor(options) {
		super("m:sSup");
		this.root.push(createMathSuperScriptProperties());
		this.root.push(createMathBase({ children: options.children }));
		this.root.push(createMathSuperScriptElement({ children: options.superScript }));
	}
};
/**
* Math SubScript Properties module for Office MathML.
*
* This module provides properties for subscript structures.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSubPr-1.html
*
* @module
*/
/**
* Creates properties for a subscript structure.
*
* This element specifies properties for the subscript object.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSubPr-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SSubPr">
*   <xsd:sequence>
*     <xsd:element name="ctrlPr" type="CT_CtrlPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createMathSubScriptProperties = () => new BuilderElement({ name: "m:sSubPr" });
/**
* Math SubScript module for Office MathML.
*
* This module provides the MathSubScript class for subscript expressions.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSub-1.html
*
* @module
*/
/**
* Represents a subscript expression in a math equation.
*
* MathSubScript displays a base with a subscript, like x₁.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSub-1.html
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SSub">
*   <xsd:sequence>
*     <xsd:element name="sSubPr" type="CT_SSubPr" minOccurs="0"/>
*     <xsd:element name="e" type="CT_OMathArg"/>
*     <xsd:element name="sub" type="CT_OMathArg"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // x with subscript 1
* new MathSubScript({
*   children: [new MathRun("x")],
*   subScript: [new MathRun("1")],
* });
* ```
*/
var MathSubScript = class extends XmlComponent {
	constructor(options) {
		super("m:sSub");
		this.root.push(createMathSubScriptProperties());
		this.root.push(createMathBase({ children: options.children }));
		this.root.push(createMathSubScriptElement({ children: options.subScript }));
	}
};
/**
* Math Sub-Super-Script Properties module for Office MathML.
*
* This module provides properties for combined subscript and superscript structures.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSubSupPr-1.html
*
* @module
*/
/**
* Creates properties for a combined subscript and superscript structure.
*
* This element specifies properties for the subscript-superscript object.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSubSupPr-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SSubSupPr">
*   <xsd:sequence>
*     <xsd:element name="alignScripts" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="ctrlPr" type="CT_CtrlPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createMathSubSuperScriptProperties = () => new BuilderElement({ name: "m:sSubSupPr" });
/**
* Math SubSuperScript module for Office MathML.
*
* This module provides the MathSubSuperScript class for combined subscript/superscript.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSubSup-1.html
*
* @module
*/
/**
* Represents a combined subscript and superscript expression in a math equation.
*
* MathSubSuperScript displays a base with both a subscript and superscript,
* commonly used for tensor notation or indexed variables with exponents.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_sSubSup-1.html
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SSubSup">
*   <xsd:sequence>
*     <xsd:element name="sSubSupPr" type="CT_SSubSupPr" minOccurs="0"/>
*     <xsd:element name="e" type="CT_OMathArg"/>
*     <xsd:element name="sub" type="CT_OMathArg"/>
*     <xsd:element name="sup" type="CT_OMathArg"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // x with subscript i and superscript 2
* new MathSubSuperScript({
*   children: [new MathRun("x")],
*   subScript: [new MathRun("i")],
*   superScript: [new MathRun("2")],
* });
* ```
*/
var MathSubSuperScript = class extends XmlComponent {
	constructor(options) {
		super("m:sSubSup");
		this.root.push(createMathSubSuperScriptProperties());
		this.root.push(createMathBase({ children: options.children }));
		this.root.push(createMathSubScriptElement({ children: options.subScript }));
		this.root.push(createMathSuperScriptElement({ children: options.superScript }));
	}
};
/**
* Math Degree module for Office MathML.
*
* This module provides the degree element for radical structures.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_deg-1.html
*
* @module
*/
/**
* Represents the degree of a radical (root) in a math equation.
*
* MathDegree specifies the degree of the root, such as 3 for cube root.
* For square roots, this element is typically hidden.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_deg-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_OMathArg">
*   <xsd:sequence>
*     <xsd:element name="argPr" type="CT_OMathArgPr" minOccurs="0"/>
*     <xsd:group ref="EG_OMathMathElements" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="ctrlPr" type="CT_CtrlPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @internal
*/
var MathDegree = class extends XmlComponent {
	constructor(children) {
		super("m:deg");
		if (!!children) for (const child of children) this.root.push(child);
	}
};
/**
* Math Degree Hide module for Office MathML.
*
* This module provides the element to hide the degree in radical structures.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_degHide-1.html
*
* @module
*/
/**
* @internal
*/
var MathDegreeHideAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { hide: "m:val" });
	}
};
/**
* Represents a property to hide the degree in a radical.
*
* MathDegreeHide is used in radical properties to hide the degree,
* typically for square roots where the degree (2) is not displayed.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_degHide-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_OnOff">
*   <xsd:attribute name="val" type="ST_OnOff"/>
* </xsd:complexType>
* ```
*
* @internal
*/
var MathDegreeHide = class extends XmlComponent {
	constructor() {
		super("m:degHide");
		this.root.push(new MathDegreeHideAttributes({ hide: 1 }));
	}
};
/**
* Math Radical Properties module for Office MathML.
*
* This module provides properties for radical (root) structures in math equations.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_radPr-1.html
*
* @module
*/
/**
* Represents properties for a radical structure.
*
* This element specifies properties for the radical object,
* such as whether to hide the degree (for square roots).
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_radPr-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_RadPr">
*   <xsd:sequence>
*     <xsd:element name="degHide" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="ctrlPr" type="CT_CtrlPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @internal
*/
var MathRadicalProperties = class extends XmlComponent {
	constructor(hasDegree) {
		super("m:radPr");
		if (!hasDegree) this.root.push(new MathDegreeHide());
	}
};
/**
* Math Radical module for Office MathML.
*
* This module provides the MathRadical class for radical (root) expressions.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_rad-1.html
*
* @module
*/
/**
* Represents a radical (root) expression in a math equation.
*
* MathRadical displays a radical symbol (√) with optional degree for
* n-th roots (cube root, fourth root, etc.).
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_rad-1.html
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Rad">
*   <xsd:sequence>
*     <xsd:element name="radPr" type="CT_RadPr" minOccurs="0"/>
*     <xsd:element name="deg" type="CT_OMathArg"/>
*     <xsd:element name="e" type="CT_OMathArg"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Square root of x
* new MathRadical({ children: [new MathRun("x")] });
*
* // Cube root of x
* new MathRadical({
*   children: [new MathRun("x")],
*   degree: [new MathRun("3")],
* });
* ```
*/
var MathRadical = class extends XmlComponent {
	constructor(options) {
		super("m:rad");
		this.root.push(new MathRadicalProperties(!!options.degree));
		this.root.push(new MathDegree(options.degree));
		this.root.push(createMathBase({ children: options.children }));
	}
};
/**
* Math Beginning Character module for Office MathML.
*
* This module provides the beginning (opening) character for bracket delimiters.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_begChr-1.html
*
* @module
*/
/**
* Creates a beginning character element for bracket delimiters.
*
* This element specifies the opening/beginning character for a delimiter object,
* such as "(", "[", "{", or "⟨".
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_begChr-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Char">
*   <xsd:attribute name="val" type="ST_Char" use="required"/>
* </xsd:complexType>
* ```
*/
var createMathBeginningCharacter = ({ character }) => new BuilderElement({
	name: "m:begChr",
	attributes: { character: {
		key: "m:val",
		value: character
	} }
});
/**
* Math Ending Character module for Office MathML.
*
* This module provides the ending (closing) character for bracket delimiters.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_endChr-1.html
*
* @module
*/
/**
* Creates an ending character element for bracket delimiters.
*
* This element specifies the closing/ending character for a delimiter object,
* such as ")", "]", "}", or "⟩".
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_endChr-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Char">
*   <xsd:attribute name="val" type="ST_Char" use="required"/>
* </xsd:complexType>
* ```
*/
var createMathEndingCharacter = ({ character }) => new BuilderElement({
	name: "m:endChr",
	attributes: { character: {
		key: "m:val",
		value: character
	} }
});
/**
* Math Bracket Properties module for Office MathML.
*
* This module provides properties for bracket delimiters in math equations.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_dPr-1.html
*
* @module
*/
/**
* Creates bracket properties for math delimiter objects.
*
* This element specifies properties for the delimiter object,
* including custom beginning and ending characters.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_dPr-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_DPr">
*   <xsd:sequence>
*     <xsd:element name="begChr" type="CT_Char" minOccurs="0"/>
*     <xsd:element name="sepChr" type="CT_Char" minOccurs="0"/>
*     <xsd:element name="endChr" type="CT_Char" minOccurs="0"/>
*     <xsd:element name="grow" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="shp" type="CT_Shp" minOccurs="0"/>
*     <xsd:element name="ctrlPr" type="CT_CtrlPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createMathBracketProperties = ({ characters }) => new BuilderElement({
	name: "m:dPr",
	children: !!characters ? [createMathBeginningCharacter({ character: characters.beginningCharacter }), createMathEndingCharacter({ character: characters.endingCharacter })] : []
});
/**
* Math Round Brackets module for Office MathML.
*
* This module provides the MathRoundBrackets class for parentheses.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_d-1.html
*
* @module
*/
/**
* Represents round brackets (parentheses) in a math equation.
*
* MathRoundBrackets displays content surrounded by parentheses ( ).
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_d-1.html
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_D">
*   <xsd:sequence>
*     <xsd:element name="dPr" type="CT_DPr" minOccurs="0"/>
*     <xsd:element name="e" type="CT_OMathArg" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new MathRoundBrackets({ children: [new MathRun("x + y")] });
* ```
*/
var MathRoundBrackets = class extends XmlComponent {
	constructor(options) {
		super("m:d");
		this.root.push(createMathBracketProperties({}));
		this.root.push(createMathBase({ children: options.children }));
	}
};
/**
* Math Square Brackets module for Office MathML.
*
* This module provides the MathSquareBrackets class for square brackets.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_d-1.html
*
* @module
*/
/**
* Represents square brackets in a math equation.
*
* MathSquareBrackets displays content surrounded by square brackets [ ].
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_d-1.html
*
* @publicApi
*
* @example
* ```typescript
* new MathSquareBrackets({ children: [new MathRun("x + y")] });
* ```
*/
var MathSquareBrackets = class extends XmlComponent {
	constructor(options) {
		super("m:d");
		this.root.push(createMathBracketProperties({ characters: {
			beginningCharacter: "[",
			endingCharacter: "]"
		} }));
		this.root.push(createMathBase({ children: options.children }));
	}
};
/**
* Math Curly Brackets module for Office MathML.
*
* This module provides the MathCurlyBrackets class for curly braces.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_d-1.html
*
* @module
*/
/**
* Represents curly braces in a math equation.
*
* MathCurlyBrackets displays content surrounded by curly braces { }.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_d-1.html
*
* @publicApi
*
* @example
* ```typescript
* new MathCurlyBrackets({ children: [new MathRun("x + y")] });
* ```
*/
var MathCurlyBrackets = class extends XmlComponent {
	constructor(options) {
		super("m:d");
		this.root.push(createMathBracketProperties({ characters: {
			beginningCharacter: "{",
			endingCharacter: "}"
		} }));
		this.root.push(createMathBase({ children: options.children }));
	}
};
/**
* Math Angled Brackets module for Office MathML.
*
* This module provides the MathAngledBrackets class for angle brackets.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_d-1.html
*
* @module
*/
/**
* Represents angle brackets in a math equation.
*
* MathAngledBrackets displays content surrounded by angle brackets ⟨ ⟩.
*
* Reference: http://www.datypic.com/sc/ooxml/e-m_d-1.html
*
* @publicApi
*
* @example
* ```typescript
* new MathAngledBrackets({ children: [new MathRun("x, y")] });
* ```
*/
var MathAngledBrackets = class extends XmlComponent {
	constructor(options) {
		super("m:d");
		this.root.push(createMathBracketProperties({ characters: {
			beginningCharacter: "〈",
			endingCharacter: "〉"
		} }));
		this.root.push(createMathBase({ children: options.children }));
	}
};
/**
* Table grid module for WordprocessingML documents.
*
* The table grid defines the column structure of a table.
*
* Reference: http://officeopenxml.com/WPtableGrid.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblGridCol">
*   <xsd:attribute name="w" type="s:ST_TwipsMeasure"/>
* </xsd:complexType>
* <xsd:complexType name="CT_TblGridBase">
*   <xsd:sequence>
*     <xsd:element name="gridCol" type="CT_TblGridCol" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* <xsd:complexType name="CT_TblGridChange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_Markup">
*       <xsd:sequence>
*         <xsd:element name="tblGrid" type="CT_TblGridBase"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Creates a single column in the table grid.
*
* The gridCol element specifies the width of a single column.
*/
var createGridCol = (width) => new BuilderElement({
	name: "w:gridCol",
	attributes: width !== void 0 ? { width: {
		key: "w:w",
		value: twipsMeasureValue(width)
	} } : void 0
});
/**
* Creates the table grid for a WordprocessingML document.
*
* The tblGrid element defines the number and width of columns in the table.
*
* Reference: http://officeopenxml.com/WPtableGrid.php
*/
var TableGrid = class extends XmlComponent {
	constructor(widths, revision) {
		super("w:tblGrid");
		for (const width of widths) this.root.push(createGridCol(width));
		if (revision) this.root.push(new TableGridChange(revision));
	}
};
var TableGridChangeAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { id: "w:id" });
	}
};
var TableGridChange = class extends XmlComponent {
	constructor(options) {
		super("w:tblGridChange");
		this.root.push(new TableGridChangeAttributes({ id: options.id }));
		this.root.push(new TableGrid(options.columnWidths));
	}
};
var InsertedTableRow = class extends XmlComponent {
	constructor(options) {
		super("w:ins");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
var DeletedTableRow = class extends XmlComponent {
	constructor(options) {
		super("w:del");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
var InsertedTableCell = class extends XmlComponent {
	constructor(options) {
		super("w:cellIns");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
var DeletedTableCell = class extends XmlComponent {
	constructor(options) {
		super("w:cellDel");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
var CellMergeAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			id: "w:id",
			author: "w:author",
			date: "w:date",
			verticalMerge: "w:vMerge",
			verticalMergeOriginal: "w:vMergeOrig"
		});
	}
};
var CellMerge = class extends XmlComponent {
	constructor(options) {
		super("w:cellMerge");
		this.root.push(new CellMergeAttributes(options));
	}
};
_objectSpread2(_objectSpread2({}, {
	TOP: "top",
	CENTER: "center",
	BOTTOM: "bottom"
}), {}, { BOTH: "both" });
/**
* Creates a vertical alignment element in a WordprocessingML document.
*
* Used in table cells and sections to control vertical text positioning.
*
* @example
* ```typescript
* createVerticalAlign(VerticalAlignTable.CENTER);
* ```
*/
var createVerticalAlign = (value) => new BuilderElement({
	name: "w:vAlign",
	attributes: { verticalAlign: {
		key: "w:val",
		value
	} }
});
/**
* Table cell margin module for WordprocessingML documents.
*
* This module provides cell margin settings for tables and individual cells.
* Margins define the padding between cell content and cell borders.
*
* Reference: http://officeopenxml.com/WPtableCellProperties-Margins.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblCellMar">
*   <xsd:sequence>
*     <xsd:element name="top" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="start" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="left" type="CT_TblWidth" minOccurs="0"/>
*     <xsd:element name="bottom" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="end" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="right" type="CT_TblWidth" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Builds an array of margin child elements based on the provided options.
*
* @internal
*/
var buildMarginChildren = ({ marginUnitType = WidthType.DXA, top, left, bottom, right }) => [
	{
		name: "w:top",
		size: top
	},
	{
		name: "w:left",
		size: left
	},
	{
		name: "w:bottom",
		size: bottom
	},
	{
		name: "w:right",
		size: right
	}
].filter((entry) => entry.size !== void 0).map(({ name, size }) => createTableWidthElement(name, {
	type: marginUnitType,
	size
}));
/**
* Creates a table-level cell margin element (tblCellMar).
*
* The tblCellMar element specifies the default cell margins for all cells
* in the table. Individual cells can override these defaults using
* cell-level margins (tcMar).
*
* Reference: http://officeopenxml.com/WPtableCellProperties-Margins.php
*
* @param options - The margin options
* @returns An XmlComponent representing the tblCellMar element, or undefined if no margins specified
*
* @example
* ```typescript
* // Table with 100 twip margins on all sides
* new Table({
*   rows: [...],
*   margins: {
*     top: 100,
*     bottom: 100,
*     left: 100,
*     right: 100,
*   },
* });
* ```
*/
var createTableCellMargin = (options) => {
	const children = buildMarginChildren(options);
	if (children.length === 0) return;
	return new BuilderElement({
		name: "w:tblCellMar",
		children
	});
};
/**
* Creates a cell-level margin element (tcMar).
*
* The tcMar element specifies the margins for a specific table cell,
* overriding any table-level default margins (tblCellMar).
*
* Reference: http://officeopenxml.com/WPtableCellProperties-Margins.php
*
* @param options - The margin options
* @returns An XmlComponent representing the tcMar element, or undefined if no margins specified
*
* @example
* ```typescript
* // Cell with custom margins
* new TableCell({
*   children: [...],
*   margins: {
*     top: 50,
*     bottom: 50,
*     left: 100,
*     right: 100,
*   },
* });
* ```
*/
var createCellMargin = (options) => {
	const children = buildMarginChildren(options);
	if (children.length === 0) return;
	return new BuilderElement({
		name: "w:tcMar",
		children
	});
};
/**
* Table width module for WordprocessingML documents.
*
* This module provides width specifications for tables and cells.
*
* Reference: http://officeopenxml.com/WPtableWidth.php
*
* @module
*/
/**
* Width type values for tables and cells.
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_TblWidth">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="nil"/>
*     <xsd:enumeration value="pct"/>
*     <xsd:enumeration value="dxa"/>
*     <xsd:enumeration value="auto"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var WidthType = {
	/** Auto. */
	AUTO: "auto",
	/** Value is in twentieths of a point */
	DXA: "dxa",
	/** No (empty) value. */
	NIL: "nil",
	/** Value is in percentage. */
	PERCENTAGE: "pct"
};
/**
* Creates a table width element in a WordprocessingML document.
*
* Used for specifying widths of tables, cells, margins, and indentation.
*
* Reference: http://officeopenxml.com/WPtableWidth.php
*
* @example
* ```typescript
* createTableWidthElement("w:tblW", { size: 5000, type: WidthType.DXA });
* createTableWidthElement("w:tcW", { size: 50, type: WidthType.PERCENTAGE });
* ```
*/
var createTableWidthElement = (name, { type = WidthType.AUTO, size }) => {
	let tableWidthValue = size;
	if (type === WidthType.PERCENTAGE && typeof size === "number") tableWidthValue = `${size}%`;
	return new BuilderElement({
		name,
		attributes: {
			type: {
				key: "w:type",
				value: type
			},
			size: {
				key: "w:w",
				value: measurementOrPercentValue(tableWidthValue)
			}
		}
	});
};
/**
* Table cell components module for WordprocessingML documents.
*
* This module provides XML components for table cell properties including borders,
* grid span (column span), vertical merge, and text direction.
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* @module
*/
/**
* Represents table cell borders (tcBorders) in a WordprocessingML document.
*
* The tcBorders element specifies the borders for a single table cell. Each border
* can be configured independently with different styles, colors, and widths.
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TcBorders">
*   <xsd:sequence>
*     <xsd:element name="top" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="start" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="left" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="bottom" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="end" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="right" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="insideH" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="insideV" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="tl2br" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="tr2bl" type="CT_Border" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new TableCellBorders({
*   top: { style: BorderStyle.SINGLE, size: 6, color: "FF0000" },
*   bottom: { style: BorderStyle.SINGLE, size: 6, color: "0000FF" },
* });
* ```
*/
var TableCellBorders = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:tcBorders");
		if (options.top) this.root.push(createBorderElement("w:top", options.top));
		if (options.start) this.root.push(createBorderElement("w:start", options.start));
		if (options.left) this.root.push(createBorderElement("w:left", options.left));
		if (options.bottom) this.root.push(createBorderElement("w:bottom", options.bottom));
		if (options.end) this.root.push(createBorderElement("w:end", options.end));
		if (options.right) this.root.push(createBorderElement("w:right", options.right));
	}
};
/**
* Attributes for the GridSpan element.
*/
var GridSpanAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents a grid span (gridSpan) element in a WordprocessingML document.
*
* The gridSpan element specifies the number of logical columns this cell spans
* in the table grid. This is used to merge cells horizontally (column span).
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_DecimalNumber">
*   <xsd:attribute name="val" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Cell spanning 3 columns
* new GridSpan(3);
* ```
*/
var GridSpan = class extends XmlComponent {
	constructor(value) {
		super("w:gridSpan");
		this.root.push(new GridSpanAttributes({ val: decimalNumber(value) }));
	}
};
/**
* Vertical merge types for table cells.
*
* Defines the merge behavior for vertically merged cells (row span).
*/
var VerticalMergeType = {
	/**
	* Cell that is merged with upper one.
	* This cell continues a vertical merge started by a cell above it.
	*/
	CONTINUE: "continue",
	/**
	* Cell that is starting the vertical merge.
	* This cell begins a new vertical merge region.
	*/
	RESTART: "restart"
};
/**
* Attributes for the VerticalMerge element.
*/
var VerticalMergeAttributes = class extends XmlAttributeComponent {
	constructor(..._args2) {
		super(..._args2);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents a vertical merge (vMerge) element in a WordprocessingML document.
*
* The vMerge element specifies that this cell is part of a vertically merged region.
* Cells can either restart a new merge region or continue an existing one from above.
* This is used to create row spans in tables.
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_VMerge">
*   <xsd:attribute name="val" type="ST_Merge"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // First cell in a vertical merge
* new VerticalMerge(VerticalMergeType.RESTART);
*
* // Subsequent cells that continue the merge
* new VerticalMerge(VerticalMergeType.CONTINUE);
* ```
*/
var VerticalMerge = class extends XmlComponent {
	constructor(value) {
		super("w:vMerge");
		this.root.push(new VerticalMergeAttributes({ val: value }));
	}
};
/**
* Attributes for the TDirection element.
*/
var TDirectionAttributes = class extends XmlAttributeComponent {
	constructor(..._args3) {
		super(..._args3);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents a text direction (textDirection) element in a WordprocessingML document.
*
* The textDirection element specifies the flow of text within a table cell. This is
* useful for creating rotated text or supporting different writing systems.
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TextDirection">
*   <xsd:attribute name="val" type="ST_TextDirection" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Vertical text flowing from top to bottom
* new TDirection(TextDirection.TOP_TO_BOTTOM_RIGHT_TO_LEFT);
* ```
*/
var TDirection = class extends XmlComponent {
	constructor(value) {
		super("w:textDirection");
		this.root.push(new TDirectionAttributes({ val: value }));
	}
};
/**
* Table cell properties module for WordprocessingML documents.
*
* This module provides cell-level properties including width, borders,
* shading, margins, and merge settings.
*
* Reference: http://officeopenxml.com/WPtableCellProperties.php
*
* @module
*/
/**
* Represents table cell properties (tcPr) in a WordprocessingML document.
*
* The tcPr element specifies properties for a table cell including width,
* borders, shading, margins, text direction, vertical alignment, and merge settings.
* These properties control the appearance and behavior of individual table cells.
*
* Reference: http://officeopenxml.com/WPtableCellProperties.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TcPr">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TcPrInner">
*       <xsd:sequence>
*         <xsd:element name="tcPrChange" type="CT_TcPrChange" minOccurs="0"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_TcPrInner">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TcPrBase">
*       <xsd:sequence>
*         <xsd:group ref="EG_CellMarkupElements" minOccurs="0" maxOccurs="1"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_TcPrBase">
*   <xsd:sequence>
*     <xsd:element name="cnfStyle" type="CT_Cnf" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tcW" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="gridSpan" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="hMerge" type="CT_HMerge" minOccurs="0"/>
*     <xsd:element name="vMerge" type="CT_VMerge" minOccurs="0"/>
*     <xsd:element name="tcBorders" type="CT_TcBorders" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="shd" type="CT_Shd" minOccurs="0"/>
*     <xsd:element name="noWrap" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="tcMar" type="CT_TcMar" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="textDirection" type="CT_TextDirection" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tcFitText" type="CT_OnOff" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="vAlign" type="CT_VerticalJc" minOccurs="0"/>
*     <xsd:element name="hideMark" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="headers" type="CT_Headers" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
*
* <xsd:group name="EG_CellMarkupElements">
*   <xsd:choice>
*     <xsd:element name="cellIns" type="CT_TrackChange" minOccurs="0"/>
*     <xsd:element name="cellDel" type="CT_TrackChange" minOccurs="0"/>
*     <xsd:element name="cellMerge" type="CT_CellMergeTrackChange" minOccurs="0"/>
*   </xsd:choice>
* </xsd:group>
*
* <xsd:complexType name="CT_TcPrChange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TrackChange">
*       <xsd:sequence>
*         <xsd:element name="tcPr" type="CT_TcPrInner" minOccurs="1"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new TableCellProperties({
*   width: { size: 3000, type: WidthType.DXA },
*   shading: { fill: "EEEEEE" },
*   verticalAlign: VerticalAlign.CENTER,
*   columnSpan: 2,
* });
* ```
*/
var TableCellProperties = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:tcPr", options.includeIfEmpty);
		if (options.width) this.root.push(createTableWidthElement("w:tcW", options.width));
		if (options.columnSpan) this.root.push(new GridSpan(options.columnSpan));
		if (options.verticalMerge) this.root.push(new VerticalMerge(options.verticalMerge));
		else if (options.rowSpan && options.rowSpan > 1) this.root.push(new VerticalMerge(VerticalMergeType.RESTART));
		if (options.borders) this.root.push(new TableCellBorders(options.borders));
		if (options.shading) this.root.push(createShading(options.shading));
		if (options.margins) {
			const cellMargin = createCellMargin(options.margins);
			if (cellMargin) this.root.push(cellMargin);
		}
		if (options.textDirection) this.root.push(new TDirection(options.textDirection));
		if (options.verticalAlign) this.root.push(createVerticalAlign(options.verticalAlign));
		if (options.insertion) this.root.push(new InsertedTableCell(options.insertion));
		if (options.deletion) this.root.push(new DeletedTableCell(options.deletion));
		if (options.revision) this.root.push(new TableCellPropertiesChange(options.revision));
		if (options.cellMerge) this.root.push(new CellMerge(options.cellMerge));
	}
};
var TableCellPropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:tcPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.root.push(new TableCellProperties(_objectSpread2(_objectSpread2({}, options), {}, { includeIfEmpty: true })));
	}
};
/**
* Table cell module for WordprocessingML documents.
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* @module
*/
/**
* Represents a table cell in a WordprocessingML document.
*
* A table cell is the basic unit of content within a table. Each cell can contain
* paragraphs, nested tables, or other block-level content. Cells must always end
* with a paragraph element.
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Tc">
*   <xsd:sequence>
*     <xsd:element name="tcPr" type="CT_TcPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:group ref="EG_BlockLevelElts" minOccurs="1" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="id" type="s:ST_String" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new TableCell({
*   children: [new Paragraph("Cell content")],
*   width: { size: 3000, type: WidthType.DXA },
* });
* ```
*/
var TableCell = class extends XmlComponent {
	constructor(options) {
		super("w:tc");
		_defineProperty(this, "options", void 0);
		this.options = options;
		this.root.push(new TableCellProperties(options));
		for (const child of options.children) this.root.push(child);
	}
	prepForXml(context) {
		if (!(this.root[this.root.length - 1] instanceof Paragraph)) this.root.push(new Paragraph({}));
		return super.prepForXml(context);
	}
};
/**
* Table borders module for WordprocessingML documents.
*
* This module provides border options for tables.
*
* Reference: http://officeopenxml.com/WPtableBorders.php
*
* @module
*/
var NONE_BORDER = {
	style: BorderStyle.NONE,
	size: 0,
	color: "auto"
};
var DEFAULT_BORDER = {
	style: BorderStyle.SINGLE,
	size: 4,
	color: "auto"
};
/**
* Represents table borders in a WordprocessingML document.
*
* The tblBorders element specifies the borders for all cells in the table.
*
* Reference: http://officeopenxml.com/WPtableBorders.php
*
* @publicApi
*
* @example
* ```typescript
* new TableBorders({
*   top: { style: BorderStyle.SINGLE, size: 6, color: "000000" },
*   bottom: { style: BorderStyle.SINGLE, size: 6, color: "000000" },
* });
*
* // To remove all borders
* new TableBorders(TableBorders.NONE);
* ```
*/
var TableBorders = class extends XmlComponent {
	constructor(options) {
		var _options$top, _options$left, _options$bottom, _options$right, _options$insideHorizo, _options$insideVertic;
		super("w:tblBorders");
		this.root.push(createBorderElement("w:top", (_options$top = options.top) !== null && _options$top !== void 0 ? _options$top : DEFAULT_BORDER));
		this.root.push(createBorderElement("w:left", (_options$left = options.left) !== null && _options$left !== void 0 ? _options$left : DEFAULT_BORDER));
		this.root.push(createBorderElement("w:bottom", (_options$bottom = options.bottom) !== null && _options$bottom !== void 0 ? _options$bottom : DEFAULT_BORDER));
		this.root.push(createBorderElement("w:right", (_options$right = options.right) !== null && _options$right !== void 0 ? _options$right : DEFAULT_BORDER));
		this.root.push(createBorderElement("w:insideH", (_options$insideHorizo = options.insideHorizontal) !== null && _options$insideHorizo !== void 0 ? _options$insideHorizo : DEFAULT_BORDER));
		this.root.push(createBorderElement("w:insideV", (_options$insideVertic = options.insideVertical) !== null && _options$insideVertic !== void 0 ? _options$insideVertic : DEFAULT_BORDER));
	}
};
_defineProperty(TableBorders, "NONE", {
	top: NONE_BORDER,
	bottom: NONE_BORDER,
	left: NONE_BORDER,
	right: NONE_BORDER,
	insideHorizontal: NONE_BORDER,
	insideVertical: NONE_BORDER
});
/**
* Creates a table overlap element.
*
* @internal
*/
var createOverlapElement = (overlap) => new BuilderElement({
	name: "w:tblOverlap",
	attributes: { val: {
		key: "w:val",
		value: overlap
	} }
});
/**
* Creates floating table properties in a WordprocessingML document.
*
* This element specifies the positioning of a floating table,
* including anchor points, offsets, and text wrapping behavior.
*
* Reference: http://officeopenxml.com/WPtableFloating.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblPPr">
*   <xsd:attribute name="leftFromText" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="rightFromText" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="topFromText" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="bottomFromText" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="vertAnchor" type="ST_VAnchor"/>
*   <xsd:attribute name="horzAnchor" type="ST_HAnchor"/>
*   <xsd:attribute name="tblpXSpec" type="s:ST_XAlign"/>
*   <xsd:attribute name="tblpX" type="ST_SignedTwipsMeasure"/>
*   <xsd:attribute name="tblpYSpec" type="s:ST_YAlign"/>
*   <xsd:attribute name="tblpY" type="ST_SignedTwipsMeasure"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* createTableFloatProperties({
*   horizontalAnchor: TableAnchorType.MARGIN,
*   relativeHorizontalPosition: RelativeHorizontalPosition.CENTER,
*   topFromText: 200,
*   bottomFromText: 200,
* });
* ```
*/
var createTableFloatProperties = ({ horizontalAnchor, verticalAnchor, absoluteHorizontalPosition, relativeHorizontalPosition, absoluteVerticalPosition, relativeVerticalPosition, bottomFromText, topFromText, leftFromText, rightFromText, overlap }) => new BuilderElement({
	name: "w:tblpPr",
	attributes: {
		leftFromText: {
			key: "w:leftFromText",
			value: leftFromText === void 0 ? void 0 : twipsMeasureValue(leftFromText)
		},
		rightFromText: {
			key: "w:rightFromText",
			value: rightFromText === void 0 ? void 0 : twipsMeasureValue(rightFromText)
		},
		topFromText: {
			key: "w:topFromText",
			value: topFromText === void 0 ? void 0 : twipsMeasureValue(topFromText)
		},
		bottomFromText: {
			key: "w:bottomFromText",
			value: bottomFromText === void 0 ? void 0 : twipsMeasureValue(bottomFromText)
		},
		absoluteHorizontalPosition: {
			key: "w:tblpX",
			value: absoluteHorizontalPosition === void 0 ? void 0 : signedTwipsMeasureValue(absoluteHorizontalPosition)
		},
		absoluteVerticalPosition: {
			key: "w:tblpY",
			value: absoluteVerticalPosition === void 0 ? void 0 : signedTwipsMeasureValue(absoluteVerticalPosition)
		},
		horizontalAnchor: {
			key: "w:horzAnchor",
			value: horizontalAnchor
		},
		relativeHorizontalPosition: {
			key: "w:tblpXSpec",
			value: relativeHorizontalPosition
		},
		relativeVerticalPosition: {
			key: "w:tblpYSpec",
			value: relativeVerticalPosition
		},
		verticalAnchor: {
			key: "w:vertAnchor",
			value: verticalAnchor
		}
	},
	children: overlap ? [createOverlapElement(overlap)] : void 0
});
/**
* Creates table layout settings in a WordprocessingML document.
*
* The tblLayout element specifies the algorithm used to lay out the table.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblLayoutType">
*   <xsd:attribute name="type" type="ST_TblLayoutType"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* createTableLayout(TableLayoutType.FIXED);
* ```
*/
var createTableLayout = (type) => new BuilderElement({
	name: "w:tblLayout",
	attributes: { type: {
		key: "w:type",
		value: type
	} }
});
/**
* Table cell spacing module for WordprocessingML documents.
*
* This module provides cell spacing settings for tables, controlling
* the space between cells in a table.
*
* Reference: http://officeopenxml.com/WPtableCellSpacing.php
*
* @module
*/
/**
* Cell spacing measurement types.
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_TblCellSpacing">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="nil"/>
*     <xsd:enumeration value="dxa"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*/
var CellSpacingType = {
	/** Value is in twentieths of a point */
	DXA: "dxa",
	/** No (empty) value. */
	NIL: "nil"
};
/**
* Creates table cell spacing in a WordprocessingML document.
*
* The tblCellSpacing element specifies the spacing between cells in a table.
*
* Reference: http://officeopenxml.com/WPtableCellSpacing.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblCellSpacing">
*   <xsd:attribute name="w" type="ST_MeasurementOrPercent"/>
*   <xsd:attribute name="type" type="ST_TblCellSpacing"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* createTableCellSpacing({ value: 100, type: CellSpacingType.DXA });
* ```
*/
var createTableCellSpacing = ({ type = CellSpacingType.DXA, value }) => new BuilderElement({
	name: "w:tblCellSpacing",
	attributes: {
		type: {
			key: "w:type",
			value: type
		},
		value: {
			key: "w:w",
			value: measurementOrPercentValue(value)
		}
	}
});
/**
* Table look module for WordprocessingML documents.
*
* Table look specifies conditional formatting settings that determine which
* special formatting is applied to a table. These settings control whether
* special formatting is applied to the first row, last row, first column,
* last column, and whether to display horizontal or vertical banding.
*
* Reference: http://officeopenxml.com/WPtblLook.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblLook">
*   <xsd:attribute name="firstRow" type="s:ST_OnOff"/>
*   <xsd:attribute name="lastRow" type="s:ST_OnOff"/>
*   <xsd:attribute name="firstColumn" type="s:ST_OnOff"/>
*   <xsd:attribute name="lastColumn" type="s:ST_OnOff"/>
*   <xsd:attribute name="noHBand" type="s:ST_OnOff"/>
*   <xsd:attribute name="noVBand" type="s:ST_OnOff"/>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Creates a table look element for conditional formatting settings.
*
* The tblLook element specifies which conditional formatting settings
* are active for a table. These settings work in conjunction with table
* styles to apply special formatting to specific regions of the table.
*
* Reference: http://officeopenxml.com/WPtblLook.php
*
* @example
* ```typescript
* // Table with header row formatting and alternating row colors
* new Table({
*   rows: [...],
*   tableLook: {
*     firstRow: true,
*     noHBand: false,
*     noVBand: true,
*   },
* });
* ```
*/
var createTableLook = ({ firstRow, lastRow, firstColumn, lastColumn, noHBand, noVBand }) => new BuilderElement({
	name: "w:tblLook",
	attributes: {
		firstRow: {
			key: "w:firstRow",
			value: firstRow
		},
		lastRow: {
			key: "w:lastRow",
			value: lastRow
		},
		firstColumn: {
			key: "w:firstColumn",
			value: firstColumn
		},
		lastColumn: {
			key: "w:lastColumn",
			value: lastColumn
		},
		noHBand: {
			key: "w:noHBand",
			value: noHBand
		},
		noVBand: {
			key: "w:noVBand",
			value: noVBand
		}
	}
});
/**
* Table properties module for WordprocessingML documents.
*
* This module provides table-level properties including width, borders,
* layout, alignment, and margins.
*
* Reference: http://officeopenxml.com/WPtableProperties.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblPrBase">
*   <xsd:sequence>
*     <xsd:element name="tblStyle" type="CT_String" minOccurs="0"/>
*     <xsd:element name="tblpPr" type="CT_TblPPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblOverlap" type="CT_TblOverlap" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="bidiVisual" type="CT_OnOff" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblStyleRowBandSize" type="CT_DecimalNumber" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblStyleColBandSize" type="CT_DecimalNumber" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblW" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="jc" type="CT_JcTable" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblCellSpacing" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblInd" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblBorders" type="CT_TblBorders" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="shd" type="CT_Shd" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblLayout" type="CT_TblLayoutType" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblCellMar" type="CT_TblCellMar" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblLook" type="CT_TblLook" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblCaption" type="CT_String" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblDescription" type="CT_String" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
* </xsd:complexType>
*
* <xsd:complexType name="CT_TblPrChange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TrackChange">
*       <xsd:sequence>
*         <xsd:element name="tblPr" type="CT_TblPrBase"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Represents table properties (tblPr) in a WordprocessingML document.
*
* The tblPr element specifies the properties for a table including width,
* alignment, borders, margins, and layout.
*
* Reference: http://officeopenxml.com/WPtableProperties.php
*/
var TableProperties = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:tblPr", options.includeIfEmpty);
		if (options.style) this.root.push(new StringValueElement("w:tblStyle", options.style));
		if (options.float) this.root.push(createTableFloatProperties(options.float));
		if (options.visuallyRightToLeft !== void 0) this.root.push(new OnOffElement("w:bidiVisual", options.visuallyRightToLeft));
		if (options.width) this.root.push(createTableWidthElement("w:tblW", options.width));
		if (options.alignment) this.root.push(createAlignment(options.alignment));
		if (options.indent) this.root.push(createTableWidthElement("w:tblInd", options.indent));
		if (options.borders) this.root.push(new TableBorders(options.borders));
		if (options.shading) this.root.push(createShading(options.shading));
		if (options.layout) this.root.push(createTableLayout(options.layout));
		if (options.cellMargin) {
			const cellMargin = createTableCellMargin(options.cellMargin);
			if (cellMargin) this.root.push(cellMargin);
		}
		if (options.tableLook) this.root.push(createTableLook(options.tableLook));
		if (options.cellSpacing) this.root.push(createTableCellSpacing(options.cellSpacing));
		if (options.revision) this.root.push(new TablePropertiesChange(options.revision));
	}
};
var TablePropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:tblPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.root.push(new TableProperties(_objectSpread2(_objectSpread2({}, options), {}, { includeIfEmpty: true })));
	}
};
/**
* Table module for WordprocessingML documents.
*
* Reference: http://officeopenxml.com/WPtableGrid.php
*
* @module
*/
/**
* Represents a table in a WordprocessingML document.
*
* A table is a set of paragraphs (and other block-level content) arranged in rows and columns.
* Tables are used to organize content into a grid structure.
*
* Reference: http://officeopenxml.com/WPtable.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Tbl">
*   <xsd:sequence>
*     <xsd:group ref="EG_RangeMarkupElements" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="tblPr" type="CT_TblPr"/>
*     <xsd:element name="tblGrid" type="CT_TblGrid"/>
*     <xsd:group ref="EG_ContentRowContent" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Table({
*   rows: [
*     new TableRow({
*       children: [
*         new TableCell({ children: [new Paragraph("Cell 1")] }),
*         new TableCell({ children: [new Paragraph("Cell 2")] }),
*       ],
*     }),
*   ],
* });
* ```
*/
var Table = class extends FileChild {
	constructor({ rows, width, columnWidths = Array(Math.max(...rows.map((row) => row.CellCount))).fill(100), columnWidthsRevision, margins, indent, float, layout, style, borders, alignment, visuallyRightToLeft, tableLook, cellSpacing, revision }) {
		super("w:tbl");
		this.root.push(new TableProperties({
			borders: borders !== null && borders !== void 0 ? borders : {},
			width: width !== null && width !== void 0 ? width : { size: 100 },
			indent,
			float,
			layout,
			style,
			alignment,
			cellMargin: margins,
			visuallyRightToLeft,
			tableLook,
			cellSpacing,
			revision
		}));
		this.root.push(new TableGrid(columnWidths, columnWidthsRevision));
		for (const row of rows) this.root.push(row);
		rows.forEach((row, rowIndex) => {
			if (rowIndex === rows.length - 1) return;
			let columnIndex = 0;
			row.cells.forEach((cell) => {
				if (cell.options.rowSpan && cell.options.rowSpan > 1) {
					const continueCell = new TableCell({
						rowSpan: cell.options.rowSpan - 1,
						columnSpan: cell.options.columnSpan,
						borders: cell.options.borders,
						children: [],
						verticalMerge: VerticalMergeType.CONTINUE
					});
					rows[rowIndex + 1].addCellToColumnIndex(continueCell, columnIndex);
				}
				columnIndex += cell.options.columnSpan || 1;
			});
		});
	}
};
/**
* Creates table row height (trHeight) in a WordprocessingML document.
*
* The trHeight element specifies the height of a table row, along with a rule
* determining how the height should be applied.
*
* Reference: http://officeopenxml.com/WPtableRow.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Height">
*   <xsd:attribute name="val" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="hRule" type="ST_HeightRule"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* createTableRowHeight(1000, HeightRule.EXACT);
* ```
*/
var createTableRowHeight = (value, rule) => new BuilderElement({
	name: "w:trHeight",
	attributes: {
		value: {
			key: "w:val",
			value: twipsMeasureValue(value)
		},
		rule: {
			key: "w:hRule",
			value: rule
		}
	}
});
/**
* Table row properties module for WordprocessingML documents.
*
* This module provides row-level properties including height and header row settings.
*
* Reference: http://officeopenxml.com/WPtableRowProperties.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TrPrBase">
*   <xsd:choice maxOccurs="unbounded">
*     <xsd:element name="cnfStyle" type="CT_Cnf" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="divId" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="gridBefore" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="gridAfter" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="wBefore" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="wAfter" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="cantSplit" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="trHeight" type="CT_Height" minOccurs="0"/>
*     <xsd:element name="tblHeader" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="tblCellSpacing" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="jc" type="CT_JcTable" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="hidden" type="CT_OnOff" minOccurs="0"/>
*   </xsd:choice>
* </xsd:complexType>
* <xsd:complexType name="CT_TrPr">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TrPrBase">
*       <xsd:sequence>
*         <xsd:element name="ins" type="CT_TrackChange" minOccurs="0"/>
*         <xsd:element name="del" type="CT_TrackChange" minOccurs="0"/>
*         <xsd:element name="trPrChange" type="CT_TrPrChange" minOccurs="0"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* <xsd:complexType name="CT_TrPrChange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TrackChange">
*       <xsd:sequence>
*         <xsd:element name="trPr" type="CT_TrPrBase" minOccurs="1"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Represents table row properties (trPr) in a WordprocessingML document.
*
* The trPr element specifies properties for a table row including height,
* whether it can split across pages, and whether it's a header row.
*
* Reference: http://officeopenxml.com/WPtableRowProperties.php
*
* @example
* ```typescript
* new TableRowProperties({
*   cantSplit: true,
*   tableHeader: true,
*   height: {
*     value: 1000,
*     rule: HeightRule.EXACT,
*   },
* });
* ```
*/
var TableRowProperties = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:trPr", options.includeIfEmpty);
		if (options.cantSplit !== void 0) this.root.push(new OnOffElement("w:cantSplit", options.cantSplit));
		if (options.tableHeader !== void 0) this.root.push(new OnOffElement("w:tblHeader", options.tableHeader));
		if (options.height) this.root.push(createTableRowHeight(options.height.value, options.height.rule));
		if (options.cellSpacing) this.root.push(createTableCellSpacing(options.cellSpacing));
		if (options.insertion) this.root.push(new InsertedTableRow(options.insertion));
		if (options.deletion) this.root.push(new DeletedTableRow(options.deletion));
		if (options.revision) this.root.push(new TableRowPropertiesChange(options.revision));
	}
};
var TableRowPropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:trPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.root.push(new TableRowProperties(_objectSpread2(_objectSpread2({}, options), {}, { includeIfEmpty: true })));
	}
};
/**
* Table row module for WordprocessingML documents.
*
* Reference: http://officeopenxml.com/WPtableRow.php
*
* @module
*/
/**
* Represents a table row in a WordprocessingML document.
*
* A table row is a single row of cells within a table. Each row contains
* one or more table cells that hold the actual content.
*
* Reference: http://officeopenxml.com/WPtableRow.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Row">
*   <xsd:sequence>
*     <xsd:element name="tblPrEx" type="CT_TblPrEx" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="trPr" type="CT_TrPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:group ref="EG_ContentCellContent" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="rsidRPr" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidR" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidDel" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidTr" type="ST_LongHexNumber"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new TableRow({
*   children: [
*     new TableCell({ children: [new Paragraph("Cell 1")] }),
*     new TableCell({ children: [new Paragraph("Cell 2")] }),
*   ],
* });
* ```
*/
var TableRow = class extends XmlComponent {
	constructor(options) {
		super("w:tr");
		_defineProperty(this, "options", void 0);
		this.options = options;
		this.root.push(new TableRowProperties(options));
		for (const child of options.children) this.root.push(child);
	}
	get CellCount() {
		return this.options.children.length;
	}
	get cells() {
		return this.root.filter((xmlComponent) => xmlComponent instanceof TableCell);
	}
	addCellToIndex(cell, index) {
		this.root.splice(index + 1, 0, cell);
	}
	addCellToColumnIndex(cell, columnIndex) {
		const rootIndex = this.columnIndexToRootIndex(columnIndex, true);
		this.addCellToIndex(cell, rootIndex - 1);
	}
	rootIndexToColumnIndex(rootIndex) {
		if (rootIndex < 1 || rootIndex >= this.root.length) throw new Error(`cell 'rootIndex' should between 1 to ${this.root.length - 1}`);
		let colIdx = 0;
		for (let rootIdx = 1; rootIdx < rootIndex; rootIdx++) {
			const cell = this.root[rootIdx];
			colIdx += cell.options.columnSpan || 1;
		}
		return colIdx;
	}
	columnIndexToRootIndex(columnIndex, allowEndNewCell = false) {
		if (columnIndex < 0) throw new Error(`cell 'columnIndex' should not less than zero`);
		let colIdx = 0;
		let rootIdx = 1;
		while (colIdx <= columnIndex) {
			if (rootIdx >= this.root.length) if (allowEndNewCell) return this.root.length;
			else throw new Error(`cell 'columnIndex' should not great than ${colIdx - 1}`);
			const cell = this.root[rootIdx];
			rootIdx += 1;
			colIdx += cell && cell.options.columnSpan || 1;
		}
		return rootIdx - 1;
	}
};
/**
* App Properties Attributes module for WordprocessingML documents.
*
* Provides namespace attributes for extended document properties.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesExtended.xsd
*
* @module
*/
/**
* XML namespace attributes for the app properties element.
*
* @property xmlns - Main namespace for extended properties
* @property vt - Namespace for variant types
*/
var AppPropertiesAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			xmlns: "xmlns",
			vt: "xmlns:vt"
		});
	}
};
/**
* App Properties module for WordprocessingML documents.
*
* Provides support for extended document properties specific to Office applications.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesExtended.xsd
*
* @module
*/
/**
* Represents the extended application properties of a WordprocessingML document.
*
* Extended properties contain application-specific metadata such as total editing time,
* word count, character count, and other Office-specific information.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesExtended.xsd
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Properties">
*   <xsd:sequence>
*     <xsd:element name="Template" type="xsd:string" minOccurs="0"/>
*     <xsd:element name="Manager" type="xsd:string" minOccurs="0"/>
*     <xsd:element name="Company" type="xsd:string" minOccurs="0"/>
*     <xsd:element name="Pages" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="Words" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="Characters" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="PresentationFormat" type="xsd:string" minOccurs="0"/>
*     <xsd:element name="Lines" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="Paragraphs" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="CharactersWithSpaces" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="Application" type="xsd:string" minOccurs="0"/>
*     <xsd:element name="DocSecurity" type="xsd:int" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const appProps = new AppProperties();
* ```
*/
var AppProperties = class extends XmlComponent {
	constructor() {
		super("Properties");
		this.root.push(new AppPropertiesAttributes({
			xmlns: "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties",
			vt: "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"
		}));
	}
};
/**
* Attributes for the Types (Content Types) element.
*
* Defines the XML namespace for the content types part.
*
* @example
* ```typescript
* new ContentTypeAttributes({
*   xmlns: "http://schemas.openxmlformats.org/package/2006/content-types"
* });
* ```
*/
var ContentTypeAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { xmlns: "xmlns" });
	}
};
/**
* Creates a default content type mapping by file extension.
*
* Default elements map file extensions (e.g., "png", "xml") to MIME content types.
* This tells the package reader what type of content to expect for files with
* a given extension.
*
* @example
* ```typescript
* // Map .png files to image/png content type
* createDefault("image/png", "png");
*
* // Map .xml files to application/xml content type
* createDefault("application/xml", "xml");
* ```
*/
var createDefault = (contentType, extension) => new BuilderElement({
	name: "Default",
	attributes: {
		contentType: {
			key: "ContentType",
			value: contentType
		},
		extension: {
			key: "Extension",
			value: extension
		}
	}
});
/**
* Creates a content type override for a specific part.
*
* Override elements map specific part paths to MIME content types,
* taking precedence over default extension mappings. This is used for
* important parts like document.xml, styles.xml, etc.
*
* @example
* ```typescript
* // Override content type for the main document part
* createOverride(
*   "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml",
*   "/word/document.xml"
* );
*
* // Override for a header part
* createOverride(
*   "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml",
*   "/word/header1.xml"
* );
* ```
*/
var createOverride = (contentType, partName) => new BuilderElement({
	name: "Override",
	attributes: {
		contentType: {
			key: "ContentType",
			value: contentType
		},
		partName: {
			key: "PartName",
			value: partName
		}
	}
});
/**
* Content Types module for Open Packaging Conventions.
*
* This module provides the [Content_Types].xml part which defines
* the content types for all parts in the DOCX package.
*
* Reference: http://officeopenxml.com/anatomyofOOXML.php
*
* @module
*/
/**
* Represents the Content Types part of an OPC package.
*
* ContentTypes maps file extensions and specific paths to their
* MIME content types, enabling applications to process each part correctly.
*
* Reference: http://officeopenxml.com/anatomyofOOXML.php
*
* @example
* ```typescript
* const contentTypes = new ContentTypes();
* contentTypes.addHeader(1); // Add header1.xml
* contentTypes.addFooter(1); // Add footer1.xml
* ```
*/
var ContentTypes = class extends XmlComponent {
	constructor() {
		super("Types");
		this.root.push(new ContentTypeAttributes({ xmlns: "http://schemas.openxmlformats.org/package/2006/content-types" }));
		this.root.push(createDefault("image/png", "png"));
		this.root.push(createDefault("image/jpeg", "jpeg"));
		this.root.push(createDefault("image/jpeg", "jpg"));
		this.root.push(createDefault("image/bmp", "bmp"));
		this.root.push(createDefault("image/gif", "gif"));
		this.root.push(createDefault("image/svg+xml", "svg"));
		this.root.push(createDefault("application/vnd.openxmlformats-package.relationships+xml", "rels"));
		this.root.push(createDefault("application/xml", "xml"));
		this.root.push(createDefault("application/vnd.openxmlformats-officedocument.obfuscatedFont", "odttf"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml", "/word/document.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml", "/word/styles.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-package.core-properties+xml", "/docProps/core.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.custom-properties+xml", "/docProps/custom.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.extended-properties+xml", "/docProps/app.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml", "/word/numbering.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml", "/word/footnotes.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml", "/word/endnotes.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml", "/word/settings.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml", "/word/comments.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.fontTable+xml", "/word/fontTable.xml"));
	}
	/**
	* Registers the commentsExtended part in the content types.
	*/
	addCommentsExtended() {
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.commentsExtended+xml", "/word/commentsExtended.xml"));
	}
	/**
	* Registers a footer part in the content types.
	*
	* @param index - Footer index number (e.g., 1 for footer1.xml)
	*/
	addFooter(index) {
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml", `/word/footer${index}.xml`));
	}
	/**
	* Registers a header part in the content types.
	*
	* @param index - Header index number (e.g., 1 for header1.xml)
	*/
	addHeader(index) {
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml", `/word/header${index}.xml`));
	}
};
/**
* Document attributes module for WordprocessingML documents.
*
* This module defines the XML namespace declarations used in OOXML documents.
* These namespaces are required for proper document parsing and generation.
*
* Reference: http://officeopenxml.com/anatomyofOOXML.php
*
* @module
*/
/**
* XML namespace URIs used in WordprocessingML documents.
*
* These namespaces define the various XML schemas that can be referenced
* in a document, including WordprocessingML, DrawingML, VML, and others.
*/
var DocumentAttributeNamespaces = {
	wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
	mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
	o: "urn:schemas-microsoft-com:office:office",
	r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
	m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
	v: "urn:schemas-microsoft-com:vml",
	wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
	wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
	w10: "urn:schemas-microsoft-com:office:word",
	w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
	w14: "http://schemas.microsoft.com/office/word/2010/wordml",
	w15: "http://schemas.microsoft.com/office/word/2012/wordml",
	wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
	wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
	wne: "http://schemas.microsoft.com/office/word/2006/wordml",
	wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
	cp: "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
	dc: "http://purl.org/dc/elements/1.1/",
	dcterms: "http://purl.org/dc/terms/",
	dcmitype: "http://purl.org/dc/dcmitype/",
	xsi: "http://www.w3.org/2001/XMLSchema-instance",
	cx: "http://schemas.microsoft.com/office/drawing/2014/chartex",
	cx1: "http://schemas.microsoft.com/office/drawing/2015/9/8/chartex",
	cx2: "http://schemas.microsoft.com/office/drawing/2015/10/21/chartex",
	cx3: "http://schemas.microsoft.com/office/drawing/2016/5/9/chartex",
	cx4: "http://schemas.microsoft.com/office/drawing/2016/5/10/chartex",
	cx5: "http://schemas.microsoft.com/office/drawing/2016/5/11/chartex",
	cx6: "http://schemas.microsoft.com/office/drawing/2016/5/12/chartex",
	cx7: "http://schemas.microsoft.com/office/drawing/2016/5/13/chartex",
	cx8: "http://schemas.microsoft.com/office/drawing/2016/5/14/chartex",
	aink: "http://schemas.microsoft.com/office/drawing/2016/ink",
	am3d: "http://schemas.microsoft.com/office/drawing/2017/model3d",
	w16cex: "http://schemas.microsoft.com/office/word/2018/wordml/cex",
	w16cid: "http://schemas.microsoft.com/office/word/2016/wordml/cid",
	w16: "http://schemas.microsoft.com/office/word/2018/wordml",
	w16sdtdh: "http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash",
	w16se: "http://schemas.microsoft.com/office/word/2015/wordml/symex"
};
/**
* Represents XML namespace attributes for a WordprocessingML document.
*
* This class generates the xmlns declarations required at the root element
* of document.xml and other document parts.
*
* @example
* ```typescript
* new DocumentAttributes(['w', 'r', 'wp'], 'w14 w15');
* // Generates: xmlns:w="..." xmlns:r="..." xmlns:wp="..." mc:Ignorable="w14 w15"
* ```
*
* @internal
*/
var DocumentAttributes = class extends XmlAttributeComponent {
	constructor(ns, Ignorable) {
		super(_objectSpread2({ Ignorable }, Object.fromEntries(ns.map((n) => [n, DocumentAttributeNamespaces[n]]))));
		_defineProperty(this, "xmlKeys", _objectSpread2({ Ignorable: "mc:Ignorable" }, Object.fromEntries(Object.keys(DocumentAttributeNamespaces).map((key) => [key, `xmlns:${key}`]))));
	}
};
/**
* Represents the core properties of a WordprocessingML document.
*
* Core properties contain document metadata based on Dublin Core elements,
* including title, subject, creator, keywords, description, and modification tracking.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCore.xsd
*
* ## XSD Schema
* ```xml
* <xs:complexType name="CT_CoreProperties">
*   <xs:all>
*     <xs:element name="category" minOccurs="0" maxOccurs="1" type="xs:string"/>
*     <xs:element name="contentStatus" minOccurs="0" maxOccurs="1" type="xs:string"/>
*     <xs:element ref="dcterms:created" minOccurs="0" maxOccurs="1"/>
*     <xs:element ref="dc:creator" minOccurs="0" maxOccurs="1"/>
*     <xs:element ref="dc:description" minOccurs="0" maxOccurs="1"/>
*     <xs:element ref="dc:identifier" minOccurs="0" maxOccurs="1"/>
*     <xs:element name="keywords" minOccurs="0" maxOccurs="1" type="CT_Keywords"/>
*     <xs:element ref="dc:language" minOccurs="0" maxOccurs="1"/>
*     <xs:element name="lastModifiedBy" minOccurs="0" maxOccurs="1" type="xs:string"/>
*     <xs:element name="lastPrinted" minOccurs="0" maxOccurs="1" type="xs:dateTime"/>
*     <xs:element ref="dcterms:modified" minOccurs="0" maxOccurs="1"/>
*     <xs:element name="revision" minOccurs="0" maxOccurs="1" type="xs:string"/>
*     <xs:element ref="dc:subject" minOccurs="0" maxOccurs="1"/>
*     <xs:element ref="dc:title" minOccurs="0" maxOccurs="1"/>
*     <xs:element name="version" minOccurs="0" maxOccurs="1" type="xs:string"/>
*   </xs:all>
* </xs:complexType>
* ```
*
* @example
* ```typescript
* const coreProps = new CoreProperties({
*   title: "My Document",
*   subject: "Sample Document",
*   creator: "John Doe",
*   keywords: "docx, example",
*   description: "A sample document",
*   lastModifiedBy: "Jane Doe",
*   revision: 1
* });
* ```
*/
var CoreProperties = class extends XmlComponent {
	constructor(options) {
		super("cp:coreProperties");
		this.root.push(new DocumentAttributes([
			"cp",
			"dc",
			"dcterms",
			"dcmitype",
			"xsi"
		]));
		if (options.title) this.root.push(new StringContainer("dc:title", options.title));
		if (options.subject) this.root.push(new StringContainer("dc:subject", options.subject));
		if (options.creator) this.root.push(new StringContainer("dc:creator", options.creator));
		if (options.keywords) this.root.push(new StringContainer("cp:keywords", options.keywords));
		if (options.description) this.root.push(new StringContainer("dc:description", options.description));
		if (options.lastModifiedBy) this.root.push(new StringContainer("cp:lastModifiedBy", options.lastModifiedBy));
		if (options.revision) this.root.push(new StringContainer("cp:revision", String(options.revision)));
		this.root.push(new TimestampElement("dcterms:created"));
		this.root.push(new TimestampElement("dcterms:modified"));
	}
};
/**
* Attributes for timestamp elements in core properties.
* Specifies the W3C DateTime Format type for timestamps.
*/
var TimestampElementProperties = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { type: "xsi:type" });
	}
};
/**
* Represents a timestamp element (created or modified date).
* Uses W3C DateTime Format (dcterms:W3CDTF) for dates.
*/
var TimestampElement = class extends XmlComponent {
	constructor(name) {
		super(name);
		this.root.push(new TimestampElementProperties({ type: "dcterms:W3CDTF" }));
		this.root.push(dateTimeValue(/* @__PURE__ */ new Date()));
	}
};
/**
* Custom Properties Attributes module for WordprocessingML documents.
*
* Provides namespace attributes for custom document properties.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* @module
*/
/**
* XML namespace attributes for the custom properties element.
*
* @property xmlns - Main namespace for custom properties
* @property vt - Namespace for variant types
*/
var CustomPropertiesAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			xmlns: "xmlns",
			vt: "xmlns:vt"
		});
	}
};
/**
* Custom Property Attributes module for WordprocessingML documents.
*
* Provides attributes for individual custom document properties.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* @module
*/
/**
* XML attributes for a custom property element.
*
* @property formatId - Format identifier (GUID)
* @property pid - Property identifier (unique ID)
* @property name - Property name
*/
var CustomPropertyAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			formatId: "fmtid",
			pid: "pid",
			name: "name"
		});
	}
};
/**
* Custom Property module for WordprocessingML documents.
*
* Provides support for individual custom document properties.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* @module
*/
/**
* Represents a single custom document property.
*
* Custom properties allow storing arbitrary key-value pairs in the document metadata.
* Each property has a unique name and a string value.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Property">
*   <xsd:sequence>
*     <xsd:element name="lpwstr" type="xsd:string" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="fmtid" type="ST_Guid" use="required"/>
*   <xsd:attribute name="pid" type="xsd:int" use="required"/>
*   <xsd:attribute name="name" type="xsd:string"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const customProp = new CustomProperty(2, {
*   name: "Department",
*   value: "Engineering"
* });
* ```
*/
var CustomProperty = class extends XmlComponent {
	constructor(id, properties) {
		super("property");
		this.root.push(new CustomPropertyAttributes({
			formatId: "{D5CDD505-2E9C-101B-9397-08002B2CF9AE}",
			pid: id.toString(),
			name: properties.name
		}));
		this.root.push(new CustomPropertyValue(properties.value));
	}
};
/**
* Represents the value of a custom property.
* Uses the variant type "long pointer to wide string" for string values.
*/
var CustomPropertyValue = class extends XmlComponent {
	constructor(value) {
		super("vt:lpwstr");
		this.root.push(value);
	}
};
/**
* Custom Properties module for WordprocessingML documents.
*
* Provides support for managing custom document properties collection.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* @module
*/
/**
* Represents the collection of custom document properties.
*
* Custom properties allow storing arbitrary metadata as name-value pairs.
* Each property is assigned a unique ID starting from 2 (per Office specification).
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_CustomProperties">
*   <xsd:sequence>
*     <xsd:element name="property" type="CT_Property" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const customProps = new CustomProperties([
*   { name: "Department", value: "Engineering" },
*   { name: "Project", value: "Alpha" }
* ]);
* ```
*/
var CustomProperties = class extends XmlComponent {
	constructor(properties) {
		super("Properties");
		_defineProperty(this, "nextId", void 0);
		_defineProperty(this, "properties", []);
		this.root.push(new CustomPropertiesAttributes({
			xmlns: "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties",
			vt: "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"
		}));
		this.nextId = 2;
		for (const property of properties) this.addCustomProperty(property);
	}
	prepForXml(context) {
		this.properties.forEach((x) => this.root.push(x));
		return super.prepForXml(context);
	}
	addCustomProperty(property) {
		this.properties.push(new CustomProperty(this.nextId++, property));
	}
};
/**
* Columns module for WordprocessingML section properties.
*
* Defines multi-column layouts within document sections.
*
* Reference: http://officeopenxml.com/WPsectionPr.php
*
* @module
*/
/**
* Creates column layout settings (cols) for a document section.
*
* This element defines the multi-column layout properties for a section,
* including column count, spacing, and whether columns have equal or custom widths.
*
* Reference: http://officeopenxml.com/WPsectionPr.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Columns">
*   <xsd:sequence minOccurs="0">
*     <xsd:element name="col" type="CT_Column" maxOccurs="45"/>
*   </xsd:sequence>
*   <xsd:attribute name="equalWidth" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="space" type="s:ST_TwipsMeasure" use="optional" default="720"/>
*   <xsd:attribute name="num" type="ST_DecimalNumber" use="optional" default="1"/>
*   <xsd:attribute name="sep" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Two equal-width columns with separator
* createColumns({
*   count: 2,
*   space: 720,
*   separate: true,
*   equalWidth: true
* });
*
* // Custom column widths
* createColumns({
*   equalWidth: false,
*   children: [
*     { width: 3000, space: 720 },
*     { width: 4000, space: 0 }
*   ]
* });
* ```
*/
var createColumns = ({ space, count, separate, equalWidth, children }) => new BuilderElement({
	name: "w:cols",
	attributes: {
		space: {
			key: "w:space",
			value: space === void 0 ? void 0 : twipsMeasureValue(space)
		},
		count: {
			key: "w:num",
			value: count === void 0 ? void 0 : decimalNumber(count)
		},
		separate: {
			key: "w:sep",
			value: separate
		},
		equalWidth: {
			key: "w:equalWidth",
			value: equalWidth
		}
	},
	children: !equalWidth && children ? children : void 0
});
/**
* This element specifies the settings for the document grid, which enables precise layout of full-width East Asian language characters within a document by specifying the desired number of characters per line and lines per page for all East Asian text content in this section.
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_docGrid_topic_ID0EHU5S.html
*
* ```xml
* <xsd:complexType name="CT_DocGrid">
*   <xsd:attribute name="type" type="ST_DocGrid"/>
*   <xsd:attribute name="linePitch" type="ST_DecimalNumber"/>
*   <xsd:attribute name="charSpace" type="ST_DecimalNumber"/>
* </xsd:complexType>
* ```
* @returns
*/
var createDocumentGrid = ({ type, linePitch, charSpace }) => new BuilderElement({
	name: "w:docGrid",
	attributes: {
		type: {
			key: "w:type",
			value: type
		},
		linePitch: {
			key: "w:linePitch",
			value: decimalNumber(linePitch)
		},
		charSpace: {
			key: "w:charSpace",
			value: charSpace ? decimalNumber(charSpace) : void 0
		}
	}
});
/**
* This simple type specifies the possible types of headers and footers which may be specified for a given header or footer reference in a document. This value determines the page(s) on which the current header or footer shall be displayed.
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_ST_HdrFtr_topic_ID0E2UW2.html
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_HdrFtr">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="even"/>
*     <xsd:enumeration value="default"/>
*     <xsd:enumeration value="first"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*/
var HeaderFooterReferenceType = {
	/** Specifies that this header or footer shall appear on every page in this section which is not overridden with a specific `even` or `first` page header/footer. In a section with all three types specified, this type shall be used on all odd numbered pages (counting from the `first` page in the section, not the section numbering). */
	DEFAULT: "default",
	/** Specifies that this header or footer shall appear on the first page in this section. The appearance of this header or footer is contingent on the setting of the `titlePg` element (§2.10.6). */
	FIRST: "first",
	/** Specifies that this header or footer shall appear on all even numbered pages in this section (counting from the first page in the section, not the section numbering). The appearance of this header or footer is contingent on the setting of the `evenAndOddHeaders` element (§2.10.1). */
	EVEN: "even"
};
var HeaderFooterType = {
	HEADER: "w:headerReference",
	FOOTER: "w:footerReference"
};
var createHeaderFooterReference = (type, options) => new BuilderElement({
	name: type,
	attributes: {
		type: {
			key: "w:type",
			value: options.type || HeaderFooterReferenceType.DEFAULT
		},
		id: {
			key: "r:id",
			value: `rId${options.id}`
		}
	}
});
/**
* This element specifies the settings for line numbering to be displayed before each column of text in this section in the document.
*
* References:
* - https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_lnNumType_topic_ID0EVRAT.html
* - http://officeopenxml.com/WPsectionLineNumbering.php
*
* ## XSD Schema
*
* ```xml
* <xsd:complexType name="CT_LineNumber">
*   <xsd:attribute name="countBy" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="start" type="ST_DecimalNumber" use="optional" default="1"/>
*   <xsd:attribute name="distance" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="restart" type="ST_LineNumberRestart" use="optional" default="newPage"/>
* </xsd:complexType>
* ```
*/
var createLineNumberType = ({ countBy, start, restart, distance }) => new BuilderElement({
	name: "w:lnNumType",
	attributes: {
		countBy: {
			key: "w:countBy",
			value: countBy === void 0 ? void 0 : decimalNumber(countBy)
		},
		start: {
			key: "w:start",
			value: start === void 0 ? void 0 : decimalNumber(start)
		},
		restart: {
			key: "w:restart",
			value: restart
		},
		distance: {
			key: "w:distance",
			value: distance === void 0 ? void 0 : twipsMeasureValue(distance)
		}
	}
});
var PageBordersAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			display: "w:display",
			offsetFrom: "w:offsetFrom",
			zOrder: "w:zOrder"
		});
	}
};
/**
* Represents page borders (pgBorders) for a document section.
*
* This element specifies the borders to display around pages in a section,
* including which pages display the borders and how they are positioned.
*
* Reference: http://officeopenxml.com/WPsectionBorders.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PageBorders">
*   <xsd:sequence>
*     <xsd:element name="top" type="CT_TopPageBorder" minOccurs="0"/>
*     <xsd:element name="left" type="CT_PageBorder" minOccurs="0"/>
*     <xsd:element name="bottom" type="CT_BottomPageBorder" minOccurs="0"/>
*     <xsd:element name="right" type="CT_PageBorder" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="zOrder" type="ST_PageBorderZOrder" use="optional" default="front"/>
*   <xsd:attribute name="display" type="ST_PageBorderDisplay" use="optional"/>
*   <xsd:attribute name="offsetFrom" type="ST_PageBorderOffset" use="optional" default="text"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Add page borders to all pages
* new PageBorders({
*   pageBorders: {
*     display: PageBorderDisplay.ALL_PAGES,
*     offsetFrom: PageBorderOffsetFrom.PAGE,
*     zOrder: PageBorderZOrder.FRONT
*   },
*   pageBorderTop: { style: BorderStyle.SINGLE, size: 24, color: "000000" },
*   pageBorderBottom: { style: BorderStyle.SINGLE, size: 24, color: "000000" }
* });
* ```
*/
var PageBorders = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:pgBorders");
		if (!options) return this;
		if (options.pageBorders) this.root.push(new PageBordersAttributes({
			display: options.pageBorders.display,
			offsetFrom: options.pageBorders.offsetFrom,
			zOrder: options.pageBorders.zOrder
		}));
		else this.root.push(new PageBordersAttributes({}));
		if (options.pageBorderTop) this.root.push(createBorderElement("w:top", options.pageBorderTop));
		if (options.pageBorderLeft) this.root.push(createBorderElement("w:left", options.pageBorderLeft));
		if (options.pageBorderBottom) this.root.push(createBorderElement("w:bottom", options.pageBorderBottom));
		if (options.pageBorderRight) this.root.push(createBorderElement("w:right", options.pageBorderRight));
	}
};
/**
* Page margin module for WordprocessingML section properties.
*
* Defines page margins for document sections.
*
* Reference: http://officeopenxml.com/WPsectionPr.php
*
* @module
*/
/**
* Creates page margins (pgMar) for a document section.
*
* This element specifies the page margins for all pages in a section,
* including top, bottom, left, right, header, footer, and gutter margins.
*
* Reference: http://officeopenxml.com/WPsectionPr.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PageMar">
*   <xsd:attribute name="top" type="ST_SignedTwipsMeasure" use="required"/>
*   <xsd:attribute name="right" type="s:ST_TwipsMeasure" use="required"/>
*   <xsd:attribute name="bottom" type="ST_SignedTwipsMeasure" use="required"/>
*   <xsd:attribute name="left" type="s:ST_TwipsMeasure" use="required"/>
*   <xsd:attribute name="header" type="s:ST_TwipsMeasure" use="required"/>
*   <xsd:attribute name="footer" type="s:ST_TwipsMeasure" use="required"/>
*   <xsd:attribute name="gutter" type="s:ST_TwipsMeasure" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create page margins with 1 inch margins (1440 twips = 1 inch)
* createPageMargin(1440, 1440, 1440, 1440, 720, 720, 0);
* ```
*/
var createPageMargin = (top, right, bottom, left, header, footer, gutter) => new BuilderElement({
	name: "w:pgMar",
	attributes: {
		top: {
			key: "w:top",
			value: signedTwipsMeasureValue(top)
		},
		right: {
			key: "w:right",
			value: twipsMeasureValue(right)
		},
		bottom: {
			key: "w:bottom",
			value: signedTwipsMeasureValue(bottom)
		},
		left: {
			key: "w:left",
			value: twipsMeasureValue(left)
		},
		header: {
			key: "w:header",
			value: twipsMeasureValue(header)
		},
		footer: {
			key: "w:footer",
			value: twipsMeasureValue(footer)
		},
		gutter: {
			key: "w:gutter",
			value: twipsMeasureValue(gutter)
		}
	}
});
/**
* Creates page numbering settings (pgNumType) for a document section.
*
* This element specifies the page numbering format and starting value
* for all pages in a section.
*
* Reference: http://officeopenxml.com/WPSectionPgNumType.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PageNumber">
*   <xsd:attribute name="fmt" type="ST_NumberFormat" use="optional" default="decimal"/>
*   <xsd:attribute name="start" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="chapStyle" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="chapSep" type="ST_ChapterSep" use="optional" default="hyphen"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Start page numbering at 5 with lowercase roman numerals
* createPageNumberType({
*   start: 5,
*   formatType: NumberFormat.LOWER_ROMAN
* });
* ```
*/
var createPageNumberType = ({ start, formatType, separator }) => new BuilderElement({
	name: "w:pgNumType",
	attributes: {
		start: {
			key: "w:start",
			value: start === void 0 ? void 0 : decimalNumber(start)
		},
		formatType: {
			key: "w:fmt",
			value: formatType
		},
		separator: {
			key: "w:chapSep",
			value: separator
		}
	}
});
/**
* This simple type specifies the orientation of all pages in the parent section. This information is used to determine the actual paper size to use when printing the file.
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_ST_PageOrientation_topic_ID0EKBK3.html
*
* ## XSD Schema
*
* ```xml
* <xsd:simpleType name="ST_PageOrientation">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="portrait"/>
*     <xsd:enumeration value="landscape"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var PageOrientation = {
	/**
	* ## Portrait Mode
	*
	* Specifies that pages in this section shall be printed in portrait mode.
	*/
	PORTRAIT: "portrait",
	/**
	* ## Landscape Mode
	*
	* Specifies that pages in this section shall be printed in landscape mode, which prints the page contents with a 90 degree rotation with respect to the normal page orientation.
	*/
	LANDSCAPE: "landscape"
};
/**
* This element specifies the properties (size and orientation) for all pages in the current section.
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_pgSz_topic_ID0ENEDT.html?hl=pgsz%2Cpage%2Csize
*
* ## XSD Schema
*
* ```xml
* <xsd:complexType name="CT_PageSz">
*   <xsd:attribute name="w" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="h" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="orient" type="ST_PageOrientation" use="optional"/>
*   <xsd:attribute name="code" type="ST_DecimalNumber" use="optional"/>
* </xsd:complexType>
* ```
*/
var createPageSize = ({ width, height, orientation, code }) => {
	const widthTwips = twipsMeasureValue(width);
	const heightTwips = twipsMeasureValue(height);
	return new BuilderElement({
		name: "w:pgSz",
		attributes: {
			width: {
				key: "w:w",
				value: orientation === PageOrientation.LANDSCAPE ? heightTwips : widthTwips
			},
			height: {
				key: "w:h",
				value: orientation === PageOrientation.LANDSCAPE ? widthTwips : heightTwips
			},
			orientation: {
				key: "w:orient",
				value: orientation
			},
			code: {
				key: "w:code",
				value: code
			}
		}
	});
};
var PageTextDirectionAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents text direction (textDirection) for pages in a section.
*
* This element specifies the direction and orientation of text flow
* for all pages in a section.
*
* Reference: http://officeopenxml.com/WPsectionPr.php
*
* @example
* ```typescript
* // Horizontal text flow (left-to-right, top-to-bottom)
* new PageTextDirection(PageTextDirectionType.LEFT_TO_RIGHT_TOP_TO_BOTTOM);
*
* // Vertical text flow (top-to-bottom, right-to-left)
* new PageTextDirection(PageTextDirectionType.TOP_TO_BOTTOM_RIGHT_TO_LEFT);
* ```
*/
var PageTextDirection = class extends XmlComponent {
	constructor(value) {
		super("w:textDirection");
		this.root.push(new PageTextDirectionAttributes({ val: value }));
	}
};
/**
* Creates section type (type) for a document section.
*
* This element specifies the type of section break, which determines
* where the new section begins relative to the previous section.
*
* Reference: http://officeopenxml.com/WPsection.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SectType">
*   <xsd:attribute name="val" type="ST_SectionMark"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a continuous section (no page break)
* createSectionType(SectionType.CONTINUOUS);
*
* // Create a section that starts on next odd page
* createSectionType(SectionType.ODD_PAGE);
* ```
*/
var createSectionType = (value) => new BuilderElement({
	name: "w:type",
	attributes: { val: {
		key: "w:val",
		value
	} }
});
/**
* Default margin values for sections (in twips).
*
* Standard margins are 1 inch (1440 twips) on all sides.
* Header/footer margins are 0.5 inches (708 twips) from page edge.
*
* @property TOP - Top margin: 1440 twips (1 inch)
* @property RIGHT - Right margin: 1440 twips (1 inch)
* @property BOTTOM - Bottom margin: 1440 twips (1 inch)
* @property LEFT - Left margin: 1440 twips (1 inch)
* @property HEADER - Header margin: 708 twips (0.5 inches)
* @property FOOTER - Footer margin: 708 twips (0.5 inches)
* @property GUTTER - Gutter margin: 0 twips
*/
var sectionMarginDefaults = {
	/** Top margin: 1440 twips (1 inch) */
	TOP: 1440,
	/** Right margin: 1440 twips (1 inch) */
	RIGHT: 1440,
	/** Bottom margin: 1440 twips (1 inch) */
	BOTTOM: 1440,
	/** Left margin: 1440 twips (1 inch) */
	LEFT: 1440,
	/** Header margin from top: 708 twips (0.5 inches) */
	HEADER: 708,
	/** Footer margin from bottom: 708 twips (0.5 inches) */
	FOOTER: 708,
	/** Gutter margin for binding: 0 twips */
	GUTTER: 0
};
/**
* Default page size values (in twips, A4 portrait).
*
* A4 size is 210mm x 297mm (8.27" x 11.69").
*
* @property WIDTH - Page width: 11906 twips (8.27 inches, 210mm)
* @property HEIGHT - Page height: 16838 twips (11.69 inches, 297mm)
* @property ORIENTATION - Page orientation: portrait
*/
var sectionPageSizeDefaults = {
	/** Page width: 11906 twips (8.27 inches, 210mm) */
	WIDTH: 11906,
	/** Page height: 16838 twips (11.69 inches, 297mm) */
	HEIGHT: 16838,
	/** Page orientation: portrait */
	ORIENTATION: PageOrientation.PORTRAIT
};
/**
* Represents section properties (sectPr) in a WordprocessingML document.
*
* Section properties define the page layout for a section of the document,
* including page size, margins, headers/footers, columns, and page numbering.
* A document can contain multiple sections with different properties.
*
* Reference: http://officeopenxml.com/WPsection.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SectPr">
*   <xsd:sequence>
*     <xsd:group ref="EG_HdrFtrReferences" minOccurs="0" maxOccurs="6"/>
*     <xsd:group ref="EG_SectPrContents" minOccurs="0"/>
*     <xsd:element name="sectPrChange" type="CT_SectPrChange" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attributeGroup ref="AG_SectPrAttributes"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create section with custom page size and margins
* new SectionProperties({
*   page: {
*     size: {
*       width: 12240,
*       height: 15840,
*       orientation: PageOrientation.PORTRAIT
*     },
*     margin: {
*       top: 1440,
*       right: 1440,
*       bottom: 1440,
*       left: 1440
*     },
*     pageNumbers: {
*       start: 1,
*       formatType: NumberFormat.DECIMAL
*     }
*   },
*   column: {
*     count: 2,
*     space: 720
*   }
* });
* ```
*/
var SectionProperties = class extends XmlComponent {
	constructor({ page: { size: { width = sectionPageSizeDefaults.WIDTH, height = sectionPageSizeDefaults.HEIGHT, orientation = sectionPageSizeDefaults.ORIENTATION, code } = {}, margin: { top = sectionMarginDefaults.TOP, right = sectionMarginDefaults.RIGHT, bottom = sectionMarginDefaults.BOTTOM, left = sectionMarginDefaults.LEFT, header = sectionMarginDefaults.HEADER, footer = sectionMarginDefaults.FOOTER, gutter = sectionMarginDefaults.GUTTER } = {}, pageNumbers = {}, borders, textDirection } = {}, grid: { linePitch = 360, charSpace, type: gridType } = {}, headerWrapperGroup = {}, footerWrapperGroup = {}, lineNumbers, titlePage, verticalAlign, column, type, revision } = {}) {
		super("w:sectPr");
		this.addHeaderFooterGroup(HeaderFooterType.HEADER, headerWrapperGroup);
		this.addHeaderFooterGroup(HeaderFooterType.FOOTER, footerWrapperGroup);
		if (type) this.root.push(createSectionType(type));
		this.root.push(createPageSize({
			width,
			height,
			orientation,
			code
		}));
		this.root.push(createPageMargin(top, right, bottom, left, header, footer, gutter));
		if (borders) this.root.push(new PageBorders(borders));
		if (lineNumbers) this.root.push(createLineNumberType(lineNumbers));
		this.root.push(createPageNumberType(pageNumbers));
		if (column) this.root.push(createColumns(column));
		if (verticalAlign) this.root.push(createVerticalAlign(verticalAlign));
		if (titlePage !== void 0) this.root.push(new OnOffElement("w:titlePg", titlePage));
		if (textDirection) this.root.push(new PageTextDirection(textDirection));
		if (revision) this.root.push(new SectionPropertiesChange(revision));
		this.root.push(createDocumentGrid({
			linePitch,
			charSpace,
			type: gridType
		}));
	}
	addHeaderFooterGroup(type, group) {
		if (group.default) this.root.push(createHeaderFooterReference(type, {
			type: HeaderFooterReferenceType.DEFAULT,
			id: group.default.View.ReferenceId
		}));
		if (group.first) this.root.push(createHeaderFooterReference(type, {
			type: HeaderFooterReferenceType.FIRST,
			id: group.first.View.ReferenceId
		}));
		if (group.even) this.root.push(createHeaderFooterReference(type, {
			type: HeaderFooterReferenceType.EVEN,
			id: group.even.View.ReferenceId
		}));
	}
};
var SectionPropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:sectPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.root.push(new SectionProperties(options));
	}
};
/**
* Document body module for WordprocessingML documents.
*
* Reference: http://officeopenxml.com/WPdocument.php
*
* @module
*/
/**
* Represents the document body in a WordprocessingML document.
*
* The body element is the container for all block-level content in the document.
* This includes paragraphs, tables, and section properties that define page layout.
*
* The body supports multiple sections, where each section (except the last one) must
* have its section properties stored in a paragraph's properties at the end of that
* section. The last section's properties are stored as a direct child of the body element.
*
* Reference: http://officeopenxml.com/WPdocument.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Body">
*   <xsd:sequence>
*     <xsd:group ref="EG_BlockLevelElts" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="sectPr" minOccurs="0" maxOccurs="1" type="CT_SectPr"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Body is typically created internally by the Document class
* const doc = new Document({});
* const body = doc.Body;
*
* // Add content to the body via Document.add()
* doc.add(new Paragraph("Content in first section"));
*
* // Add a new section
* body.addSection({
*   page: {
*     size: { width: 12240, height: 15840 },
*   },
* });
*
* // Content after addSection belongs to the new section
* doc.add(new Paragraph("Content in second section"));
* ```
*/
var Body = class extends XmlComponent {
	constructor() {
		super("w:body");
		_defineProperty(this, "sections", []);
	}
	/**
	* Adds new section properties to the document body.
	*
	* Creates a new section by moving the previous section's properties into a paragraph
	* at the end of that section, and then adding the new section as the current section.
	*
	* According to the OOXML specification:
	* - Section properties for all sections except the last must be stored in a paragraph's
	*   properties (pPr/sectPr) at the end of each section
	* - The last section's properties are stored as a direct child of the body element (w:body/w:sectPr)
	*
	* @param options - Section properties configuration (page size, margins, headers, footers, etc.)
	*/
	addSection(options) {
		const currentSection = this.sections.pop();
		this.root.push(this.createSectionParagraph(currentSection));
		this.sections.push(new SectionProperties(options));
	}
	/**
	* Prepares the body element for XML serialization.
	*
	* Ensures that the last section's properties are placed as a direct child of the body
	* element, as required by the OOXML specification.
	*
	* @param context - The XML serialization context
	* @returns The prepared XML object or undefined
	*/
	prepForXml(context) {
		if (this.sections.length === 1) {
			this.root.splice(0, 1);
			this.root.push(this.sections.pop());
		}
		return super.prepForXml(context);
	}
	/**
	* Adds a block-level component to the body.
	*
	* This method is used internally by the Document class to add paragraphs,
	* tables, and other block-level elements to the document body.
	*
	* @param component - The XML component to add (paragraph, table, etc.)
	*/
	push(component) {
		this.root.push(component);
	}
	createSectionParagraph(section) {
		const paragraph = new Paragraph({});
		const properties = new ParagraphProperties({});
		properties.push(section);
		paragraph.addChildElement(properties);
		return paragraph;
	}
};
/**
* Document background module for WordprocessingML documents.
*
* This module provides functionality for setting document background colors
* and theme-based backgrounds.
*
* Reference: http://officeopenxml.com/WPdocument.php
*
* @module
*/
/**
* Attributes for the document background element.
*
* ## XSD Schema (ST_ThemeColor)
* ```xml
* <xsd:simpleType name="ST_ThemeColor">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="dark1"/>
*     <xsd:enumeration value="light1"/>
*     <xsd:enumeration value="dark2"/>
*     <xsd:enumeration value="light2"/>
*     <xsd:enumeration value="accent1"/>
*     <xsd:enumeration value="accent2"/>
*     <xsd:enumeration value="accent3"/>
*     <xsd:enumeration value="accent4"/>
*     <xsd:enumeration value="accent5"/>
*     <xsd:enumeration value="accent6"/>
*     <xsd:enumeration value="hyperlink"/>
*     <xsd:enumeration value="followedHyperlink"/>
*     <xsd:enumeration value="none"/>
*     <xsd:enumeration value="background1"/>
*     <xsd:enumeration value="text1"/>
*     <xsd:enumeration value="background2"/>
*     <xsd:enumeration value="text2"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @internal
*/
var DocumentBackgroundAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			color: "w:color",
			themeColor: "w:themeColor",
			themeShade: "w:themeShade",
			themeTint: "w:themeTint"
		});
	}
};
/**
* Represents a document background in a WordprocessingML document.
*
* The background element specifies the background color or theme color
* for the document.
*
* Reference: http://officeopenxml.com/WPdocument.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Background">
*   <xsd:sequence>
*     <xsd:sequence maxOccurs="unbounded">
*       <xsd:any processContents="lax" namespace="urn:schemas-microsoft-com:vml" minOccurs="0" maxOccurs="unbounded"/>
*       <xsd:any processContents="lax" namespace="urn:schemas-microsoft-com:office:office" minOccurs="0" maxOccurs="unbounded"/>
*     </xsd:sequence>
*     <xsd:element name="drawing" type="CT_Drawing" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="color" type="ST_HexColor" use="optional" default="auto"/>
*   <xsd:attribute name="themeColor" type="ST_ThemeColor" use="optional"/>
*   <xsd:attribute name="themeTint" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="themeShade" type="ST_UcharHexNumber" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new DocumentBackground({ color: "FFFF00" }); // Yellow background
* new DocumentBackground({ themeColor: "accent1" }); // Theme accent color
* ```
*/
var DocumentBackground = class extends XmlComponent {
	constructor(options) {
		super("w:background");
		this.root.push(new DocumentBackgroundAttributes({
			color: options.color === void 0 ? void 0 : hexColorValue(options.color),
			themeColor: options.themeColor,
			themeShade: options.themeShade === void 0 ? void 0 : uCharHexNumber(options.themeShade),
			themeTint: options.themeTint === void 0 ? void 0 : uCharHexNumber(options.themeTint)
		}));
	}
};
/**
* Document module for WordprocessingML documents.
*
* Reference: http://officeopenxml.com/WPdocument.php
*
* @module
*/
/**
* Represents the main document element in a WordprocessingML document.
*
* The document element is the root element of the main document part. It contains
* the body element which holds all the content of the document.
*
* Reference: http://officeopenxml.com/WPdocument.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="document" type="CT_Document"/>
*
* <xsd:complexType name="CT_Document">
*   <xsd:complexContent>
*     <xsd:extension base="CT_DocumentBase">
*       <xsd:sequence>
*         <xsd:element name="body" type="CT_Body" minOccurs="0" maxOccurs="1"/>
*       </xsd:sequence>
*       <xsd:attribute name="conformance" type="s:ST_ConformanceClass"/>
*       <xsd:attribute ref="mc:Ignorable" use="optional" />
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_DocumentBase">
*   <xsd:sequence>
*     <xsd:element name="background" type="CT_Background" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a document with default options
* const doc = new Document({});
*
* // Create a document with background
* const doc = new Document({
*   background: {
*     color: "FF0000",
*   },
* });
*
* // Add content to the document
* doc.add(new Paragraph("Hello World"));
* doc.add(new Table({ rows: [...] }));
* ```
*/
var Document = class extends XmlComponent {
	constructor(options) {
		super("w:document");
		_defineProperty(this, "body", void 0);
		this.root.push(new DocumentAttributes([
			"wpc",
			"mc",
			"o",
			"r",
			"m",
			"v",
			"wp14",
			"wp",
			"w10",
			"w",
			"w14",
			"w15",
			"wpg",
			"wpi",
			"wne",
			"wps",
			"cx",
			"cx1",
			"cx2",
			"cx3",
			"cx4",
			"cx5",
			"cx6",
			"cx7",
			"cx8",
			"aink",
			"am3d",
			"w16cex",
			"w16cid",
			"w16",
			"w16sdtdh",
			"w16se"
		], "w14 w15 wp14"));
		this.body = new Body();
		if (options.background) this.root.push(new DocumentBackground(options.background));
		this.root.push(this.body);
	}
	/**
	* Adds a block-level element to the document body.
	*
	* @param item - The element to add (paragraph, table, table of contents, or hyperlink)
	* @returns The Document instance for method chaining
	*/
	add(item) {
		this.body.push(item);
		return this;
	}
	/**
	* Gets the document body element.
	*
	* @returns The Body instance containing all document content
	*/
	get Body() {
		return this.body;
	}
};
/**
* Document wrapper module for WordprocessingML documents.
*
* This module provides wrappers that combine the main document/header/footer
* views with their associated relationships, enabling proper management of
* document parts and their references.
*
* @module
*/
/**
* Wrapper for the main document body.
*
* DocumentWrapper combines the main Document view with its Relationships,
* managing the primary content of the .docx file along with references to
* images, hyperlinks, and other linked resources.
*
* @example
* ```typescript
* const wrapper = new DocumentWrapper({
*   sections: [{
*     children: [new Paragraph("Hello World")],
*   }],
* });
* ```
*/
var DocumentWrapper = class {
	constructor(options) {
		_defineProperty(this, "document", void 0);
		_defineProperty(this, "relationships", void 0);
		this.document = new Document(options);
		this.relationships = new Relationships();
	}
	get View() {
		return this.document;
	}
	get Relationships() {
		return this.relationships;
	}
};
var EndnotesAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			wpc: "xmlns:wpc",
			mc: "xmlns:mc",
			o: "xmlns:o",
			r: "xmlns:r",
			m: "xmlns:m",
			v: "xmlns:v",
			wp14: "xmlns:wp14",
			wp: "xmlns:wp",
			w10: "xmlns:w10",
			w: "xmlns:w",
			w14: "xmlns:w14",
			w15: "xmlns:w15",
			wpg: "xmlns:wpg",
			wpi: "xmlns:wpi",
			wne: "xmlns:wne",
			wps: "xmlns:wps",
			Ignorable: "mc:Ignorable"
		});
	}
};
var EndnoteAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			type: "w:type",
			id: "w:id"
		});
	}
};
var EndnoteRefRun = class extends Run {
	constructor() {
		super({ style: "EndnoteReference" });
		this.root.push(new EndnoteReference());
	}
};
var EndnoteType = {
	SEPARATOR: "separator",
	CONTINUATION_SEPARATOR: "continuationSeparator"
};
var Endnote = class extends XmlComponent {
	constructor(options) {
		super("w:endnote");
		this.root.push(new EndnoteAttributes({
			type: options.type,
			id: options.id
		}));
		for (let i = 0; i < options.children.length; i++) {
			const child = options.children[i];
			if (i === 0) child.addRunToFront(new EndnoteRefRun());
			this.root.push(child);
		}
	}
};
/**
* Footnote continuation separator module for WordprocessingML documents.
*
* This module provides the continuation separator element that defines
* the line used when footnotes span multiple pages.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents a footnote continuation separator in WordprocessingML.
*
* ContinuationSeperator creates the separator line that appears when
* footnotes continue from a previous page to the current page.
*
* ## XSD Schema
* ```xml
* <xsd:element name="continuationSeparator" type="CT_Empty" minOccurs="0"/>
* ```
*
* @internal
*/
var ContinuationSeperator = class extends XmlComponent {
	constructor() {
		super("w:continuationSeparator");
	}
};
/**
* Footnote continuation separator run module for WordprocessingML documents.
*
* This module provides the run containing the continuation separator element.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents a footnote continuation separator run in WordprocessingML.
*
* ContinuationSeperatorRun creates a run containing the continuation
* separator element that defines the line used when footnotes continue
* from a previous page.
*
* @internal
*/
var ContinuationSeperatorRun = class extends Run {
	constructor() {
		super({});
		this.root.push(new ContinuationSeperator());
	}
};
/**
* Footnote separator module for WordprocessingML documents.
*
* This module provides the separator element that defines the line
* separating body text from footnotes.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents a footnote separator in WordprocessingML.
*
* Seperator creates the separator line that appears between the main
* document text and the footnote area at the bottom of the page.
*
* ## XSD Schema
* ```xml
* <xsd:element name="separator" type="CT_Empty" minOccurs="0"/>
* ```
*
* @internal
*/
var Seperator = class extends XmlComponent {
	constructor() {
		super("w:separator");
	}
};
/**
* Footnote separator run module for WordprocessingML documents.
*
* This module provides the run containing the separator element.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents a footnote separator run in WordprocessingML.
*
* SeperatorRun creates a run containing the separator element that
* defines the horizontal line between body text and footnotes.
*
* @internal
*/
var SeperatorRun = class extends Run {
	constructor() {
		super({});
		this.root.push(new Seperator());
	}
};
var Endnotes = class extends XmlComponent {
	constructor() {
		super("w:endnotes");
		this.root.push(new EndnotesAttributes({
			wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
			o: "urn:schemas-microsoft-com:office:office",
			r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
			v: "urn:schemas-microsoft-com:vml",
			wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			w10: "urn:schemas-microsoft-com:office:word",
			w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			w14: "http://schemas.microsoft.com/office/word/2010/wordml",
			w15: "http://schemas.microsoft.com/office/word/2012/wordml",
			wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			wne: "http://schemas.microsoft.com/office/word/2006/wordml",
			wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
			Ignorable: "w14 w15 wp14"
		}));
		const begin = new Endnote({
			id: -1,
			type: EndnoteType.SEPARATOR,
			children: [new Paragraph({
				spacing: {
					after: 0,
					line: 240,
					lineRule: LineRuleType.AUTO
				},
				children: [new SeperatorRun()]
			})]
		});
		this.root.push(begin);
		const spacing = new Endnote({
			id: 0,
			type: EndnoteType.CONTINUATION_SEPARATOR,
			children: [new Paragraph({
				spacing: {
					after: 0,
					line: 240,
					lineRule: LineRuleType.AUTO
				},
				children: [new ContinuationSeperatorRun()]
			})]
		});
		this.root.push(spacing);
	}
	createEndnote(id, paragraph) {
		const endnote = new Endnote({
			id,
			children: paragraph
		});
		this.root.push(endnote);
	}
};
var EndnotesWrapper = class {
	constructor() {
		_defineProperty(this, "endnotes", void 0);
		_defineProperty(this, "relationships", void 0);
		this.endnotes = new Endnotes();
		this.relationships = new Relationships();
	}
	get View() {
		return this.endnotes;
	}
	get Relationships() {
		return this.relationships;
	}
};
/**
* Component for managing XML namespace attributes on footer elements.
*
* This class handles the serialization of namespace declarations that are required
* for proper XML validation and processing of footer content in WordprocessingML documents.
*
* @example
* ```typescript
* new FooterAttributes({
*   w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
*   r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
* });
* ```
*/
var FooterAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			wpc: "xmlns:wpc",
			mc: "xmlns:mc",
			o: "xmlns:o",
			r: "xmlns:r",
			m: "xmlns:m",
			v: "xmlns:v",
			wp14: "xmlns:wp14",
			wp: "xmlns:wp",
			w10: "xmlns:w10",
			w: "xmlns:w",
			w14: "xmlns:w14",
			w15: "xmlns:w15",
			wpg: "xmlns:wpg",
			wpi: "xmlns:wpi",
			wne: "xmlns:wne",
			wps: "xmlns:wps",
			cp: "xmlns:cp",
			dc: "xmlns:dc",
			dcterms: "xmlns:dcterms",
			dcmitype: "xmlns:dcmitype",
			xsi: "xmlns:xsi",
			type: "xsi:type"
		});
	}
};
/**
* Footer module for WordprocessingML documents.
*
* Footers are repeated at the bottom of each page in a section.
*
* Reference: http://officeopenxml.com/WPfooters.php
*
* @module
*/
/**
* Represents a footer in a WordprocessingML document.
*
* A footer is the portion of the document that appears at the bottom of each page in a section.
* Footers can contain block-level elements such as paragraphs and tables. Each section can
* have up to three different footers: first page, even pages, and odd pages.
*
* Reference: http://officeopenxml.com/WPfooters.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_HdrFtr">
*   <xsd:group ref="EG_BlockLevelElts" minOccurs="1" maxOccurs="unbounded"/>
* </xsd:complexType>
*
* <xsd:element name="ftr" type="CT_HdrFtr"/>
* ```
*
* @example
* ```typescript
* // Create a simple footer with page numbers
* const footer = new Footer(1);
* footer.add(new Paragraph({
*   alignment: AlignmentType.CENTER,
*   children: [new TextRun("Page "), PageNumber.CURRENT]
* }));
*
* // Create a footer with a table
* const footer = new Footer(2);
* footer.add(new Table({
*   rows: [
*     new TableRow({
*       children: [new TableCell({ children: [new Paragraph("Footer Content")] })]
*     })
*   ]
* }));
* ```
*/
var Footer$1 = class extends InitializableXmlComponent {
	constructor(referenceNumber, initContent) {
		super("w:ftr", initContent);
		_defineProperty(this, "refId", void 0);
		this.refId = referenceNumber;
		if (!initContent) this.root.push(new FooterAttributes({
			wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
			o: "urn:schemas-microsoft-com:office:office",
			r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
			v: "urn:schemas-microsoft-com:vml",
			wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			w10: "urn:schemas-microsoft-com:office:word",
			w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			w14: "http://schemas.microsoft.com/office/word/2010/wordml",
			w15: "http://schemas.microsoft.com/office/word/2012/wordml",
			wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			wne: "http://schemas.microsoft.com/office/word/2006/wordml",
			wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape"
		}));
	}
	get ReferenceId() {
		return this.refId;
	}
	add(item) {
		this.root.push(item);
	}
};
/**
* Wrapper for document footers.
*
* FooterWrapper combines a Footer view with its Relationships and Media,
* enabling footers to contain paragraphs, tables, images, and hyperlinks.
* Each section can have multiple footers for different page types.
*
* Reference: http://officeopenxml.com/WPfooter.php
*
* @example
* ```typescript
* const footerWrapper = new FooterWrapper(media, 1);
* footerWrapper.add(new Paragraph("Page Footer"));
* footerWrapper.add(new Table({
*   rows: [new TableRow({ children: [new TableCell({ children: [new Paragraph("Cell")] })] })],
* }));
* ```
*/
var FooterWrapper = class {
	constructor(media, referenceId, initContent) {
		_defineProperty(this, "media", void 0);
		_defineProperty(this, "footer", void 0);
		_defineProperty(this, "relationships", void 0);
		this.media = media;
		this.footer = new Footer$1(referenceId, initContent);
		this.relationships = new Relationships();
	}
	add(item) {
		this.footer.add(item);
	}
	addChildElement(childElement) {
		this.footer.addChildElement(childElement);
	}
	get View() {
		return this.footer;
	}
	get Relationships() {
		return this.relationships;
	}
	get Media() {
		return this.media;
	}
};
/**
* Footnote attributes module for WordprocessingML documents.
*
* This module defines attributes for individual footnote elements.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents the attributes for a footnote element.
*
* FootnoteAttributes defines the type and unique identifier for each footnote.
*
* @internal
*/
var FootnoteAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			type: "w:type",
			id: "w:id"
		});
	}
};
/**
* Footnote reference marker module for WordprocessingML documents.
*
* This module provides the automatic footnote reference marker that appears
* at the beginning of footnote content.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents a footnote reference marker in WordprocessingML.
*
* FootnoteRef creates the automatic reference mark (typically a superscript
* number) that appears at the beginning of the footnote content itself.
* This corresponds to the w:footnoteRef element in OOXML.
*
* ## XSD Schema
* ```xml
* <xsd:element name="footnoteRef" type="CT_Empty" minOccurs="0"/>
* ```
*
* @internal
*/
var FootnoteRef = class extends XmlComponent {
	constructor() {
		super("w:footnoteRef");
	}
};
/**
* Footnote Reference Run module for WordprocessingML documents.
*
* This module provides the footnote reference marker that appears
* at the start of a footnote.
*
* @module
*/
/**
* Represents a footnote reference run in a WordprocessingML document.
*
* FootnoteRefRun displays the footnote reference mark (usually a superscript
* number) at the beginning of the footnote content.
*
* @internal
*/
var FootnoteRefRun = class extends Run {
	constructor() {
		super({ style: "FootnoteReference" });
		this.root.push(new FootnoteRef());
	}
};
/**
* Enumeration of footnote types.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @publicApi
*/
var FootnoteType = {
	/** Separator line between body text and footnotes */
	SEPERATOR: "separator",
	/** Continuation separator for footnotes spanning pages */
	CONTINUATION_SEPERATOR: "continuationSeparator"
};
/**
* Represents a footnote in a WordprocessingML document.
*
* Footnotes appear at the bottom of the page and are referenced
* from the main document text using footnote reference marks.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_FtnEdn">
*   <xsd:sequence>
*     <xsd:group ref="EG_BlockLevelElts" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="type" type="ST_FtnEdn"/>
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a footnote with content
* const footnote = new Footnote({
*   id: 1,
*   children: [
*     new Paragraph({
*       children: [
*         new TextRun("This is the footnote content."),
*       ],
*     }),
*   ],
* });
* ```
*/
var Footnote = class extends XmlComponent {
	constructor(options) {
		super("w:footnote");
		this.root.push(new FootnoteAttributes({
			type: options.type,
			id: options.id
		}));
		for (let i = 0; i < options.children.length; i++) {
			const child = options.children[i];
			if (i === 0) child.addRunToFront(new FootnoteRefRun());
			this.root.push(child);
		}
	}
};
/**
* Footnotes attributes module for WordprocessingML documents.
*
* This module defines XML namespace attributes for the footnotes element.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents the XML namespace attributes for the footnotes root element.
*
* FootnotesAttributes defines all necessary XML namespace declarations
* for the footnotes.xml part of a WordprocessingML document.
*
* @internal
*/
var FootnotesAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			wpc: "xmlns:wpc",
			mc: "xmlns:mc",
			o: "xmlns:o",
			r: "xmlns:r",
			m: "xmlns:m",
			v: "xmlns:v",
			wp14: "xmlns:wp14",
			wp: "xmlns:wp",
			w10: "xmlns:w10",
			w: "xmlns:w",
			w14: "xmlns:w14",
			w15: "xmlns:w15",
			wpg: "xmlns:wpg",
			wpi: "xmlns:wpi",
			wne: "xmlns:wne",
			wps: "xmlns:wps",
			Ignorable: "mc:Ignorable"
		});
	}
};
/**
* Footnotes module for WordprocessingML documents.
*
* This module manages the collection of footnotes in a document, including
* separator and continuation separator footnotes that appear by default.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents the footnotes collection in a WordprocessingML document.
*
* FootNotes manages all footnotes in a document and automatically creates
* the required separator and continuation separator footnotes. These special
* footnotes define the line that separates body text from footnotes and the
* line used when footnotes continue across pages.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Footnotes">
*   <xsd:sequence maxOccurs="unbounded">
*     <xsd:element name="footnote" type="CT_FtnEdn" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // FootNotes is typically managed internally by the Document class
* // Users create footnotes through the Document API
* const doc = new Document({
*   sections: [{
*     children: [
*       new Paragraph({
*         children: [
*           new TextRun("Text with footnote"),
*           new FootnoteReferenceRun(1),
*         ],
*       }),
*     ],
*     footnotes: {
*       1: {
*         children: [new Paragraph("Footnote content")],
*       },
*     },
*   }],
* });
* ```
*/
var FootNotes = class extends XmlComponent {
	constructor() {
		super("w:footnotes");
		this.root.push(new FootnotesAttributes({
			wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
			o: "urn:schemas-microsoft-com:office:office",
			r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
			v: "urn:schemas-microsoft-com:vml",
			wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			w10: "urn:schemas-microsoft-com:office:word",
			w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			w14: "http://schemas.microsoft.com/office/word/2010/wordml",
			w15: "http://schemas.microsoft.com/office/word/2012/wordml",
			wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			wne: "http://schemas.microsoft.com/office/word/2006/wordml",
			wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
			Ignorable: "w14 w15 wp14"
		}));
		const begin = new Footnote({
			id: -1,
			type: FootnoteType.SEPERATOR,
			children: [new Paragraph({
				spacing: {
					after: 0,
					line: 240,
					lineRule: LineRuleType.AUTO
				},
				children: [new SeperatorRun()]
			})]
		});
		this.root.push(begin);
		const spacing = new Footnote({
			id: 0,
			type: FootnoteType.CONTINUATION_SEPERATOR,
			children: [new Paragraph({
				spacing: {
					after: 0,
					line: 240,
					lineRule: LineRuleType.AUTO
				},
				children: [new ContinuationSeperatorRun()]
			})]
		});
		this.root.push(spacing);
	}
	/**
	* Creates and adds a new footnote to the collection.
	*
	* @param id - Unique numeric identifier for the footnote
	* @param paragraph - Array of paragraphs that make up the footnote content
	*/
	createFootNote(id, paragraph) {
		const footnote = new Footnote({
			id,
			children: paragraph
		});
		this.root.push(footnote);
	}
};
/**
* Wrapper class for managing footnotes in a document.
*
* Encapsulates the footnotes collection and its relationships,
* implementing the IViewWrapper interface for consistent access.
*
* @example
* ```typescript
* const wrapper = new FootnotesWrapper();
* const footnotes = wrapper.View;
* const relationships = wrapper.Relationships;
* ```
*/
var FootnotesWrapper = class {
	constructor() {
		_defineProperty(this, "footnotess", void 0);
		_defineProperty(this, "relationships", void 0);
		this.footnotess = new FootNotes();
		this.relationships = new Relationships();
	}
	get View() {
		return this.footnotess;
	}
	get Relationships() {
		return this.relationships;
	}
};
/**
* Component for managing XML namespace attributes on header elements.
*
* This class handles the serialization of namespace declarations that are required
* for proper XML validation and processing of header content in WordprocessingML documents.
*
* @example
* ```typescript
* new HeaderAttributes({
*   w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
*   r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
* });
* ```
*/
var HeaderAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			wpc: "xmlns:wpc",
			mc: "xmlns:mc",
			o: "xmlns:o",
			r: "xmlns:r",
			m: "xmlns:m",
			v: "xmlns:v",
			wp14: "xmlns:wp14",
			wp: "xmlns:wp",
			w10: "xmlns:w10",
			w: "xmlns:w",
			w14: "xmlns:w14",
			w15: "xmlns:w15",
			wpg: "xmlns:wpg",
			wpi: "xmlns:wpi",
			wne: "xmlns:wne",
			wps: "xmlns:wps",
			cp: "xmlns:cp",
			dc: "xmlns:dc",
			dcterms: "xmlns:dcterms",
			dcmitype: "xmlns:dcmitype",
			xsi: "xmlns:xsi",
			type: "xsi:type",
			cx: "xmlns:cx",
			cx1: "xmlns:cx1",
			cx2: "xmlns:cx2",
			cx3: "xmlns:cx3",
			cx4: "xmlns:cx4",
			cx5: "xmlns:cx5",
			cx6: "xmlns:cx6",
			cx7: "xmlns:cx7",
			cx8: "xmlns:cx8",
			w16cid: "xmlns:w16cid",
			w16se: "xmlns:w16se"
		});
	}
};
/**
* Header module for WordprocessingML documents.
*
* Headers are repeated at the top of each page in a section.
*
* Reference: http://officeopenxml.com/WPheaders.php
*
* @module
*/
/**
* Represents a header in a WordprocessingML document.
*
* A header is the portion of the document that appears at the top of each page in a section.
* Headers can contain block-level elements such as paragraphs and tables. Each section can
* have up to three different headers: first page, even pages, and odd pages.
*
* Reference: http://officeopenxml.com/WPheaders.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_HdrFtr">
*   <xsd:group ref="EG_BlockLevelElts" minOccurs="1" maxOccurs="unbounded"/>
* </xsd:complexType>
*
* <xsd:element name="hdr" type="CT_HdrFtr"/>
* ```
*
* @example
* ```typescript
* // Create a simple header
* const header = new Header(1);
* header.add(new Paragraph("Company Name"));
*
* // Create a header with a table
* const header = new Header(2);
* header.add(new Table({
*   rows: [
*     new TableRow({
*       children: [new TableCell({ children: [new Paragraph("Header Content")] })]
*     })
*   ]
* }));
* ```
*/
var Header$1 = class extends InitializableXmlComponent {
	constructor(referenceNumber, initContent) {
		super("w:hdr", initContent);
		_defineProperty(this, "refId", void 0);
		this.refId = referenceNumber;
		if (!initContent) this.root.push(new HeaderAttributes({
			wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
			o: "urn:schemas-microsoft-com:office:office",
			r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
			v: "urn:schemas-microsoft-com:vml",
			wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			w10: "urn:schemas-microsoft-com:office:word",
			w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			w14: "http://schemas.microsoft.com/office/word/2010/wordml",
			w15: "http://schemas.microsoft.com/office/word/2012/wordml",
			wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			wne: "http://schemas.microsoft.com/office/word/2006/wordml",
			wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
			cx: "http://schemas.microsoft.com/office/drawing/2014/chartex",
			cx1: "http://schemas.microsoft.com/office/drawing/2015/9/8/chartex",
			cx2: "http://schemas.microsoft.com/office/drawing/2015/10/21/chartex",
			cx3: "http://schemas.microsoft.com/office/drawing/2016/5/9/chartex",
			cx4: "http://schemas.microsoft.com/office/drawing/2016/5/10/chartex",
			cx5: "http://schemas.microsoft.com/office/drawing/2016/5/11/chartex",
			cx6: "http://schemas.microsoft.com/office/drawing/2016/5/12/chartex",
			cx7: "http://schemas.microsoft.com/office/drawing/2016/5/13/chartex",
			cx8: "http://schemas.microsoft.com/office/drawing/2016/5/14/chartex",
			w16cid: "http://schemas.microsoft.com/office/word/2016/wordml/cid",
			w16se: "http://schemas.microsoft.com/office/word/2015/wordml/symex"
		}));
	}
	get ReferenceId() {
		return this.refId;
	}
	add(item) {
		this.root.push(item);
	}
};
/**
* Wrapper for document headers.
*
* HeaderWrapper combines a Header view with its Relationships and Media,
* enabling headers to contain paragraphs, tables, images, and hyperlinks.
* Each section can have multiple headers for different page types.
*
* Reference: http://officeopenxml.com/WPheader.php
*
* @example
* ```typescript
* const headerWrapper = new HeaderWrapper(media, 1);
* headerWrapper.add(new Paragraph("Page Header"));
* headerWrapper.add(new Table({
*   rows: [new TableRow({ children: [new TableCell({ children: [new Paragraph("Cell")] })] })],
* }));
* ```
*/
var HeaderWrapper = class {
	constructor(media, referenceId, initContent) {
		_defineProperty(this, "media", void 0);
		_defineProperty(this, "header", void 0);
		_defineProperty(this, "relationships", void 0);
		this.media = media;
		this.header = new Header$1(referenceId, initContent);
		this.relationships = new Relationships();
	}
	add(item) {
		this.header.add(item);
		return this;
	}
	addChildElement(childElement) {
		this.header.addChildElement(childElement);
	}
	get View() {
		return this.header;
	}
	get Relationships() {
		return this.relationships;
	}
	get Media() {
		return this.media;
	}
};
/**
* Manages embedded media (images) in a document.
*
* Media stores all images referenced in the document and provides
* access to their data for packaging into the DOCX file. Each image
* is stored with a unique key for retrieval.
*
* @example
* ```typescript
* const media = new Media();
* media.addImage("image1", {
*   type: "png",
*   fileName: "image1.png",
*   transformation: {
*     pixels: { x: 200, y: 100 },
*     emus: { x: 1828800, y: 914400 }
*   },
*   data: imageBuffer
* });
* const allImages = media.Array;
* ```
*/
var Media = class {
	constructor() {
		_defineProperty(this, "map", void 0);
		this.map = /* @__PURE__ */ new Map();
	}
	/**
	* Adds an image to the media collection.
	*
	* @param key - Unique identifier for this image
	* @param mediaData - Complete image data including file name, transformation, and raw data
	*/
	addImage(key, mediaData) {
		this.map.set(key, mediaData);
	}
	/**
	* Gets all images as an array.
	*
	* @returns Read-only array of all media data in the collection
	*/
	get Array() {
		return Array.from(this.map.values());
	}
};
/**
* Numbering level definitions module for WordprocessingML documents.
*
* This module defines the formatting and behavior of individual levels within
* a numbered or bulleted list hierarchy.
*
* Reference: http://officeopenxml.com/WPnumbering-numFmt.php
*
* @module
*/
/**
* Number format types for list levels.
*
* Defines the various numbering formats available for list levels, including
* decimal, roman numerals, letters, and various international formats.
*
* Reference: http://officeopenxml.com/WPnumbering-numFmt.php
*
* @example
* ```typescript
* // Use decimal numbering (1, 2, 3...)
* format: LevelFormat.DECIMAL
*
* // Use lowercase roman numerals (i, ii, iii...)
* format: LevelFormat.LOWER_ROMAN
*
* // Use bullet points
* format: LevelFormat.BULLET
* ```
*
* @publicApi
*/
var LevelFormat = {
	/** Decimal numbering (1, 2, 3...). */
	DECIMAL: "decimal",
	/** Uppercase roman numerals (I, II, III...). */
	UPPER_ROMAN: "upperRoman",
	/** Lowercase roman numerals (i, ii, iii...). */
	LOWER_ROMAN: "lowerRoman",
	/** Uppercase letters (A, B, C...). */
	UPPER_LETTER: "upperLetter",
	/** Lowercase letters (a, b, c...). */
	LOWER_LETTER: "lowerLetter",
	/** Ordinal numbers (1st, 2nd, 3rd...). */
	ORDINAL: "ordinal",
	/** Cardinal text (one, two, three...). */
	CARDINAL_TEXT: "cardinalText",
	/** Ordinal text (first, second, third...). */
	ORDINAL_TEXT: "ordinalText",
	/** Hexadecimal numbering. */
	HEX: "hex",
	/** Chicago Manual of Style numbering. */
	CHICAGO: "chicago",
	/** Ideograph digital numbering. */
	IDEOGRAPH__DIGITAL: "ideographDigital",
	/** Japanese counting system. */
	JAPANESE_COUNTING: "japaneseCounting",
	/** Japanese aiueo ordering. */
	AIUEO: "aiueo",
	/** Japanese iroha ordering. */
	IROHA: "iroha",
	/** Full-width decimal numbering. */
	DECIMAL_FULL_WIDTH: "decimalFullWidth",
	/** Half-width decimal numbering. */
	DECIMAL_HALF_WIDTH: "decimalHalfWidth",
	/** Japanese legal numbering. */
	JAPANESE_LEGAL: "japaneseLegal",
	/** Japanese digital ten thousand numbering. */
	JAPANESE_DIGITAL_TEN_THOUSAND: "japaneseDigitalTenThousand",
	/** Decimal numbers enclosed in circles. */
	DECIMAL_ENCLOSED_CIRCLE: "decimalEnclosedCircle",
	/** Full-width decimal numbering variant 2. */
	DECIMAL_FULL_WIDTH2: "decimalFullWidth2",
	/** Full-width aiueo ordering. */
	AIUEO_FULL_WIDTH: "aiueoFullWidth",
	/** Full-width iroha ordering. */
	IROHA_FULL_WIDTH: "irohaFullWidth",
	/** Decimal with leading zeros. */
	DECIMAL_ZERO: "decimalZero",
	/** Bullet points. */
	BULLET: "bullet",
	/** Korean ganada ordering. */
	GANADA: "ganada",
	/** Korean chosung ordering. */
	CHOSUNG: "chosung",
	/** Decimal enclosed with fullstop. */
	DECIMAL_ENCLOSED_FULLSTOP: "decimalEnclosedFullstop",
	/** Decimal enclosed in parentheses. */
	DECIMAL_ENCLOSED_PARENTHESES: "decimalEnclosedParen",
	/** Decimal enclosed in circles (Chinese). */
	DECIMAL_ENCLOSED_CIRCLE_CHINESE: "decimalEnclosedCircleChinese",
	/** Ideograph enclosed in circles. */
	IDEOGRAPH_ENCLOSED_CIRCLE: "ideographEnclosedCircle",
	/** Traditional ideograph numbering. */
	IDEOGRAPH_TRADITIONAL: "ideographTraditional",
	/** Ideograph zodiac numbering. */
	IDEOGRAPH_ZODIAC: "ideographZodiac",
	/** Traditional ideograph zodiac numbering. */
	IDEOGRAPH_ZODIAC_TRADITIONAL: "ideographZodiacTraditional",
	/** Taiwanese counting system. */
	TAIWANESE_COUNTING: "taiwaneseCounting",
	/** Traditional ideograph legal numbering. */
	IDEOGRAPH_LEGAL_TRADITIONAL: "ideographLegalTraditional",
	/** Taiwanese counting thousand system. */
	TAIWANESE_COUNTING_THOUSAND: "taiwaneseCountingThousand",
	/** Taiwanese digital numbering. */
	TAIWANESE_DIGITAL: "taiwaneseDigital",
	/** Chinese counting system. */
	CHINESE_COUNTING: "chineseCounting",
	/** Simplified Chinese legal numbering. */
	CHINESE_LEGAL_SIMPLIFIED: "chineseLegalSimplified",
	/** Chinese counting thousand system. */
	CHINESE_COUNTING_THOUSAND: "chineseCountingThousand",
	/** Korean digital numbering. */
	KOREAN_DIGITAL: "koreanDigital",
	/** Korean counting system. */
	KOREAN_COUNTING: "koreanCounting",
	/** Korean legal numbering. */
	KOREAN_LEGAL: "koreanLegal",
	/** Korean digital numbering variant 2. */
	KOREAN_DIGITAL2: "koreanDigital2",
	/** Vietnamese counting system. */
	VIETNAMESE_COUNTING: "vietnameseCounting",
	/** Russian lowercase numbering. */
	RUSSIAN_LOWER: "russianLower",
	/** Russian uppercase numbering. */
	RUSSIAN_UPPER: "russianUpper",
	/** No numbering. */
	NONE: "none",
	/** Number enclosed in dashes. */
	NUMBER_IN_DASH: "numberInDash",
	/** Hebrew numbering variant 1. */
	HEBREW1: "hebrew1",
	/** Hebrew numbering variant 2. */
	HEBREW2: "hebrew2",
	/** Arabic alpha numbering. */
	ARABIC_ALPHA: "arabicAlpha",
	/** Arabic abjad numbering. */
	ARABIC_ABJAD: "arabicAbjad",
	/** Hindi vowels. */
	HINDI_VOWELS: "hindiVowels",
	/** Hindi consonants. */
	HINDI_CONSONANTS: "hindiConsonants",
	/** Hindi numbers. */
	HINDI_NUMBERS: "hindiNumbers",
	/** Hindi counting system. */
	HINDI_COUNTING: "hindiCounting",
	/** Thai letters. */
	THAI_LETTERS: "thaiLetters",
	/** Thai numbers. */
	THAI_NUMBERS: "thaiNumbers",
	/** Thai counting system. */
	THAI_COUNTING: "thaiCounting",
	/** Thai Baht text. */
	BAHT_TEXT: "bahtText",
	/** Dollar text. */
	DOLLAR_TEXT: "dollarText",
	/** Custom numbering format. */
	CUSTOM: "custom"
};
/**
* Attributes for numbering levels.
*/
var LevelAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			ilvl: "w:ilvl",
			tentative: "w15:tentative"
		});
	}
};
/**
* Number format specification for a level.
*
* Specifies the numbering format to use (decimal, roman, letter, etc.).
*/
var NumberFormat$1 = class extends XmlComponent {
	constructor(value) {
		super("w:numFmt");
		this.root.push(new Attributes({ val: value }));
	}
};
/**
* Level text template for displaying the numbering.
*
* The text can include placeholders like %1, %2, etc. to reference
* numbering from different levels.
*/
var LevelText = class extends XmlComponent {
	constructor(value) {
		super("w:lvlText");
		this.root.push(new Attributes({ val: value }));
	}
};
/**
* Alignment specification for level numbering.
*/
var LevelJc = class extends XmlComponent {
	constructor(value) {
		super("w:lvlJc");
		this.root.push(new Attributes({ val: value }));
	}
};
/**
* Suffix specification for a level.
*
* Defines what character(s) follow the numbering text.
*/
var Suffix = class extends XmlComponent {
	constructor(value) {
		super("w:suff");
		this.root.push(new Attributes({ val: value }));
	}
};
/**
* Legal numbering style flag.
*
* When enabled, creates multi-level legal numbering like 1.1.1.
*
* Reference: http://officeopenxml.com/WPnumbering-isLgl.php
*/
var IsLegalNumberingStyle = class extends XmlComponent {
	constructor() {
		super("w:isLgl");
	}
};
/**
* Base class for numbering level definitions.
*
* Defines the formatting and behavior of a single level in a multi-level
* numbering scheme. Each level can have its own numbering format, text template,
* alignment, and styling.
*
* Reference: http://officeopenxml.com/WPnumbering-numFmt.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Lvl">
*   <xsd:sequence>
*     <xsd:element name="start" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="numFmt" type="CT_NumFmt" minOccurs="0"/>
*     <xsd:element name="lvlRestart" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="pStyle" type="CT_String" minOccurs="0"/>
*     <xsd:element name="isLgl" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="suff" type="CT_LevelSuffix" minOccurs="0"/>
*     <xsd:element name="lvlText" type="CT_LevelText" minOccurs="0"/>
*     <xsd:element name="lvlPicBulletId" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="legacy" type="CT_LvlLegacy" minOccurs="0"/>
*     <xsd:element name="lvlJc" type="CT_Jc" minOccurs="0"/>
*     <xsd:element name="pPr" type="CT_PPrGeneral" minOccurs="0"/>
*     <xsd:element name="rPr" type="CT_RPr" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="ilvl" type="ST_DecimalNumber" use="required"/>
*   <xsd:attribute name="tplc" type="ST_LongHexNumber" use="optional"/>
*   <xsd:attribute name="tentative" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*/
var LevelBase = class extends XmlComponent {
	/**
	* Creates a new numbering level.
	*
	* @param options - Level configuration options
	* @throws Error if level is greater than 9 (Word limitation)
	*/
	constructor({ level, format, text, alignment = AlignmentType.START, start = 1, style, suffix, isLegalNumberingStyle }) {
		super("w:lvl");
		_defineProperty(this, "paragraphProperties", void 0);
		_defineProperty(this, "runProperties", void 0);
		this.root.push(new NumberValueElement("w:start", decimalNumber(start)));
		if (format) this.root.push(new NumberFormat$1(format));
		if (suffix) this.root.push(new Suffix(suffix));
		if (isLegalNumberingStyle) this.root.push(new IsLegalNumberingStyle());
		if (text) this.root.push(new LevelText(text));
		this.root.push(new LevelJc(alignment));
		if (style === null || style === void 0 ? void 0 : style.style) this.root.push(createParagraphStyle(style.style));
		this.paragraphProperties = new ParagraphProperties(style && style.paragraph);
		this.runProperties = new RunProperties(style && style.run);
		this.root.push(this.paragraphProperties);
		this.root.push(this.runProperties);
		if (level > 9) throw new Error("Level cannot be greater than 9. Read more here: https://answers.microsoft.com/en-us/msoffice/forum/all/does-word-support-more-than-9-list-levels/d130fdcd-1781-446d-8c84-c6c79124e4d7");
		this.root.push(new LevelAttributes({
			ilvl: decimalNumber(level),
			tentative: 1
		}));
	}
};
/**
* Represents a numbering level within an abstract numbering definition.
*
* This is the standard level definition used in abstract numbering definitions.
* Each abstract numbering definition can contain up to 9 levels (0-8).
*
* Reference: http://officeopenxml.com/WPnumbering-numFmt.php
*
* @example
* ```typescript
* // Create a decimal numbered level
* const level = new Level({
*   level: 0,
*   format: LevelFormat.DECIMAL,
*   text: "%1.",
*   alignment: AlignmentType.LEFT,
*   start: 1,
* });
*
* // Create a bullet level with custom styling
* const bulletLevel = new Level({
*   level: 0,
*   format: LevelFormat.BULLET,
*   text: "\u2022",
*   alignment: AlignmentType.LEFT,
*   style: {
*     paragraph: {
*       indent: { left: 720, hanging: 360 },
*     },
*   },
* });
* ```
*/
var Level = class extends LevelBase {};
/**
* Multi-level type definitions for WordprocessingML documents.
*
* Defines the type of numbering structure (single-level, multi-level, or hybrid).
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* @module
*/
/**
* Represents the multi-level type of a numbering definition.
*
* The multi-level type specifies whether the numbering definition uses a single
* level, multiple levels, or a hybrid approach.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_MultiLevelType">
*   <xsd:attribute name="val" type="ST_MultiLevelType" use="required"/>
* </xsd:complexType>
*
* <xsd:simpleType name="ST_MultiLevelType">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="singleLevel"/>
*     <xsd:enumeration value="multilevel"/>
*     <xsd:enumeration value="hybridMultilevel"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @example
* ```typescript
* // Create a hybrid multi-level numbering
* const multiLevel = new MultiLevelType("hybridMultilevel");
*
* // Create a single-level numbering
* const singleLevel = new MultiLevelType("singleLevel");
* ```
*/
var MultiLevelType = class extends XmlComponent {
	/**
	* Creates a new multi-level type specification.
	*
	* @param value - The multi-level type: "singleLevel", "multilevel", or "hybridMultilevel"
	*/
	constructor(value) {
		super("w:multiLevelType");
		this.root.push(new Attributes({ val: value }));
	}
};
/**
* Abstract numbering definitions module for WordprocessingML documents.
*
* Abstract numbering definitions contain the formatting and style information
* that can be shared across multiple numbering instances.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* @module
*/
/**
* Attributes for abstract numbering definitions.
*
* @property abstractNumId - Unique identifier for the abstract numbering definition
* @property restartNumberingAfterBreak - Whether to restart numbering after section breaks
*/
var AbstractNumberingAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			abstractNumId: "w:abstractNumId",
			restartNumberingAfterBreak: "w15:restartNumberingAfterBreak"
		});
	}
};
/**
* Represents an abstract numbering definition in a WordprocessingML document.
*
* Abstract numbering definitions define the formatting and style of numbered or
* bulleted lists that can be referenced by concrete numbering instances.
* Each abstract definition can contain up to 9 levels.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_AbstractNum">
*   <xsd:sequence>
*     <xsd:element name="nsid" type="CT_LongHexNumber" minOccurs="0"/>
*     <xsd:element name="multiLevelType" type="CT_MultiLevelType" minOccurs="0"/>
*     <xsd:element name="tmpl" type="CT_LongHexNumber" minOccurs="0"/>
*     <xsd:element name="name" type="CT_String" minOccurs="0"/>
*     <xsd:element name="styleLink" type="CT_String" minOccurs="0"/>
*     <xsd:element name="numStyleLink" type="CT_String" minOccurs="0"/>
*     <xsd:element name="lvl" type="CT_Lvl" minOccurs="0" maxOccurs="9"/>
*   </xsd:sequence>
*   <xsd:attribute name="abstractNumId" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create an abstract numbering definition with multiple levels
* const abstractNumbering = new AbstractNumbering(1, [
*   {
*     level: 0,
*     format: LevelFormat.DECIMAL,
*     text: "%1.",
*     alignment: AlignmentType.LEFT,
*   },
*   {
*     level: 1,
*     format: LevelFormat.LOWER_LETTER,
*     text: "%2)",
*     alignment: AlignmentType.LEFT,
*   },
* ]);
* ```
*/
var AbstractNumbering = class extends XmlComponent {
	/**
	* Creates a new abstract numbering definition.
	*
	* @param id - Unique identifier for this abstract numbering definition
	* @param levelOptions - Array of level definitions (up to 9 levels)
	*/
	constructor(id, levelOptions) {
		super("w:abstractNum");
		_defineProperty(
			this,
			/** The unique identifier for this abstract numbering definition. */
			"id",
			void 0
		);
		this.root.push(new AbstractNumberingAttributes({
			abstractNumId: decimalNumber(id),
			restartNumberingAfterBreak: 0
		}));
		this.root.push(new MultiLevelType("hybridMultilevel"));
		this.id = id;
		for (const option of levelOptions) this.root.push(new Level(option));
	}
};
/**
* Concrete numbering instances module for WordprocessingML documents.
*
* Concrete numbering instances reference abstract numbering definitions and
* can override specific level settings. Each paragraph references a concrete
* numbering instance to apply list formatting.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* @module
*/
/**
* Reference to an abstract numbering definition.
*/
var AbstractNumId = class extends XmlComponent {
	constructor(value) {
		super("w:abstractNumId");
		this.root.push(new Attributes({ val: value }));
	}
};
/**
* Attributes for concrete numbering instances.
*/
var NumAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { numId: "w:numId" });
	}
};
/**
* Represents a concrete numbering instance in a WordprocessingML document.
*
* A concrete numbering instance references an abstract numbering definition and
* can override specific levels. Paragraphs reference concrete numbering instances
* to apply list formatting.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Num">
*   <xsd:sequence>
*     <xsd:element name="abstractNumId" type="CT_DecimalNumber" minOccurs="1"/>
*     <xsd:element name="lvlOverride" type="CT_NumLvl" minOccurs="0" maxOccurs="9"/>
*   </xsd:sequence>
*   <xsd:attribute name="numId" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a concrete numbering instance
* const concreteNumbering = new ConcreteNumbering({
*   numId: 1,
*   abstractNumId: 0,
*   reference: "my-numbering",
*   instance: 0,
*   overrideLevels: [
*     {
*       num: 0,
*       start: 5, // Start numbering at 5 instead of 1
*     },
*   ],
* });
* ```
*/
var ConcreteNumbering = class extends XmlComponent {
	/**
	* Creates a new concrete numbering instance.
	*
	* @param options - Configuration options for the numbering instance
	*/
	constructor(options) {
		super("w:num");
		_defineProperty(
			this,
			/** The unique identifier for this numbering instance. */
			"numId",
			void 0
		);
		_defineProperty(
			this,
			/** The reference name for this numbering instance. */
			"reference",
			void 0
		);
		_defineProperty(
			this,
			/** The instance number for tracking multiple uses. */
			"instance",
			void 0
		);
		this.numId = options.numId;
		this.reference = options.reference;
		this.instance = options.instance;
		this.root.push(new NumAttributes({ numId: decimalNumber(options.numId) }));
		this.root.push(new AbstractNumId(decimalNumber(options.abstractNumId)));
		if (options.overrideLevels && options.overrideLevels.length) for (const level of options.overrideLevels) this.root.push(new LevelOverride(level.num, level.start));
	}
};
/**
* Attributes for level overrides.
*/
var LevelOverrideAttributes = class extends XmlAttributeComponent {
	constructor(..._args2) {
		super(..._args2);
		_defineProperty(this, "xmlKeys", { ilvl: "w:ilvl" });
	}
};
/**
* Represents a level override in a concrete numbering instance.
*
* Level overrides allow customization of specific levels within a numbering
* instance, such as changing the starting number.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_NumLvl">
*   <xsd:sequence>
*     <xsd:element name="startOverride" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="lvl" type="CT_Lvl" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="ilvl" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*/
var LevelOverride = class extends XmlComponent {
	/**
	* Creates a new level override.
	*
	* @param levelNum - The level number to override (0-8)
	* @param start - Optional starting number for the level
	*/
	constructor(levelNum, start) {
		super("w:lvlOverride");
		this.root.push(new LevelOverrideAttributes({ ilvl: levelNum }));
		if (start !== void 0) this.root.push(new StartOverride(start));
	}
};
/**
* Attributes for start override values.
*/
var StartOverrideAttributes = class extends XmlAttributeComponent {
	constructor(..._args3) {
		super(..._args3);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents a start override for a numbering level.
*
* This element overrides the starting number for a specific level.
*/
var StartOverride = class extends XmlComponent {
	/**
	* Creates a new start override.
	*
	* @param start - The starting number
	*/
	constructor(start) {
		super("w:startOverride");
		this.root.push(new StartOverrideAttributes({ val: start }));
	}
};
/**
* Numbering module for WordprocessingML documents.
*
* Numbering provides support for numbered and bulleted lists.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* @see https://stackoverflow.com/questions/58622437/purpose-of-abstractnum-and-numberinginstance
*
* @module
*/
/**
* Represents the numbering definitions in a WordprocessingML document.
*
* The numbering element contains abstract numbering definitions and their
* concrete instances, which are referenced by paragraphs to create lists.
* Each numbering configuration includes a default bullet list and any
* custom numbering schemes defined by the user.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="numbering" type="CT_Numbering"/>
*
* <xsd:complexType name="CT_Numbering">
*   <xsd:sequence>
*     <xsd:element name="numPicBullet" type="CT_NumPicBullet" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="abstractNum" type="CT_AbstractNum" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="num" type="CT_Num" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="numIdMacAtCleanup" type="CT_DecimalNumber" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create numbering with custom decimal list
* const numbering = new Numbering({
*   config: [
*     {
*       reference: "my-decimal-list",
*       levels: [
*         {
*           level: 0,
*           format: LevelFormat.DECIMAL,
*           text: "%1.",
*           alignment: AlignmentType.LEFT,
*           start: 1,
*           style: {
*             paragraph: {
*               indent: { left: 720, hanging: 360 },
*             },
*           },
*         },
*         {
*           level: 1,
*           format: LevelFormat.LOWER_LETTER,
*           text: "%2)",
*           alignment: AlignmentType.LEFT,
*           style: {
*             paragraph: {
*               indent: { left: 1440, hanging: 360 },
*             },
*           },
*         },
*       ],
*     },
*   ],
* });
* ```
*/
var Numbering = class extends XmlComponent {
	/**
	* Creates a new numbering definition collection.
	*
	* Initializes the numbering with a default bullet list configuration and
	* any custom numbering configurations provided in the options.
	*
	* @param options - Configuration options for numbering definitions
	*/
	constructor(options) {
		super("w:numbering");
		_defineProperty(this, "abstractNumberingMap", /* @__PURE__ */ new Map());
		_defineProperty(this, "concreteNumberingMap", /* @__PURE__ */ new Map());
		_defineProperty(this, "referenceConfigMap", /* @__PURE__ */ new Map());
		_defineProperty(this, "abstractNumUniqueNumericId", abstractNumUniqueNumericIdGen());
		_defineProperty(this, "concreteNumUniqueNumericId", concreteNumUniqueNumericIdGen());
		this.root.push(new DocumentAttributes([
			"wpc",
			"mc",
			"o",
			"r",
			"m",
			"v",
			"wp14",
			"wp",
			"w10",
			"w",
			"w14",
			"w15",
			"wpg",
			"wpi",
			"wne",
			"wps"
		], "w14 w15 wp14"));
		const abstractNumbering = new AbstractNumbering(this.abstractNumUniqueNumericId(), [
			{
				level: 0,
				format: LevelFormat.BULLET,
				text: "●",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: convertInchesToTwip(.5),
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 1,
				format: LevelFormat.BULLET,
				text: "○",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: convertInchesToTwip(1),
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 2,
				format: LevelFormat.BULLET,
				text: "■",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 2160,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 3,
				format: LevelFormat.BULLET,
				text: "●",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 2880,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 4,
				format: LevelFormat.BULLET,
				text: "○",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 3600,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 5,
				format: LevelFormat.BULLET,
				text: "■",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 4320,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 6,
				format: LevelFormat.BULLET,
				text: "●",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 5040,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 7,
				format: LevelFormat.BULLET,
				text: "●",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 5760,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 8,
				format: LevelFormat.BULLET,
				text: "●",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 6480,
					hanging: convertInchesToTwip(.25)
				} } }
			}
		]);
		this.concreteNumberingMap.set("default-bullet-numbering", new ConcreteNumbering({
			numId: 1,
			abstractNumId: abstractNumbering.id,
			reference: "default-bullet-numbering",
			instance: 0,
			overrideLevels: [{
				num: 0,
				start: 1
			}]
		}));
		this.abstractNumberingMap.set("default-bullet-numbering", abstractNumbering);
		for (const con of options.config) {
			this.abstractNumberingMap.set(con.reference, new AbstractNumbering(this.abstractNumUniqueNumericId(), con.levels));
			this.referenceConfigMap.set(con.reference, con.levels);
		}
	}
	/**
	* Prepares the numbering definitions for XML serialization.
	*
	* Adds all abstract and concrete numbering definitions to the XML tree.
	*
	* @param context - The XML context
	* @returns The prepared XML object
	*/
	prepForXml(context) {
		for (const numbering of this.abstractNumberingMap.values()) this.root.push(numbering);
		for (const numbering of this.concreteNumberingMap.values()) this.root.push(numbering);
		return super.prepForXml(context);
	}
	/**
	* Creates a concrete numbering instance from an abstract numbering definition.
	*
	* This method creates a new concrete numbering instance that references an
	* abstract numbering definition. It's used internally when paragraphs reference
	* numbering configurations.
	*
	* @param reference - The reference name of the abstract numbering definition
	* @param instance - The instance number for this concrete numbering
	*/
	createConcreteNumberingInstance(reference, instance) {
		const abstractNumbering = this.abstractNumberingMap.get(reference);
		if (!abstractNumbering) return;
		const fullReference = `${reference}-${instance}`;
		if (this.concreteNumberingMap.has(fullReference)) return;
		const referenceConfigLevels = this.referenceConfigMap.get(reference);
		const firstLevelStartNumber = referenceConfigLevels && referenceConfigLevels[0].start;
		const concreteNumberingSettings = {
			numId: this.concreteNumUniqueNumericId(),
			abstractNumId: abstractNumbering.id,
			reference,
			instance,
			overrideLevels: [typeof firstLevelStartNumber === "number" && Number.isInteger(firstLevelStartNumber) ? {
				num: 0,
				start: firstLevelStartNumber
			} : {
				num: 0,
				start: 1
			}]
		};
		this.concreteNumberingMap.set(fullReference, new ConcreteNumbering(concreteNumberingSettings));
	}
	/**
	* Gets all concrete numbering instances.
	*
	* @returns An array of all concrete numbering instances
	*/
	get ConcreteNumbering() {
		return Array.from(this.concreteNumberingMap.values());
	}
	/**
	* Gets all reference configurations.
	*
	* @returns An array of all numbering reference configurations
	*/
	get ReferenceConfig() {
		return Array.from(this.referenceConfigMap.values());
	}
};
/**
* Compatibility setting module for WordprocessingML documents.
*
* This module provides the compatibility mode version setting that controls
* which Word version's behavior the document should emulate.
*
* Reference: https://docs.microsoft.com/en-us/openspecs/office_standards/ms-docx/90138c4d-eb18-4edc-aa6c-dfb799cb1d0d
*
* @module
*/
/**
* Creates a compatibility setting for a WordprocessingML document.
*
* Currently hard-coded to set Microsoft Word compatibility mode version.
* This controls which Word version's formatting and layout behavior the document emulates.
*
* Common version values:
* - 11: Word 2003
* - 12: Word 2007
* - 14: Word 2010
* - 15: Word 2013+
*
* Reference: https://docs.microsoft.com/en-us/openspecs/office_standards/ms-docx/90138c4d-eb18-4edc-aa6c-dfb799cb1d0d
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_CompatSetting">
*   <xsd:attribute name="name" type="s:ST_String"/>
*   <xsd:attribute name="uri" type="s:ST_String"/>
*   <xsd:attribute name="val" type="s:ST_String"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set compatibility mode to Word 2013+
* createCompatibilitySetting(15);
*
* // Set compatibility mode to Word 2010
* createCompatibilitySetting(14);
* ```
*/
var createCompatibilitySetting = (version) => new BuilderElement({
	name: "w:compatSetting",
	attributes: {
		version: {
			key: "w:val",
			value: version
		},
		name: {
			key: "w:name",
			value: "compatibilityMode"
		},
		uri: {
			key: "w:uri",
			value: "http://schemas.microsoft.com/office/word"
		}
	}
});
/**
* Compatibility module for WordprocessingML documents.
*
* This module provides compatibility settings that control how Word
* handles documents created in older versions or other word processors.
*
* Reference: http://www.datypic.com/sc/ooxml/e-w_compat-1.html
*
* @module
*/
/**
* Represents compatibility settings in a WordprocessingML document.
*
* Compatibility settings control document rendering and layout behavior
* to match older Word versions or other word processors. This ensures
* documents maintain consistent appearance across different applications.
*
* Reference: http://www.datypic.com/sc/ooxml/e-w_compat-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Compat">
*   <xsd:sequence>
*     <xsd:element name="useSingleBorderforContiguousCells" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="wpJustification" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="noTabHangInd" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="noLeading" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="usePrinterMetrics" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="compatSetting" type="CT_CompatSetting" minOccurs="0" maxOccurs="unbounded"/>
*     <!-- Additional compatibility elements omitted for brevity -->
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set compatibility mode to Word 2013+
* new Compatibility({
*   version: 15,
* });
*
* // Enable specific compatibility options
* new Compatibility({
*   version: 15,
*   usePrinterMetrics: true,
*   doNotSnapToGridInCell: true,
* });
* ```
*/
var Compatibility = class extends XmlComponent {
	constructor(options) {
		super("w:compat");
		if (options.version) this.root.push(createCompatibilitySetting(options.version));
		if (options.useSingleBorderforContiguousCells) this.root.push(new OnOffElement("w:useSingleBorderforContiguousCells", options.useSingleBorderforContiguousCells));
		if (options.wordPerfectJustification) this.root.push(new OnOffElement("w:wpJustification", options.wordPerfectJustification));
		if (options.noTabStopForHangingIndent) this.root.push(new OnOffElement("w:noTabHangInd", options.noTabStopForHangingIndent));
		if (options.noLeading) this.root.push(new OnOffElement("w:noLeading", options.noLeading));
		if (options.spaceForUnderline) this.root.push(new OnOffElement("w:spaceForUL", options.spaceForUnderline));
		if (options.noColumnBalance) this.root.push(new OnOffElement("w:noColumnBalance", options.noColumnBalance));
		if (options.balanceSingleByteDoubleByteWidth) this.root.push(new OnOffElement("w:balanceSingleByteDoubleByteWidth", options.balanceSingleByteDoubleByteWidth));
		if (options.noExtraLineSpacing) this.root.push(new OnOffElement("w:noExtraLineSpacing", options.noExtraLineSpacing));
		if (options.doNotLeaveBackslashAlone) this.root.push(new OnOffElement("w:doNotLeaveBackslashAlone", options.doNotLeaveBackslashAlone));
		if (options.underlineTrailingSpaces) this.root.push(new OnOffElement("w:ulTrailSpace", options.underlineTrailingSpaces));
		if (options.doNotExpandShiftReturn) this.root.push(new OnOffElement("w:doNotExpandShiftReturn", options.doNotExpandShiftReturn));
		if (options.spacingInWholePoints) this.root.push(new OnOffElement("w:spacingInWholePoints", options.spacingInWholePoints));
		if (options.lineWrapLikeWord6) this.root.push(new OnOffElement("w:lineWrapLikeWord6", options.lineWrapLikeWord6));
		if (options.printBodyTextBeforeHeader) this.root.push(new OnOffElement("w:printBodyTextBeforeHeader", options.printBodyTextBeforeHeader));
		if (options.printColorsBlack) this.root.push(new OnOffElement("w:printColBlack", options.printColorsBlack));
		if (options.spaceWidth) this.root.push(new OnOffElement("w:wpSpaceWidth", options.spaceWidth));
		if (options.showBreaksInFrames) this.root.push(new OnOffElement("w:showBreaksInFrames", options.showBreaksInFrames));
		if (options.subFontBySize) this.root.push(new OnOffElement("w:subFontBySize", options.subFontBySize));
		if (options.suppressBottomSpacing) this.root.push(new OnOffElement("w:suppressBottomSpacing", options.suppressBottomSpacing));
		if (options.suppressTopSpacing) this.root.push(new OnOffElement("w:suppressTopSpacing", options.suppressTopSpacing));
		if (options.suppressSpacingAtTopOfPage) this.root.push(new OnOffElement("w:suppressSpacingAtTopOfPage", options.suppressSpacingAtTopOfPage));
		if (options.suppressTopSpacingWP) this.root.push(new OnOffElement("w:suppressTopSpacingWP", options.suppressTopSpacingWP));
		if (options.suppressSpBfAfterPgBrk) this.root.push(new OnOffElement("w:suppressSpBfAfterPgBrk", options.suppressSpBfAfterPgBrk));
		if (options.swapBordersFacingPages) this.root.push(new OnOffElement("w:swapBordersFacingPages", options.swapBordersFacingPages));
		if (options.convertMailMergeEsc) this.root.push(new OnOffElement("w:convMailMergeEsc", options.convertMailMergeEsc));
		if (options.truncateFontHeightsLikeWP6) this.root.push(new OnOffElement("w:truncateFontHeightsLikeWP6", options.truncateFontHeightsLikeWP6));
		if (options.macWordSmallCaps) this.root.push(new OnOffElement("w:mwSmallCaps", options.macWordSmallCaps));
		if (options.usePrinterMetrics) this.root.push(new OnOffElement("w:usePrinterMetrics", options.usePrinterMetrics));
		if (options.doNotSuppressParagraphBorders) this.root.push(new OnOffElement("w:doNotSuppressParagraphBorders", options.doNotSuppressParagraphBorders));
		if (options.wrapTrailSpaces) this.root.push(new OnOffElement("w:wrapTrailSpaces", options.wrapTrailSpaces));
		if (options.footnoteLayoutLikeWW8) this.root.push(new OnOffElement("w:footnoteLayoutLikeWW8", options.footnoteLayoutLikeWW8));
		if (options.shapeLayoutLikeWW8) this.root.push(new OnOffElement("w:shapeLayoutLikeWW8", options.shapeLayoutLikeWW8));
		if (options.alignTablesRowByRow) this.root.push(new OnOffElement("w:alignTablesRowByRow", options.alignTablesRowByRow));
		if (options.forgetLastTabAlignment) this.root.push(new OnOffElement("w:forgetLastTabAlignment", options.forgetLastTabAlignment));
		if (options.adjustLineHeightInTable) this.root.push(new OnOffElement("w:adjustLineHeightInTable", options.adjustLineHeightInTable));
		if (options.autoSpaceLikeWord95) this.root.push(new OnOffElement("w:autoSpaceLikeWord95", options.autoSpaceLikeWord95));
		if (options.noSpaceRaiseLower) this.root.push(new OnOffElement("w:noSpaceRaiseLower", options.noSpaceRaiseLower));
		if (options.doNotUseHTMLParagraphAutoSpacing) this.root.push(new OnOffElement("w:doNotUseHTMLParagraphAutoSpacing", options.doNotUseHTMLParagraphAutoSpacing));
		if (options.layoutRawTableWidth) this.root.push(new OnOffElement("w:layoutRawTableWidth", options.layoutRawTableWidth));
		if (options.layoutTableRowsApart) this.root.push(new OnOffElement("w:layoutTableRowsApart", options.layoutTableRowsApart));
		if (options.useWord97LineBreakRules) this.root.push(new OnOffElement("w:useWord97LineBreakRules", options.useWord97LineBreakRules));
		if (options.doNotBreakWrappedTables) this.root.push(new OnOffElement("w:doNotBreakWrappedTables", options.doNotBreakWrappedTables));
		if (options.doNotSnapToGridInCell) this.root.push(new OnOffElement("w:doNotSnapToGridInCell", options.doNotSnapToGridInCell));
		if (options.selectFieldWithFirstOrLastCharacter) this.root.push(new OnOffElement("w:selectFldWithFirstOrLastChar", options.selectFieldWithFirstOrLastCharacter));
		if (options.applyBreakingRules) this.root.push(new OnOffElement("w:applyBreakingRules", options.applyBreakingRules));
		if (options.doNotWrapTextWithPunctuation) this.root.push(new OnOffElement("w:doNotWrapTextWithPunct", options.doNotWrapTextWithPunctuation));
		if (options.doNotUseEastAsianBreakRules) this.root.push(new OnOffElement("w:doNotUseEastAsianBreakRules", options.doNotUseEastAsianBreakRules));
		if (options.useWord2002TableStyleRules) this.root.push(new OnOffElement("w:useWord2002TableStyleRules", options.useWord2002TableStyleRules));
		if (options.growAutofit) this.root.push(new OnOffElement("w:growAutofit", options.growAutofit));
		if (options.useFELayout) this.root.push(new OnOffElement("w:useFELayout", options.useFELayout));
		if (options.useNormalStyleForList) this.root.push(new OnOffElement("w:useNormalStyleForList", options.useNormalStyleForList));
		if (options.doNotUseIndentAsNumberingTabStop) this.root.push(new OnOffElement("w:doNotUseIndentAsNumberingTabStop", options.doNotUseIndentAsNumberingTabStop));
		if (options.useAlternateEastAsianLineBreakRules) this.root.push(new OnOffElement("w:useAltKinsokuLineBreakRules", options.useAlternateEastAsianLineBreakRules));
		if (options.allowSpaceOfSameStyleInTable) this.root.push(new OnOffElement("w:allowSpaceOfSameStyleInTable", options.allowSpaceOfSameStyleInTable));
		if (options.doNotSuppressIndentation) this.root.push(new OnOffElement("w:doNotSuppressIndentation", options.doNotSuppressIndentation));
		if (options.doNotAutofitConstrainedTables) this.root.push(new OnOffElement("w:doNotAutofitConstrainedTables", options.doNotAutofitConstrainedTables));
		if (options.autofitToFirstFixedWidthCell) this.root.push(new OnOffElement("w:autofitToFirstFixedWidthCell", options.autofitToFirstFixedWidthCell));
		if (options.underlineTabInNumberingList) this.root.push(new OnOffElement("w:underlineTabInNumList", options.underlineTabInNumberingList));
		if (options.displayHangulFixedWidth) this.root.push(new OnOffElement("w:displayHangulFixedWidth", options.displayHangulFixedWidth));
		if (options.splitPgBreakAndParaMark) this.root.push(new OnOffElement("w:splitPgBreakAndParaMark", options.splitPgBreakAndParaMark));
		if (options.doNotVerticallyAlignCellWithSp) this.root.push(new OnOffElement("w:doNotVertAlignCellWithSp", options.doNotVerticallyAlignCellWithSp));
		if (options.doNotBreakConstrainedForcedTable) this.root.push(new OnOffElement("w:doNotBreakConstrainedForcedTable", options.doNotBreakConstrainedForcedTable));
		if (options.ignoreVerticalAlignmentInTextboxes) this.root.push(new OnOffElement("w:doNotVertAlignInTxbx", options.ignoreVerticalAlignmentInTextboxes));
		if (options.useAnsiKerningPairs) this.root.push(new OnOffElement("w:useAnsiKerningPairs", options.useAnsiKerningPairs));
		if (options.cachedColumnBalance) this.root.push(new OnOffElement("w:cachedColBalance", options.cachedColumnBalance));
	}
};
/**
* Settings module for WordprocessingML documents.
*
* This module provides document-level settings including compatibility,
* track changes, headers/footers, and hyphenation options.
*
* Reference: http://officeopenxml.com/WPsettings.php
*
* @module
*/
/**
* Attributes for the settings element with XML namespace declarations.
*
* Defines the XML namespaces required for the settings.xml document part.
* These namespaces enable compatibility features, markup compatibility,
* and various Office-specific extensions.
*
* @internal
*/
var SettingsAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			wpc: "xmlns:wpc",
			mc: "xmlns:mc",
			o: "xmlns:o",
			r: "xmlns:r",
			m: "xmlns:m",
			v: "xmlns:v",
			wp14: "xmlns:wp14",
			wp: "xmlns:wp",
			w10: "xmlns:w10",
			w: "xmlns:w",
			w14: "xmlns:w14",
			w15: "xmlns:w15",
			wpg: "xmlns:wpg",
			wpi: "xmlns:wpi",
			wne: "xmlns:wne",
			wps: "xmlns:wps",
			Ignorable: "mc:Ignorable"
		});
	}
};
/**
* Represents document settings in a WordprocessingML document.
*
* Settings contain document-wide configuration options such as
* compatibility mode, track changes, hyphenation, and more.
*
* Reference: http://officeopenxml.com/WPsettings.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Settings">
*   <xsd:sequence>
*     <xsd:element name="trackRevisions" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="evenAndOddHeaders" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="defaultTabStop" type="CT_TwipsMeasure" minOccurs="0"/>
*     <xsd:element name="autoHyphenation" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="consecutiveHyphenLimit" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="hyphenationZone" type="CT_TwipsMeasure" minOccurs="0"/>
*     <xsd:element name="doNotHyphenateCaps" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="updateFields" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="compat" type="CT_Compat" minOccurs="0"/>
*     <!-- Additional elements omitted for brevity -->
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Basic settings with track changes enabled
* new Settings({
*   trackRevisions: true,
*   evenAndOddHeaders: true,
* });
*
* // Settings with compatibility mode and hyphenation
* new Settings({
*   compatibility: {
*     version: 15, // Word 2013+
*   },
*   hyphenation: {
*     autoHyphenation: true,
*     consecutiveHyphenLimit: 2,
*   },
* });
* ```
*/
var Settings = class extends XmlComponent {
	constructor(options) {
		var _options$hyphenation, _options$hyphenation2, _options$hyphenation3, _options$hyphenation4, _options$compatibilit, _ref, _options$compatibilit2, _options$compatibilit3;
		super("w:settings");
		this.root.push(new SettingsAttributes({
			wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
			o: "urn:schemas-microsoft-com:office:office",
			r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
			v: "urn:schemas-microsoft-com:vml",
			wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			w10: "urn:schemas-microsoft-com:office:word",
			w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			w14: "http://schemas.microsoft.com/office/word/2010/wordml",
			w15: "http://schemas.microsoft.com/office/word/2012/wordml",
			wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			wne: "http://schemas.microsoft.com/office/word/2006/wordml",
			wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
			Ignorable: "w14 w15 wp14"
		}));
		this.root.push(new OnOffElement("w:displayBackgroundShape", true));
		if (options.trackRevisions !== void 0) this.root.push(new OnOffElement("w:trackRevisions", options.trackRevisions));
		if (options.evenAndOddHeaders !== void 0) this.root.push(new OnOffElement("w:evenAndOddHeaders", options.evenAndOddHeaders));
		if (options.updateFields !== void 0) this.root.push(new OnOffElement("w:updateFields", options.updateFields));
		if (options.defaultTabStop !== void 0) this.root.push(new NumberValueElement("w:defaultTabStop", options.defaultTabStop));
		if (((_options$hyphenation = options.hyphenation) === null || _options$hyphenation === void 0 ? void 0 : _options$hyphenation.autoHyphenation) !== void 0) this.root.push(new OnOffElement("w:autoHyphenation", options.hyphenation.autoHyphenation));
		if (((_options$hyphenation2 = options.hyphenation) === null || _options$hyphenation2 === void 0 ? void 0 : _options$hyphenation2.hyphenationZone) !== void 0) this.root.push(new NumberValueElement("w:hyphenationZone", options.hyphenation.hyphenationZone));
		if (((_options$hyphenation3 = options.hyphenation) === null || _options$hyphenation3 === void 0 ? void 0 : _options$hyphenation3.consecutiveHyphenLimit) !== void 0) this.root.push(new NumberValueElement("w:consecutiveHyphenLimit", options.hyphenation.consecutiveHyphenLimit));
		if (((_options$hyphenation4 = options.hyphenation) === null || _options$hyphenation4 === void 0 ? void 0 : _options$hyphenation4.doNotHyphenateCaps) !== void 0) this.root.push(new OnOffElement("w:doNotHyphenateCaps", options.hyphenation.doNotHyphenateCaps));
		this.root.push(new Compatibility(_objectSpread2(_objectSpread2({}, (_options$compatibilit = options.compatibility) !== null && _options$compatibilit !== void 0 ? _options$compatibilit : {}), {}, { version: (_ref = (_options$compatibilit2 = (_options$compatibilit3 = options.compatibility) === null || _options$compatibilit3 === void 0 ? void 0 : _options$compatibilit3.version) !== null && _options$compatibilit2 !== void 0 ? _options$compatibilit2 : options.compatibilityModeVersion) !== null && _ref !== void 0 ? _ref : 15 })));
	}
};
/**
* Style components module for WordprocessingML documents.
*
* Provides common elements used in style definitions.
*
* Reference: http://officeopenxml.com/WPstyleGenProps.php
*
* @module
*/
/**
* Represents component attributes with a value.
*
* @internal
*/
var ComponentAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents the name element of a style.
*
* This element specifies the display name of a style as shown in the user interface.
*
* Reference: http://officeopenxml.com/WPstyleGenProps.php
*
* @example
* ```typescript
* // Typically used internally by Style class
* new Name("Heading 1");
* ```
*/
var Name = class extends XmlComponent {
	constructor(value) {
		super("w:name");
		this.root.push(new ComponentAttributes({ val: value }));
	}
};
/**
* Represents the UI priority of a style.
*
* This element specifies the sort order priority for displaying the style in the user interface.
* Lower numbers appear first in style lists.
*
* Reference: http://officeopenxml.com/WPstyleGenProps.php
*
* @example
* ```typescript
* // Typically used internally by Style class
* new UiPriority(99);
* ```
*/
var UiPriority = class extends XmlComponent {
	constructor(value) {
		super("w:uiPriority");
		this.root.push(new ComponentAttributes({ val: decimalNumber(value) }));
	}
};
/**
* Style definition module for WordprocessingML documents.
*
* Provides base style functionality for paragraph and character styles.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* @module
*/
/**
* Represents style attributes for XML serialization.
*
* @internal
*/
var StyleAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			type: "w:type",
			styleId: "w:styleId",
			default: "w:default",
			customStyle: "w:customStyle"
		});
	}
};
/**
* Represents a base style definition in a WordprocessingML document.
*
* This is the base class for paragraph and character styles. It defines common
* style properties such as name, inheritance (basedOn), UI priority, and visibility.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Style">
*   <xsd:sequence>
*     <xsd:element name="name" type="CT_String" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="aliases" type="CT_String" minOccurs="0"/>
*     <xsd:element name="basedOn" type="CT_String" minOccurs="0"/>
*     <xsd:element name="next" type="CT_String" minOccurs="0"/>
*     <xsd:element name="link" type="CT_String" minOccurs="0"/>
*     <xsd:element name="autoRedefine" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="hidden" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="uiPriority" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="semiHidden" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="unhideWhenUsed" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="qFormat" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="locked" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="personal" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="personalCompose" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="personalReply" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="rsid" type="CT_LongHexNumber" minOccurs="0"/>
*     <xsd:element name="pPr" type="CT_PPrGeneral" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="rPr" type="CT_RPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblPr" type="CT_TblPrBase" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="trPr" type="CT_TrPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tcPr" type="CT_TcPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblStylePr" type="CT_TblStylePr" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="type" type="ST_StyleType" use="optional"/>
*   <xsd:attribute name="styleId" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="default" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="customStyle" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // This is typically extended by StyleForParagraph or StyleForCharacter
* // See those classes for usage examples
* ```
*/
var Style = class extends XmlComponent {
	constructor(attributes, options) {
		super("w:style");
		this.root.push(new StyleAttributes(attributes));
		if (options.name) this.root.push(new Name(options.name));
		if (options.basedOn) this.root.push(new StringValueElement("w:basedOn", options.basedOn));
		if (options.next) this.root.push(new StringValueElement("w:next", options.next));
		if (options.link) this.root.push(new StringValueElement("w:link", options.link));
		if (options.uiPriority !== void 0) this.root.push(new UiPriority(options.uiPriority));
		if (options.semiHidden !== void 0) this.root.push(new OnOffElement("w:semiHidden", options.semiHidden));
		if (options.unhideWhenUsed !== void 0) this.root.push(new OnOffElement("w:unhideWhenUsed", options.unhideWhenUsed));
		if (options.quickFormat !== void 0) this.root.push(new OnOffElement("w:qFormat", options.quickFormat));
	}
};
/**
* Paragraph style module for WordprocessingML documents.
*
* Paragraph styles define formatting that applies to entire paragraphs.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* @module
*/
/**
* Represents a paragraph style in a WordprocessingML document.
*
* Paragraph styles apply formatting to entire paragraphs, including both
* paragraph-level properties (spacing, alignment, indentation) and
* run-level properties (font, size, color) for text within the paragraph.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Style">
*   <xsd:sequence>
*     <!-- Style elements including pPr for paragraph properties -->
*     <xsd:element name="pPr" type="CT_PPrGeneral" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="rPr" type="CT_RPr" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="type" type="ST_StyleType" use="optional"/>
*   <xsd:attribute name="styleId" type="s:ST_String" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a custom heading style
* new StyleForParagraph({
*   id: "CustomHeading",
*   name: "Custom Heading",
*   basedOn: "Normal",
*   paragraph: {
*     spacing: { before: 240, after: 120 },
*     alignment: AlignmentType.LEFT
*   },
*   run: {
*     size: 28,
*     bold: true,
*     color: "2E74B5"
*   }
* });
* ```
*/
var StyleForParagraph = class extends Style {
	constructor(options) {
		super({
			type: "paragraph",
			styleId: options.id
		}, options);
		_defineProperty(this, "paragraphProperties", void 0);
		_defineProperty(this, "runProperties", void 0);
		this.paragraphProperties = new ParagraphProperties(options.paragraph);
		this.runProperties = new RunProperties(options.run);
		this.root.push(this.paragraphProperties);
		this.root.push(this.runProperties);
	}
};
/**
* Character style module for WordprocessingML documents.
*
* Character styles define formatting that applies to individual text runs.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* @module
*/
/**
* Represents a character style in a WordprocessingML document.
*
* Character styles apply formatting to individual runs of text within a paragraph,
* such as font, size, color, bold, italic, and other text-level formatting.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Style">
*   <xsd:sequence>
*     <!-- Style elements including rPr for run properties -->
*     <xsd:element name="rPr" type="CT_RPr" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="type" type="ST_StyleType" use="optional"/>
*   <xsd:attribute name="styleId" type="s:ST_String" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a custom character style for highlighting
* new StyleForCharacter({
*   id: "Highlight",
*   name: "Highlight Text",
*   basedOn: "DefaultParagraphFont",
*   run: {
*     color: "FF0000",
*     bold: true
*   }
* });
* ```
*/
var StyleForCharacter = class extends Style {
	constructor(options) {
		super({
			type: "character",
			styleId: options.id
		}, _objectSpread2({
			uiPriority: 99,
			unhideWhenUsed: true
		}, options));
		_defineProperty(this, "runProperties", void 0);
		this.runProperties = new RunProperties(options.run);
		this.root.push(this.runProperties);
	}
};
/**
* Default styles module for WordprocessingML documents.
*
* Provides pre-configured style classes for common document elements like headings,
* hyperlinks, and footnotes.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* @module
*/
/**
* Base class for heading styles.
*
* Provides common configuration for heading styles, including basedOn="Normal"
* and quickFormat enabled.
*
* @example
* ```typescript
* // Typically extended by specific heading classes
* new HeadingStyle({
*   id: "CustomHeading",
*   name: "Custom Heading",
*   run: { bold: true, size: 28 }
* });
* ```
*/
var HeadingStyle = class extends StyleForParagraph {
	constructor(options) {
		super(_objectSpread2({
			basedOn: "Normal",
			next: "Normal",
			quickFormat: true
		}, options));
	}
};
/**
* Represents the Title paragraph style.
*
* Used for document titles with larger font size and emphasis.
*
* @example
* ```typescript
* new TitleStyle({
*   run: { size: 56, bold: true }
* });
* ```
*/
var TitleStyle = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Title",
			name: "Title"
		}, options));
	}
};
/**
* Represents the Heading 1 paragraph style.
*
* First-level heading style for major document sections.
*
* @example
* ```typescript
* new Heading1Style({
*   run: { size: 32, color: "2E74B5" }
* });
* ```
*/
var Heading1Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading1",
			name: "Heading 1"
		}, options));
	}
};
/**
* Represents the Heading 2 paragraph style.
*
* Second-level heading style for subsections.
*/
var Heading2Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading2",
			name: "Heading 2"
		}, options));
	}
};
/**
* Represents the Heading 3 paragraph style.
*
* Third-level heading style for sub-subsections.
*/
var Heading3Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading3",
			name: "Heading 3"
		}, options));
	}
};
/**
* Represents the Heading 4 paragraph style.
*
* Fourth-level heading style for nested sections.
*/
var Heading4Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading4",
			name: "Heading 4"
		}, options));
	}
};
/**
* Represents the Heading 5 paragraph style.
*
* Fifth-level heading style for deeply nested sections.
*/
var Heading5Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading5",
			name: "Heading 5"
		}, options));
	}
};
/**
* Represents the Heading 6 paragraph style.
*
* Sixth-level heading style for the deepest nested sections.
*/
var Heading6Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading6",
			name: "Heading 6"
		}, options));
	}
};
/**
* Represents the Strong paragraph style.
*
* Used for emphasizing important paragraphs with bold formatting.
*/
var StrongStyle = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Strong",
			name: "Strong"
		}, options));
	}
};
/**
* Represents the List Paragraph style.
*
* Used for paragraphs within numbered or bulleted lists.
*/
var ListParagraph = class extends StyleForParagraph {
	constructor(options) {
		super(_objectSpread2({
			id: "ListParagraph",
			name: "List Paragraph",
			basedOn: "Normal",
			quickFormat: true
		}, options));
	}
};
/**
* Represents the Footnote Text paragraph style.
*
* Used for the text content of footnotes with smaller font size and tighter spacing.
*/
var FootnoteText = class extends StyleForParagraph {
	constructor(options) {
		super(_objectSpread2({
			id: "FootnoteText",
			name: "footnote text",
			link: "FootnoteTextChar",
			basedOn: "Normal",
			uiPriority: 99,
			semiHidden: true,
			unhideWhenUsed: true,
			paragraph: { spacing: {
				after: 0,
				line: 240,
				lineRule: LineRuleType.AUTO
			} },
			run: { size: 20 }
		}, options));
	}
};
/**
* Represents the Footnote Reference character style.
*
* Used for footnote reference numbers in the main text, displayed as superscript.
*/
var FootnoteReferenceStyle = class extends StyleForCharacter {
	constructor(options) {
		super(_objectSpread2({
			id: "FootnoteReference",
			name: "footnote reference",
			basedOn: "DefaultParagraphFont",
			semiHidden: true,
			run: { superScript: true }
		}, options));
	}
};
/**
* Represents the Footnote Text Char character style.
*
* Character style linked to FootnoteText paragraph style for consistent formatting.
*/
var FootnoteTextChar = class extends StyleForCharacter {
	constructor(options) {
		super(_objectSpread2({
			id: "FootnoteTextChar",
			name: "Footnote Text Char",
			basedOn: "DefaultParagraphFont",
			link: "FootnoteText",
			semiHidden: true,
			run: { size: 20 }
		}, options));
	}
};
/**
* Represents the Endnote Text paragraph style.
*
* Used for the text content of endnotes with smaller font size and tighter spacing.
*/
var EndnoteText = class extends StyleForParagraph {
	constructor(options) {
		super(_objectSpread2({
			id: "EndnoteText",
			name: "endnote text",
			link: "EndnoteTextChar",
			basedOn: "Normal",
			uiPriority: 99,
			semiHidden: true,
			unhideWhenUsed: true,
			paragraph: { spacing: {
				after: 0,
				line: 240,
				lineRule: LineRuleType.AUTO
			} },
			run: { size: 20 }
		}, options));
	}
};
/**
* Represents the Endnote Reference character style.
*
* Used for endnote reference numbers in the main text, displayed as superscript.
*/
var EndnoteReferenceStyle = class extends StyleForCharacter {
	constructor(options) {
		super(_objectSpread2({
			id: "EndnoteReference",
			name: "endnote reference",
			basedOn: "DefaultParagraphFont",
			semiHidden: true,
			run: { superScript: true }
		}, options));
	}
};
/**
* Represents the Endnote Text Char character style.
*
* Character style linked to EndnoteText paragraph style for consistent formatting.
*/
var EndnoteTextChar = class extends StyleForCharacter {
	constructor(options) {
		super(_objectSpread2({
			id: "EndnoteTextChar",
			name: "Endnote Text Char",
			basedOn: "DefaultParagraphFont",
			link: "EndnoteText",
			semiHidden: true,
			run: { size: 20 }
		}, options));
	}
};
/**
* Represents the Hyperlink character style.
*
* Used for hyperlinks with blue color and single underline formatting.
*/
var HyperlinkStyle = class extends StyleForCharacter {
	constructor(options) {
		super(_objectSpread2({
			id: "Hyperlink",
			name: "Hyperlink",
			basedOn: "DefaultParagraphFont",
			run: {
				color: "0563C1",
				underline: { type: UnderlineType.SINGLE }
			}
		}, options));
	}
};
/**
* Represents the styles definitions in a WordprocessingML document.
*
* The styles element contains document defaults, latent styles, and
* individual style definitions for paragraphs and characters. Styles provide
* a way to define consistent formatting across a document.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Styles">
*   <xsd:sequence>
*     <xsd:element name="docDefaults" type="CT_DocDefaults" minOccurs="0"/>
*     <xsd:element name="latentStyles" type="CT_LatentStyles" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="style" type="CT_Style" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create styles with custom paragraph and character styles
* new Styles({
*   paragraphStyles: [{
*     id: "CustomHeading",
*     name: "Custom Heading",
*     basedOn: "Normal",
*     run: { bold: true, size: 28 }
*   }],
*   characterStyles: [{
*     id: "Highlight",
*     name: "Highlight",
*     run: { color: "FF0000" }
*   }]
* });
* ```
*/
var Styles = class extends XmlComponent {
	constructor(options) {
		super("w:styles");
		if (options.initialStyles) this.root.push(options.initialStyles);
		if (options.importedStyles) for (const style of options.importedStyles) this.root.push(style);
		if (options.paragraphStyles) for (const style of options.paragraphStyles) this.root.push(new StyleForParagraph(style));
		if (options.characterStyles) for (const style of options.characterStyles) this.root.push(new StyleForCharacter(style));
	}
};
/**
* Represents default paragraph properties in a WordprocessingML document.
*
* This element defines the default paragraph formatting properties that apply
* to all paragraphs in the document unless overridden.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PPrDefault">
*   <xsd:sequence>
*     <xsd:element name="pPr" type="CT_PPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set default paragraph spacing
* new ParagraphPropertiesDefaults({
*   spacing: { after: 200, line: 276 }
* });
* ```
*/
var ParagraphPropertiesDefaults = class extends XmlComponent {
	constructor(options) {
		super("w:pPrDefault");
		this.root.push(new ParagraphProperties(options));
	}
};
/**
* Represents default run properties in a WordprocessingML document.
*
* This element defines the default text run formatting properties that apply
* to all text runs in the document unless overridden by styles or direct formatting.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_RPrDefault">
*   <xsd:sequence>
*     <xsd:element name="rPr" type="CT_RPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set default font and size
* new RunPropertiesDefaults({
*   font: "Calibri",
*   size: 22
* });
* ```
*/
var RunPropertiesDefaults = class extends XmlComponent {
	constructor(options) {
		super("w:rPrDefault");
		this.root.push(new RunProperties(options));
	}
};
/**
* Represents document-wide default formatting in a WordprocessingML document.
*
* Document defaults define the base formatting properties that apply to all
* paragraphs and runs in a document unless overridden by a style or direct formatting.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_DocDefaults">
*   <xsd:sequence>
*     <xsd:element name="rPrDefault" type="CT_RPrDefault" minOccurs="0"/>
*     <xsd:element name="pPrDefault" type="CT_PPrDefault" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set default font and spacing for the document
* new DocumentDefaults({
*   run: {
*     font: "Calibri",
*     size: 22
*   },
*   paragraph: {
*     spacing: { after: 200, line: 276 }
*   }
* });
* ```
*/
var DocumentDefaults = class extends XmlComponent {
	constructor(options) {
		super("w:docDefaults");
		_defineProperty(this, "runPropertiesDefaults", void 0);
		_defineProperty(this, "paragraphPropertiesDefaults", void 0);
		this.runPropertiesDefaults = new RunPropertiesDefaults(options.run);
		this.paragraphPropertiesDefaults = new ParagraphPropertiesDefaults(options.paragraph);
		this.root.push(this.runPropertiesDefaults);
		this.root.push(this.paragraphPropertiesDefaults);
	}
};
/**
* External styles factory module for WordprocessingML documents.
*
* Provides functionality to import and parse styles from external XML sources.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* @module
*/
/**
* Factory for creating styles from external XML sources.
*
* This factory parses styles from XML (typically from a styles.xml file)
* and converts them into Styles components that can be used in the document.
*
* @example
* ```typescript
* // Import styles from an external styles.xml file
* const factory = new ExternalStylesFactory();
* const xmlData = '<?xml version="1.0"?><w:styles>...</w:styles>';
* const styles = factory.newInstance(xmlData);
* ```
*/
var ExternalStylesFactory = class {
	/**
	* Creates new Styles based on the given XML data.
	*
	* Parses the styles XML and converts them to XmlComponent instances.
	*
	* Example content from styles.xml:
	* ```xml
	* <?xml version="1.0"?>
	* <w:styles xmlns:mc="some schema" ...>
	*   <w:style w:type="paragraph" w:styleId="Heading1">
	*     <w:name w:val="heading 1"/>
	*     ...
	*   </w:style>
	*   <w:style w:type="paragraph" w:styleId="Heading2">
	*     <w:name w:val="heading 2"/>
	*     ...
	*   </w:style>
	*   <w:docDefaults>...</w:docDefaults>
	* </w:styles>
	* ```
	*
	* @param xmlData - XML string containing styles data from styles.xml
	* @returns Styles object containing all parsed styles
	* @throws Error if styles element cannot be found in the XML
	*/
	newInstance(xmlData) {
		const xmlObj = (0, import_lib.xml2js)(xmlData, { compact: false });
		let stylesXmlElement;
		for (const xmlElm of xmlObj.elements || []) if (xmlElm.name === "w:styles") stylesXmlElement = xmlElm;
		if (stylesXmlElement === void 0) throw new Error("can not find styles element");
		const stylesElements = stylesXmlElement.elements || [];
		return {
			initialStyles: new ImportedRootElementAttributes(stylesXmlElement.attributes),
			importedStyles: stylesElements.map((childElm) => convertToXmlComponent(childElm))
		};
	}
};
/**
* Factory module for creating default document styles.
*
* Provides a factory class that creates pre-configured styles for common document elements.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* @module
*/
/**
* Factory for creating default document styles.
*
* This factory creates a complete set of default styles for common document elements
* such as headings, hyperlinks, and footnotes with sensible default formatting.
*
* @example
* ```typescript
* // Create default styles with custom heading colors
* const factory = new DefaultStylesFactory();
* const styles = factory.newInstance({
*   heading1: {
*     run: { color: "FF0000", size: 32 }
*   },
*   heading2: {
*     run: { color: "00FF00", size: 26 }
*   }
* });
* ```
*/
var DefaultStylesFactory = class {
	newInstance(options = {}) {
		var _options$document;
		return {
			initialStyles: new DocumentAttributes([
				"mc",
				"r",
				"w",
				"w14",
				"w15"
			], "w14 w15"),
			importedStyles: [
				new DocumentDefaults((_options$document = options.document) !== null && _options$document !== void 0 ? _options$document : {}),
				new TitleStyle(_objectSpread2({ run: { size: 56 } }, options.title)),
				new Heading1Style(_objectSpread2({ run: {
					color: "2E74B5",
					size: 32
				} }, options.heading1)),
				new Heading2Style(_objectSpread2({ run: {
					color: "2E74B5",
					size: 26
				} }, options.heading2)),
				new Heading3Style(_objectSpread2({ run: {
					color: "1F4D78",
					size: 24
				} }, options.heading3)),
				new Heading4Style(_objectSpread2({ run: {
					color: "2E74B5",
					italics: true
				} }, options.heading4)),
				new Heading5Style(_objectSpread2({ run: { color: "2E74B5" } }, options.heading5)),
				new Heading6Style(_objectSpread2({ run: { color: "1F4D78" } }, options.heading6)),
				new StrongStyle(_objectSpread2({ run: { bold: true } }, options.strong)),
				new ListParagraph(options.listParagraph || {}),
				new HyperlinkStyle(options.hyperlink || {}),
				new FootnoteReferenceStyle(options.footnoteReference || {}),
				new FootnoteText(options.footnoteText || {}),
				new FootnoteTextChar(options.footnoteTextChar || {}),
				new EndnoteReferenceStyle(options.endnoteReference || {}),
				new EndnoteText(options.endnoteText || {}),
				new EndnoteTextChar(options.endnoteTextChar || {})
			]
		};
	}
};
/**
* File module for WordprocessingML documents.
*
* The File class is the main entry point for creating DOCX documents.
* It manages all document parts including content, styles, numbering, and media.
*
* @module
*/
/**
* Represents a Word document file.
*
* The File class (exported as `Document`) is the main entry point for creating DOCX documents.
* It manages all document components including content, styles, numbering, headers/footers,
* and media. Documents are organized into sections, each of which can have its own page
* settings, headers, and footers.
*
* This class handles the assembly of all OOXML parts required for a valid .docx file,
* including relationships, content types, and document properties.
*
* @publicApi
*
* @example
* ```typescript
* // Simple document with one section
* const doc = new Document({
*   sections: [{
*     children: [
*       new Paragraph("Hello World"),
*     ],
*   }],
* });
*
* // Document with multiple sections and headers/footers
* const doc = new Document({
*   creator: "John Doe",
*   sections: [
*     {
*       headers: {
*         default: new Header({
*           children: [new Paragraph("Header Text")],
*         }),
*       },
*       children: [
*         new Paragraph("Section 1 content"),
*       ],
*     },
*     {
*       children: [
*         new Paragraph("Section 2 content"),
*       ],
*     },
*   ],
* });
*
* // Document with custom styles and numbering
* const doc = new Document({
*   styles: {
*     paragraphStyles: [
*       {
*         id: "MyHeading",
*         name: "My Heading",
*         basedOn: "Heading1",
*         run: { bold: true, color: "FF0000" },
*       },
*     ],
*   },
*   numbering: {
*     config: [
*       {
*         reference: "my-numbering",
*         levels: [
*           { level: 0, format: "decimal", text: "%1.", alignment: "left" },
*         ],
*       },
*     ],
*   },
*   sections: [{
*     children: [new Paragraph("Content")],
*   }],
* });
* ```
*/
var File = class {
	constructor(options) {
		var _options$creator, _options$revision, _options$lastModified, _options$comments, _options$customProper, _options$features, _options$features2, _options$hyphenation, _options$hyphenation2, _options$hyphenation3, _options$hyphenation4, _options$fonts;
		_defineProperty(this, "currentRelationshipId", 1);
		_defineProperty(this, "documentWrapper", void 0);
		_defineProperty(this, "headers", []);
		_defineProperty(this, "footers", []);
		_defineProperty(this, "coreProperties", void 0);
		_defineProperty(this, "numbering", void 0);
		_defineProperty(this, "media", void 0);
		_defineProperty(this, "fileRelationships", void 0);
		_defineProperty(this, "footnotesWrapper", void 0);
		_defineProperty(this, "endnotesWrapper", void 0);
		_defineProperty(this, "settings", void 0);
		_defineProperty(this, "contentTypes", void 0);
		_defineProperty(this, "customProperties", void 0);
		_defineProperty(this, "appProperties", void 0);
		_defineProperty(this, "styles", void 0);
		_defineProperty(this, "comments", void 0);
		_defineProperty(
			this,
			/** Extended comment data for reply threading and resolved state (word/commentsExtended.xml). */
			"commentsExtended",
			void 0
		);
		_defineProperty(this, "fontWrapper", void 0);
		this.coreProperties = new CoreProperties(_objectSpread2(_objectSpread2({}, options), {}, {
			creator: (_options$creator = options.creator) !== null && _options$creator !== void 0 ? _options$creator : "Un-named",
			revision: (_options$revision = options.revision) !== null && _options$revision !== void 0 ? _options$revision : 1,
			lastModifiedBy: (_options$lastModified = options.lastModifiedBy) !== null && _options$lastModified !== void 0 ? _options$lastModified : "Un-named"
		}));
		this.numbering = new Numbering(options.numbering ? options.numbering : { config: [] });
		this.comments = new Comments((_options$comments = options.comments) !== null && _options$comments !== void 0 ? _options$comments : { children: [] });
		if (this.comments.ThreadData) this.commentsExtended = new CommentsExtended(this.comments.ThreadData);
		this.fileRelationships = new Relationships();
		this.customProperties = new CustomProperties((_options$customProper = options.customProperties) !== null && _options$customProper !== void 0 ? _options$customProper : []);
		this.appProperties = new AppProperties();
		this.footnotesWrapper = new FootnotesWrapper();
		this.endnotesWrapper = new EndnotesWrapper();
		this.contentTypes = new ContentTypes();
		this.documentWrapper = new DocumentWrapper({ background: options.background });
		this.settings = new Settings({
			compatibilityModeVersion: options.compatabilityModeVersion,
			compatibility: options.compatibility,
			evenAndOddHeaders: options.evenAndOddHeaderAndFooters ? true : false,
			trackRevisions: (_options$features = options.features) === null || _options$features === void 0 ? void 0 : _options$features.trackRevisions,
			updateFields: (_options$features2 = options.features) === null || _options$features2 === void 0 ? void 0 : _options$features2.updateFields,
			defaultTabStop: options.defaultTabStop,
			hyphenation: {
				autoHyphenation: (_options$hyphenation = options.hyphenation) === null || _options$hyphenation === void 0 ? void 0 : _options$hyphenation.autoHyphenation,
				hyphenationZone: (_options$hyphenation2 = options.hyphenation) === null || _options$hyphenation2 === void 0 ? void 0 : _options$hyphenation2.hyphenationZone,
				consecutiveHyphenLimit: (_options$hyphenation3 = options.hyphenation) === null || _options$hyphenation3 === void 0 ? void 0 : _options$hyphenation3.consecutiveHyphenLimit,
				doNotHyphenateCaps: (_options$hyphenation4 = options.hyphenation) === null || _options$hyphenation4 === void 0 ? void 0 : _options$hyphenation4.doNotHyphenateCaps
			}
		});
		this.media = new Media();
		if (options.externalStyles !== void 0) {
			var _options$styles;
			const defaultStyles = new DefaultStylesFactory().newInstance((_options$styles = options.styles) === null || _options$styles === void 0 ? void 0 : _options$styles.default);
			const externalStyles = new ExternalStylesFactory().newInstance(options.externalStyles);
			this.styles = new Styles(_objectSpread2(_objectSpread2({}, externalStyles), {}, { importedStyles: [...defaultStyles.importedStyles, ...externalStyles.importedStyles] }));
		} else if (options.styles) {
			const defaultStyles = new DefaultStylesFactory().newInstance(options.styles.default);
			this.styles = new Styles(_objectSpread2(_objectSpread2({}, defaultStyles), options.styles));
		} else {
			const stylesFactory = new DefaultStylesFactory();
			this.styles = new Styles(stylesFactory.newInstance());
		}
		this.addDefaultRelationships();
		for (const section of options.sections) this.addSection(section);
		if (options.footnotes) for (const key in options.footnotes) this.footnotesWrapper.View.createFootNote(parseFloat(key), options.footnotes[key].children);
		if (options.endnotes) for (const key in options.endnotes) this.endnotesWrapper.View.createEndnote(parseFloat(key), options.endnotes[key].children);
		this.fontWrapper = new FontWrapper((_options$fonts = options.fonts) !== null && _options$fonts !== void 0 ? _options$fonts : []);
	}
	addSection({ headers = {}, footers = {}, children, properties }) {
		this.documentWrapper.View.Body.addSection(_objectSpread2(_objectSpread2({}, properties), {}, {
			headerWrapperGroup: {
				default: headers.default ? this.createHeader(headers.default) : void 0,
				first: headers.first ? this.createHeader(headers.first) : void 0,
				even: headers.even ? this.createHeader(headers.even) : void 0
			},
			footerWrapperGroup: {
				default: footers.default ? this.createFooter(footers.default) : void 0,
				first: footers.first ? this.createFooter(footers.first) : void 0,
				even: footers.even ? this.createFooter(footers.even) : void 0
			}
		}));
		for (const child of children) this.documentWrapper.View.add(child);
	}
	createHeader(header) {
		const wrapper = new HeaderWrapper(this.media, this.currentRelationshipId++);
		for (const child of header.options.children) wrapper.add(child);
		this.addHeaderToDocument(wrapper);
		return wrapper;
	}
	createFooter(footer) {
		const wrapper = new FooterWrapper(this.media, this.currentRelationshipId++);
		for (const child of footer.options.children) wrapper.add(child);
		this.addFooterToDocument(wrapper);
		return wrapper;
	}
	addHeaderToDocument(header, type = HeaderFooterReferenceType.DEFAULT) {
		this.headers.push({
			header,
			type
		});
		this.documentWrapper.Relationships.addRelationship(header.View.ReferenceId, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header", `header${this.headers.length}.xml`);
		this.contentTypes.addHeader(this.headers.length);
	}
	addFooterToDocument(footer, type = HeaderFooterReferenceType.DEFAULT) {
		this.footers.push({
			footer,
			type
		});
		this.documentWrapper.Relationships.addRelationship(footer.View.ReferenceId, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer", `footer${this.footers.length}.xml`);
		this.contentTypes.addFooter(this.footers.length);
	}
	addDefaultRelationships() {
		this.fileRelationships.addRelationship(1, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument", "word/document.xml");
		this.fileRelationships.addRelationship(2, "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties", "docProps/core.xml");
		this.fileRelationships.addRelationship(3, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties", "docProps/app.xml");
		this.fileRelationships.addRelationship(4, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties", "docProps/custom.xml");
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles", "styles.xml");
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering", "numbering.xml");
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes", "footnotes.xml");
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/endnotes", "endnotes.xml");
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings", "settings.xml");
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments", "comments.xml");
		if (this.commentsExtended) {
			this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.microsoft.com/office/2011/relationships/commentsExtended", "commentsExtended.xml");
			this.contentTypes.addCommentsExtended();
		}
	}
	get Document() {
		return this.documentWrapper;
	}
	get Styles() {
		return this.styles;
	}
	get CoreProperties() {
		return this.coreProperties;
	}
	get Numbering() {
		return this.numbering;
	}
	get Media() {
		return this.media;
	}
	get FileRelationships() {
		return this.fileRelationships;
	}
	get Headers() {
		return this.headers.map((item) => item.header);
	}
	get Footers() {
		return this.footers.map((item) => item.footer);
	}
	get ContentTypes() {
		return this.contentTypes;
	}
	get CustomProperties() {
		return this.customProperties;
	}
	get AppProperties() {
		return this.appProperties;
	}
	get FootNotes() {
		return this.footnotesWrapper;
	}
	get Endnotes() {
		return this.endnotesWrapper;
	}
	get Settings() {
		return this.settings;
	}
	get Comments() {
		return this.comments;
	}
	/** Extended comments part for reply threading. Undefined when no comment threads exist. */
	get CommentsExtended() {
		return this.commentsExtended;
	}
	get FontTable() {
		return this.fontWrapper;
	}
};
var require_jszip_min = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	init_dist$1();
	init_dist();
	/*!
	
	JSZip v3.10.1 - A JavaScript class for generating and reading zip files
	<http://stuartk.com/jszip>
	
	(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
	Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.
	
	JSZip uses the library pako released under the MIT license :
	https://github.com/nodeca/pako/blob/main/LICENSE
	*/
	(function(e) {
		if ("object" == typeof exports && "undefined" != typeof module) module.exports = e();
		else if ("function" == typeof define && define.amd) define([], e);
		else ("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this).JSZip = e();
	})(function() {
		return function s(a, o, h) {
			function u(r, e) {
				if (!o[r]) {
					if (!a[r]) {
						var t = "function" == typeof __require && __require;
						if (!e && t) return t(r, !0);
						if (l) return l(r, !0);
						var n = /* @__PURE__ */ new Error("Cannot find module '" + r + "'");
						throw n.code = "MODULE_NOT_FOUND", n;
					}
					var i = o[r] = { exports: {} };
					a[r][0].call(i.exports, function(e) {
						var t = a[r][1][e];
						return u(t || e);
					}, i, i.exports, s, a, o, h);
				}
				return o[r].exports;
			}
			for (var l = "function" == typeof __require && __require, e = 0; e < h.length; e++) u(h[e]);
			return u;
		}({
			1: [function(e, t, r) {
				"use strict";
				var d = e("./utils"), c = e("./support"), p = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
				r.encode = function(e) {
					for (var t, r, n, i, s, a, o, h = [], u = 0, l = e.length, f = l, c = "string" !== d.getTypeOf(e); u < e.length;) f = l - u, n = c ? (t = e[u++], r = u < l ? e[u++] : 0, u < l ? e[u++] : 0) : (t = e.charCodeAt(u++), r = u < l ? e.charCodeAt(u++) : 0, u < l ? e.charCodeAt(u++) : 0), i = t >> 2, s = (3 & t) << 4 | r >> 4, a = 1 < f ? (15 & r) << 2 | n >> 6 : 64, o = 2 < f ? 63 & n : 64, h.push(p.charAt(i) + p.charAt(s) + p.charAt(a) + p.charAt(o));
					return h.join("");
				}, r.decode = function(e) {
					var t, r, n, i, s, a, o = 0, h = 0, u = "data:";
					if (e.substr(0, u.length) === u) throw new Error("Invalid base64 input, it looks like a data url.");
					var l, f = 3 * (e = e.replace(/[^A-Za-z0-9+/=]/g, "")).length / 4;
					if (e.charAt(e.length - 1) === p.charAt(64) && f--, e.charAt(e.length - 2) === p.charAt(64) && f--, f % 1 != 0) throw new Error("Invalid base64 input, bad content length.");
					for (l = c.uint8array ? new Uint8Array(0 | f) : new Array(0 | f); o < e.length;) t = p.indexOf(e.charAt(o++)) << 2 | (i = p.indexOf(e.charAt(o++))) >> 4, r = (15 & i) << 4 | (s = p.indexOf(e.charAt(o++))) >> 2, n = (3 & s) << 6 | (a = p.indexOf(e.charAt(o++))), l[h++] = t, 64 !== s && (l[h++] = r), 64 !== a && (l[h++] = n);
					return l;
				};
			}, {
				"./support": 30,
				"./utils": 32
			}],
			2: [function(e, t, r) {
				"use strict";
				var n = e("./external"), i = e("./stream/DataWorker"), s = e("./stream/Crc32Probe"), a = e("./stream/DataLengthProbe");
				function o(e, t, r, n, i) {
					this.compressedSize = e, this.uncompressedSize = t, this.crc32 = r, this.compression = n, this.compressedContent = i;
				}
				o.prototype = {
					getContentWorker: function() {
						var e = new i(n.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")), t = this;
						return e.on("end", function() {
							if (this.streamInfo.data_length !== t.uncompressedSize) throw new Error("Bug : uncompressed data size mismatch");
						}), e;
					},
					getCompressedWorker: function() {
						return new i(n.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize", this.compressedSize).withStreamInfo("uncompressedSize", this.uncompressedSize).withStreamInfo("crc32", this.crc32).withStreamInfo("compression", this.compression);
					}
				}, o.createWorkerFrom = function(e, t, r) {
					return e.pipe(new s()).pipe(new a("uncompressedSize")).pipe(t.compressWorker(r)).pipe(new a("compressedSize")).withStreamInfo("compression", t);
				}, t.exports = o;
			}, {
				"./external": 6,
				"./stream/Crc32Probe": 25,
				"./stream/DataLengthProbe": 26,
				"./stream/DataWorker": 27
			}],
			3: [function(e, t, r) {
				"use strict";
				var n = e("./stream/GenericWorker");
				r.STORE = {
					magic: "\0\0",
					compressWorker: function() {
						return new n("STORE compression");
					},
					uncompressWorker: function() {
						return new n("STORE decompression");
					}
				}, r.DEFLATE = e("./flate");
			}, {
				"./flate": 7,
				"./stream/GenericWorker": 28
			}],
			4: [function(e, t, r) {
				"use strict";
				var n = e("./utils");
				var o = function() {
					for (var e, t = [], r = 0; r < 256; r++) {
						e = r;
						for (var n = 0; n < 8; n++) e = 1 & e ? 3988292384 ^ e >>> 1 : e >>> 1;
						t[r] = e;
					}
					return t;
				}();
				t.exports = function(e, t) {
					return void 0 !== e && e.length ? "string" !== n.getTypeOf(e) ? function(e, t, r, n) {
						var i = o, s = n + r;
						e ^= -1;
						for (var a = n; a < s; a++) e = e >>> 8 ^ i[255 & (e ^ t[a])];
						return -1 ^ e;
					}(0 | t, e, e.length, 0) : function(e, t, r, n) {
						var i = o, s = n + r;
						e ^= -1;
						for (var a = n; a < s; a++) e = e >>> 8 ^ i[255 & (e ^ t.charCodeAt(a))];
						return -1 ^ e;
					}(0 | t, e, e.length, 0) : 0;
				};
			}, { "./utils": 32 }],
			5: [function(e, t, r) {
				"use strict";
				r.base64 = !1, r.binary = !1, r.dir = !1, r.createFolders = !0, r.date = null, r.compression = null, r.compressionOptions = null, r.comment = null, r.unixPermissions = null, r.dosPermissions = null;
			}, {}],
			6: [function(e, t, r) {
				"use strict";
				var n = null;
				n = "undefined" != typeof Promise ? Promise : e("lie"), t.exports = { Promise: n };
			}, { lie: 37 }],
			7: [function(e, t, r) {
				"use strict";
				var n = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Uint32Array, i = e("pako"), s = e("./utils"), a = e("./stream/GenericWorker"), o = n ? "uint8array" : "array";
				function h(e, t) {
					a.call(this, "FlateWorker/" + e), this._pako = null, this._pakoAction = e, this._pakoOptions = t, this.meta = {};
				}
				r.magic = "\b\0", s.inherits(h, a), h.prototype.processChunk = function(e) {
					this.meta = e.meta, null === this._pako && this._createPako(), this._pako.push(s.transformTo(o, e.data), !1);
				}, h.prototype.flush = function() {
					a.prototype.flush.call(this), null === this._pako && this._createPako(), this._pako.push([], !0);
				}, h.prototype.cleanUp = function() {
					a.prototype.cleanUp.call(this), this._pako = null;
				}, h.prototype._createPako = function() {
					this._pako = new i[this._pakoAction]({
						raw: !0,
						level: this._pakoOptions.level || -1
					});
					var t = this;
					this._pako.onData = function(e) {
						t.push({
							data: e,
							meta: t.meta
						});
					};
				}, r.compressWorker = function(e) {
					return new h("Deflate", e);
				}, r.uncompressWorker = function() {
					return new h("Inflate", {});
				};
			}, {
				"./stream/GenericWorker": 28,
				"./utils": 32,
				pako: 38
			}],
			8: [function(e, t, r) {
				"use strict";
				function A(e, t) {
					var r, n = "";
					for (r = 0; r < t; r++) n += String.fromCharCode(255 & e), e >>>= 8;
					return n;
				}
				function n(e, t, r, n, i, s) {
					var a, o, h = e.file, u = e.compression, l = s !== O.utf8encode, f = I.transformTo("string", s(h.name)), c = I.transformTo("string", O.utf8encode(h.name)), d = h.comment, p = I.transformTo("string", s(d)), m = I.transformTo("string", O.utf8encode(d)), _ = c.length !== h.name.length, g = m.length !== d.length, b = "", v = "", y = "", w = h.dir, k = h.date, x = {
						crc32: 0,
						compressedSize: 0,
						uncompressedSize: 0
					};
					t && !r || (x.crc32 = e.crc32, x.compressedSize = e.compressedSize, x.uncompressedSize = e.uncompressedSize);
					var S = 0;
					t && (S |= 8), l || !_ && !g || (S |= 2048);
					var z = 0, C = 0;
					w && (z |= 16), "UNIX" === i ? (C = 798, z |= function(e, t) {
						var r = e;
						return e || (r = t ? 16893 : 33204), (65535 & r) << 16;
					}(h.unixPermissions, w)) : (C = 20, z |= function(e) {
						return 63 & (e || 0);
					}(h.dosPermissions)), a = k.getUTCHours(), a <<= 6, a |= k.getUTCMinutes(), a <<= 5, a |= k.getUTCSeconds() / 2, o = k.getUTCFullYear() - 1980, o <<= 4, o |= k.getUTCMonth() + 1, o <<= 5, o |= k.getUTCDate(), _ && (v = A(1, 1) + A(B(f), 4) + c, b += "up" + A(v.length, 2) + v), g && (y = A(1, 1) + A(B(p), 4) + m, b += "uc" + A(y.length, 2) + y);
					var E = "";
					return E += "\n\0", E += A(S, 2), E += u.magic, E += A(a, 2), E += A(o, 2), E += A(x.crc32, 4), E += A(x.compressedSize, 4), E += A(x.uncompressedSize, 4), E += A(f.length, 2), E += A(b.length, 2), {
						fileRecord: R.LOCAL_FILE_HEADER + E + f + b,
						dirRecord: R.CENTRAL_FILE_HEADER + A(C, 2) + E + A(p.length, 2) + "\0\0\0\0" + A(z, 4) + A(n, 4) + f + b + p
					};
				}
				var I = e("../utils"), i = e("../stream/GenericWorker"), O = e("../utf8"), B = e("../crc32"), R = e("../signature");
				function s(e, t, r, n) {
					i.call(this, "ZipFileWorker"), this.bytesWritten = 0, this.zipComment = t, this.zipPlatform = r, this.encodeFileName = n, this.streamFiles = e, this.accumulate = !1, this.contentBuffer = [], this.dirRecords = [], this.currentSourceOffset = 0, this.entriesCount = 0, this.currentFile = null, this._sources = [];
				}
				I.inherits(s, i), s.prototype.push = function(e) {
					var t = e.meta.percent || 0, r = this.entriesCount, n = this._sources.length;
					this.accumulate ? this.contentBuffer.push(e) : (this.bytesWritten += e.data.length, i.prototype.push.call(this, {
						data: e.data,
						meta: {
							currentFile: this.currentFile,
							percent: r ? (t + 100 * (r - n - 1)) / r : 100
						}
					}));
				}, s.prototype.openedSource = function(e) {
					this.currentSourceOffset = this.bytesWritten, this.currentFile = e.file.name;
					var t = this.streamFiles && !e.file.dir;
					if (t) {
						var r = n(e, t, !1, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
						this.push({
							data: r.fileRecord,
							meta: { percent: 0 }
						});
					} else this.accumulate = !0;
				}, s.prototype.closedSource = function(e) {
					this.accumulate = !1;
					var t = this.streamFiles && !e.file.dir, r = n(e, t, !0, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
					if (this.dirRecords.push(r.dirRecord), t) this.push({
						data: function(e) {
							return R.DATA_DESCRIPTOR + A(e.crc32, 4) + A(e.compressedSize, 4) + A(e.uncompressedSize, 4);
						}(e),
						meta: { percent: 100 }
					});
					else for (this.push({
						data: r.fileRecord,
						meta: { percent: 0 }
					}); this.contentBuffer.length;) this.push(this.contentBuffer.shift());
					this.currentFile = null;
				}, s.prototype.flush = function() {
					for (var e = this.bytesWritten, t = 0; t < this.dirRecords.length; t++) this.push({
						data: this.dirRecords[t],
						meta: { percent: 100 }
					});
					var r = this.bytesWritten - e, n = function(e, t, r, n, i) {
						var s = I.transformTo("string", i(n));
						return R.CENTRAL_DIRECTORY_END + "\0\0\0\0" + A(e, 2) + A(e, 2) + A(t, 4) + A(r, 4) + A(s.length, 2) + s;
					}(this.dirRecords.length, r, e, this.zipComment, this.encodeFileName);
					this.push({
						data: n,
						meta: { percent: 100 }
					});
				}, s.prototype.prepareNextSource = function() {
					this.previous = this._sources.shift(), this.openedSource(this.previous.streamInfo), this.isPaused ? this.previous.pause() : this.previous.resume();
				}, s.prototype.registerPrevious = function(e) {
					this._sources.push(e);
					var t = this;
					return e.on("data", function(e) {
						t.processChunk(e);
					}), e.on("end", function() {
						t.closedSource(t.previous.streamInfo), t._sources.length ? t.prepareNextSource() : t.end();
					}), e.on("error", function(e) {
						t.error(e);
					}), this;
				}, s.prototype.resume = function() {
					return !!i.prototype.resume.call(this) && (!this.previous && this._sources.length ? (this.prepareNextSource(), !0) : this.previous || this._sources.length || this.generatedError ? void 0 : (this.end(), !0));
				}, s.prototype.error = function(e) {
					var t = this._sources;
					if (!i.prototype.error.call(this, e)) return !1;
					for (var r = 0; r < t.length; r++) try {
						t[r].error(e);
					} catch (e) {}
					return !0;
				}, s.prototype.lock = function() {
					i.prototype.lock.call(this);
					for (var e = this._sources, t = 0; t < e.length; t++) e[t].lock();
				}, t.exports = s;
			}, {
				"../crc32": 4,
				"../signature": 23,
				"../stream/GenericWorker": 28,
				"../utf8": 31,
				"../utils": 32
			}],
			9: [function(e, t, r) {
				"use strict";
				var u = e("../compressions"), n = e("./ZipFileWorker");
				r.generateWorker = function(e, a, t) {
					var o = new n(a.streamFiles, t, a.platform, a.encodeFileName), h = 0;
					try {
						e.forEach(function(e, t) {
							h++;
							var r = function(e, t) {
								var r = e || t, n = u[r];
								if (!n) throw new Error(r + " is not a valid compression method !");
								return n;
							}(t.options.compression, a.compression), n = t.options.compressionOptions || a.compressionOptions || {}, i = t.dir, s = t.date;
							t._compressWorker(r, n).withStreamInfo("file", {
								name: e,
								dir: i,
								date: s,
								comment: t.comment || "",
								unixPermissions: t.unixPermissions,
								dosPermissions: t.dosPermissions
							}).pipe(o);
						}), o.entriesCount = h;
					} catch (e) {
						o.error(e);
					}
					return o;
				};
			}, {
				"../compressions": 3,
				"./ZipFileWorker": 8
			}],
			10: [function(e, t, r) {
				"use strict";
				function n() {
					if (!(this instanceof n)) return new n();
					if (arguments.length) throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");
					this.files = Object.create(null), this.comment = null, this.root = "", this.clone = function() {
						var e = new n();
						for (var t in this) "function" != typeof this[t] && (e[t] = this[t]);
						return e;
					};
				}
				(n.prototype = e("./object")).loadAsync = e("./load"), n.support = e("./support"), n.defaults = e("./defaults"), n.version = "3.10.1", n.loadAsync = function(e, t) {
					return new n().loadAsync(e, t);
				}, n.external = e("./external"), t.exports = n;
			}, {
				"./defaults": 5,
				"./external": 6,
				"./load": 11,
				"./object": 15,
				"./support": 30
			}],
			11: [function(e, t, r) {
				"use strict";
				var u = e("./utils"), i = e("./external"), n = e("./utf8"), s = e("./zipEntries"), a = e("./stream/Crc32Probe"), l = e("./nodejsUtils");
				function f(n) {
					return new i.Promise(function(e, t) {
						var r = n.decompressed.getContentWorker().pipe(new a());
						r.on("error", function(e) {
							t(e);
						}).on("end", function() {
							r.streamInfo.crc32 !== n.decompressed.crc32 ? t(/* @__PURE__ */ new Error("Corrupted zip : CRC32 mismatch")) : e();
						}).resume();
					});
				}
				t.exports = function(e, o) {
					var h = this;
					return o = u.extend(o || {}, {
						base64: !1,
						checkCRC32: !1,
						optimizedBinaryString: !1,
						createFolders: !1,
						decodeFileName: n.utf8decode
					}), l.isNode && l.isStream(e) ? i.Promise.reject(/* @__PURE__ */ new Error("JSZip can't accept a stream when loading a zip file.")) : u.prepareContent("the loaded zip file", e, !0, o.optimizedBinaryString, o.base64).then(function(e) {
						var t = new s(o);
						return t.load(e), t;
					}).then(function(e) {
						var t = [i.Promise.resolve(e)], r = e.files;
						if (o.checkCRC32) for (var n = 0; n < r.length; n++) t.push(f(r[n]));
						return i.Promise.all(t);
					}).then(function(e) {
						for (var t = e.shift(), r = t.files, n = 0; n < r.length; n++) {
							var i = r[n], s = i.fileNameStr, a = u.resolve(i.fileNameStr);
							h.file(a, i.decompressed, {
								binary: !0,
								optimizedBinaryString: !0,
								date: i.date,
								dir: i.dir,
								comment: i.fileCommentStr.length ? i.fileCommentStr : null,
								unixPermissions: i.unixPermissions,
								dosPermissions: i.dosPermissions,
								createFolders: o.createFolders
							}), i.dir || (h.file(a).unsafeOriginalName = s);
						}
						return t.zipComment.length && (h.comment = t.zipComment), h;
					});
				};
			}, {
				"./external": 6,
				"./nodejsUtils": 14,
				"./stream/Crc32Probe": 25,
				"./utf8": 31,
				"./utils": 32,
				"./zipEntries": 33
			}],
			12: [function(e, t, r) {
				"use strict";
				var n = e("../utils"), i = e("../stream/GenericWorker");
				function s(e, t) {
					i.call(this, "Nodejs stream input adapter for " + e), this._upstreamEnded = !1, this._bindStream(t);
				}
				n.inherits(s, i), s.prototype._bindStream = function(e) {
					var t = this;
					(this._stream = e).pause(), e.on("data", function(e) {
						t.push({
							data: e,
							meta: { percent: 0 }
						});
					}).on("error", function(e) {
						t.isPaused ? this.generatedError = e : t.error(e);
					}).on("end", function() {
						t.isPaused ? t._upstreamEnded = !0 : t.end();
					});
				}, s.prototype.pause = function() {
					return !!i.prototype.pause.call(this) && (this._stream.pause(), !0);
				}, s.prototype.resume = function() {
					return !!i.prototype.resume.call(this) && (this._upstreamEnded ? this.end() : this._stream.resume(), !0);
				}, t.exports = s;
			}, {
				"../stream/GenericWorker": 28,
				"../utils": 32
			}],
			13: [function(e, t, r) {
				"use strict";
				var i = e("readable-stream").Readable;
				function n(e, t, r) {
					i.call(this, t), this._helper = e;
					var n = this;
					e.on("data", function(e, t) {
						n.push(e) || n._helper.pause(), r && r(t);
					}).on("error", function(e) {
						n.emit("error", e);
					}).on("end", function() {
						n.push(null);
					});
				}
				e("../utils").inherits(n, i), n.prototype._read = function() {
					this._helper.resume();
				}, t.exports = n;
			}, {
				"../utils": 32,
				"readable-stream": 16
			}],
			14: [function(e, t, r) {
				"use strict";
				t.exports = {
					isNode: "undefined" != typeof Buffer,
					newBufferFrom: function(e, t) {
						if (Buffer.from && Buffer.from !== Uint8Array.from) return Buffer.from(e, t);
						if ("number" == typeof e) throw new Error("The \"data\" argument must not be a number");
						return new Buffer(e, t);
					},
					allocBuffer: function(e) {
						if (Buffer.alloc) return Buffer.alloc(e);
						var t = new Buffer(e);
						return t.fill(0), t;
					},
					isBuffer: function(e) {
						return Buffer.isBuffer(e);
					},
					isStream: function(e) {
						return e && "function" == typeof e.on && "function" == typeof e.pause && "function" == typeof e.resume;
					}
				};
			}, {}],
			15: [function(e, t, r) {
				"use strict";
				function s(e, t, r) {
					var n, i = u.getTypeOf(t), s = u.extend(r || {}, f);
					s.date = s.date || /* @__PURE__ */ new Date(), null !== s.compression && (s.compression = s.compression.toUpperCase()), "string" == typeof s.unixPermissions && (s.unixPermissions = parseInt(s.unixPermissions, 8)), s.unixPermissions && 16384 & s.unixPermissions && (s.dir = !0), s.dosPermissions && 16 & s.dosPermissions && (s.dir = !0), s.dir && (e = g(e)), s.createFolders && (n = _(e)) && b.call(this, n, !0);
					var a = "string" === i && !1 === s.binary && !1 === s.base64;
					r && void 0 !== r.binary || (s.binary = !a), (t instanceof c && 0 === t.uncompressedSize || s.dir || !t || 0 === t.length) && (s.base64 = !1, s.binary = !0, t = "", s.compression = "STORE", i = "string");
					var o = null;
					o = t instanceof c || t instanceof l ? t : p.isNode && p.isStream(t) ? new m(e, t) : u.prepareContent(e, t, s.binary, s.optimizedBinaryString, s.base64);
					var h = new d(e, o, s);
					this.files[e] = h;
				}
				var i = e("./utf8"), u = e("./utils"), l = e("./stream/GenericWorker"), a = e("./stream/StreamHelper"), f = e("./defaults"), c = e("./compressedObject"), d = e("./zipObject"), o = e("./generate"), p = e("./nodejsUtils"), m = e("./nodejs/NodejsStreamInputAdapter"), _ = function(e) {
					"/" === e.slice(-1) && (e = e.substring(0, e.length - 1));
					var t = e.lastIndexOf("/");
					return 0 < t ? e.substring(0, t) : "";
				}, g = function(e) {
					return "/" !== e.slice(-1) && (e += "/"), e;
				}, b = function(e, t) {
					return t = void 0 !== t ? t : f.createFolders, e = g(e), this.files[e] || s.call(this, e, null, {
						dir: !0,
						createFolders: t
					}), this.files[e];
				};
				function h(e) {
					return "[object RegExp]" === Object.prototype.toString.call(e);
				}
				t.exports = {
					load: function() {
						throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
					},
					forEach: function(e) {
						var t, r, n;
						for (t in this.files) n = this.files[t], (r = t.slice(this.root.length, t.length)) && t.slice(0, this.root.length) === this.root && e(r, n);
					},
					filter: function(r) {
						var n = [];
						return this.forEach(function(e, t) {
							r(e, t) && n.push(t);
						}), n;
					},
					file: function(e, t, r) {
						if (1 !== arguments.length) return e = this.root + e, s.call(this, e, t, r), this;
						if (h(e)) {
							var n = e;
							return this.filter(function(e, t) {
								return !t.dir && n.test(e);
							});
						}
						var i = this.files[this.root + e];
						return i && !i.dir ? i : null;
					},
					folder: function(r) {
						if (!r) return this;
						if (h(r)) return this.filter(function(e, t) {
							return t.dir && r.test(e);
						});
						var e = this.root + r, t = b.call(this, e), n = this.clone();
						return n.root = t.name, n;
					},
					remove: function(r) {
						r = this.root + r;
						var e = this.files[r];
						if (e || ("/" !== r.slice(-1) && (r += "/"), e = this.files[r]), e && !e.dir) delete this.files[r];
						else for (var t = this.filter(function(e, t) {
							return t.name.slice(0, r.length) === r;
						}), n = 0; n < t.length; n++) delete this.files[t[n].name];
						return this;
					},
					generate: function() {
						throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
					},
					generateInternalStream: function(e) {
						var t, r = {};
						try {
							if ((r = u.extend(e || {}, {
								streamFiles: !1,
								compression: "STORE",
								compressionOptions: null,
								type: "",
								platform: "DOS",
								comment: null,
								mimeType: "application/zip",
								encodeFileName: i.utf8encode
							})).type = r.type.toLowerCase(), r.compression = r.compression.toUpperCase(), "binarystring" === r.type && (r.type = "string"), !r.type) throw new Error("No output type specified.");
							u.checkSupport(r.type), "darwin" !== r.platform && "freebsd" !== r.platform && "linux" !== r.platform && "sunos" !== r.platform || (r.platform = "UNIX"), "win32" === r.platform && (r.platform = "DOS");
							var n = r.comment || this.comment || "";
							t = o.generateWorker(this, r, n);
						} catch (e) {
							(t = new l("error")).error(e);
						}
						return new a(t, r.type || "string", r.mimeType);
					},
					generateAsync: function(e, t) {
						return this.generateInternalStream(e).accumulate(t);
					},
					generateNodeStream: function(e, t) {
						return (e = e || {}).type || (e.type = "nodebuffer"), this.generateInternalStream(e).toNodejsStream(t);
					}
				};
			}, {
				"./compressedObject": 2,
				"./defaults": 5,
				"./generate": 9,
				"./nodejs/NodejsStreamInputAdapter": 12,
				"./nodejsUtils": 14,
				"./stream/GenericWorker": 28,
				"./stream/StreamHelper": 29,
				"./utf8": 31,
				"./utils": 32,
				"./zipObject": 35
			}],
			16: [function(e, t, r) {
				"use strict";
				t.exports = e("stream");
			}, { stream: void 0 }],
			17: [function(e, t, r) {
				"use strict";
				var n = e("./DataReader");
				function i(e) {
					n.call(this, e);
					for (var t = 0; t < this.data.length; t++) e[t] = 255 & e[t];
				}
				e("../utils").inherits(i, n), i.prototype.byteAt = function(e) {
					return this.data[this.zero + e];
				}, i.prototype.lastIndexOfSignature = function(e) {
					for (var t = e.charCodeAt(0), r = e.charCodeAt(1), n = e.charCodeAt(2), i = e.charCodeAt(3), s = this.length - 4; 0 <= s; --s) if (this.data[s] === t && this.data[s + 1] === r && this.data[s + 2] === n && this.data[s + 3] === i) return s - this.zero;
					return -1;
				}, i.prototype.readAndCheckSignature = function(e) {
					var t = e.charCodeAt(0), r = e.charCodeAt(1), n = e.charCodeAt(2), i = e.charCodeAt(3), s = this.readData(4);
					return t === s[0] && r === s[1] && n === s[2] && i === s[3];
				}, i.prototype.readData = function(e) {
					if (this.checkOffset(e), 0 === e) return [];
					var t = this.data.slice(this.zero + this.index, this.zero + this.index + e);
					return this.index += e, t;
				}, t.exports = i;
			}, {
				"../utils": 32,
				"./DataReader": 18
			}],
			18: [function(e, t, r) {
				"use strict";
				var n = e("../utils");
				function i(e) {
					this.data = e, this.length = e.length, this.index = 0, this.zero = 0;
				}
				i.prototype = {
					checkOffset: function(e) {
						this.checkIndex(this.index + e);
					},
					checkIndex: function(e) {
						if (this.length < this.zero + e || e < 0) throw new Error("End of data reached (data length = " + this.length + ", asked index = " + e + "). Corrupted zip ?");
					},
					setIndex: function(e) {
						this.checkIndex(e), this.index = e;
					},
					skip: function(e) {
						this.setIndex(this.index + e);
					},
					byteAt: function() {},
					readInt: function(e) {
						var t, r = 0;
						for (this.checkOffset(e), t = this.index + e - 1; t >= this.index; t--) r = (r << 8) + this.byteAt(t);
						return this.index += e, r;
					},
					readString: function(e) {
						return n.transformTo("string", this.readData(e));
					},
					readData: function() {},
					lastIndexOfSignature: function() {},
					readAndCheckSignature: function() {},
					readDate: function() {
						var e = this.readInt(4);
						return new Date(Date.UTC(1980 + (e >> 25 & 127), (e >> 21 & 15) - 1, e >> 16 & 31, e >> 11 & 31, e >> 5 & 63, (31 & e) << 1));
					}
				}, t.exports = i;
			}, { "../utils": 32 }],
			19: [function(e, t, r) {
				"use strict";
				var n = e("./Uint8ArrayReader");
				function i(e) {
					n.call(this, e);
				}
				e("../utils").inherits(i, n), i.prototype.readData = function(e) {
					this.checkOffset(e);
					var t = this.data.slice(this.zero + this.index, this.zero + this.index + e);
					return this.index += e, t;
				}, t.exports = i;
			}, {
				"../utils": 32,
				"./Uint8ArrayReader": 21
			}],
			20: [function(e, t, r) {
				"use strict";
				var n = e("./DataReader");
				function i(e) {
					n.call(this, e);
				}
				e("../utils").inherits(i, n), i.prototype.byteAt = function(e) {
					return this.data.charCodeAt(this.zero + e);
				}, i.prototype.lastIndexOfSignature = function(e) {
					return this.data.lastIndexOf(e) - this.zero;
				}, i.prototype.readAndCheckSignature = function(e) {
					return e === this.readData(4);
				}, i.prototype.readData = function(e) {
					this.checkOffset(e);
					var t = this.data.slice(this.zero + this.index, this.zero + this.index + e);
					return this.index += e, t;
				}, t.exports = i;
			}, {
				"../utils": 32,
				"./DataReader": 18
			}],
			21: [function(e, t, r) {
				"use strict";
				var n = e("./ArrayReader");
				function i(e) {
					n.call(this, e);
				}
				e("../utils").inherits(i, n), i.prototype.readData = function(e) {
					if (this.checkOffset(e), 0 === e) return /* @__PURE__ */ new Uint8Array(0);
					var t = this.data.subarray(this.zero + this.index, this.zero + this.index + e);
					return this.index += e, t;
				}, t.exports = i;
			}, {
				"../utils": 32,
				"./ArrayReader": 17
			}],
			22: [function(e, t, r) {
				"use strict";
				var n = e("../utils"), i = e("../support"), s = e("./ArrayReader"), a = e("./StringReader"), o = e("./NodeBufferReader"), h = e("./Uint8ArrayReader");
				t.exports = function(e) {
					var t = n.getTypeOf(e);
					return n.checkSupport(t), "string" !== t || i.uint8array ? "nodebuffer" === t ? new o(e) : i.uint8array ? new h(n.transformTo("uint8array", e)) : new s(n.transformTo("array", e)) : new a(e);
				};
			}, {
				"../support": 30,
				"../utils": 32,
				"./ArrayReader": 17,
				"./NodeBufferReader": 19,
				"./StringReader": 20,
				"./Uint8ArrayReader": 21
			}],
			23: [function(e, t, r) {
				"use strict";
				r.LOCAL_FILE_HEADER = "PK", r.CENTRAL_FILE_HEADER = "PK", r.CENTRAL_DIRECTORY_END = "PK", r.ZIP64_CENTRAL_DIRECTORY_LOCATOR = "PK\x07", r.ZIP64_CENTRAL_DIRECTORY_END = "PK", r.DATA_DESCRIPTOR = "PK\x07\b";
			}, {}],
			24: [function(e, t, r) {
				"use strict";
				var n = e("./GenericWorker"), i = e("../utils");
				function s(e) {
					n.call(this, "ConvertWorker to " + e), this.destType = e;
				}
				i.inherits(s, n), s.prototype.processChunk = function(e) {
					this.push({
						data: i.transformTo(this.destType, e.data),
						meta: e.meta
					});
				}, t.exports = s;
			}, {
				"../utils": 32,
				"./GenericWorker": 28
			}],
			25: [function(e, t, r) {
				"use strict";
				var n = e("./GenericWorker"), i = e("../crc32");
				function s() {
					n.call(this, "Crc32Probe"), this.withStreamInfo("crc32", 0);
				}
				e("../utils").inherits(s, n), s.prototype.processChunk = function(e) {
					this.streamInfo.crc32 = i(e.data, this.streamInfo.crc32 || 0), this.push(e);
				}, t.exports = s;
			}, {
				"../crc32": 4,
				"../utils": 32,
				"./GenericWorker": 28
			}],
			26: [function(e, t, r) {
				"use strict";
				var n = e("../utils"), i = e("./GenericWorker");
				function s(e) {
					i.call(this, "DataLengthProbe for " + e), this.propName = e, this.withStreamInfo(e, 0);
				}
				n.inherits(s, i), s.prototype.processChunk = function(e) {
					if (e) {
						var t = this.streamInfo[this.propName] || 0;
						this.streamInfo[this.propName] = t + e.data.length;
					}
					i.prototype.processChunk.call(this, e);
				}, t.exports = s;
			}, {
				"../utils": 32,
				"./GenericWorker": 28
			}],
			27: [function(e, t, r) {
				"use strict";
				var n = e("../utils"), i = e("./GenericWorker");
				function s(e) {
					i.call(this, "DataWorker");
					var t = this;
					this.dataIsReady = !1, this.index = 0, this.max = 0, this.data = null, this.type = "", this._tickScheduled = !1, e.then(function(e) {
						t.dataIsReady = !0, t.data = e, t.max = e && e.length || 0, t.type = n.getTypeOf(e), t.isPaused || t._tickAndRepeat();
					}, function(e) {
						t.error(e);
					});
				}
				n.inherits(s, i), s.prototype.cleanUp = function() {
					i.prototype.cleanUp.call(this), this.data = null;
				}, s.prototype.resume = function() {
					return !!i.prototype.resume.call(this) && (!this._tickScheduled && this.dataIsReady && (this._tickScheduled = !0, n.delay(this._tickAndRepeat, [], this)), !0);
				}, s.prototype._tickAndRepeat = function() {
					this._tickScheduled = !1, this.isPaused || this.isFinished || (this._tick(), this.isFinished || (n.delay(this._tickAndRepeat, [], this), this._tickScheduled = !0));
				}, s.prototype._tick = function() {
					if (this.isPaused || this.isFinished) return !1;
					var e = null, t = Math.min(this.max, this.index + 16384);
					if (this.index >= this.max) return this.end();
					switch (this.type) {
						case "string":
							e = this.data.substring(this.index, t);
							break;
						case "uint8array":
							e = this.data.subarray(this.index, t);
							break;
						case "array":
						case "nodebuffer": e = this.data.slice(this.index, t);
					}
					return this.index = t, this.push({
						data: e,
						meta: { percent: this.max ? this.index / this.max * 100 : 0 }
					});
				}, t.exports = s;
			}, {
				"../utils": 32,
				"./GenericWorker": 28
			}],
			28: [function(e, t, r) {
				"use strict";
				function n(e) {
					this.name = e || "default", this.streamInfo = {}, this.generatedError = null, this.extraStreamInfo = {}, this.isPaused = !0, this.isFinished = !1, this.isLocked = !1, this._listeners = {
						data: [],
						end: [],
						error: []
					}, this.previous = null;
				}
				n.prototype = {
					push: function(e) {
						this.emit("data", e);
					},
					end: function() {
						if (this.isFinished) return !1;
						this.flush();
						try {
							this.emit("end"), this.cleanUp(), this.isFinished = !0;
						} catch (e) {
							this.emit("error", e);
						}
						return !0;
					},
					error: function(e) {
						return !this.isFinished && (this.isPaused ? this.generatedError = e : (this.isFinished = !0, this.emit("error", e), this.previous && this.previous.error(e), this.cleanUp()), !0);
					},
					on: function(e, t) {
						return this._listeners[e].push(t), this;
					},
					cleanUp: function() {
						this.streamInfo = this.generatedError = this.extraStreamInfo = null, this._listeners = [];
					},
					emit: function(e, t) {
						if (this._listeners[e]) for (var r = 0; r < this._listeners[e].length; r++) this._listeners[e][r].call(this, t);
					},
					pipe: function(e) {
						return e.registerPrevious(this);
					},
					registerPrevious: function(e) {
						if (this.isLocked) throw new Error("The stream '" + this + "' has already been used.");
						this.streamInfo = e.streamInfo, this.mergeStreamInfo(), this.previous = e;
						var t = this;
						return e.on("data", function(e) {
							t.processChunk(e);
						}), e.on("end", function() {
							t.end();
						}), e.on("error", function(e) {
							t.error(e);
						}), this;
					},
					pause: function() {
						return !this.isPaused && !this.isFinished && (this.isPaused = !0, this.previous && this.previous.pause(), !0);
					},
					resume: function() {
						if (!this.isPaused || this.isFinished) return !1;
						var e = this.isPaused = !1;
						return this.generatedError && (this.error(this.generatedError), e = !0), this.previous && this.previous.resume(), !e;
					},
					flush: function() {},
					processChunk: function(e) {
						this.push(e);
					},
					withStreamInfo: function(e, t) {
						return this.extraStreamInfo[e] = t, this.mergeStreamInfo(), this;
					},
					mergeStreamInfo: function() {
						for (var e in this.extraStreamInfo) Object.prototype.hasOwnProperty.call(this.extraStreamInfo, e) && (this.streamInfo[e] = this.extraStreamInfo[e]);
					},
					lock: function() {
						if (this.isLocked) throw new Error("The stream '" + this + "' has already been used.");
						this.isLocked = !0, this.previous && this.previous.lock();
					},
					toString: function() {
						var e = "Worker " + this.name;
						return this.previous ? this.previous + " -> " + e : e;
					}
				}, t.exports = n;
			}, {}],
			29: [function(e, t, r) {
				"use strict";
				var h = e("../utils"), i = e("./ConvertWorker"), s = e("./GenericWorker"), u = e("../base64"), n = e("../support"), a = e("../external"), o = null;
				if (n.nodestream) try {
					o = e("../nodejs/NodejsStreamOutputAdapter");
				} catch (e) {}
				function l(e, o) {
					return new a.Promise(function(t, r) {
						var n = [], i = e._internalType, s = e._outputType, a = e._mimeType;
						e.on("data", function(e, t) {
							n.push(e), o && o(t);
						}).on("error", function(e) {
							n = [], r(e);
						}).on("end", function() {
							try {
								t(function(e, t, r) {
									switch (e) {
										case "blob": return h.newBlob(h.transformTo("arraybuffer", t), r);
										case "base64": return u.encode(t);
										default: return h.transformTo(e, t);
									}
								}(s, function(e, t) {
									var r, n = 0, i = null, s = 0;
									for (r = 0; r < t.length; r++) s += t[r].length;
									switch (e) {
										case "string": return t.join("");
										case "array": return Array.prototype.concat.apply([], t);
										case "uint8array":
											for (i = new Uint8Array(s), r = 0; r < t.length; r++) i.set(t[r], n), n += t[r].length;
											return i;
										case "nodebuffer": return Buffer.concat(t);
										default: throw new Error("concat : unsupported type '" + e + "'");
									}
								}(i, n), a));
							} catch (e) {
								r(e);
							}
							n = [];
						}).resume();
					});
				}
				function f(e, t, r) {
					var n = t;
					switch (t) {
						case "blob":
						case "arraybuffer":
							n = "uint8array";
							break;
						case "base64": n = "string";
					}
					try {
						this._internalType = n, this._outputType = t, this._mimeType = r, h.checkSupport(n), this._worker = e.pipe(new i(n)), e.lock();
					} catch (e) {
						this._worker = new s("error"), this._worker.error(e);
					}
				}
				f.prototype = {
					accumulate: function(e) {
						return l(this, e);
					},
					on: function(e, t) {
						var r = this;
						return "data" === e ? this._worker.on(e, function(e) {
							t.call(r, e.data, e.meta);
						}) : this._worker.on(e, function() {
							h.delay(t, arguments, r);
						}), this;
					},
					resume: function() {
						return h.delay(this._worker.resume, [], this._worker), this;
					},
					pause: function() {
						return this._worker.pause(), this;
					},
					toNodejsStream: function(e) {
						if (h.checkSupport("nodestream"), "nodebuffer" !== this._outputType) throw new Error(this._outputType + " is not supported by this method");
						return new o(this, { objectMode: "nodebuffer" !== this._outputType }, e);
					}
				}, t.exports = f;
			}, {
				"../base64": 1,
				"../external": 6,
				"../nodejs/NodejsStreamOutputAdapter": 13,
				"../support": 30,
				"../utils": 32,
				"./ConvertWorker": 24,
				"./GenericWorker": 28
			}],
			30: [function(e, t, r) {
				"use strict";
				if (r.base64 = !0, r.array = !0, r.string = !0, r.arraybuffer = "undefined" != typeof ArrayBuffer && "undefined" != typeof Uint8Array, r.nodebuffer = "undefined" != typeof Buffer, r.uint8array = "undefined" != typeof Uint8Array, "undefined" == typeof ArrayBuffer) r.blob = !1;
				else {
					var n = /* @__PURE__ */ new ArrayBuffer(0);
					try {
						r.blob = 0 === new Blob([n], { type: "application/zip" }).size;
					} catch (e) {
						try {
							var i = new (self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder)();
							i.append(n), r.blob = 0 === i.getBlob("application/zip").size;
						} catch (e) {
							r.blob = !1;
						}
					}
				}
				try {
					r.nodestream = !!e("readable-stream").Readable;
				} catch (e) {
					r.nodestream = !1;
				}
			}, { "readable-stream": 16 }],
			31: [function(e, t, s) {
				"use strict";
				for (var o = e("./utils"), h = e("./support"), r = e("./nodejsUtils"), n = e("./stream/GenericWorker"), u = new Array(256), i = 0; i < 256; i++) u[i] = 252 <= i ? 6 : 248 <= i ? 5 : 240 <= i ? 4 : 224 <= i ? 3 : 192 <= i ? 2 : 1;
				u[254] = u[254] = 1;
				function a() {
					n.call(this, "utf-8 decode"), this.leftOver = null;
				}
				function l() {
					n.call(this, "utf-8 encode");
				}
				s.utf8encode = function(e) {
					return h.nodebuffer ? r.newBufferFrom(e, "utf-8") : function(e) {
						var t, r, n, i, s, a = e.length, o = 0;
						for (i = 0; i < a; i++) 55296 == (64512 & (r = e.charCodeAt(i))) && i + 1 < a && 56320 == (64512 & (n = e.charCodeAt(i + 1))) && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++), o += r < 128 ? 1 : r < 2048 ? 2 : r < 65536 ? 3 : 4;
						for (t = h.uint8array ? new Uint8Array(o) : new Array(o), i = s = 0; s < o; i++) 55296 == (64512 & (r = e.charCodeAt(i))) && i + 1 < a && 56320 == (64512 & (n = e.charCodeAt(i + 1))) && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++), r < 128 ? t[s++] = r : (r < 2048 ? t[s++] = 192 | r >>> 6 : (r < 65536 ? t[s++] = 224 | r >>> 12 : (t[s++] = 240 | r >>> 18, t[s++] = 128 | r >>> 12 & 63), t[s++] = 128 | r >>> 6 & 63), t[s++] = 128 | 63 & r);
						return t;
					}(e);
				}, s.utf8decode = function(e) {
					return h.nodebuffer ? o.transformTo("nodebuffer", e).toString("utf-8") : function(e) {
						var t, r, n, i, s = e.length, a = new Array(2 * s);
						for (t = r = 0; t < s;) if ((n = e[t++]) < 128) a[r++] = n;
						else if (4 < (i = u[n])) a[r++] = 65533, t += i - 1;
						else {
							for (n &= 2 === i ? 31 : 3 === i ? 15 : 7; 1 < i && t < s;) n = n << 6 | 63 & e[t++], i--;
							1 < i ? a[r++] = 65533 : n < 65536 ? a[r++] = n : (n -= 65536, a[r++] = 55296 | n >> 10 & 1023, a[r++] = 56320 | 1023 & n);
						}
						return a.length !== r && (a.subarray ? a = a.subarray(0, r) : a.length = r), o.applyFromCharCode(a);
					}(e = o.transformTo(h.uint8array ? "uint8array" : "array", e));
				}, o.inherits(a, n), a.prototype.processChunk = function(e) {
					var t = o.transformTo(h.uint8array ? "uint8array" : "array", e.data);
					if (this.leftOver && this.leftOver.length) {
						if (h.uint8array) {
							var r = t;
							(t = new Uint8Array(r.length + this.leftOver.length)).set(this.leftOver, 0), t.set(r, this.leftOver.length);
						} else t = this.leftOver.concat(t);
						this.leftOver = null;
					}
					var n = function(e, t) {
						var r;
						for ((t = t || e.length) > e.length && (t = e.length), r = t - 1; 0 <= r && 128 == (192 & e[r]);) r--;
						return r < 0 ? t : 0 === r ? t : r + u[e[r]] > t ? r : t;
					}(t), i = t;
					n !== t.length && (h.uint8array ? (i = t.subarray(0, n), this.leftOver = t.subarray(n, t.length)) : (i = t.slice(0, n), this.leftOver = t.slice(n, t.length))), this.push({
						data: s.utf8decode(i),
						meta: e.meta
					});
				}, a.prototype.flush = function() {
					this.leftOver && this.leftOver.length && (this.push({
						data: s.utf8decode(this.leftOver),
						meta: {}
					}), this.leftOver = null);
				}, s.Utf8DecodeWorker = a, o.inherits(l, n), l.prototype.processChunk = function(e) {
					this.push({
						data: s.utf8encode(e.data),
						meta: e.meta
					});
				}, s.Utf8EncodeWorker = l;
			}, {
				"./nodejsUtils": 14,
				"./stream/GenericWorker": 28,
				"./support": 30,
				"./utils": 32
			}],
			32: [function(e, t, a) {
				"use strict";
				var o = e("./support"), h = e("./base64"), r = e("./nodejsUtils"), u = e("./external");
				function n(e) {
					return e;
				}
				function l(e, t) {
					for (var r = 0; r < e.length; ++r) t[r] = 255 & e.charCodeAt(r);
					return t;
				}
				e("setimmediate"), a.newBlob = function(t, r) {
					a.checkSupport("blob");
					try {
						return new Blob([t], { type: r });
					} catch (e) {
						try {
							var n = new (self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder)();
							return n.append(t), n.getBlob(r);
						} catch (e) {
							throw new Error("Bug : can't construct the Blob.");
						}
					}
				};
				var i = {
					stringifyByChunk: function(e, t, r) {
						var n = [], i = 0, s = e.length;
						if (s <= r) return String.fromCharCode.apply(null, e);
						for (; i < s;) "array" === t || "nodebuffer" === t ? n.push(String.fromCharCode.apply(null, e.slice(i, Math.min(i + r, s)))) : n.push(String.fromCharCode.apply(null, e.subarray(i, Math.min(i + r, s)))), i += r;
						return n.join("");
					},
					stringifyByChar: function(e) {
						for (var t = "", r = 0; r < e.length; r++) t += String.fromCharCode(e[r]);
						return t;
					},
					applyCanBeUsed: {
						uint8array: function() {
							try {
								return o.uint8array && 1 === String.fromCharCode.apply(null, /* @__PURE__ */ new Uint8Array(1)).length;
							} catch (e) {
								return !1;
							}
						}(),
						nodebuffer: function() {
							try {
								return o.nodebuffer && 1 === String.fromCharCode.apply(null, r.allocBuffer(1)).length;
							} catch (e) {
								return !1;
							}
						}()
					}
				};
				function s(e) {
					var t = 65536, r = a.getTypeOf(e), n = !0;
					if ("uint8array" === r ? n = i.applyCanBeUsed.uint8array : "nodebuffer" === r && (n = i.applyCanBeUsed.nodebuffer), n) for (; 1 < t;) try {
						return i.stringifyByChunk(e, r, t);
					} catch (e) {
						t = Math.floor(t / 2);
					}
					return i.stringifyByChar(e);
				}
				function f(e, t) {
					for (var r = 0; r < e.length; r++) t[r] = e[r];
					return t;
				}
				a.applyFromCharCode = s;
				var c = {};
				c.string = {
					string: n,
					array: function(e) {
						return l(e, new Array(e.length));
					},
					arraybuffer: function(e) {
						return c.string.uint8array(e).buffer;
					},
					uint8array: function(e) {
						return l(e, new Uint8Array(e.length));
					},
					nodebuffer: function(e) {
						return l(e, r.allocBuffer(e.length));
					}
				}, c.array = {
					string: s,
					array: n,
					arraybuffer: function(e) {
						return new Uint8Array(e).buffer;
					},
					uint8array: function(e) {
						return new Uint8Array(e);
					},
					nodebuffer: function(e) {
						return r.newBufferFrom(e);
					}
				}, c.arraybuffer = {
					string: function(e) {
						return s(new Uint8Array(e));
					},
					array: function(e) {
						return f(new Uint8Array(e), new Array(e.byteLength));
					},
					arraybuffer: n,
					uint8array: function(e) {
						return new Uint8Array(e);
					},
					nodebuffer: function(e) {
						return r.newBufferFrom(new Uint8Array(e));
					}
				}, c.uint8array = {
					string: s,
					array: function(e) {
						return f(e, new Array(e.length));
					},
					arraybuffer: function(e) {
						return e.buffer;
					},
					uint8array: n,
					nodebuffer: function(e) {
						return r.newBufferFrom(e);
					}
				}, c.nodebuffer = {
					string: s,
					array: function(e) {
						return f(e, new Array(e.length));
					},
					arraybuffer: function(e) {
						return c.nodebuffer.uint8array(e).buffer;
					},
					uint8array: function(e) {
						return f(e, new Uint8Array(e.length));
					},
					nodebuffer: n
				}, a.transformTo = function(e, t) {
					if (t = t || "", !e) return t;
					a.checkSupport(e);
					return c[a.getTypeOf(t)][e](t);
				}, a.resolve = function(e) {
					for (var t = e.split("/"), r = [], n = 0; n < t.length; n++) {
						var i = t[n];
						"." === i || "" === i && 0 !== n && n !== t.length - 1 || (".." === i ? r.pop() : r.push(i));
					}
					return r.join("/");
				}, a.getTypeOf = function(e) {
					return "string" == typeof e ? "string" : "[object Array]" === Object.prototype.toString.call(e) ? "array" : o.nodebuffer && r.isBuffer(e) ? "nodebuffer" : o.uint8array && e instanceof Uint8Array ? "uint8array" : o.arraybuffer && e instanceof ArrayBuffer ? "arraybuffer" : void 0;
				}, a.checkSupport = function(e) {
					if (!o[e.toLowerCase()]) throw new Error(e + " is not supported by this platform");
				}, a.MAX_VALUE_16BITS = 65535, a.MAX_VALUE_32BITS = -1, a.pretty = function(e) {
					var t, r, n = "";
					for (r = 0; r < (e || "").length; r++) n += "\\x" + ((t = e.charCodeAt(r)) < 16 ? "0" : "") + t.toString(16).toUpperCase();
					return n;
				}, a.delay = function(e, t, r) {
					setImmediate(function() {
						e.apply(r || null, t || []);
					});
				}, a.inherits = function(e, t) {
					function r() {}
					r.prototype = t.prototype, e.prototype = new r();
				}, a.extend = function() {
					var e, t, r = {};
					for (e = 0; e < arguments.length; e++) for (t in arguments[e]) Object.prototype.hasOwnProperty.call(arguments[e], t) && void 0 === r[t] && (r[t] = arguments[e][t]);
					return r;
				}, a.prepareContent = function(r, e, n, i, s) {
					return u.Promise.resolve(e).then(function(n) {
						return o.blob && (n instanceof Blob || -1 !== ["[object File]", "[object Blob]"].indexOf(Object.prototype.toString.call(n))) && "undefined" != typeof FileReader ? new u.Promise(function(t, r) {
							var e = new FileReader();
							e.onload = function(e) {
								t(e.target.result);
							}, e.onerror = function(e) {
								r(e.target.error);
							}, e.readAsArrayBuffer(n);
						}) : n;
					}).then(function(e) {
						var t = a.getTypeOf(e);
						return t ? ("arraybuffer" === t ? e = a.transformTo("uint8array", e) : "string" === t && (s ? e = h.decode(e) : n && !0 !== i && (e = function(e) {
							return l(e, o.uint8array ? new Uint8Array(e.length) : new Array(e.length));
						}(e))), e) : u.Promise.reject(/* @__PURE__ */ new Error("Can't read the data of '" + r + "'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"));
					});
				};
			}, {
				"./base64": 1,
				"./external": 6,
				"./nodejsUtils": 14,
				"./support": 30,
				setimmediate: 54
			}],
			33: [function(e, t, r) {
				"use strict";
				var n = e("./reader/readerFor"), i = e("./utils"), s = e("./signature"), a = e("./zipEntry"), o = e("./support");
				function h(e) {
					this.files = [], this.loadOptions = e;
				}
				h.prototype = {
					checkSignature: function(e) {
						if (!this.reader.readAndCheckSignature(e)) {
							this.reader.index -= 4;
							var t = this.reader.readString(4);
							throw new Error("Corrupted zip or bug: unexpected signature (" + i.pretty(t) + ", expected " + i.pretty(e) + ")");
						}
					},
					isSignature: function(e, t) {
						var r = this.reader.index;
						this.reader.setIndex(e);
						var n = this.reader.readString(4) === t;
						return this.reader.setIndex(r), n;
					},
					readBlockEndOfCentral: function() {
						this.diskNumber = this.reader.readInt(2), this.diskWithCentralDirStart = this.reader.readInt(2), this.centralDirRecordsOnThisDisk = this.reader.readInt(2), this.centralDirRecords = this.reader.readInt(2), this.centralDirSize = this.reader.readInt(4), this.centralDirOffset = this.reader.readInt(4), this.zipCommentLength = this.reader.readInt(2);
						var e = this.reader.readData(this.zipCommentLength), t = o.uint8array ? "uint8array" : "array", r = i.transformTo(t, e);
						this.zipComment = this.loadOptions.decodeFileName(r);
					},
					readBlockZip64EndOfCentral: function() {
						this.zip64EndOfCentralSize = this.reader.readInt(8), this.reader.skip(4), this.diskNumber = this.reader.readInt(4), this.diskWithCentralDirStart = this.reader.readInt(4), this.centralDirRecordsOnThisDisk = this.reader.readInt(8), this.centralDirRecords = this.reader.readInt(8), this.centralDirSize = this.reader.readInt(8), this.centralDirOffset = this.reader.readInt(8), this.zip64ExtensibleData = {};
						for (var e, t, r, n = this.zip64EndOfCentralSize - 44; 0 < n;) e = this.reader.readInt(2), t = this.reader.readInt(4), r = this.reader.readData(t), this.zip64ExtensibleData[e] = {
							id: e,
							length: t,
							value: r
						};
					},
					readBlockZip64EndOfCentralLocator: function() {
						if (this.diskWithZip64CentralDirStart = this.reader.readInt(4), this.relativeOffsetEndOfZip64CentralDir = this.reader.readInt(8), this.disksCount = this.reader.readInt(4), 1 < this.disksCount) throw new Error("Multi-volumes zip are not supported");
					},
					readLocalFiles: function() {
						var e, t;
						for (e = 0; e < this.files.length; e++) t = this.files[e], this.reader.setIndex(t.localHeaderOffset), this.checkSignature(s.LOCAL_FILE_HEADER), t.readLocalPart(this.reader), t.handleUTF8(), t.processAttributes();
					},
					readCentralDir: function() {
						var e;
						for (this.reader.setIndex(this.centralDirOffset); this.reader.readAndCheckSignature(s.CENTRAL_FILE_HEADER);) (e = new a({ zip64: this.zip64 }, this.loadOptions)).readCentralPart(this.reader), this.files.push(e);
						if (this.centralDirRecords !== this.files.length && 0 !== this.centralDirRecords && 0 === this.files.length) throw new Error("Corrupted zip or bug: expected " + this.centralDirRecords + " records in central dir, got " + this.files.length);
					},
					readEndOfCentral: function() {
						var e = this.reader.lastIndexOfSignature(s.CENTRAL_DIRECTORY_END);
						if (e < 0) throw !this.isSignature(0, s.LOCAL_FILE_HEADER) ? /* @__PURE__ */ new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html") : /* @__PURE__ */ new Error("Corrupted zip: can't find end of central directory");
						this.reader.setIndex(e);
						var t = e;
						if (this.checkSignature(s.CENTRAL_DIRECTORY_END), this.readBlockEndOfCentral(), this.diskNumber === i.MAX_VALUE_16BITS || this.diskWithCentralDirStart === i.MAX_VALUE_16BITS || this.centralDirRecordsOnThisDisk === i.MAX_VALUE_16BITS || this.centralDirRecords === i.MAX_VALUE_16BITS || this.centralDirSize === i.MAX_VALUE_32BITS || this.centralDirOffset === i.MAX_VALUE_32BITS) {
							if (this.zip64 = !0, (e = this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR)) < 0) throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");
							if (this.reader.setIndex(e), this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR), this.readBlockZip64EndOfCentralLocator(), !this.isSignature(this.relativeOffsetEndOfZip64CentralDir, s.ZIP64_CENTRAL_DIRECTORY_END) && (this.relativeOffsetEndOfZip64CentralDir = this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_END), this.relativeOffsetEndOfZip64CentralDir < 0)) throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");
							this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir), this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_END), this.readBlockZip64EndOfCentral();
						}
						var r = this.centralDirOffset + this.centralDirSize;
						this.zip64 && (r += 20, r += 12 + this.zip64EndOfCentralSize);
						var n = t - r;
						if (0 < n) this.isSignature(t, s.CENTRAL_FILE_HEADER) || (this.reader.zero = n);
						else if (n < 0) throw new Error("Corrupted zip: missing " + Math.abs(n) + " bytes.");
					},
					prepareReader: function(e) {
						this.reader = n(e);
					},
					load: function(e) {
						this.prepareReader(e), this.readEndOfCentral(), this.readCentralDir(), this.readLocalFiles();
					}
				}, t.exports = h;
			}, {
				"./reader/readerFor": 22,
				"./signature": 23,
				"./support": 30,
				"./utils": 32,
				"./zipEntry": 34
			}],
			34: [function(e, t, r) {
				"use strict";
				var n = e("./reader/readerFor"), s = e("./utils"), i = e("./compressedObject"), a = e("./crc32"), o = e("./utf8"), h = e("./compressions"), u = e("./support");
				function l(e, t) {
					this.options = e, this.loadOptions = t;
				}
				l.prototype = {
					isEncrypted: function() {
						return 1 == (1 & this.bitFlag);
					},
					useUTF8: function() {
						return 2048 == (2048 & this.bitFlag);
					},
					readLocalPart: function(e) {
						var t, r;
						if (e.skip(22), this.fileNameLength = e.readInt(2), r = e.readInt(2), this.fileName = e.readData(this.fileNameLength), e.skip(r), -1 === this.compressedSize || -1 === this.uncompressedSize) throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");
						if (null === (t = function(e) {
							for (var t in h) if (Object.prototype.hasOwnProperty.call(h, t) && h[t].magic === e) return h[t];
							return null;
						}(this.compressionMethod))) throw new Error("Corrupted zip : compression " + s.pretty(this.compressionMethod) + " unknown (inner file : " + s.transformTo("string", this.fileName) + ")");
						this.decompressed = new i(this.compressedSize, this.uncompressedSize, this.crc32, t, e.readData(this.compressedSize));
					},
					readCentralPart: function(e) {
						this.versionMadeBy = e.readInt(2), e.skip(2), this.bitFlag = e.readInt(2), this.compressionMethod = e.readString(2), this.date = e.readDate(), this.crc32 = e.readInt(4), this.compressedSize = e.readInt(4), this.uncompressedSize = e.readInt(4);
						var t = e.readInt(2);
						if (this.extraFieldsLength = e.readInt(2), this.fileCommentLength = e.readInt(2), this.diskNumberStart = e.readInt(2), this.internalFileAttributes = e.readInt(2), this.externalFileAttributes = e.readInt(4), this.localHeaderOffset = e.readInt(4), this.isEncrypted()) throw new Error("Encrypted zip are not supported");
						e.skip(t), this.readExtraFields(e), this.parseZIP64ExtraField(e), this.fileComment = e.readData(this.fileCommentLength);
					},
					processAttributes: function() {
						this.unixPermissions = null, this.dosPermissions = null;
						var e = this.versionMadeBy >> 8;
						this.dir = !!(16 & this.externalFileAttributes), 0 == e && (this.dosPermissions = 63 & this.externalFileAttributes), 3 == e && (this.unixPermissions = this.externalFileAttributes >> 16 & 65535), this.dir || "/" !== this.fileNameStr.slice(-1) || (this.dir = !0);
					},
					parseZIP64ExtraField: function() {
						if (this.extraFields[1]) {
							var e = n(this.extraFields[1].value);
							this.uncompressedSize === s.MAX_VALUE_32BITS && (this.uncompressedSize = e.readInt(8)), this.compressedSize === s.MAX_VALUE_32BITS && (this.compressedSize = e.readInt(8)), this.localHeaderOffset === s.MAX_VALUE_32BITS && (this.localHeaderOffset = e.readInt(8)), this.diskNumberStart === s.MAX_VALUE_32BITS && (this.diskNumberStart = e.readInt(4));
						}
					},
					readExtraFields: function(e) {
						var t, r, n, i = e.index + this.extraFieldsLength;
						for (this.extraFields || (this.extraFields = {}); e.index + 4 < i;) t = e.readInt(2), r = e.readInt(2), n = e.readData(r), this.extraFields[t] = {
							id: t,
							length: r,
							value: n
						};
						e.setIndex(i);
					},
					handleUTF8: function() {
						var e = u.uint8array ? "uint8array" : "array";
						if (this.useUTF8()) this.fileNameStr = o.utf8decode(this.fileName), this.fileCommentStr = o.utf8decode(this.fileComment);
						else {
							var t = this.findExtraFieldUnicodePath();
							if (null !== t) this.fileNameStr = t;
							else {
								var r = s.transformTo(e, this.fileName);
								this.fileNameStr = this.loadOptions.decodeFileName(r);
							}
							var n = this.findExtraFieldUnicodeComment();
							if (null !== n) this.fileCommentStr = n;
							else {
								var i = s.transformTo(e, this.fileComment);
								this.fileCommentStr = this.loadOptions.decodeFileName(i);
							}
						}
					},
					findExtraFieldUnicodePath: function() {
						var e = this.extraFields[28789];
						if (e) {
							var t = n(e.value);
							return 1 !== t.readInt(1) ? null : a(this.fileName) !== t.readInt(4) ? null : o.utf8decode(t.readData(e.length - 5));
						}
						return null;
					},
					findExtraFieldUnicodeComment: function() {
						var e = this.extraFields[25461];
						if (e) {
							var t = n(e.value);
							return 1 !== t.readInt(1) ? null : a(this.fileComment) !== t.readInt(4) ? null : o.utf8decode(t.readData(e.length - 5));
						}
						return null;
					}
				}, t.exports = l;
			}, {
				"./compressedObject": 2,
				"./compressions": 3,
				"./crc32": 4,
				"./reader/readerFor": 22,
				"./support": 30,
				"./utf8": 31,
				"./utils": 32
			}],
			35: [function(e, t, r) {
				"use strict";
				function n(e, t, r) {
					this.name = e, this.dir = r.dir, this.date = r.date, this.comment = r.comment, this.unixPermissions = r.unixPermissions, this.dosPermissions = r.dosPermissions, this._data = t, this._dataBinary = r.binary, this.options = {
						compression: r.compression,
						compressionOptions: r.compressionOptions
					};
				}
				var s = e("./stream/StreamHelper"), i = e("./stream/DataWorker"), a = e("./utf8"), o = e("./compressedObject"), h = e("./stream/GenericWorker");
				n.prototype = {
					internalStream: function(e) {
						var t = null, r = "string";
						try {
							if (!e) throw new Error("No output type specified.");
							var n = "string" === (r = e.toLowerCase()) || "text" === r;
							"binarystring" !== r && "text" !== r || (r = "string"), t = this._decompressWorker();
							var i = !this._dataBinary;
							i && !n && (t = t.pipe(new a.Utf8EncodeWorker())), !i && n && (t = t.pipe(new a.Utf8DecodeWorker()));
						} catch (e) {
							(t = new h("error")).error(e);
						}
						return new s(t, r, "");
					},
					async: function(e, t) {
						return this.internalStream(e).accumulate(t);
					},
					nodeStream: function(e, t) {
						return this.internalStream(e || "nodebuffer").toNodejsStream(t);
					},
					_compressWorker: function(e, t) {
						if (this._data instanceof o && this._data.compression.magic === e.magic) return this._data.getCompressedWorker();
						var r = this._decompressWorker();
						return this._dataBinary || (r = r.pipe(new a.Utf8EncodeWorker())), o.createWorkerFrom(r, e, t);
					},
					_decompressWorker: function() {
						return this._data instanceof o ? this._data.getContentWorker() : this._data instanceof h ? this._data : new i(this._data);
					}
				};
				for (var u = [
					"asText",
					"asBinary",
					"asNodeBuffer",
					"asUint8Array",
					"asArrayBuffer"
				], l = function() {
					throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
				}, f = 0; f < u.length; f++) n.prototype[u[f]] = l;
				t.exports = n;
			}, {
				"./compressedObject": 2,
				"./stream/DataWorker": 27,
				"./stream/GenericWorker": 28,
				"./stream/StreamHelper": 29,
				"./utf8": 31
			}],
			36: [function(e, l, t) {
				(function(t) {
					"use strict";
					var r, n, e = t.MutationObserver || t.WebKitMutationObserver;
					if (e) {
						var i = 0, s = new e(u), a = t.document.createTextNode("");
						s.observe(a, { characterData: !0 }), r = function() {
							a.data = i = ++i % 2;
						};
					} else if (t.setImmediate || void 0 === t.MessageChannel) r = "document" in t && "onreadystatechange" in t.document.createElement("script") ? function() {
						var e = t.document.createElement("script");
						e.onreadystatechange = function() {
							u(), e.onreadystatechange = null, e.parentNode.removeChild(e), e = null;
						}, t.document.documentElement.appendChild(e);
					} : function() {
						setTimeout(u, 0);
					};
					else {
						var o = new t.MessageChannel();
						o.port1.onmessage = u, r = function() {
							o.port2.postMessage(0);
						};
					}
					var h = [];
					function u() {
						var e, t;
						n = !0;
						for (var r = h.length; r;) {
							for (t = h, h = [], e = -1; ++e < r;) t[e]();
							r = h.length;
						}
						n = !1;
					}
					l.exports = function(e) {
						1 !== h.push(e) || n || r();
					};
				}).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
			}, {}],
			37: [function(e, t, r) {
				"use strict";
				var i = e("immediate");
				function u() {}
				var l = {}, s = ["REJECTED"], a = ["FULFILLED"], n = ["PENDING"];
				function o(e) {
					if ("function" != typeof e) throw new TypeError("resolver must be a function");
					this.state = n, this.queue = [], this.outcome = void 0, e !== u && d(this, e);
				}
				function h(e, t, r) {
					this.promise = e, "function" == typeof t && (this.onFulfilled = t, this.callFulfilled = this.otherCallFulfilled), "function" == typeof r && (this.onRejected = r, this.callRejected = this.otherCallRejected);
				}
				function f(t, r, n) {
					i(function() {
						var e;
						try {
							e = r(n);
						} catch (e) {
							return l.reject(t, e);
						}
						e === t ? l.reject(t, /* @__PURE__ */ new TypeError("Cannot resolve promise with itself")) : l.resolve(t, e);
					});
				}
				function c(e) {
					var t = e && e.then;
					if (e && ("object" == typeof e || "function" == typeof e) && "function" == typeof t) return function() {
						t.apply(e, arguments);
					};
				}
				function d(t, e) {
					var r = !1;
					function n(e) {
						r || (r = !0, l.reject(t, e));
					}
					function i(e) {
						r || (r = !0, l.resolve(t, e));
					}
					var s = p(function() {
						e(i, n);
					});
					"error" === s.status && n(s.value);
				}
				function p(e, t) {
					var r = {};
					try {
						r.value = e(t), r.status = "success";
					} catch (e) {
						r.status = "error", r.value = e;
					}
					return r;
				}
				(t.exports = o).prototype.finally = function(t) {
					if ("function" != typeof t) return this;
					var r = this.constructor;
					return this.then(function(e) {
						return r.resolve(t()).then(function() {
							return e;
						});
					}, function(e) {
						return r.resolve(t()).then(function() {
							throw e;
						});
					});
				}, o.prototype.catch = function(e) {
					return this.then(null, e);
				}, o.prototype.then = function(e, t) {
					if ("function" != typeof e && this.state === a || "function" != typeof t && this.state === s) return this;
					var r = new this.constructor(u);
					this.state !== n ? f(r, this.state === a ? e : t, this.outcome) : this.queue.push(new h(r, e, t));
					return r;
				}, h.prototype.callFulfilled = function(e) {
					l.resolve(this.promise, e);
				}, h.prototype.otherCallFulfilled = function(e) {
					f(this.promise, this.onFulfilled, e);
				}, h.prototype.callRejected = function(e) {
					l.reject(this.promise, e);
				}, h.prototype.otherCallRejected = function(e) {
					f(this.promise, this.onRejected, e);
				}, l.resolve = function(e, t) {
					var r = p(c, t);
					if ("error" === r.status) return l.reject(e, r.value);
					var n = r.value;
					if (n) d(e, n);
					else {
						e.state = a, e.outcome = t;
						for (var i = -1, s = e.queue.length; ++i < s;) e.queue[i].callFulfilled(t);
					}
					return e;
				}, l.reject = function(e, t) {
					e.state = s, e.outcome = t;
					for (var r = -1, n = e.queue.length; ++r < n;) e.queue[r].callRejected(t);
					return e;
				}, o.resolve = function(e) {
					if (e instanceof this) return e;
					return l.resolve(new this(u), e);
				}, o.reject = function(e) {
					var t = new this(u);
					return l.reject(t, e);
				}, o.all = function(e) {
					var r = this;
					if ("[object Array]" !== Object.prototype.toString.call(e)) return this.reject(/* @__PURE__ */ new TypeError("must be an array"));
					var n = e.length, i = !1;
					if (!n) return this.resolve([]);
					var s = new Array(n), a = 0, t = -1, o = new this(u);
					for (; ++t < n;) h(e[t], t);
					return o;
					function h(e, t) {
						r.resolve(e).then(function(e) {
							s[t] = e, ++a !== n || i || (i = !0, l.resolve(o, s));
						}, function(e) {
							i || (i = !0, l.reject(o, e));
						});
					}
				}, o.race = function(e) {
					var t = this;
					if ("[object Array]" !== Object.prototype.toString.call(e)) return this.reject(/* @__PURE__ */ new TypeError("must be an array"));
					var r = e.length, n = !1;
					if (!r) return this.resolve([]);
					var i = -1, s = new this(u);
					for (; ++i < r;) a = e[i], t.resolve(a).then(function(e) {
						n || (n = !0, l.resolve(s, e));
					}, function(e) {
						n || (n = !0, l.reject(s, e));
					});
					var a;
					return s;
				};
			}, { immediate: 36 }],
			38: [function(e, t, r) {
				"use strict";
				var n = {};
				(0, e("./lib/utils/common").assign)(n, e("./lib/deflate"), e("./lib/inflate"), e("./lib/zlib/constants")), t.exports = n;
			}, {
				"./lib/deflate": 39,
				"./lib/inflate": 40,
				"./lib/utils/common": 41,
				"./lib/zlib/constants": 44
			}],
			39: [function(e, t, r) {
				"use strict";
				var a = e("./zlib/deflate"), o = e("./utils/common"), h = e("./utils/strings"), i = e("./zlib/messages"), s = e("./zlib/zstream"), u = Object.prototype.toString, l = 0, f = -1, c = 0, d = 8;
				function p(e) {
					if (!(this instanceof p)) return new p(e);
					this.options = o.assign({
						level: f,
						method: d,
						chunkSize: 16384,
						windowBits: 15,
						memLevel: 8,
						strategy: c,
						to: ""
					}, e || {});
					var t = this.options;
					t.raw && 0 < t.windowBits ? t.windowBits = -t.windowBits : t.gzip && 0 < t.windowBits && t.windowBits < 16 && (t.windowBits += 16), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new s(), this.strm.avail_out = 0;
					var r = a.deflateInit2(this.strm, t.level, t.method, t.windowBits, t.memLevel, t.strategy);
					if (r !== l) throw new Error(i[r]);
					if (t.header && a.deflateSetHeader(this.strm, t.header), t.dictionary) {
						var n;
						if (n = "string" == typeof t.dictionary ? h.string2buf(t.dictionary) : "[object ArrayBuffer]" === u.call(t.dictionary) ? new Uint8Array(t.dictionary) : t.dictionary, (r = a.deflateSetDictionary(this.strm, n)) !== l) throw new Error(i[r]);
						this._dict_set = !0;
					}
				}
				function n(e, t) {
					var r = new p(t);
					if (r.push(e, !0), r.err) throw r.msg || i[r.err];
					return r.result;
				}
				p.prototype.push = function(e, t) {
					var r, n, i = this.strm, s = this.options.chunkSize;
					if (this.ended) return !1;
					n = t === ~~t ? t : !0 === t ? 4 : 0, "string" == typeof e ? i.input = h.string2buf(e) : "[object ArrayBuffer]" === u.call(e) ? i.input = new Uint8Array(e) : i.input = e, i.next_in = 0, i.avail_in = i.input.length;
					do {
						if (0 === i.avail_out && (i.output = new o.Buf8(s), i.next_out = 0, i.avail_out = s), 1 !== (r = a.deflate(i, n)) && r !== l) return this.onEnd(r), !(this.ended = !0);
						0 !== i.avail_out && (0 !== i.avail_in || 4 !== n && 2 !== n) || ("string" === this.options.to ? this.onData(h.buf2binstring(o.shrinkBuf(i.output, i.next_out))) : this.onData(o.shrinkBuf(i.output, i.next_out)));
					} while ((0 < i.avail_in || 0 === i.avail_out) && 1 !== r);
					return 4 === n ? (r = a.deflateEnd(this.strm), this.onEnd(r), this.ended = !0, r === l) : 2 !== n || (this.onEnd(l), !(i.avail_out = 0));
				}, p.prototype.onData = function(e) {
					this.chunks.push(e);
				}, p.prototype.onEnd = function(e) {
					e === l && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = o.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
				}, r.Deflate = p, r.deflate = n, r.deflateRaw = function(e, t) {
					return (t = t || {}).raw = !0, n(e, t);
				}, r.gzip = function(e, t) {
					return (t = t || {}).gzip = !0, n(e, t);
				};
			}, {
				"./utils/common": 41,
				"./utils/strings": 42,
				"./zlib/deflate": 46,
				"./zlib/messages": 51,
				"./zlib/zstream": 53
			}],
			40: [function(e, t, r) {
				"use strict";
				var c = e("./zlib/inflate"), d = e("./utils/common"), p = e("./utils/strings"), m = e("./zlib/constants"), n = e("./zlib/messages"), i = e("./zlib/zstream"), s = e("./zlib/gzheader"), _ = Object.prototype.toString;
				function a(e) {
					if (!(this instanceof a)) return new a(e);
					this.options = d.assign({
						chunkSize: 16384,
						windowBits: 0,
						to: ""
					}, e || {});
					var t = this.options;
					t.raw && 0 <= t.windowBits && t.windowBits < 16 && (t.windowBits = -t.windowBits, 0 === t.windowBits && (t.windowBits = -15)), !(0 <= t.windowBits && t.windowBits < 16) || e && e.windowBits || (t.windowBits += 32), 15 < t.windowBits && t.windowBits < 48 && 0 == (15 & t.windowBits) && (t.windowBits |= 15), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new i(), this.strm.avail_out = 0;
					var r = c.inflateInit2(this.strm, t.windowBits);
					if (r !== m.Z_OK) throw new Error(n[r]);
					this.header = new s(), c.inflateGetHeader(this.strm, this.header);
				}
				function o(e, t) {
					var r = new a(t);
					if (r.push(e, !0), r.err) throw r.msg || n[r.err];
					return r.result;
				}
				a.prototype.push = function(e, t) {
					var r, n, i, s, a, o, h = this.strm, u = this.options.chunkSize, l = this.options.dictionary, f = !1;
					if (this.ended) return !1;
					n = t === ~~t ? t : !0 === t ? m.Z_FINISH : m.Z_NO_FLUSH, "string" == typeof e ? h.input = p.binstring2buf(e) : "[object ArrayBuffer]" === _.call(e) ? h.input = new Uint8Array(e) : h.input = e, h.next_in = 0, h.avail_in = h.input.length;
					do {
						if (0 === h.avail_out && (h.output = new d.Buf8(u), h.next_out = 0, h.avail_out = u), (r = c.inflate(h, m.Z_NO_FLUSH)) === m.Z_NEED_DICT && l && (o = "string" == typeof l ? p.string2buf(l) : "[object ArrayBuffer]" === _.call(l) ? new Uint8Array(l) : l, r = c.inflateSetDictionary(this.strm, o)), r === m.Z_BUF_ERROR && !0 === f && (r = m.Z_OK, f = !1), r !== m.Z_STREAM_END && r !== m.Z_OK) return this.onEnd(r), !(this.ended = !0);
						h.next_out && (0 !== h.avail_out && r !== m.Z_STREAM_END && (0 !== h.avail_in || n !== m.Z_FINISH && n !== m.Z_SYNC_FLUSH) || ("string" === this.options.to ? (i = p.utf8border(h.output, h.next_out), s = h.next_out - i, a = p.buf2string(h.output, i), h.next_out = s, h.avail_out = u - s, s && d.arraySet(h.output, h.output, i, s, 0), this.onData(a)) : this.onData(d.shrinkBuf(h.output, h.next_out)))), 0 === h.avail_in && 0 === h.avail_out && (f = !0);
					} while ((0 < h.avail_in || 0 === h.avail_out) && r !== m.Z_STREAM_END);
					return r === m.Z_STREAM_END && (n = m.Z_FINISH), n === m.Z_FINISH ? (r = c.inflateEnd(this.strm), this.onEnd(r), this.ended = !0, r === m.Z_OK) : n !== m.Z_SYNC_FLUSH || (this.onEnd(m.Z_OK), !(h.avail_out = 0));
				}, a.prototype.onData = function(e) {
					this.chunks.push(e);
				}, a.prototype.onEnd = function(e) {
					e === m.Z_OK && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = d.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
				}, r.Inflate = a, r.inflate = o, r.inflateRaw = function(e, t) {
					return (t = t || {}).raw = !0, o(e, t);
				}, r.ungzip = o;
			}, {
				"./utils/common": 41,
				"./utils/strings": 42,
				"./zlib/constants": 44,
				"./zlib/gzheader": 47,
				"./zlib/inflate": 49,
				"./zlib/messages": 51,
				"./zlib/zstream": 53
			}],
			41: [function(e, t, r) {
				"use strict";
				var n = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Int32Array;
				r.assign = function(e) {
					for (var t = Array.prototype.slice.call(arguments, 1); t.length;) {
						var r = t.shift();
						if (r) {
							if ("object" != typeof r) throw new TypeError(r + "must be non-object");
							for (var n in r) r.hasOwnProperty(n) && (e[n] = r[n]);
						}
					}
					return e;
				}, r.shrinkBuf = function(e, t) {
					return e.length === t ? e : e.subarray ? e.subarray(0, t) : (e.length = t, e);
				};
				var i = {
					arraySet: function(e, t, r, n, i) {
						if (t.subarray && e.subarray) e.set(t.subarray(r, r + n), i);
						else for (var s = 0; s < n; s++) e[i + s] = t[r + s];
					},
					flattenChunks: function(e) {
						var t, r, n, i, s, a;
						for (t = n = 0, r = e.length; t < r; t++) n += e[t].length;
						for (a = new Uint8Array(n), t = i = 0, r = e.length; t < r; t++) s = e[t], a.set(s, i), i += s.length;
						return a;
					}
				}, s = {
					arraySet: function(e, t, r, n, i) {
						for (var s = 0; s < n; s++) e[i + s] = t[r + s];
					},
					flattenChunks: function(e) {
						return [].concat.apply([], e);
					}
				};
				r.setTyped = function(e) {
					e ? (r.Buf8 = Uint8Array, r.Buf16 = Uint16Array, r.Buf32 = Int32Array, r.assign(r, i)) : (r.Buf8 = Array, r.Buf16 = Array, r.Buf32 = Array, r.assign(r, s));
				}, r.setTyped(n);
			}, {}],
			42: [function(e, t, r) {
				"use strict";
				var h = e("./common"), i = !0, s = !0;
				try {
					String.fromCharCode.apply(null, [0]);
				} catch (e) {
					i = !1;
				}
				try {
					String.fromCharCode.apply(null, /* @__PURE__ */ new Uint8Array(1));
				} catch (e) {
					s = !1;
				}
				for (var u = new h.Buf8(256), n = 0; n < 256; n++) u[n] = 252 <= n ? 6 : 248 <= n ? 5 : 240 <= n ? 4 : 224 <= n ? 3 : 192 <= n ? 2 : 1;
				function l(e, t) {
					if (t < 65537 && (e.subarray && s || !e.subarray && i)) return String.fromCharCode.apply(null, h.shrinkBuf(e, t));
					for (var r = "", n = 0; n < t; n++) r += String.fromCharCode(e[n]);
					return r;
				}
				u[254] = u[254] = 1, r.string2buf = function(e) {
					var t, r, n, i, s, a = e.length, o = 0;
					for (i = 0; i < a; i++) 55296 == (64512 & (r = e.charCodeAt(i))) && i + 1 < a && 56320 == (64512 & (n = e.charCodeAt(i + 1))) && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++), o += r < 128 ? 1 : r < 2048 ? 2 : r < 65536 ? 3 : 4;
					for (t = new h.Buf8(o), i = s = 0; s < o; i++) 55296 == (64512 & (r = e.charCodeAt(i))) && i + 1 < a && 56320 == (64512 & (n = e.charCodeAt(i + 1))) && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++), r < 128 ? t[s++] = r : (r < 2048 ? t[s++] = 192 | r >>> 6 : (r < 65536 ? t[s++] = 224 | r >>> 12 : (t[s++] = 240 | r >>> 18, t[s++] = 128 | r >>> 12 & 63), t[s++] = 128 | r >>> 6 & 63), t[s++] = 128 | 63 & r);
					return t;
				}, r.buf2binstring = function(e) {
					return l(e, e.length);
				}, r.binstring2buf = function(e) {
					for (var t = new h.Buf8(e.length), r = 0, n = t.length; r < n; r++) t[r] = e.charCodeAt(r);
					return t;
				}, r.buf2string = function(e, t) {
					var r, n, i, s, a = t || e.length, o = new Array(2 * a);
					for (r = n = 0; r < a;) if ((i = e[r++]) < 128) o[n++] = i;
					else if (4 < (s = u[i])) o[n++] = 65533, r += s - 1;
					else {
						for (i &= 2 === s ? 31 : 3 === s ? 15 : 7; 1 < s && r < a;) i = i << 6 | 63 & e[r++], s--;
						1 < s ? o[n++] = 65533 : i < 65536 ? o[n++] = i : (i -= 65536, o[n++] = 55296 | i >> 10 & 1023, o[n++] = 56320 | 1023 & i);
					}
					return l(o, n);
				}, r.utf8border = function(e, t) {
					var r;
					for ((t = t || e.length) > e.length && (t = e.length), r = t - 1; 0 <= r && 128 == (192 & e[r]);) r--;
					return r < 0 ? t : 0 === r ? t : r + u[e[r]] > t ? r : t;
				};
			}, { "./common": 41 }],
			43: [function(e, t, r) {
				"use strict";
				t.exports = function(e, t, r, n) {
					for (var i = 65535 & e | 0, s = e >>> 16 & 65535 | 0, a = 0; 0 !== r;) {
						for (r -= a = 2e3 < r ? 2e3 : r; s = s + (i = i + t[n++] | 0) | 0, --a;);
						i %= 65521, s %= 65521;
					}
					return i | s << 16 | 0;
				};
			}, {}],
			44: [function(e, t, r) {
				"use strict";
				t.exports = {
					Z_NO_FLUSH: 0,
					Z_PARTIAL_FLUSH: 1,
					Z_SYNC_FLUSH: 2,
					Z_FULL_FLUSH: 3,
					Z_FINISH: 4,
					Z_BLOCK: 5,
					Z_TREES: 6,
					Z_OK: 0,
					Z_STREAM_END: 1,
					Z_NEED_DICT: 2,
					Z_ERRNO: -1,
					Z_STREAM_ERROR: -2,
					Z_DATA_ERROR: -3,
					Z_BUF_ERROR: -5,
					Z_NO_COMPRESSION: 0,
					Z_BEST_SPEED: 1,
					Z_BEST_COMPRESSION: 9,
					Z_DEFAULT_COMPRESSION: -1,
					Z_FILTERED: 1,
					Z_HUFFMAN_ONLY: 2,
					Z_RLE: 3,
					Z_FIXED: 4,
					Z_DEFAULT_STRATEGY: 0,
					Z_BINARY: 0,
					Z_TEXT: 1,
					Z_UNKNOWN: 2,
					Z_DEFLATED: 8
				};
			}, {}],
			45: [function(e, t, r) {
				"use strict";
				var o = function() {
					for (var e, t = [], r = 0; r < 256; r++) {
						e = r;
						for (var n = 0; n < 8; n++) e = 1 & e ? 3988292384 ^ e >>> 1 : e >>> 1;
						t[r] = e;
					}
					return t;
				}();
				t.exports = function(e, t, r, n) {
					var i = o, s = n + r;
					e ^= -1;
					for (var a = n; a < s; a++) e = e >>> 8 ^ i[255 & (e ^ t[a])];
					return -1 ^ e;
				};
			}, {}],
			46: [function(e, t, r) {
				"use strict";
				var h, c = e("../utils/common"), u = e("./trees"), d = e("./adler32"), p = e("./crc32"), n = e("./messages"), l = 0, f = 4, m = 0, _ = -2, g = -1, b = 4, i = 2, v = 8, y = 9, s = 286, a = 30, o = 19, w = 2 * s + 1, k = 15, x = 3, S = 258, z = S + x + 1, C = 42, E = 113, A = 1, I = 2, O = 3, B = 4;
				function R(e, t) {
					return e.msg = n[t], t;
				}
				function T(e) {
					return (e << 1) - (4 < e ? 9 : 0);
				}
				function D(e) {
					for (var t = e.length; 0 <= --t;) e[t] = 0;
				}
				function F(e) {
					var t = e.state, r = t.pending;
					r > e.avail_out && (r = e.avail_out), 0 !== r && (c.arraySet(e.output, t.pending_buf, t.pending_out, r, e.next_out), e.next_out += r, t.pending_out += r, e.total_out += r, e.avail_out -= r, t.pending -= r, 0 === t.pending && (t.pending_out = 0));
				}
				function N(e, t) {
					u._tr_flush_block(e, 0 <= e.block_start ? e.block_start : -1, e.strstart - e.block_start, t), e.block_start = e.strstart, F(e.strm);
				}
				function U(e, t) {
					e.pending_buf[e.pending++] = t;
				}
				function P(e, t) {
					e.pending_buf[e.pending++] = t >>> 8 & 255, e.pending_buf[e.pending++] = 255 & t;
				}
				function L(e, t) {
					var r, n, i = e.max_chain_length, s = e.strstart, a = e.prev_length, o = e.nice_match, h = e.strstart > e.w_size - z ? e.strstart - (e.w_size - z) : 0, u = e.window, l = e.w_mask, f = e.prev, c = e.strstart + S, d = u[s + a - 1], p = u[s + a];
					e.prev_length >= e.good_match && (i >>= 2), o > e.lookahead && (o = e.lookahead);
					do
						if (u[(r = t) + a] === p && u[r + a - 1] === d && u[r] === u[s] && u[++r] === u[s + 1]) {
							s += 2, r++;
							do							;
while (u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && u[++s] === u[++r] && s < c);
							if (n = S - (c - s), s = c - S, a < n) {
								if (e.match_start = t, o <= (a = n)) break;
								d = u[s + a - 1], p = u[s + a];
							}
						}
					while ((t = f[t & l]) > h && 0 != --i);
					return a <= e.lookahead ? a : e.lookahead;
				}
				function j(e) {
					var t, r, n, i, s, a, o, h, u, l, f = e.w_size;
					do {
						if (i = e.window_size - e.lookahead - e.strstart, e.strstart >= f + (f - z)) {
							for (c.arraySet(e.window, e.window, f, f, 0), e.match_start -= f, e.strstart -= f, e.block_start -= f, t = r = e.hash_size; n = e.head[--t], e.head[t] = f <= n ? n - f : 0, --r;);
							for (t = r = f; n = e.prev[--t], e.prev[t] = f <= n ? n - f : 0, --r;);
							i += f;
						}
						if (0 === e.strm.avail_in) break;
						if (a = e.strm, o = e.window, h = e.strstart + e.lookahead, u = i, l = void 0, l = a.avail_in, u < l && (l = u), r = 0 === l ? 0 : (a.avail_in -= l, c.arraySet(o, a.input, a.next_in, l, h), 1 === a.state.wrap ? a.adler = d(a.adler, o, l, h) : 2 === a.state.wrap && (a.adler = p(a.adler, o, l, h)), a.next_in += l, a.total_in += l, l), e.lookahead += r, e.lookahead + e.insert >= x) for (s = e.strstart - e.insert, e.ins_h = e.window[s], e.ins_h = (e.ins_h << e.hash_shift ^ e.window[s + 1]) & e.hash_mask; e.insert && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[s + x - 1]) & e.hash_mask, e.prev[s & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = s, s++, e.insert--, !(e.lookahead + e.insert < x)););
					} while (e.lookahead < z && 0 !== e.strm.avail_in);
				}
				function Z(e, t) {
					for (var r, n;;) {
						if (e.lookahead < z) {
							if (j(e), e.lookahead < z && t === l) return A;
							if (0 === e.lookahead) break;
						}
						if (r = 0, e.lookahead >= x && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + x - 1]) & e.hash_mask, r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), 0 !== r && e.strstart - r <= e.w_size - z && (e.match_length = L(e, r)), e.match_length >= x) if (n = u._tr_tally(e, e.strstart - e.match_start, e.match_length - x), e.lookahead -= e.match_length, e.match_length <= e.max_lazy_match && e.lookahead >= x) {
							for (e.match_length--; e.strstart++, e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + x - 1]) & e.hash_mask, r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart, 0 != --e.match_length;);
							e.strstart++;
						} else e.strstart += e.match_length, e.match_length = 0, e.ins_h = e.window[e.strstart], e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + 1]) & e.hash_mask;
						else n = u._tr_tally(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++;
						if (n && (N(e, !1), 0 === e.strm.avail_out)) return A;
					}
					return e.insert = e.strstart < x - 1 ? e.strstart : x - 1, t === f ? (N(e, !0), 0 === e.strm.avail_out ? O : B) : e.last_lit && (N(e, !1), 0 === e.strm.avail_out) ? A : I;
				}
				function W(e, t) {
					for (var r, n, i;;) {
						if (e.lookahead < z) {
							if (j(e), e.lookahead < z && t === l) return A;
							if (0 === e.lookahead) break;
						}
						if (r = 0, e.lookahead >= x && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + x - 1]) & e.hash_mask, r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), e.prev_length = e.match_length, e.prev_match = e.match_start, e.match_length = x - 1, 0 !== r && e.prev_length < e.max_lazy_match && e.strstart - r <= e.w_size - z && (e.match_length = L(e, r), e.match_length <= 5 && (1 === e.strategy || e.match_length === x && 4096 < e.strstart - e.match_start) && (e.match_length = x - 1)), e.prev_length >= x && e.match_length <= e.prev_length) {
							for (i = e.strstart + e.lookahead - x, n = u._tr_tally(e, e.strstart - 1 - e.prev_match, e.prev_length - x), e.lookahead -= e.prev_length - 1, e.prev_length -= 2; ++e.strstart <= i && (e.ins_h = (e.ins_h << e.hash_shift ^ e.window[e.strstart + x - 1]) & e.hash_mask, r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), 0 != --e.prev_length;);
							if (e.match_available = 0, e.match_length = x - 1, e.strstart++, n && (N(e, !1), 0 === e.strm.avail_out)) return A;
						} else if (e.match_available) {
							if ((n = u._tr_tally(e, 0, e.window[e.strstart - 1])) && N(e, !1), e.strstart++, e.lookahead--, 0 === e.strm.avail_out) return A;
						} else e.match_available = 1, e.strstart++, e.lookahead--;
					}
					return e.match_available && (n = u._tr_tally(e, 0, e.window[e.strstart - 1]), e.match_available = 0), e.insert = e.strstart < x - 1 ? e.strstart : x - 1, t === f ? (N(e, !0), 0 === e.strm.avail_out ? O : B) : e.last_lit && (N(e, !1), 0 === e.strm.avail_out) ? A : I;
				}
				function M(e, t, r, n, i) {
					this.good_length = e, this.max_lazy = t, this.nice_length = r, this.max_chain = n, this.func = i;
				}
				function H() {
					this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = v, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new c.Buf16(2 * w), this.dyn_dtree = new c.Buf16(2 * (2 * a + 1)), this.bl_tree = new c.Buf16(2 * (2 * o + 1)), D(this.dyn_ltree), D(this.dyn_dtree), D(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new c.Buf16(k + 1), this.heap = new c.Buf16(2 * s + 1), D(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = new c.Buf16(2 * s + 1), D(this.depth), this.l_buf = 0, this.lit_bufsize = 0, this.last_lit = 0, this.d_buf = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0;
				}
				function G(e) {
					var t;
					return e && e.state ? (e.total_in = e.total_out = 0, e.data_type = i, (t = e.state).pending = 0, t.pending_out = 0, t.wrap < 0 && (t.wrap = -t.wrap), t.status = t.wrap ? C : E, e.adler = 2 === t.wrap ? 0 : 1, t.last_flush = l, u._tr_init(t), m) : R(e, _);
				}
				function K(e) {
					var t = G(e);
					return t === m && function(e) {
						e.window_size = 2 * e.w_size, D(e.head), e.max_lazy_match = h[e.level].max_lazy, e.good_match = h[e.level].good_length, e.nice_match = h[e.level].nice_length, e.max_chain_length = h[e.level].max_chain, e.strstart = 0, e.block_start = 0, e.lookahead = 0, e.insert = 0, e.match_length = e.prev_length = x - 1, e.match_available = 0, e.ins_h = 0;
					}(e.state), t;
				}
				function Y(e, t, r, n, i, s) {
					if (!e) return _;
					var a = 1;
					if (t === g && (t = 6), n < 0 ? (a = 0, n = -n) : 15 < n && (a = 2, n -= 16), i < 1 || y < i || r !== v || n < 8 || 15 < n || t < 0 || 9 < t || s < 0 || b < s) return R(e, _);
					8 === n && (n = 9);
					var o = new H();
					return (e.state = o).strm = e, o.wrap = a, o.gzhead = null, o.w_bits = n, o.w_size = 1 << o.w_bits, o.w_mask = o.w_size - 1, o.hash_bits = i + 7, o.hash_size = 1 << o.hash_bits, o.hash_mask = o.hash_size - 1, o.hash_shift = ~~((o.hash_bits + x - 1) / x), o.window = new c.Buf8(2 * o.w_size), o.head = new c.Buf16(o.hash_size), o.prev = new c.Buf16(o.w_size), o.lit_bufsize = 1 << i + 6, o.pending_buf_size = 4 * o.lit_bufsize, o.pending_buf = new c.Buf8(o.pending_buf_size), o.d_buf = 1 * o.lit_bufsize, o.l_buf = 3 * o.lit_bufsize, o.level = t, o.strategy = s, o.method = r, K(e);
				}
				h = [
					new M(0, 0, 0, 0, function(e, t) {
						var r = 65535;
						for (r > e.pending_buf_size - 5 && (r = e.pending_buf_size - 5);;) {
							if (e.lookahead <= 1) {
								if (j(e), 0 === e.lookahead && t === l) return A;
								if (0 === e.lookahead) break;
							}
							e.strstart += e.lookahead, e.lookahead = 0;
							var n = e.block_start + r;
							if ((0 === e.strstart || e.strstart >= n) && (e.lookahead = e.strstart - n, e.strstart = n, N(e, !1), 0 === e.strm.avail_out)) return A;
							if (e.strstart - e.block_start >= e.w_size - z && (N(e, !1), 0 === e.strm.avail_out)) return A;
						}
						return e.insert = 0, t === f ? (N(e, !0), 0 === e.strm.avail_out ? O : B) : (e.strstart > e.block_start && (N(e, !1), e.strm.avail_out), A);
					}),
					new M(4, 4, 8, 4, Z),
					new M(4, 5, 16, 8, Z),
					new M(4, 6, 32, 32, Z),
					new M(4, 4, 16, 16, W),
					new M(8, 16, 32, 32, W),
					new M(8, 16, 128, 128, W),
					new M(8, 32, 128, 256, W),
					new M(32, 128, 258, 1024, W),
					new M(32, 258, 258, 4096, W)
				], r.deflateInit = function(e, t) {
					return Y(e, t, v, 15, 8, 0);
				}, r.deflateInit2 = Y, r.deflateReset = K, r.deflateResetKeep = G, r.deflateSetHeader = function(e, t) {
					return e && e.state ? 2 !== e.state.wrap ? _ : (e.state.gzhead = t, m) : _;
				}, r.deflate = function(e, t) {
					var r, n, i, s;
					if (!e || !e.state || 5 < t || t < 0) return e ? R(e, _) : _;
					if (n = e.state, !e.output || !e.input && 0 !== e.avail_in || 666 === n.status && t !== f) return R(e, 0 === e.avail_out ? -5 : _);
					if (n.strm = e, r = n.last_flush, n.last_flush = t, n.status === C) if (2 === n.wrap) e.adler = 0, U(n, 31), U(n, 139), U(n, 8), n.gzhead ? (U(n, (n.gzhead.text ? 1 : 0) + (n.gzhead.hcrc ? 2 : 0) + (n.gzhead.extra ? 4 : 0) + (n.gzhead.name ? 8 : 0) + (n.gzhead.comment ? 16 : 0)), U(n, 255 & n.gzhead.time), U(n, n.gzhead.time >> 8 & 255), U(n, n.gzhead.time >> 16 & 255), U(n, n.gzhead.time >> 24 & 255), U(n, 9 === n.level ? 2 : 2 <= n.strategy || n.level < 2 ? 4 : 0), U(n, 255 & n.gzhead.os), n.gzhead.extra && n.gzhead.extra.length && (U(n, 255 & n.gzhead.extra.length), U(n, n.gzhead.extra.length >> 8 & 255)), n.gzhead.hcrc && (e.adler = p(e.adler, n.pending_buf, n.pending, 0)), n.gzindex = 0, n.status = 69) : (U(n, 0), U(n, 0), U(n, 0), U(n, 0), U(n, 0), U(n, 9 === n.level ? 2 : 2 <= n.strategy || n.level < 2 ? 4 : 0), U(n, 3), n.status = E);
					else {
						var a = v + (n.w_bits - 8 << 4) << 8;
						a |= (2 <= n.strategy || n.level < 2 ? 0 : n.level < 6 ? 1 : 6 === n.level ? 2 : 3) << 6, 0 !== n.strstart && (a |= 32), a += 31 - a % 31, n.status = E, P(n, a), 0 !== n.strstart && (P(n, e.adler >>> 16), P(n, 65535 & e.adler)), e.adler = 1;
					}
					if (69 === n.status) if (n.gzhead.extra) {
						for (i = n.pending; n.gzindex < (65535 & n.gzhead.extra.length) && (n.pending !== n.pending_buf_size || (n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), F(e), i = n.pending, n.pending !== n.pending_buf_size));) U(n, 255 & n.gzhead.extra[n.gzindex]), n.gzindex++;
						n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), n.gzindex === n.gzhead.extra.length && (n.gzindex = 0, n.status = 73);
					} else n.status = 73;
					if (73 === n.status) if (n.gzhead.name) {
						i = n.pending;
						do {
							if (n.pending === n.pending_buf_size && (n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), F(e), i = n.pending, n.pending === n.pending_buf_size)) {
								s = 1;
								break;
							}
							s = n.gzindex < n.gzhead.name.length ? 255 & n.gzhead.name.charCodeAt(n.gzindex++) : 0, U(n, s);
						} while (0 !== s);
						n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), 0 === s && (n.gzindex = 0, n.status = 91);
					} else n.status = 91;
					if (91 === n.status) if (n.gzhead.comment) {
						i = n.pending;
						do {
							if (n.pending === n.pending_buf_size && (n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), F(e), i = n.pending, n.pending === n.pending_buf_size)) {
								s = 1;
								break;
							}
							s = n.gzindex < n.gzhead.comment.length ? 255 & n.gzhead.comment.charCodeAt(n.gzindex++) : 0, U(n, s);
						} while (0 !== s);
						n.gzhead.hcrc && n.pending > i && (e.adler = p(e.adler, n.pending_buf, n.pending - i, i)), 0 === s && (n.status = 103);
					} else n.status = 103;
					if (103 === n.status && (n.gzhead.hcrc ? (n.pending + 2 > n.pending_buf_size && F(e), n.pending + 2 <= n.pending_buf_size && (U(n, 255 & e.adler), U(n, e.adler >> 8 & 255), e.adler = 0, n.status = E)) : n.status = E), 0 !== n.pending) {
						if (F(e), 0 === e.avail_out) return n.last_flush = -1, m;
					} else if (0 === e.avail_in && T(t) <= T(r) && t !== f) return R(e, -5);
					if (666 === n.status && 0 !== e.avail_in) return R(e, -5);
					if (0 !== e.avail_in || 0 !== n.lookahead || t !== l && 666 !== n.status) {
						var o = 2 === n.strategy ? function(e, t) {
							for (var r;;) {
								if (0 === e.lookahead && (j(e), 0 === e.lookahead)) {
									if (t === l) return A;
									break;
								}
								if (e.match_length = 0, r = u._tr_tally(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++, r && (N(e, !1), 0 === e.strm.avail_out)) return A;
							}
							return e.insert = 0, t === f ? (N(e, !0), 0 === e.strm.avail_out ? O : B) : e.last_lit && (N(e, !1), 0 === e.strm.avail_out) ? A : I;
						}(n, t) : 3 === n.strategy ? function(e, t) {
							for (var r, n, i, s, a = e.window;;) {
								if (e.lookahead <= S) {
									if (j(e), e.lookahead <= S && t === l) return A;
									if (0 === e.lookahead) break;
								}
								if (e.match_length = 0, e.lookahead >= x && 0 < e.strstart && (n = a[i = e.strstart - 1]) === a[++i] && n === a[++i] && n === a[++i]) {
									s = e.strstart + S;
									do									;
while (n === a[++i] && n === a[++i] && n === a[++i] && n === a[++i] && n === a[++i] && n === a[++i] && n === a[++i] && n === a[++i] && i < s);
									e.match_length = S - (s - i), e.match_length > e.lookahead && (e.match_length = e.lookahead);
								}
								if (e.match_length >= x ? (r = u._tr_tally(e, 1, e.match_length - x), e.lookahead -= e.match_length, e.strstart += e.match_length, e.match_length = 0) : (r = u._tr_tally(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++), r && (N(e, !1), 0 === e.strm.avail_out)) return A;
							}
							return e.insert = 0, t === f ? (N(e, !0), 0 === e.strm.avail_out ? O : B) : e.last_lit && (N(e, !1), 0 === e.strm.avail_out) ? A : I;
						}(n, t) : h[n.level].func(n, t);
						if (o !== O && o !== B || (n.status = 666), o === A || o === O) return 0 === e.avail_out && (n.last_flush = -1), m;
						if (o === I && (1 === t ? u._tr_align(n) : 5 !== t && (u._tr_stored_block(n, 0, 0, !1), 3 === t && (D(n.head), 0 === n.lookahead && (n.strstart = 0, n.block_start = 0, n.insert = 0))), F(e), 0 === e.avail_out)) return n.last_flush = -1, m;
					}
					return t !== f ? m : n.wrap <= 0 ? 1 : (2 === n.wrap ? (U(n, 255 & e.adler), U(n, e.adler >> 8 & 255), U(n, e.adler >> 16 & 255), U(n, e.adler >> 24 & 255), U(n, 255 & e.total_in), U(n, e.total_in >> 8 & 255), U(n, e.total_in >> 16 & 255), U(n, e.total_in >> 24 & 255)) : (P(n, e.adler >>> 16), P(n, 65535 & e.adler)), F(e), 0 < n.wrap && (n.wrap = -n.wrap), 0 !== n.pending ? m : 1);
				}, r.deflateEnd = function(e) {
					var t;
					return e && e.state ? (t = e.state.status) !== C && 69 !== t && 73 !== t && 91 !== t && 103 !== t && t !== E && 666 !== t ? R(e, _) : (e.state = null, t === E ? R(e, -3) : m) : _;
				}, r.deflateSetDictionary = function(e, t) {
					var r, n, i, s, a, o, h, u, l = t.length;
					if (!e || !e.state) return _;
					if (2 === (s = (r = e.state).wrap) || 1 === s && r.status !== C || r.lookahead) return _;
					for (1 === s && (e.adler = d(e.adler, t, l, 0)), r.wrap = 0, l >= r.w_size && (0 === s && (D(r.head), r.strstart = 0, r.block_start = 0, r.insert = 0), u = new c.Buf8(r.w_size), c.arraySet(u, t, l - r.w_size, r.w_size, 0), t = u, l = r.w_size), a = e.avail_in, o = e.next_in, h = e.input, e.avail_in = l, e.next_in = 0, e.input = t, j(r); r.lookahead >= x;) {
						for (n = r.strstart, i = r.lookahead - (x - 1); r.ins_h = (r.ins_h << r.hash_shift ^ r.window[n + x - 1]) & r.hash_mask, r.prev[n & r.w_mask] = r.head[r.ins_h], r.head[r.ins_h] = n, n++, --i;);
						r.strstart = n, r.lookahead = x - 1, j(r);
					}
					return r.strstart += r.lookahead, r.block_start = r.strstart, r.insert = r.lookahead, r.lookahead = 0, r.match_length = r.prev_length = x - 1, r.match_available = 0, e.next_in = o, e.input = h, e.avail_in = a, r.wrap = s, m;
				}, r.deflateInfo = "pako deflate (from Nodeca project)";
			}, {
				"../utils/common": 41,
				"./adler32": 43,
				"./crc32": 45,
				"./messages": 51,
				"./trees": 52
			}],
			47: [function(e, t, r) {
				"use strict";
				t.exports = function() {
					this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = !1;
				};
			}, {}],
			48: [function(e, t, r) {
				"use strict";
				t.exports = function(e, t) {
					var r = e.state, n = e.next_in, i, s, a, o, h, u, l, f, c, d, p, m, _, g, b, v, y, w, k, x, S, z = e.input, C;
					i = n + (e.avail_in - 5), s = e.next_out, C = e.output, a = s - (t - e.avail_out), o = s + (e.avail_out - 257), h = r.dmax, u = r.wsize, l = r.whave, f = r.wnext, c = r.window, d = r.hold, p = r.bits, m = r.lencode, _ = r.distcode, g = (1 << r.lenbits) - 1, b = (1 << r.distbits) - 1;
					e: do {
						p < 15 && (d += z[n++] << p, p += 8, d += z[n++] << p, p += 8), v = m[d & g];
						t: for (;;) {
							if (d >>>= y = v >>> 24, p -= y, 0 === (y = v >>> 16 & 255)) C[s++] = 65535 & v;
							else {
								if (!(16 & y)) {
									if (0 == (64 & y)) {
										v = m[(65535 & v) + (d & (1 << y) - 1)];
										continue t;
									}
									if (32 & y) {
										r.mode = 12;
										break e;
									}
									e.msg = "invalid literal/length code", r.mode = 30;
									break e;
								}
								w = 65535 & v, (y &= 15) && (p < y && (d += z[n++] << p, p += 8), w += d & (1 << y) - 1, d >>>= y, p -= y), p < 15 && (d += z[n++] << p, p += 8, d += z[n++] << p, p += 8), v = _[d & b];
								r: for (;;) {
									if (d >>>= y = v >>> 24, p -= y, !(16 & (y = v >>> 16 & 255))) {
										if (0 == (64 & y)) {
											v = _[(65535 & v) + (d & (1 << y) - 1)];
											continue r;
										}
										e.msg = "invalid distance code", r.mode = 30;
										break e;
									}
									if (k = 65535 & v, p < (y &= 15) && (d += z[n++] << p, (p += 8) < y && (d += z[n++] << p, p += 8)), h < (k += d & (1 << y) - 1)) {
										e.msg = "invalid distance too far back", r.mode = 30;
										break e;
									}
									if (d >>>= y, p -= y, (y = s - a) < k) {
										if (l < (y = k - y) && r.sane) {
											e.msg = "invalid distance too far back", r.mode = 30;
											break e;
										}
										if (S = c, (x = 0) === f) {
											if (x += u - y, y < w) {
												for (w -= y; C[s++] = c[x++], --y;);
												x = s - k, S = C;
											}
										} else if (f < y) {
											if (x += u + f - y, (y -= f) < w) {
												for (w -= y; C[s++] = c[x++], --y;);
												if (x = 0, f < w) {
													for (w -= y = f; C[s++] = c[x++], --y;);
													x = s - k, S = C;
												}
											}
										} else if (x += f - y, y < w) {
											for (w -= y; C[s++] = c[x++], --y;);
											x = s - k, S = C;
										}
										for (; 2 < w;) C[s++] = S[x++], C[s++] = S[x++], C[s++] = S[x++], w -= 3;
										w && (C[s++] = S[x++], 1 < w && (C[s++] = S[x++]));
									} else {
										for (x = s - k; C[s++] = C[x++], C[s++] = C[x++], C[s++] = C[x++], 2 < (w -= 3););
										w && (C[s++] = C[x++], 1 < w && (C[s++] = C[x++]));
									}
									break;
								}
							}
							break;
						}
					} while (n < i && s < o);
					n -= w = p >> 3, d &= (1 << (p -= w << 3)) - 1, e.next_in = n, e.next_out = s, e.avail_in = n < i ? i - n + 5 : 5 - (n - i), e.avail_out = s < o ? o - s + 257 : 257 - (s - o), r.hold = d, r.bits = p;
				};
			}, {}],
			49: [function(e, t, r) {
				"use strict";
				var I = e("../utils/common"), O = e("./adler32"), B = e("./crc32"), R = e("./inffast"), T = e("./inftrees"), D = 1, F = 2, N = 0, U = -2, P = 1, n = 852, i = 592;
				function L(e) {
					return (e >>> 24 & 255) + (e >>> 8 & 65280) + ((65280 & e) << 8) + ((255 & e) << 24);
				}
				function s() {
					this.mode = 0, this.last = !1, this.wrap = 0, this.havedict = !1, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = new I.Buf16(320), this.work = new I.Buf16(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0;
				}
				function a(e) {
					var t;
					return e && e.state ? (t = e.state, e.total_in = e.total_out = t.total = 0, e.msg = "", t.wrap && (e.adler = 1 & t.wrap), t.mode = P, t.last = 0, t.havedict = 0, t.dmax = 32768, t.head = null, t.hold = 0, t.bits = 0, t.lencode = t.lendyn = new I.Buf32(n), t.distcode = t.distdyn = new I.Buf32(i), t.sane = 1, t.back = -1, N) : U;
				}
				function o(e) {
					var t;
					return e && e.state ? ((t = e.state).wsize = 0, t.whave = 0, t.wnext = 0, a(e)) : U;
				}
				function h(e, t) {
					var r, n;
					return e && e.state ? (n = e.state, t < 0 ? (r = 0, t = -t) : (r = 1 + (t >> 4), t < 48 && (t &= 15)), t && (t < 8 || 15 < t) ? U : (null !== n.window && n.wbits !== t && (n.window = null), n.wrap = r, n.wbits = t, o(e))) : U;
				}
				function u(e, t) {
					var r, n;
					return e ? (n = new s(), (e.state = n).window = null, (r = h(e, t)) !== N && (e.state = null), r) : U;
				}
				var l, f, c = !0;
				function j(e) {
					if (c) {
						var t;
						for (l = new I.Buf32(512), f = new I.Buf32(32), t = 0; t < 144;) e.lens[t++] = 8;
						for (; t < 256;) e.lens[t++] = 9;
						for (; t < 280;) e.lens[t++] = 7;
						for (; t < 288;) e.lens[t++] = 8;
						for (T(D, e.lens, 0, 288, l, 0, e.work, { bits: 9 }), t = 0; t < 32;) e.lens[t++] = 5;
						T(F, e.lens, 0, 32, f, 0, e.work, { bits: 5 }), c = !1;
					}
					e.lencode = l, e.lenbits = 9, e.distcode = f, e.distbits = 5;
				}
				function Z(e, t, r, n) {
					var i, s = e.state;
					return null === s.window && (s.wsize = 1 << s.wbits, s.wnext = 0, s.whave = 0, s.window = new I.Buf8(s.wsize)), n >= s.wsize ? (I.arraySet(s.window, t, r - s.wsize, s.wsize, 0), s.wnext = 0, s.whave = s.wsize) : (n < (i = s.wsize - s.wnext) && (i = n), I.arraySet(s.window, t, r - n, i, s.wnext), (n -= i) ? (I.arraySet(s.window, t, r - n, n, 0), s.wnext = n, s.whave = s.wsize) : (s.wnext += i, s.wnext === s.wsize && (s.wnext = 0), s.whave < s.wsize && (s.whave += i))), 0;
				}
				r.inflateReset = o, r.inflateReset2 = h, r.inflateResetKeep = a, r.inflateInit = function(e) {
					return u(e, 15);
				}, r.inflateInit2 = u, r.inflate = function(e, t) {
					var r, n, i, s, a, o, h, u, l, f, c, d, p, m, _, g, b, v, y, w, k, x, S, z, C = 0, E = new I.Buf8(4), A = [
						16,
						17,
						18,
						0,
						8,
						7,
						9,
						6,
						10,
						5,
						11,
						4,
						12,
						3,
						13,
						2,
						14,
						1,
						15
					];
					if (!e || !e.state || !e.output || !e.input && 0 !== e.avail_in) return U;
					12 === (r = e.state).mode && (r.mode = 13), a = e.next_out, i = e.output, h = e.avail_out, s = e.next_in, n = e.input, o = e.avail_in, u = r.hold, l = r.bits, f = o, c = h, x = N;
					e: for (;;) switch (r.mode) {
						case P:
							if (0 === r.wrap) {
								r.mode = 13;
								break;
							}
							for (; l < 16;) {
								if (0 === o) break e;
								o--, u += n[s++] << l, l += 8;
							}
							if (2 & r.wrap && 35615 === u) {
								E[r.check = 0] = 255 & u, E[1] = u >>> 8 & 255, r.check = B(r.check, E, 2, 0), l = u = 0, r.mode = 2;
								break;
							}
							if (r.flags = 0, r.head && (r.head.done = !1), !(1 & r.wrap) || (((255 & u) << 8) + (u >> 8)) % 31) {
								e.msg = "incorrect header check", r.mode = 30;
								break;
							}
							if (8 != (15 & u)) {
								e.msg = "unknown compression method", r.mode = 30;
								break;
							}
							if (l -= 4, k = 8 + (15 & (u >>>= 4)), 0 === r.wbits) r.wbits = k;
							else if (k > r.wbits) {
								e.msg = "invalid window size", r.mode = 30;
								break;
							}
							r.dmax = 1 << k, e.adler = r.check = 1, r.mode = 512 & u ? 10 : 12, l = u = 0;
							break;
						case 2:
							for (; l < 16;) {
								if (0 === o) break e;
								o--, u += n[s++] << l, l += 8;
							}
							if (r.flags = u, 8 != (255 & r.flags)) {
								e.msg = "unknown compression method", r.mode = 30;
								break;
							}
							if (57344 & r.flags) {
								e.msg = "unknown header flags set", r.mode = 30;
								break;
							}
							r.head && (r.head.text = u >> 8 & 1), 512 & r.flags && (E[0] = 255 & u, E[1] = u >>> 8 & 255, r.check = B(r.check, E, 2, 0)), l = u = 0, r.mode = 3;
						case 3:
							for (; l < 32;) {
								if (0 === o) break e;
								o--, u += n[s++] << l, l += 8;
							}
							r.head && (r.head.time = u), 512 & r.flags && (E[0] = 255 & u, E[1] = u >>> 8 & 255, E[2] = u >>> 16 & 255, E[3] = u >>> 24 & 255, r.check = B(r.check, E, 4, 0)), l = u = 0, r.mode = 4;
						case 4:
							for (; l < 16;) {
								if (0 === o) break e;
								o--, u += n[s++] << l, l += 8;
							}
							r.head && (r.head.xflags = 255 & u, r.head.os = u >> 8), 512 & r.flags && (E[0] = 255 & u, E[1] = u >>> 8 & 255, r.check = B(r.check, E, 2, 0)), l = u = 0, r.mode = 5;
						case 5:
							if (1024 & r.flags) {
								for (; l < 16;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								r.length = u, r.head && (r.head.extra_len = u), 512 & r.flags && (E[0] = 255 & u, E[1] = u >>> 8 & 255, r.check = B(r.check, E, 2, 0)), l = u = 0;
							} else r.head && (r.head.extra = null);
							r.mode = 6;
						case 6:
							if (1024 & r.flags && (o < (d = r.length) && (d = o), d && (r.head && (k = r.head.extra_len - r.length, r.head.extra || (r.head.extra = new Array(r.head.extra_len)), I.arraySet(r.head.extra, n, s, d, k)), 512 & r.flags && (r.check = B(r.check, n, d, s)), o -= d, s += d, r.length -= d), r.length)) break e;
							r.length = 0, r.mode = 7;
						case 7:
							if (2048 & r.flags) {
								if (0 === o) break e;
								for (d = 0; k = n[s + d++], r.head && k && r.length < 65536 && (r.head.name += String.fromCharCode(k)), k && d < o;);
								if (512 & r.flags && (r.check = B(r.check, n, d, s)), o -= d, s += d, k) break e;
							} else r.head && (r.head.name = null);
							r.length = 0, r.mode = 8;
						case 8:
							if (4096 & r.flags) {
								if (0 === o) break e;
								for (d = 0; k = n[s + d++], r.head && k && r.length < 65536 && (r.head.comment += String.fromCharCode(k)), k && d < o;);
								if (512 & r.flags && (r.check = B(r.check, n, d, s)), o -= d, s += d, k) break e;
							} else r.head && (r.head.comment = null);
							r.mode = 9;
						case 9:
							if (512 & r.flags) {
								for (; l < 16;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								if (u !== (65535 & r.check)) {
									e.msg = "header crc mismatch", r.mode = 30;
									break;
								}
								l = u = 0;
							}
							r.head && (r.head.hcrc = r.flags >> 9 & 1, r.head.done = !0), e.adler = r.check = 0, r.mode = 12;
							break;
						case 10:
							for (; l < 32;) {
								if (0 === o) break e;
								o--, u += n[s++] << l, l += 8;
							}
							e.adler = r.check = L(u), l = u = 0, r.mode = 11;
						case 11:
							if (0 === r.havedict) return e.next_out = a, e.avail_out = h, e.next_in = s, e.avail_in = o, r.hold = u, r.bits = l, 2;
							e.adler = r.check = 1, r.mode = 12;
						case 12: if (5 === t || 6 === t) break e;
						case 13:
							if (r.last) {
								u >>>= 7 & l, l -= 7 & l, r.mode = 27;
								break;
							}
							for (; l < 3;) {
								if (0 === o) break e;
								o--, u += n[s++] << l, l += 8;
							}
							switch (r.last = 1 & u, l -= 1, 3 & (u >>>= 1)) {
								case 0:
									r.mode = 14;
									break;
								case 1:
									if (j(r), r.mode = 20, 6 !== t) break;
									u >>>= 2, l -= 2;
									break e;
								case 2:
									r.mode = 17;
									break;
								case 3: e.msg = "invalid block type", r.mode = 30;
							}
							u >>>= 2, l -= 2;
							break;
						case 14:
							for (u >>>= 7 & l, l -= 7 & l; l < 32;) {
								if (0 === o) break e;
								o--, u += n[s++] << l, l += 8;
							}
							if ((65535 & u) != (u >>> 16 ^ 65535)) {
								e.msg = "invalid stored block lengths", r.mode = 30;
								break;
							}
							if (r.length = 65535 & u, l = u = 0, r.mode = 15, 6 === t) break e;
						case 15: r.mode = 16;
						case 16:
							if (d = r.length) {
								if (o < d && (d = o), h < d && (d = h), 0 === d) break e;
								I.arraySet(i, n, s, d, a), o -= d, s += d, h -= d, a += d, r.length -= d;
								break;
							}
							r.mode = 12;
							break;
						case 17:
							for (; l < 14;) {
								if (0 === o) break e;
								o--, u += n[s++] << l, l += 8;
							}
							if (r.nlen = 257 + (31 & u), u >>>= 5, l -= 5, r.ndist = 1 + (31 & u), u >>>= 5, l -= 5, r.ncode = 4 + (15 & u), u >>>= 4, l -= 4, 286 < r.nlen || 30 < r.ndist) {
								e.msg = "too many length or distance symbols", r.mode = 30;
								break;
							}
							r.have = 0, r.mode = 18;
						case 18:
							for (; r.have < r.ncode;) {
								for (; l < 3;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								r.lens[A[r.have++]] = 7 & u, u >>>= 3, l -= 3;
							}
							for (; r.have < 19;) r.lens[A[r.have++]] = 0;
							if (r.lencode = r.lendyn, r.lenbits = 7, S = { bits: r.lenbits }, x = T(0, r.lens, 0, 19, r.lencode, 0, r.work, S), r.lenbits = S.bits, x) {
								e.msg = "invalid code lengths set", r.mode = 30;
								break;
							}
							r.have = 0, r.mode = 19;
						case 19:
							for (; r.have < r.nlen + r.ndist;) {
								for (; g = (C = r.lencode[u & (1 << r.lenbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_ = C >>> 24) <= l);) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								if (b < 16) u >>>= _, l -= _, r.lens[r.have++] = b;
								else {
									if (16 === b) {
										for (z = _ + 2; l < z;) {
											if (0 === o) break e;
											o--, u += n[s++] << l, l += 8;
										}
										if (u >>>= _, l -= _, 0 === r.have) {
											e.msg = "invalid bit length repeat", r.mode = 30;
											break;
										}
										k = r.lens[r.have - 1], d = 3 + (3 & u), u >>>= 2, l -= 2;
									} else if (17 === b) {
										for (z = _ + 3; l < z;) {
											if (0 === o) break e;
											o--, u += n[s++] << l, l += 8;
										}
										l -= _, k = 0, d = 3 + (7 & (u >>>= _)), u >>>= 3, l -= 3;
									} else {
										for (z = _ + 7; l < z;) {
											if (0 === o) break e;
											o--, u += n[s++] << l, l += 8;
										}
										l -= _, k = 0, d = 11 + (127 & (u >>>= _)), u >>>= 7, l -= 7;
									}
									if (r.have + d > r.nlen + r.ndist) {
										e.msg = "invalid bit length repeat", r.mode = 30;
										break;
									}
									for (; d--;) r.lens[r.have++] = k;
								}
							}
							if (30 === r.mode) break;
							if (0 === r.lens[256]) {
								e.msg = "invalid code -- missing end-of-block", r.mode = 30;
								break;
							}
							if (r.lenbits = 9, S = { bits: r.lenbits }, x = T(D, r.lens, 0, r.nlen, r.lencode, 0, r.work, S), r.lenbits = S.bits, x) {
								e.msg = "invalid literal/lengths set", r.mode = 30;
								break;
							}
							if (r.distbits = 6, r.distcode = r.distdyn, S = { bits: r.distbits }, x = T(F, r.lens, r.nlen, r.ndist, r.distcode, 0, r.work, S), r.distbits = S.bits, x) {
								e.msg = "invalid distances set", r.mode = 30;
								break;
							}
							if (r.mode = 20, 6 === t) break e;
						case 20: r.mode = 21;
						case 21:
							if (6 <= o && 258 <= h) {
								e.next_out = a, e.avail_out = h, e.next_in = s, e.avail_in = o, r.hold = u, r.bits = l, R(e, c), a = e.next_out, i = e.output, h = e.avail_out, s = e.next_in, n = e.input, o = e.avail_in, u = r.hold, l = r.bits, 12 === r.mode && (r.back = -1);
								break;
							}
							for (r.back = 0; g = (C = r.lencode[u & (1 << r.lenbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_ = C >>> 24) <= l);) {
								if (0 === o) break e;
								o--, u += n[s++] << l, l += 8;
							}
							if (g && 0 == (240 & g)) {
								for (v = _, y = g, w = b; g = (C = r.lencode[w + ((u & (1 << v + y) - 1) >> v)]) >>> 16 & 255, b = 65535 & C, !(v + (_ = C >>> 24) <= l);) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								u >>>= v, l -= v, r.back += v;
							}
							if (u >>>= _, l -= _, r.back += _, r.length = b, 0 === g) {
								r.mode = 26;
								break;
							}
							if (32 & g) {
								r.back = -1, r.mode = 12;
								break;
							}
							if (64 & g) {
								e.msg = "invalid literal/length code", r.mode = 30;
								break;
							}
							r.extra = 15 & g, r.mode = 22;
						case 22:
							if (r.extra) {
								for (z = r.extra; l < z;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								r.length += u & (1 << r.extra) - 1, u >>>= r.extra, l -= r.extra, r.back += r.extra;
							}
							r.was = r.length, r.mode = 23;
						case 23:
							for (; g = (C = r.distcode[u & (1 << r.distbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_ = C >>> 24) <= l);) {
								if (0 === o) break e;
								o--, u += n[s++] << l, l += 8;
							}
							if (0 == (240 & g)) {
								for (v = _, y = g, w = b; g = (C = r.distcode[w + ((u & (1 << v + y) - 1) >> v)]) >>> 16 & 255, b = 65535 & C, !(v + (_ = C >>> 24) <= l);) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								u >>>= v, l -= v, r.back += v;
							}
							if (u >>>= _, l -= _, r.back += _, 64 & g) {
								e.msg = "invalid distance code", r.mode = 30;
								break;
							}
							r.offset = b, r.extra = 15 & g, r.mode = 24;
						case 24:
							if (r.extra) {
								for (z = r.extra; l < z;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								r.offset += u & (1 << r.extra) - 1, u >>>= r.extra, l -= r.extra, r.back += r.extra;
							}
							if (r.offset > r.dmax) {
								e.msg = "invalid distance too far back", r.mode = 30;
								break;
							}
							r.mode = 25;
						case 25:
							if (0 === h) break e;
							if (d = c - h, r.offset > d) {
								if ((d = r.offset - d) > r.whave && r.sane) {
									e.msg = "invalid distance too far back", r.mode = 30;
									break;
								}
								p = d > r.wnext ? (d -= r.wnext, r.wsize - d) : r.wnext - d, d > r.length && (d = r.length), m = r.window;
							} else m = i, p = a - r.offset, d = r.length;
							for (h < d && (d = h), h -= d, r.length -= d; i[a++] = m[p++], --d;);
							0 === r.length && (r.mode = 21);
							break;
						case 26:
							if (0 === h) break e;
							i[a++] = r.length, h--, r.mode = 21;
							break;
						case 27:
							if (r.wrap) {
								for (; l < 32;) {
									if (0 === o) break e;
									o--, u |= n[s++] << l, l += 8;
								}
								if (c -= h, e.total_out += c, r.total += c, c && (e.adler = r.check = r.flags ? B(r.check, i, c, a - c) : O(r.check, i, c, a - c)), c = h, (r.flags ? u : L(u)) !== r.check) {
									e.msg = "incorrect data check", r.mode = 30;
									break;
								}
								l = u = 0;
							}
							r.mode = 28;
						case 28:
							if (r.wrap && r.flags) {
								for (; l < 32;) {
									if (0 === o) break e;
									o--, u += n[s++] << l, l += 8;
								}
								if (u !== (4294967295 & r.total)) {
									e.msg = "incorrect length check", r.mode = 30;
									break;
								}
								l = u = 0;
							}
							r.mode = 29;
						case 29:
							x = 1;
							break e;
						case 30:
							x = -3;
							break e;
						case 31: return -4;
						case 32:
						default: return U;
					}
					return e.next_out = a, e.avail_out = h, e.next_in = s, e.avail_in = o, r.hold = u, r.bits = l, (r.wsize || c !== e.avail_out && r.mode < 30 && (r.mode < 27 || 4 !== t)) && Z(e, e.output, e.next_out, c - e.avail_out) ? (r.mode = 31, -4) : (f -= e.avail_in, c -= e.avail_out, e.total_in += f, e.total_out += c, r.total += c, r.wrap && c && (e.adler = r.check = r.flags ? B(r.check, i, c, e.next_out - c) : O(r.check, i, c, e.next_out - c)), e.data_type = r.bits + (r.last ? 64 : 0) + (12 === r.mode ? 128 : 0) + (20 === r.mode || 15 === r.mode ? 256 : 0), (0 == f && 0 === c || 4 === t) && x === N && (x = -5), x);
				}, r.inflateEnd = function(e) {
					if (!e || !e.state) return U;
					var t = e.state;
					return t.window && (t.window = null), e.state = null, N;
				}, r.inflateGetHeader = function(e, t) {
					var r;
					return e && e.state ? 0 == (2 & (r = e.state).wrap) ? U : ((r.head = t).done = !1, N) : U;
				}, r.inflateSetDictionary = function(e, t) {
					var r, n = t.length;
					return e && e.state ? 0 !== (r = e.state).wrap && 11 !== r.mode ? U : 11 === r.mode && O(1, t, n, 0) !== r.check ? -3 : Z(e, t, n, n) ? (r.mode = 31, -4) : (r.havedict = 1, N) : U;
				}, r.inflateInfo = "pako inflate (from Nodeca project)";
			}, {
				"../utils/common": 41,
				"./adler32": 43,
				"./crc32": 45,
				"./inffast": 48,
				"./inftrees": 50
			}],
			50: [function(e, t, r) {
				"use strict";
				var D = e("../utils/common"), F = [
					3,
					4,
					5,
					6,
					7,
					8,
					9,
					10,
					11,
					13,
					15,
					17,
					19,
					23,
					27,
					31,
					35,
					43,
					51,
					59,
					67,
					83,
					99,
					115,
					131,
					163,
					195,
					227,
					258,
					0,
					0
				], N = [
					16,
					16,
					16,
					16,
					16,
					16,
					16,
					16,
					17,
					17,
					17,
					17,
					18,
					18,
					18,
					18,
					19,
					19,
					19,
					19,
					20,
					20,
					20,
					20,
					21,
					21,
					21,
					21,
					16,
					72,
					78
				], U = [
					1,
					2,
					3,
					4,
					5,
					7,
					9,
					13,
					17,
					25,
					33,
					49,
					65,
					97,
					129,
					193,
					257,
					385,
					513,
					769,
					1025,
					1537,
					2049,
					3073,
					4097,
					6145,
					8193,
					12289,
					16385,
					24577,
					0,
					0
				], P = [
					16,
					16,
					16,
					16,
					17,
					17,
					18,
					18,
					19,
					19,
					20,
					20,
					21,
					21,
					22,
					22,
					23,
					23,
					24,
					24,
					25,
					25,
					26,
					26,
					27,
					27,
					28,
					28,
					29,
					29,
					64,
					64
				];
				t.exports = function(e, t, r, n, i, s, a, o) {
					var h, u, l, f, c, d, p, m, _, g = o.bits, b = 0, v = 0, y = 0, w = 0, k = 0, x = 0, S = 0, z = 0, C = 0, E = 0, A = null, I = 0, O = new D.Buf16(16), B = new D.Buf16(16), R = null, T = 0;
					for (b = 0; b <= 15; b++) O[b] = 0;
					for (v = 0; v < n; v++) O[t[r + v]]++;
					for (k = g, w = 15; 1 <= w && 0 === O[w]; w--);
					if (w < k && (k = w), 0 === w) return i[s++] = 20971520, i[s++] = 20971520, o.bits = 1, 0;
					for (y = 1; y < w && 0 === O[y]; y++);
					for (k < y && (k = y), b = z = 1; b <= 15; b++) if (z <<= 1, (z -= O[b]) < 0) return -1;
					if (0 < z && (0 === e || 1 !== w)) return -1;
					for (B[1] = 0, b = 1; b < 15; b++) B[b + 1] = B[b] + O[b];
					for (v = 0; v < n; v++) 0 !== t[r + v] && (a[B[t[r + v]]++] = v);
					if (d = 0 === e ? (A = R = a, 19) : 1 === e ? (A = F, I -= 257, R = N, T -= 257, 256) : (A = U, R = P, -1), b = y, c = s, S = v = E = 0, l = -1, f = (C = 1 << (x = k)) - 1, 1 === e && 852 < C || 2 === e && 592 < C) return 1;
					for (;;) {
						for (p = b - S, _ = a[v] < d ? (m = 0, a[v]) : a[v] > d ? (m = R[T + a[v]], A[I + a[v]]) : (m = 96, 0), h = 1 << b - S, y = u = 1 << x; i[c + (E >> S) + (u -= h)] = p << 24 | m << 16 | _ | 0, 0 !== u;);
						for (h = 1 << b - 1; E & h;) h >>= 1;
						if (0 !== h ? (E &= h - 1, E += h) : E = 0, v++, 0 == --O[b]) {
							if (b === w) break;
							b = t[r + a[v]];
						}
						if (k < b && (E & f) !== l) {
							for (0 === S && (S = k), c += y, z = 1 << (x = b - S); x + S < w && !((z -= O[x + S]) <= 0);) x++, z <<= 1;
							if (C += 1 << x, 1 === e && 852 < C || 2 === e && 592 < C) return 1;
							i[l = E & f] = k << 24 | x << 16 | c - s | 0;
						}
					}
					return 0 !== E && (i[c + E] = b - S << 24 | 4194304), o.bits = k, 0;
				};
			}, { "../utils/common": 41 }],
			51: [function(e, t, r) {
				"use strict";
				t.exports = {
					2: "need dictionary",
					1: "stream end",
					0: "",
					"-1": "file error",
					"-2": "stream error",
					"-3": "data error",
					"-4": "insufficient memory",
					"-5": "buffer error",
					"-6": "incompatible version"
				};
			}, {}],
			52: [function(e, t, r) {
				"use strict";
				var i = e("../utils/common"), o = 0, h = 1;
				function n(e) {
					for (var t = e.length; 0 <= --t;) e[t] = 0;
				}
				var s = 0, a = 29, u = 256, l = u + 1 + a, f = 30, c = 19, _ = 2 * l + 1, g = 15, d = 16, p = 7, m = 256, b = 16, v = 17, y = 18, w = [
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					1,
					1,
					1,
					1,
					2,
					2,
					2,
					2,
					3,
					3,
					3,
					3,
					4,
					4,
					4,
					4,
					5,
					5,
					5,
					5,
					0
				], k = [
					0,
					0,
					0,
					0,
					1,
					1,
					2,
					2,
					3,
					3,
					4,
					4,
					5,
					5,
					6,
					6,
					7,
					7,
					8,
					8,
					9,
					9,
					10,
					10,
					11,
					11,
					12,
					12,
					13,
					13
				], x = [
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					2,
					3,
					7
				], S = [
					16,
					17,
					18,
					0,
					8,
					7,
					9,
					6,
					10,
					5,
					11,
					4,
					12,
					3,
					13,
					2,
					14,
					1,
					15
				], z = new Array(2 * (l + 2));
				n(z);
				var C = new Array(2 * f);
				n(C);
				var E = new Array(512);
				n(E);
				var A = new Array(256);
				n(A);
				var I = new Array(a);
				n(I);
				var O, B, R, T = new Array(f);
				function D(e, t, r, n, i) {
					this.static_tree = e, this.extra_bits = t, this.extra_base = r, this.elems = n, this.max_length = i, this.has_stree = e && e.length;
				}
				function F(e, t) {
					this.dyn_tree = e, this.max_code = 0, this.stat_desc = t;
				}
				function N(e) {
					return e < 256 ? E[e] : E[256 + (e >>> 7)];
				}
				function U(e, t) {
					e.pending_buf[e.pending++] = 255 & t, e.pending_buf[e.pending++] = t >>> 8 & 255;
				}
				function P(e, t, r) {
					e.bi_valid > d - r ? (e.bi_buf |= t << e.bi_valid & 65535, U(e, e.bi_buf), e.bi_buf = t >> d - e.bi_valid, e.bi_valid += r - d) : (e.bi_buf |= t << e.bi_valid & 65535, e.bi_valid += r);
				}
				function L(e, t, r) {
					P(e, r[2 * t], r[2 * t + 1]);
				}
				function j(e, t) {
					for (var r = 0; r |= 1 & e, e >>>= 1, r <<= 1, 0 < --t;);
					return r >>> 1;
				}
				function Z(e, t, r) {
					var n, i, s = new Array(g + 1), a = 0;
					for (n = 1; n <= g; n++) s[n] = a = a + r[n - 1] << 1;
					for (i = 0; i <= t; i++) {
						var o = e[2 * i + 1];
						0 !== o && (e[2 * i] = j(s[o]++, o));
					}
				}
				function W(e) {
					var t;
					for (t = 0; t < l; t++) e.dyn_ltree[2 * t] = 0;
					for (t = 0; t < f; t++) e.dyn_dtree[2 * t] = 0;
					for (t = 0; t < c; t++) e.bl_tree[2 * t] = 0;
					e.dyn_ltree[2 * m] = 1, e.opt_len = e.static_len = 0, e.last_lit = e.matches = 0;
				}
				function M(e) {
					8 < e.bi_valid ? U(e, e.bi_buf) : 0 < e.bi_valid && (e.pending_buf[e.pending++] = e.bi_buf), e.bi_buf = 0, e.bi_valid = 0;
				}
				function H(e, t, r, n) {
					var i = 2 * t, s = 2 * r;
					return e[i] < e[s] || e[i] === e[s] && n[t] <= n[r];
				}
				function G(e, t, r) {
					for (var n = e.heap[r], i = r << 1; i <= e.heap_len && (i < e.heap_len && H(t, e.heap[i + 1], e.heap[i], e.depth) && i++, !H(t, n, e.heap[i], e.depth));) e.heap[r] = e.heap[i], r = i, i <<= 1;
					e.heap[r] = n;
				}
				function K(e, t, r) {
					var n, i, s, a, o = 0;
					if (0 !== e.last_lit) for (; n = e.pending_buf[e.d_buf + 2 * o] << 8 | e.pending_buf[e.d_buf + 2 * o + 1], i = e.pending_buf[e.l_buf + o], o++, 0 === n ? L(e, i, t) : (L(e, (s = A[i]) + u + 1, t), 0 !== (a = w[s]) && P(e, i -= I[s], a), L(e, s = N(--n), r), 0 !== (a = k[s]) && P(e, n -= T[s], a)), o < e.last_lit;);
					L(e, m, t);
				}
				function Y(e, t) {
					var r, n, i, s = t.dyn_tree, a = t.stat_desc.static_tree, o = t.stat_desc.has_stree, h = t.stat_desc.elems, u = -1;
					for (e.heap_len = 0, e.heap_max = _, r = 0; r < h; r++) 0 !== s[2 * r] ? (e.heap[++e.heap_len] = u = r, e.depth[r] = 0) : s[2 * r + 1] = 0;
					for (; e.heap_len < 2;) s[2 * (i = e.heap[++e.heap_len] = u < 2 ? ++u : 0)] = 1, e.depth[i] = 0, e.opt_len--, o && (e.static_len -= a[2 * i + 1]);
					for (t.max_code = u, r = e.heap_len >> 1; 1 <= r; r--) G(e, s, r);
					for (i = h; r = e.heap[1], e.heap[1] = e.heap[e.heap_len--], G(e, s, 1), n = e.heap[1], e.heap[--e.heap_max] = r, e.heap[--e.heap_max] = n, s[2 * i] = s[2 * r] + s[2 * n], e.depth[i] = (e.depth[r] >= e.depth[n] ? e.depth[r] : e.depth[n]) + 1, s[2 * r + 1] = s[2 * n + 1] = i, e.heap[1] = i++, G(e, s, 1), 2 <= e.heap_len;);
					e.heap[--e.heap_max] = e.heap[1], function(e, t) {
						var r, n, i, s, a, o, h = t.dyn_tree, u = t.max_code, l = t.stat_desc.static_tree, f = t.stat_desc.has_stree, c = t.stat_desc.extra_bits, d = t.stat_desc.extra_base, p = t.stat_desc.max_length, m = 0;
						for (s = 0; s <= g; s++) e.bl_count[s] = 0;
						for (h[2 * e.heap[e.heap_max] + 1] = 0, r = e.heap_max + 1; r < _; r++) p < (s = h[2 * h[2 * (n = e.heap[r]) + 1] + 1] + 1) && (s = p, m++), h[2 * n + 1] = s, u < n || (e.bl_count[s]++, a = 0, d <= n && (a = c[n - d]), o = h[2 * n], e.opt_len += o * (s + a), f && (e.static_len += o * (l[2 * n + 1] + a)));
						if (0 !== m) {
							do {
								for (s = p - 1; 0 === e.bl_count[s];) s--;
								e.bl_count[s]--, e.bl_count[s + 1] += 2, e.bl_count[p]--, m -= 2;
							} while (0 < m);
							for (s = p; 0 !== s; s--) for (n = e.bl_count[s]; 0 !== n;) u < (i = e.heap[--r]) || (h[2 * i + 1] !== s && (e.opt_len += (s - h[2 * i + 1]) * h[2 * i], h[2 * i + 1] = s), n--);
						}
					}(e, t), Z(s, u, e.bl_count);
				}
				function X(e, t, r) {
					var n, i, s = -1, a = t[1], o = 0, h = 7, u = 4;
					for (0 === a && (h = 138, u = 3), t[2 * (r + 1) + 1] = 65535, n = 0; n <= r; n++) i = a, a = t[2 * (n + 1) + 1], ++o < h && i === a || (o < u ? e.bl_tree[2 * i] += o : 0 !== i ? (i !== s && e.bl_tree[2 * i]++, e.bl_tree[2 * b]++) : o <= 10 ? e.bl_tree[2 * v]++ : e.bl_tree[2 * y]++, s = i, u = (o = 0) === a ? (h = 138, 3) : i === a ? (h = 6, 3) : (h = 7, 4));
				}
				function V(e, t, r) {
					var n, i, s = -1, a = t[1], o = 0, h = 7, u = 4;
					for (0 === a && (h = 138, u = 3), n = 0; n <= r; n++) if (i = a, a = t[2 * (n + 1) + 1], !(++o < h && i === a)) {
						if (o < u) for (; L(e, i, e.bl_tree), 0 != --o;);
						else 0 !== i ? (i !== s && (L(e, i, e.bl_tree), o--), L(e, b, e.bl_tree), P(e, o - 3, 2)) : o <= 10 ? (L(e, v, e.bl_tree), P(e, o - 3, 3)) : (L(e, y, e.bl_tree), P(e, o - 11, 7));
						s = i, u = (o = 0) === a ? (h = 138, 3) : i === a ? (h = 6, 3) : (h = 7, 4);
					}
				}
				n(T);
				var q = !1;
				function J(e, t, r, n) {
					P(e, (s << 1) + (n ? 1 : 0), 3), function(e, t, r, n) {
						M(e), n && (U(e, r), U(e, ~r)), i.arraySet(e.pending_buf, e.window, t, r, e.pending), e.pending += r;
					}(e, t, r, !0);
				}
				r._tr_init = function(e) {
					q || (function() {
						var e, t, r, n, i, s = new Array(g + 1);
						for (n = r = 0; n < a - 1; n++) for (I[n] = r, e = 0; e < 1 << w[n]; e++) A[r++] = n;
						for (A[r - 1] = n, n = i = 0; n < 16; n++) for (T[n] = i, e = 0; e < 1 << k[n]; e++) E[i++] = n;
						for (i >>= 7; n < f; n++) for (T[n] = i << 7, e = 0; e < 1 << k[n] - 7; e++) E[256 + i++] = n;
						for (t = 0; t <= g; t++) s[t] = 0;
						for (e = 0; e <= 143;) z[2 * e + 1] = 8, e++, s[8]++;
						for (; e <= 255;) z[2 * e + 1] = 9, e++, s[9]++;
						for (; e <= 279;) z[2 * e + 1] = 7, e++, s[7]++;
						for (; e <= 287;) z[2 * e + 1] = 8, e++, s[8]++;
						for (Z(z, l + 1, s), e = 0; e < f; e++) C[2 * e + 1] = 5, C[2 * e] = j(e, 5);
						O = new D(z, w, u + 1, l, g), B = new D(C, k, 0, f, g), R = new D(new Array(0), x, 0, c, p);
					}(), q = !0), e.l_desc = new F(e.dyn_ltree, O), e.d_desc = new F(e.dyn_dtree, B), e.bl_desc = new F(e.bl_tree, R), e.bi_buf = 0, e.bi_valid = 0, W(e);
				}, r._tr_stored_block = J, r._tr_flush_block = function(e, t, r, n) {
					var i, s, a = 0;
					0 < e.level ? (2 === e.strm.data_type && (e.strm.data_type = function(e) {
						var t, r = 4093624447;
						for (t = 0; t <= 31; t++, r >>>= 1) if (1 & r && 0 !== e.dyn_ltree[2 * t]) return o;
						if (0 !== e.dyn_ltree[18] || 0 !== e.dyn_ltree[20] || 0 !== e.dyn_ltree[26]) return h;
						for (t = 32; t < u; t++) if (0 !== e.dyn_ltree[2 * t]) return h;
						return o;
					}(e)), Y(e, e.l_desc), Y(e, e.d_desc), a = function(e) {
						var t;
						for (X(e, e.dyn_ltree, e.l_desc.max_code), X(e, e.dyn_dtree, e.d_desc.max_code), Y(e, e.bl_desc), t = c - 1; 3 <= t && 0 === e.bl_tree[2 * S[t] + 1]; t--);
						return e.opt_len += 3 * (t + 1) + 5 + 5 + 4, t;
					}(e), i = e.opt_len + 3 + 7 >>> 3, (s = e.static_len + 3 + 7 >>> 3) <= i && (i = s)) : i = s = r + 5, r + 4 <= i && -1 !== t ? J(e, t, r, n) : 4 === e.strategy || s === i ? (P(e, 2 + (n ? 1 : 0), 3), K(e, z, C)) : (P(e, 4 + (n ? 1 : 0), 3), function(e, t, r, n) {
						var i;
						for (P(e, t - 257, 5), P(e, r - 1, 5), P(e, n - 4, 4), i = 0; i < n; i++) P(e, e.bl_tree[2 * S[i] + 1], 3);
						V(e, e.dyn_ltree, t - 1), V(e, e.dyn_dtree, r - 1);
					}(e, e.l_desc.max_code + 1, e.d_desc.max_code + 1, a + 1), K(e, e.dyn_ltree, e.dyn_dtree)), W(e), n && M(e);
				}, r._tr_tally = function(e, t, r) {
					return e.pending_buf[e.d_buf + 2 * e.last_lit] = t >>> 8 & 255, e.pending_buf[e.d_buf + 2 * e.last_lit + 1] = 255 & t, e.pending_buf[e.l_buf + e.last_lit] = 255 & r, e.last_lit++, 0 === t ? e.dyn_ltree[2 * r]++ : (e.matches++, t--, e.dyn_ltree[2 * (A[r] + u + 1)]++, e.dyn_dtree[2 * N(t)]++), e.last_lit === e.lit_bufsize - 1;
				}, r._tr_align = function(e) {
					P(e, 2, 3), L(e, m, z), function(e) {
						16 === e.bi_valid ? (U(e, e.bi_buf), e.bi_buf = 0, e.bi_valid = 0) : 8 <= e.bi_valid && (e.pending_buf[e.pending++] = 255 & e.bi_buf, e.bi_buf >>= 8, e.bi_valid -= 8);
					}(e);
				};
			}, { "../utils/common": 41 }],
			53: [function(e, t, r) {
				"use strict";
				t.exports = function() {
					this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0;
				};
			}, {}],
			54: [function(e, t, r) {
				(function(e) {
					(function(r, n) {
						"use strict";
						if (!r.setImmediate) {
							var i, s, t, a, o = 1, h = {}, u = !1, l = r.document, e = Object.getPrototypeOf && Object.getPrototypeOf(r);
							e = e && e.setTimeout ? e : r, i = "[object process]" === {}.toString.call(r.process) ? function(e) {
								process$1.nextTick(function() {
									c(e);
								});
							} : function() {
								if (r.postMessage && !r.importScripts) {
									var e = !0, t = r.onmessage;
									return r.onmessage = function() {
										e = !1;
									}, r.postMessage("", "*"), r.onmessage = t, e;
								}
							}() ? (a = "setImmediate$" + Math.random() + "$", r.addEventListener ? r.addEventListener("message", d, !1) : r.attachEvent("onmessage", d), function(e) {
								r.postMessage(a + e, "*");
							}) : r.MessageChannel ? ((t = new MessageChannel()).port1.onmessage = function(e) {
								c(e.data);
							}, function(e) {
								t.port2.postMessage(e);
							}) : l && "onreadystatechange" in l.createElement("script") ? (s = l.documentElement, function(e) {
								var t = l.createElement("script");
								t.onreadystatechange = function() {
									c(e), t.onreadystatechange = null, s.removeChild(t), t = null;
								}, s.appendChild(t);
							}) : function(e) {
								setTimeout(c, 0, e);
							}, e.setImmediate = function(e) {
								"function" != typeof e && (e = new Function("" + e));
								for (var t = new Array(arguments.length - 1), r = 0; r < t.length; r++) t[r] = arguments[r + 1];
								return h[o] = {
									callback: e,
									args: t
								}, i(o), o++;
							}, e.clearImmediate = f;
						}
						function f(e) {
							delete h[e];
						}
						function c(e) {
							if (u) setTimeout(c, 0, e);
							else {
								var t = h[e];
								if (t) {
									u = !0;
									try {
										(function(e) {
											var t = e.callback, r = e.args;
											switch (r.length) {
												case 0:
													t();
													break;
												case 1:
													t(r[0]);
													break;
												case 2:
													t(r[0], r[1]);
													break;
												case 3:
													t(r[0], r[1], r[2]);
													break;
												default: t.apply(n, r);
											}
										})(t);
									} finally {
										f(e), u = !1;
									}
								}
							}
						}
						function d(e) {
							e.source === r && "string" == typeof e.data && 0 === e.data.indexOf(a) && c(+e.data.slice(a.length));
						}
					})("undefined" == typeof self ? void 0 === e ? this : e : self);
				}).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
			}, {}]
		}, {}, [10])(10);
	});
}));
var require_escapeForXML = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var XML_CHARACTER_MAP = {
		"&": "&amp;",
		"\"": "&quot;",
		"'": "&apos;",
		"<": "&lt;",
		">": "&gt;"
	};
	function escapeForXML(string) {
		return string && string.replace ? string.replace(/([&"<>'])/g, function(str, item) {
			return XML_CHARACTER_MAP[item];
		}) : string;
	}
	module.exports = escapeForXML;
}));
var require_xml = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	init_dist();
	var escapeForXML = require_escapeForXML();
	var Stream = require_stream_browserify().Stream;
	var DEFAULT_INDENT = "    ";
	function xml(input, options) {
		if (typeof options !== "object") options = { indent: options };
		var stream = options.stream ? new Stream() : null, output = "", interrupted = false, indent = !options.indent ? "" : options.indent === true ? DEFAULT_INDENT : options.indent, instant = true;
		function delay(func) {
			if (!instant) func();
			else process$1.nextTick(func);
		}
		function append(interrupt, out) {
			if (out !== void 0) output += out;
			if (interrupt && !interrupted) {
				stream = stream || new Stream();
				interrupted = true;
			}
			if (interrupt && interrupted) {
				var data = output;
				delay(function() {
					stream.emit("data", data);
				});
				output = "";
			}
		}
		function add(value, last) {
			format(append, resolve(value, indent, indent ? 1 : 0), last);
		}
		function end() {
			if (stream) {
				var data = output;
				delay(function() {
					stream.emit("data", data);
					stream.emit("end");
					stream.readable = false;
					stream.emit("close");
				});
			}
		}
		function addXmlDeclaration(declaration) {
			var attr = {
				version: "1.0",
				encoding: declaration.encoding || "UTF-8"
			};
			if (declaration.standalone) attr.standalone = declaration.standalone;
			add({ "?xml": { _attr: attr } });
			output = output.replace("/>", "?>");
		}
		delay(function() {
			instant = false;
		});
		if (options.declaration) addXmlDeclaration(options.declaration);
		if (input && input.forEach) input.forEach(function(value, i) {
			var last;
			if (i + 1 === input.length) last = end;
			add(value, last);
		});
		else add(input, end);
		if (stream) {
			stream.readable = true;
			return stream;
		}
		return output;
	}
	function element() {
		var self = { _elem: resolve(Array.prototype.slice.call(arguments)) };
		self.push = function(input) {
			if (!this.append) throw new Error("not assigned to a parent!");
			var that = this;
			var indent = this._elem.indent;
			format(this.append, resolve(input, indent, this._elem.icount + (indent ? 1 : 0)), function() {
				that.append(true);
			});
		};
		self.close = function(input) {
			if (input !== void 0) this.push(input);
			if (this.end) this.end();
		};
		return self;
	}
	function create_indent(character, count) {
		return new Array(count || 0).join(character || "");
	}
	function resolve(data, indent, indent_count) {
		indent_count = indent_count || 0;
		var indent_spaces = create_indent(indent, indent_count);
		var name;
		var values = data;
		var interrupt = false;
		if (typeof data === "object") {
			name = Object.keys(data)[0];
			values = data[name];
			if (values && values._elem) {
				values._elem.name = name;
				values._elem.icount = indent_count;
				values._elem.indent = indent;
				values._elem.indents = indent_spaces;
				values._elem.interrupt = values;
				return values._elem;
			}
		}
		var attributes = [], content = [];
		var isStringContent;
		function get_attributes(obj) {
			Object.keys(obj).forEach(function(key) {
				attributes.push(attribute(key, obj[key]));
			});
		}
		switch (typeof values) {
			case "object":
				if (values === null) break;
				if (values._attr) get_attributes(values._attr);
				if (values._cdata) content.push(("<![CDATA[" + values._cdata).replace(/\]\]>/g, "]]]]><![CDATA[>") + "]]>");
				if (values.forEach) {
					isStringContent = false;
					content.push("");
					values.forEach(function(value) {
						if (typeof value == "object") if (Object.keys(value)[0] == "_attr") get_attributes(value._attr);
						else content.push(resolve(value, indent, indent_count + 1));
						else {
							content.pop();
							isStringContent = true;
							content.push(escapeForXML(value));
						}
					});
					if (!isStringContent) content.push("");
				}
				break;
			default: content.push(escapeForXML(values));
		}
		return {
			name,
			interrupt,
			attributes,
			content,
			icount: indent_count,
			indents: indent_spaces,
			indent
		};
	}
	function format(append, elem, end) {
		if (typeof elem != "object") return append(false, elem);
		var len = elem.interrupt ? 1 : elem.content.length;
		function proceed() {
			while (elem.content.length) {
				var value = elem.content.shift();
				if (value === void 0) continue;
				if (interrupt(value)) return;
				format(append, value);
			}
			append(false, (len > 1 ? elem.indents : "") + (elem.name ? "</" + elem.name + ">" : "") + (elem.indent && !end ? "\n" : ""));
			if (end) end();
		}
		function interrupt(value) {
			if (value.interrupt) {
				value.interrupt.append = append;
				value.interrupt.end = proceed;
				value.interrupt = false;
				append(true);
				return true;
			}
			return false;
		}
		append(false, elem.indents + (elem.name ? "<" + elem.name : "") + (elem.attributes.length ? " " + elem.attributes.join(" ") : "") + (len ? elem.name ? ">" : "" : elem.name ? "/>" : "") + (elem.indent && len > 1 ? "\n" : ""));
		if (!len) return append(false, elem.indent ? "\n" : "");
		if (!interrupt(elem)) proceed();
	}
	function attribute(key, value) {
		return key + "=\"" + escapeForXML(value) + "\"";
	}
	module.exports = xml;
	module.exports.element = module.exports.Element = element;
}));
var import_stream_browserify = require_stream_browserify();
var import_jszip_min = /* @__PURE__ */ __toESM(require_jszip_min(), 1);
var import_xml = /* @__PURE__ */ __toESM(require_xml(), 1);
/**
* Font obfuscation module for embedding fonts in WordprocessingML documents.
*
* This module implements the OOXML font obfuscation algorithm used to embed
* fonts in DOCX documents. Obfuscation is required by the OOXML specification
* to prevent simple extraction of embedded font files.
*
* Reference: ECMA-376 Part 2, Section 11.1 (Font Embedding)
*
* @module
*/
/** Start offset for obfuscation in the font file */
var obfuscatedStartOffset = 0;
/** End offset for obfuscation (first 32 bytes are obfuscated) */
var obfuscatedEndOffset = 32;
/** Expected GUID size (32 hex characters without dashes) */
var guidSize = 32;
/**
* Obfuscates a TrueType font file for embedding in OOXML documents.
*
* The obfuscation algorithm XORs the first 32 bytes of the font file
* with a reversed byte sequence derived from the font's GUID key.
* This prevents simple extraction while maintaining font functionality.
*
* @param buf - The original font file as a byte array
* @param fontKey - The GUID key for the font (with or without dashes)
* @returns The obfuscated font data
* @throws Error if the fontKey is not a valid 32-character GUID
*
* @example
* ```typescript
* const fontData = readFileSync("font.ttf");
* const fontKey = "00000000-0000-0000-0000-000000000000";
* const obfuscatedData = obfuscate(fontData, fontKey);
* ```
*
* @internal
*/
var obfuscate = (buf, fontKey) => {
	const guid = fontKey.replace(/-/g, "");
	if (guid.length !== guidSize) throw new Error(`Error: Cannot extract GUID from font filename: ${fontKey}`);
	const hexNumbers = guid.replace(/(..)/g, "$1 ").trim().split(" ").map((hexString) => parseInt(hexString, 16));
	hexNumbers.reverse();
	const obfuscatedBytes = buf.slice(obfuscatedStartOffset, obfuscatedEndOffset).map((byte, i) => byte ^ hexNumbers[i % hexNumbers.length]);
	const out = new Uint8Array(obfuscatedStartOffset + obfuscatedBytes.length + Math.max(0, buf.length - obfuscatedEndOffset));
	out.set(buf.slice(0, obfuscatedStartOffset));
	out.set(obfuscatedBytes, obfuscatedStartOffset);
	out.set(buf.slice(obfuscatedEndOffset), obfuscatedStartOffset + obfuscatedBytes.length);
	return out;
};
/**
* Converts XML components into serializable objects ready for XML generation.
*
* The Formatter is responsible for preparing XML components for serialization by calling
* their prepForXml method with the appropriate context. This is a critical step in the
* export pipeline that transforms the declarative API objects into XML-compatible structures.
*
* @example
* ```typescript
* const formatter = new Formatter();
* const paragraph = new Paragraph("Hello World");
* const xmlObject = formatter.format(paragraph, context);
* ```
*/
var Formatter = class {
	/**
	* Formats an XML component into a serializable object.
	*
	* @param input - The XML component to format
	* @param context - The context containing file state and relationships
	* @returns A serializable XML object structure
	* @throws Error if the component cannot be formatted correctly
	*/
	format(input, context = { stack: [] }) {
		const output = input.prepForXml(context);
		if (output) return output;
		else throw Error("XMLComponent did not format correctly");
	}
};
/**
* Replaces image placeholders with relationship IDs in XML content.
*
* During document compilation, images are referenced using placeholder tokens
* like {image1.png}. This class replaces those placeholders with the actual
* relationship IDs used in the OOXML structure.
*
* @example
* ```typescript
* const replacer = new ImageReplacer();
* const mediaData = replacer.getMediaData(xmlString, media);
* const updatedXml = replacer.replace(xmlString, mediaData, 1);
* ```
*/
var ImageReplacer = class {
	/**
	* Replaces image placeholder tokens with relationship IDs.
	*
	* @param xmlData - The XML string containing image placeholders
	* @param mediaData - Array of media data to replace
	* @param offset - Starting offset for relationship IDs
	* @returns XML string with placeholders replaced by relationship IDs
	*/
	replace(xmlData, mediaData, offset) {
		let currentXmlData = xmlData;
		mediaData.forEach((image, i) => {
			currentXmlData = currentXmlData.replace(new RegExp(`{${image.fileName}}`, "g"), (offset + i).toString());
		});
		return currentXmlData;
	}
	/**
	* Extracts media data referenced in the XML content.
	*
	* @param xmlData - The XML string to search for media references
	* @param media - The media collection to search within
	* @returns Array of media data found in the XML
	*/
	getMediaData(xmlData, media) {
		return media.Array.filter((image) => xmlData.search(`{${image.fileName}}`) > 0);
	}
};
/**
* Replaces numbering instance placeholders with actual numbering IDs in XML content.
*
* Numbering instances (for bullets and numbered lists) use placeholder tokens during
* compilation. This class replaces those placeholders with the final numbering IDs
* that reference the numbering definitions in numbering.xml.
*
* @example
* ```typescript
* const replacer = new NumberingReplacer();
* const updatedXml = replacer.replace(xmlString, concreteNumberings);
* ```
*/
var NumberingReplacer = class {
	/**
	* Replaces numbering placeholder tokens with actual numbering IDs.
	*
	* Placeholder format: {reference-instance} where reference identifies the
	* numbering definition and instance is the specific usage.
	*
	* @param xmlData - The XML string containing numbering placeholders
	* @param concreteNumberings - Array of concrete numbering instances to replace
	* @returns XML string with placeholders replaced by numbering IDs
	*/
	replace(xmlData, concreteNumberings) {
		let currentXmlData = xmlData;
		for (const concreteNumbering of concreteNumberings) currentXmlData = currentXmlData.replace(new RegExp(`{${concreteNumbering.reference}-${concreteNumbering.instance}}`, "g"), concreteNumbering.numId.toString());
		return currentXmlData;
	}
};
/**
* Compiler module for converting File objects into OOXML ZIP archives.
*
* @module
*/
/**
* Compiles File objects into OOXML-compliant ZIP archives.
*
* The Compiler is responsible for converting the internal document representation
* into the complete set of XML files required for a .docx document, managing
* relationships, images, fonts, and all other document components.
*
* @example
* ```typescript
* const compiler = new Compiler();
* const zip = compiler.compile(file, PrettifyType.WITH_2_BLANKS);
* ```
*/
var Compiler = class {
	/**
	* Creates a new Compiler instance.
	*
	* Initializes the formatter and replacer utilities used during compilation.
	*/
	constructor() {
		_defineProperty(this, "formatter", void 0);
		_defineProperty(this, "imageReplacer", void 0);
		_defineProperty(this, "numberingReplacer", void 0);
		this.formatter = new Formatter();
		this.imageReplacer = new ImageReplacer();
		this.numberingReplacer = new NumberingReplacer();
	}
	/**
	* Compiles a File object into a JSZip archive containing the complete OOXML package.
	*
	* This method orchestrates the entire compilation process:
	* - Converts all document components to XML
	* - Manages image and numbering placeholder replacements
	* - Creates relationship files
	* - Packages fonts and media files
	* - Assembles everything into a ZIP archive
	*
	* @param file - The document to compile
	* @param prettifyXml - Optional XML formatting style
	* @param overrides - Optional custom XML file overrides
	* @returns A JSZip instance containing the complete .docx package
	*/
	compile(file, prettifyXml, overrides = []) {
		const zip = new import_jszip_min.default();
		const xmlifiedFileMapping = this.xmlifyFile(file, prettifyXml);
		const map = new Map(Object.entries(xmlifiedFileMapping));
		for (const [, obj] of map) if (Array.isArray(obj)) for (const subFile of obj) zip.file(subFile.path, encodeUtf8(subFile.data));
		else zip.file(obj.path, encodeUtf8(obj.data));
		for (const subFile of overrides) zip.file(subFile.path, encodeUtf8(subFile.data));
		for (const data of file.Media.Array) if (data.type !== "svg") zip.file(`word/media/${data.fileName}`, data.data);
		else {
			zip.file(`word/media/${data.fileName}`, data.data);
			zip.file(`word/media/${data.fallback.fileName}`, data.fallback.data);
		}
		for (const [i, { data: buffer, fontKey }] of file.FontTable.fontOptionsWithKey.entries()) zip.file(`word/fonts/font${i + 1}.odttf`, obfuscate(buffer, fontKey));
		return zip;
	}
	xmlifyFile(file, prettify) {
		const documentRelationshipCount = file.Document.Relationships.RelationshipCount + 1;
		const documentXmlData = (0, import_xml.default)(this.formatter.format(file.Document.View, {
			viewWrapper: file.Document,
			file,
			stack: []
		}), {
			indent: prettify,
			declaration: {
				standalone: "yes",
				encoding: "UTF-8"
			}
		});
		const commentRelationshipCount = file.Comments.Relationships.RelationshipCount + 1;
		const commentXmlData = (0, import_xml.default)(this.formatter.format(file.Comments, {
			viewWrapper: {
				View: file.Comments,
				Relationships: file.Comments.Relationships
			},
			file,
			stack: []
		}), {
			indent: prettify,
			declaration: {
				standalone: "yes",
				encoding: "UTF-8"
			}
		});
		const footnoteRelationshipCount = file.FootNotes.Relationships.RelationshipCount + 1;
		const footnoteXmlData = (0, import_xml.default)(this.formatter.format(file.FootNotes.View, {
			viewWrapper: file.FootNotes,
			file,
			stack: []
		}), {
			indent: prettify,
			declaration: {
				standalone: "yes",
				encoding: "UTF-8"
			}
		});
		const documentMediaDatas = this.imageReplacer.getMediaData(documentXmlData, file.Media);
		const commentMediaDatas = this.imageReplacer.getMediaData(commentXmlData, file.Media);
		const footnoteMediaDatas = this.imageReplacer.getMediaData(footnoteXmlData, file.Media);
		return _objectSpread2(_objectSpread2({
			Relationships: {
				data: (() => {
					documentMediaDatas.forEach((mediaData, i) => {
						file.Document.Relationships.addRelationship(documentRelationshipCount + i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${mediaData.fileName}`);
					});
					file.Document.Relationships.addRelationship(file.Document.Relationships.RelationshipCount + 1, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/fontTable", "fontTable.xml");
					return (0, import_xml.default)(this.formatter.format(file.Document.Relationships, {
						viewWrapper: file.Document,
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: { encoding: "UTF-8" }
					});
				})(),
				path: "word/_rels/document.xml.rels"
			},
			Document: {
				data: (() => {
					const xmlData = this.imageReplacer.replace(documentXmlData, documentMediaDatas, documentRelationshipCount);
					return this.numberingReplacer.replace(xmlData, file.Numbering.ConcreteNumbering);
				})(),
				path: "word/document.xml"
			},
			Styles: {
				data: (() => {
					const xmlStyles = (0, import_xml.default)(this.formatter.format(file.Styles, {
						viewWrapper: file.Document,
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: {
							standalone: "yes",
							encoding: "UTF-8"
						}
					});
					return this.numberingReplacer.replace(xmlStyles, file.Numbering.ConcreteNumbering);
				})(),
				path: "word/styles.xml"
			},
			Properties: {
				data: (0, import_xml.default)(this.formatter.format(file.CoreProperties, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "docProps/core.xml"
			},
			Numbering: {
				data: (0, import_xml.default)(this.formatter.format(file.Numbering, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "word/numbering.xml"
			},
			FileRelationships: {
				data: (0, import_xml.default)(this.formatter.format(file.FileRelationships, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				}),
				path: "_rels/.rels"
			},
			HeaderRelationships: file.Headers.map((headerWrapper, index) => {
				const xmlData = (0, import_xml.default)(this.formatter.format(headerWrapper.View, {
					viewWrapper: headerWrapper,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				});
				this.imageReplacer.getMediaData(xmlData, file.Media).forEach((mediaData, i) => {
					headerWrapper.Relationships.addRelationship(i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${mediaData.fileName}`);
				});
				return {
					data: (0, import_xml.default)(this.formatter.format(headerWrapper.Relationships, {
						viewWrapper: headerWrapper,
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: { encoding: "UTF-8" }
					}),
					path: `word/_rels/header${index + 1}.xml.rels`
				};
			}),
			FooterRelationships: file.Footers.map((footerWrapper, index) => {
				const xmlData = (0, import_xml.default)(this.formatter.format(footerWrapper.View, {
					viewWrapper: footerWrapper,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				});
				this.imageReplacer.getMediaData(xmlData, file.Media).forEach((mediaData, i) => {
					footerWrapper.Relationships.addRelationship(i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${mediaData.fileName}`);
				});
				return {
					data: (0, import_xml.default)(this.formatter.format(footerWrapper.Relationships, {
						viewWrapper: footerWrapper,
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: { encoding: "UTF-8" }
					}),
					path: `word/_rels/footer${index + 1}.xml.rels`
				};
			}),
			Headers: file.Headers.map((headerWrapper, index) => {
				const tempXmlData = (0, import_xml.default)(this.formatter.format(headerWrapper.View, {
					viewWrapper: headerWrapper,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				});
				const mediaDatas = this.imageReplacer.getMediaData(tempXmlData, file.Media);
				const xmlData = this.imageReplacer.replace(tempXmlData, mediaDatas, 0);
				return {
					data: this.numberingReplacer.replace(xmlData, file.Numbering.ConcreteNumbering),
					path: `word/header${index + 1}.xml`
				};
			}),
			Footers: file.Footers.map((footerWrapper, index) => {
				const tempXmlData = (0, import_xml.default)(this.formatter.format(footerWrapper.View, {
					viewWrapper: footerWrapper,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				});
				const mediaDatas = this.imageReplacer.getMediaData(tempXmlData, file.Media);
				const xmlData = this.imageReplacer.replace(tempXmlData, mediaDatas, 0);
				return {
					data: this.numberingReplacer.replace(xmlData, file.Numbering.ConcreteNumbering),
					path: `word/footer${index + 1}.xml`
				};
			}),
			ContentTypes: {
				data: (0, import_xml.default)(this.formatter.format(file.ContentTypes, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				}),
				path: "[Content_Types].xml"
			},
			CustomProperties: {
				data: (0, import_xml.default)(this.formatter.format(file.CustomProperties, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "docProps/custom.xml"
			},
			AppProperties: {
				data: (0, import_xml.default)(this.formatter.format(file.AppProperties, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "docProps/app.xml"
			},
			FootNotes: {
				data: (() => {
					const xmlData = this.imageReplacer.replace(footnoteXmlData, footnoteMediaDatas, footnoteRelationshipCount);
					return this.numberingReplacer.replace(xmlData, file.Numbering.ConcreteNumbering);
				})(),
				path: "word/footnotes.xml"
			},
			FootNotesRelationships: {
				data: (() => {
					footnoteMediaDatas.forEach((mediaData, i) => {
						file.FootNotes.Relationships.addRelationship(footnoteRelationshipCount + i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${mediaData.fileName}`);
					});
					return (0, import_xml.default)(this.formatter.format(file.FootNotes.Relationships, {
						viewWrapper: file.FootNotes,
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: { encoding: "UTF-8" }
					});
				})(),
				path: "word/_rels/footnotes.xml.rels"
			},
			Endnotes: {
				data: (0, import_xml.default)(this.formatter.format(file.Endnotes.View, {
					viewWrapper: file.Endnotes,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				}),
				path: "word/endnotes.xml"
			},
			EndnotesRelationships: {
				data: (0, import_xml.default)(this.formatter.format(file.Endnotes.Relationships, {
					viewWrapper: file.Endnotes,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				}),
				path: "word/_rels/endnotes.xml.rels"
			},
			Settings: {
				data: (0, import_xml.default)(this.formatter.format(file.Settings, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "word/settings.xml"
			},
			Comments: {
				data: (() => {
					const xmlData = this.imageReplacer.replace(commentXmlData, commentMediaDatas, commentRelationshipCount);
					return this.numberingReplacer.replace(xmlData, file.Numbering.ConcreteNumbering);
				})(),
				path: "word/comments.xml"
			},
			CommentsRelationships: {
				data: (() => {
					commentMediaDatas.forEach((mediaData, i) => {
						file.Comments.Relationships.addRelationship(commentRelationshipCount + i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${mediaData.fileName}`);
					});
					return (0, import_xml.default)(this.formatter.format(file.Comments.Relationships, {
						viewWrapper: {
							View: file.Comments,
							Relationships: file.Comments.Relationships
						},
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: { encoding: "UTF-8" }
					});
				})(),
				path: "word/_rels/comments.xml.rels"
			}
		}, file.CommentsExtended ? { CommentsExtended: {
			data: (0, import_xml.default)(this.formatter.format(file.CommentsExtended, {
				viewWrapper: {
					View: file.CommentsExtended,
					Relationships: file.Comments.Relationships
				},
				file,
				stack: []
			}), {
				indent: prettify,
				declaration: {
					standalone: "yes",
					encoding: "UTF-8"
				}
			}),
			path: "word/commentsExtended.xml"
		} } : {}), {}, {
			FontTable: {
				data: (0, import_xml.default)(this.formatter.format(file.FontTable.View, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "word/fontTable.xml"
			},
			FontTableRelationships: {
				data: (0, import_xml.default)(this.formatter.format(file.FontTable.Relationships, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				}),
				path: "word/_rels/fontTable.xml.rels"
			}
		});
	}
};
function asyncGeneratorStep(n, t, e, r, o, a, c) {
	try {
		var i = n[a](c), u = i.value;
	} catch (n) {
		e(n);
		return;
	}
	i.done ? t(u) : Promise.resolve(u).then(r, o);
}
function _asyncToGenerator(n) {
	return function() {
		var t = this, e = arguments;
		return new Promise(function(r, o) {
			var a = n.apply(t, e);
			function _next(n) {
				asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
			}
			function _throw(n) {
				asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
			}
			_next(void 0);
		});
	};
}
/**
* Packer module for exporting documents to various output formats.
*
* @module
*/
/**
* Prettify options for formatting XML output.
*
* Controls the indentation style used when formatting the generated XML.
* Prettified output is more human-readable but results in larger file sizes.
*
* @publicApi
*/
var PrettifyType = {
	/** No prettification (smallest file size) */
	NONE: "",
	/** Indent with 2 spaces */
	WITH_2_BLANKS: "  ",
	/** Indent with 4 spaces */
	WITH_4_BLANKS: "    ",
	/** Indent with tab character */
	WITH_TAB: "	"
};
var convertPrettifyType = (prettify) => prettify === true ? PrettifyType.WITH_2_BLANKS : prettify === false ? void 0 : prettify;
/**
* Exports documents to various output formats.
*
* The Packer class provides static methods to convert a File object into different
* output formats such as Buffer, Blob, string, or stream. It handles the compilation
* of the document structure into OOXML format and compression into a .docx ZIP archive.
*
* @publicApi
*
* @example
* ```typescript
* // Export to buffer (Node.js)
* const buffer = await Packer.toBuffer(doc);
*
* // Export to blob (browser)
* const blob = await Packer.toBlob(doc);
*
* // Export with prettified XML
* const buffer = await Packer.toBuffer(doc, PrettifyType.WITH_2_BLANKS);
* ```
*/
var Packer = class Packer {
	/**
	* Exports a document to the specified output format.
	*
	* @param file - The document to export
	* @param type - The output format type (e.g., "nodebuffer", "blob", "string")
	* @param prettify - Whether to prettify the XML output (boolean or PrettifyType)
	* @param overrides - Optional array of file overrides for custom XML content
	* @returns A promise resolving to the exported document in the specified format
	*/
	static pack(_x, _x2, _x3) {
		var _this = this;
		return _asyncToGenerator(function* (file, type, prettify, overrides = []) {
			return _this.compiler.compile(file, convertPrettifyType(prettify), overrides).generateAsync({
				type,
				mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
				compression: "DEFLATE"
			});
		}).apply(this, arguments);
	}
	/**
	* Exports a document to a string representation.
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A promise resolving to the document as a string
	*/
	static toString(file, prettify, overrides = []) {
		return Packer.pack(file, "string", prettify, overrides);
	}
	/**
	* Exports a document to a Node.js Buffer.
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A promise resolving to the document as a Buffer
	*/
	static toBuffer(file, prettify, overrides = []) {
		return Packer.pack(file, "nodebuffer", prettify, overrides);
	}
	/**
	* Exports a document to a base64-encoded string.
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A promise resolving to the document as a base64 string
	*/
	static toBase64String(file, prettify, overrides = []) {
		return Packer.pack(file, "base64", prettify, overrides);
	}
	/**
	* Exports a document to a Blob (for browser environments).
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A promise resolving to the document as a Blob
	*/
	static toBlob(file, prettify, overrides = []) {
		return Packer.pack(file, "blob", prettify, overrides);
	}
	/**
	* Exports a document to an ArrayBuffer.
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A promise resolving to the document as an ArrayBuffer
	*/
	static toArrayBuffer(file, prettify, overrides = []) {
		return Packer.pack(file, "arraybuffer", prettify, overrides);
	}
	/**
	* Exports a document to a Node.js Stream.
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A readable stream containing the document data
	*/
	static toStream(file, prettify, overrides = []) {
		const stream = new import_stream_browserify.Stream();
		this.compiler.compile(file, convertPrettifyType(prettify), overrides).generateAsync({
			type: "nodebuffer",
			mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
			compression: "DEFLATE"
		}).then((z) => {
			stream.emit("data", z);
			stream.emit("end");
		});
		return stream;
	}
};
_defineProperty(Packer, "compiler", new Compiler());
/**
* Utility functions for XML manipulation in document patching.
*
* @module
*/
var formatter$1 = new Formatter();
/**
* Converts XML string to JSON element structure.
*
* Parses XML text into a JavaScript object representation that can be
* manipulated programmatically. Preserves spaces between elements for
* accurate text handling.
*
* @param xmlData - The XML string to parse
* @returns Parsed XML as an Element object
*
* @example
* ```typescript
* const element = toJson('<w:p><w:r><w:t>Hello</w:t></w:r></w:p>');
* ```
*/
var toJson = (xmlData) => {
	return (0, import_lib.xml2js)(xmlData, {
		compact: false,
		captureSpacesBetweenElements: true
	});
};
/**
* Creates text element contents from a text string.
*
* Generates the XML element structure for a text node (w:t) by formatting
* a Text component and extracting its element contents. Used when creating
* new text runs during replacement operations.
*
* @param text - The text content to wrap in element structure
* @returns Array of XML elements representing the text
*
* @example
* ```typescript
* const elements = createTextElementContents("Hello World");
* // Returns XML elements for <w:t>Hello World</w:t>
* ```
*/
var createTextElementContents = (text) => {
	var _textJson$elements$0$;
	return (_textJson$elements$0$ = toJson((0, import_xml.default)(formatter$1.format(new Text({ text })))).elements[0].elements) !== null && _textJson$elements$0$ !== void 0 ? _textJson$elements$0$ : [];
};
/**
* Adds xml:space="preserve" attribute to an element.
*
* The xml:space attribute instructs XML processors to preserve whitespace
* in the element's content. This is important when text contains leading
* or trailing spaces that must be maintained.
*
* @param element - The element to patch
* @returns New element with xml:space attribute added
*
* @example
* ```typescript
* const patched = patchSpaceAttribute(textElement);
* // Adds xml:space="preserve" to maintain whitespace
* ```
*/
var patchSpaceAttribute = (element) => _objectSpread2(_objectSpread2({}, element), {}, { attributes: { "xml:space": "preserve" } });
/**
* Retrieves first-level child elements by parent element name.
*
* Finds the first element with the specified name and returns its children.
* Used to access collections like relationship elements or content type definitions.
*
* @param relationships - The parent XML element to search
* @param id - The element name to find
* @returns Array of child elements
*
* @example
* ```typescript
* const rels = getFirstLevelElements(relationshipsXml, "Relationships");
* // Returns array of Relationship elements
* ```
*/
var getFirstLevelElements = (relationships, id) => {
	var _relationships$elemen, _relationships$elemen2;
	return (_relationships$elemen = (_relationships$elemen2 = relationships.elements) === null || _relationships$elemen2 === void 0 ? void 0 : _relationships$elemen2.filter((e) => e.name === id)[0].elements) !== null && _relationships$elemen !== void 0 ? _relationships$elemen : [];
};
/**
* Appends a content type definition to the [Content_Types].xml structure.
*
* The [Content_Types].xml file declares the MIME types for all file extensions
* in the OOXML package. This function adds a new content type if it doesn't
* already exist, ensuring that newly added media files are properly declared.
*
* @param element - The [Content_Types].xml root element
* @param contentType - The MIME type (e.g., "image/png")
* @param extension - The file extension (e.g., "png")
*
* @example
* ```typescript
* appendContentType(contentTypesElement, "image/png", "png");
* appendContentType(contentTypesElement, "image/jpeg", "jpg");
* ```
*/
var appendContentType = (element, contentType, extension) => {
	const relationshipElements = getFirstLevelElements(element, "Types");
	if (relationshipElements.some((el) => {
		var _el$attributes, _el$attributes2;
		return el.type === "element" && el.name === "Default" && (el === null || el === void 0 || (_el$attributes = el.attributes) === null || _el$attributes === void 0 ? void 0 : _el$attributes.ContentType) === contentType && (el === null || el === void 0 || (_el$attributes2 = el.attributes) === null || _el$attributes2 === void 0 ? void 0 : _el$attributes2.Extension) === extension;
	})) return;
	relationshipElements.push({
		attributes: {
			ContentType: contentType,
			Extension: extension
		},
		name: "Default",
		type: "element"
	});
};
/**
* Extracts the numeric ID from a relationship ID string.
*
* @param relationshipId - Relationship ID in format "rId123"
* @returns The numeric portion of the ID
*/
var getIdFromRelationshipId = (relationshipId) => {
	const output = parseInt(relationshipId.substring(3), 10);
	return isNaN(output) ? 0 : output;
};
/**
* Determines the next available relationship ID number.
*
* Scans all existing relationships and returns the next sequential ID number
* to use when adding a new relationship.
*
* @param relationships - The relationships XML element
* @returns The next available relationship ID number
*
* @example
* ```typescript
* const nextId = getNextRelationshipIndex(relationshipsElement);
* // If highest existing ID is rId5, returns 6
* ```
*/
var getNextRelationshipIndex = (relationships) => {
	return getFirstLevelElements(relationships, "Relationships").map((e) => {
		var _e$attributes$Id$toSt, _e$attributes;
		return getIdFromRelationshipId((_e$attributes$Id$toSt = (_e$attributes = e.attributes) === null || _e$attributes === void 0 || (_e$attributes = _e$attributes.Id) === null || _e$attributes === void 0 ? void 0 : _e$attributes.toString()) !== null && _e$attributes$Id$toSt !== void 0 ? _e$attributes$Id$toSt : "");
	}).reduce((acc, curr) => Math.max(acc, curr), 0) + 1;
};
/**
* Appends a new relationship to a .rels file structure.
*
* Relationships define connections between parts of an OOXML package,
* such as linking documents to images, hyperlinks, or other resources.
*
* @param relationships - The relationships XML element
* @param id - The relationship ID (number or string)
* @param type - The relationship type URI
* @param target - The target path or URI
* @param targetMode - Optional target mode (Internal or External)
* @returns The updated relationship elements array
*
* @example
* ```typescript
* appendRelationship(
*   relationshipsElement,
*   6,
*   "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
*   "media/image1.png"
* );
* ```
*/
var appendRelationship = (relationships, id, type, target, targetMode) => {
	const relationshipElements = getFirstLevelElements(relationships, "Relationships");
	relationshipElements.push({
		attributes: {
			Id: `rId${id}`,
			Type: type,
			Target: target,
			TargetMode: targetMode
		},
		name: "Relationship",
		type: "element"
	});
	return relationshipElements;
};
var TokenNotFoundError = class extends Error {
	constructor(token) {
		super(`Token ${token} not found`);
		this.name = "TokenNotFoundError";
	}
};
/**
* Finds the index of the run element containing a specific token.
*
* Searches through all run (w:r) elements in a paragraph to find which one
* contains the specified token text. This is used to locate where new content
* should be injected during replacement operations.
*
* @param paragraphElement - The paragraph element to search
* @param token - The token text to find
* @returns The index of the run element containing the token
* @throws Error if the token is not found in any run
*
* @example
* ```typescript
* const index = findRunElementIndexWithToken(paragraph, "ɵ");
* // Returns the index of the run containing the split token
* ```
*/
var findRunElementIndexWithToken = (paragraphElement, token) => {
	var _paragraphElement$ele;
	for (let i = 0; i < ((_paragraphElement$ele = paragraphElement.elements) !== null && _paragraphElement$ele !== void 0 ? _paragraphElement$ele : []).length; i++) {
		const element = paragraphElement.elements[i];
		if (element.type === "element" && element.name === "w:r") {
			var _element$elements;
			const textElement = ((_element$elements = element.elements) !== null && _element$elements !== void 0 ? _element$elements : []).filter((e) => e.type === "element" && e.name === "w:t");
			for (const text of textElement) {
				var _text$elements, _text$elements$0$text;
				if (!((_text$elements = text.elements) === null || _text$elements === void 0 ? void 0 : _text$elements[0])) continue;
				if ((_text$elements$0$text = text.elements[0].text) === null || _text$elements$0$text === void 0 ? void 0 : _text$elements$0$text.includes(token)) return i;
			}
		}
	}
	throw new TokenNotFoundError(token);
};
/**
* Splits a run element at a token position into left and right parts.
*
* Divides a run element at the location of a token, creating two separate
* runs. This allows new content to be injected between the split parts while
* preserving the original run's formatting properties.
*
* @param runElement - The run element to split
* @param token - The token text marking the split point
* @returns Object containing the left and right run elements
*
* @example
* ```typescript
* const { left, right } = splitRunElement(run, "ɵ");
* // If run contains "Helloɵworld", left contains "Hello" and right contains "world"
* ```
*/
var splitRunElement = (runElement, token) => {
	var _runElement$elements$, _runElement$elements;
	let splitIndex = -1;
	const splitElements = (_runElement$elements$ = (_runElement$elements = runElement.elements) === null || _runElement$elements === void 0 ? void 0 : _runElement$elements.map((e, i) => {
		if (splitIndex !== -1) return e;
		if (e.type === "element" && e.name === "w:t") {
			var _e$elements$0$text, _e$elements;
			const splitText = ((_e$elements$0$text = (_e$elements = e.elements) === null || _e$elements === void 0 || (_e$elements = _e$elements[0]) === null || _e$elements === void 0 ? void 0 : _e$elements.text) !== null && _e$elements$0$text !== void 0 ? _e$elements$0$text : "").split(token);
			const newElements = splitText.map((t) => _objectSpread2(_objectSpread2(_objectSpread2({}, e), patchSpaceAttribute(e)), {}, { elements: createTextElementContents(t) }));
			if (splitText.length > 1) splitIndex = i;
			return newElements;
		} else return e;
	}).flat()) !== null && _runElement$elements$ !== void 0 ? _runElement$elements$ : [];
	return {
		left: _objectSpread2(_objectSpread2({}, JSON.parse(JSON.stringify(runElement))), {}, { elements: splitElements.slice(0, splitIndex + 1) }),
		right: _objectSpread2(_objectSpread2({}, JSON.parse(JSON.stringify(runElement))), {}, { elements: splitElements.slice(splitIndex + 1) })
	};
};
/**
* Replacement modes for multi-run text replacement.
*/
var ReplaceMode = {
	/** Looking for the start of the replacement text */
	START: 0,
	/** Processing runs in the middle of the replacement text */
	MIDDLE: 1,
	/** Reached the end of the replacement text */
	END: 2
};
/**
* Replaces a token with replacement text within a paragraph's run elements.
*
* Handles the complex case where placeholder text may span multiple runs
* (text fragments) within a paragraph. Processes each run to replace the
* appropriate portion of the token, handling start, middle, and end sections.
*
* @param paragraphElement - The paragraph XML element to modify
* @param renderedParagraph - Pre-rendered paragraph structure with text positions
* @param originalText - The token text to replace (e.g., "{{name}}")
* @param replacementText - The text to replace it with (often a split token)
* @returns The modified paragraph element
*
* @example
* ```typescript
* replaceTokenInParagraphElement({
*   paragraphElement,
*   renderedParagraph,
*   originalText: "{{placeholder}}",
*   replacementText: "ɵ",
* });
* ```
*/
var replaceTokenInParagraphElement = ({ paragraphElement, renderedParagraph, originalText, replacementText }) => {
	const startIndex = renderedParagraph.text.indexOf(originalText);
	const endIndex = startIndex + originalText.length - 1;
	let replaceMode = ReplaceMode.START;
	for (const run of renderedParagraph.runs) for (const { text, index, start, end } of run.parts) switch (replaceMode) {
		case ReplaceMode.START:
			if (startIndex >= start && startIndex <= end) {
				const offsetStartIndex = startIndex - start;
				const offsetEndIndex = Math.min(endIndex, end) - start;
				const partToReplace = run.text.substring(offsetStartIndex, offsetEndIndex + 1);
				if (partToReplace === "") continue;
				const firstPart = text.replace(partToReplace, replacementText);
				patchTextElement(paragraphElement.elements[run.index].elements[index], firstPart);
				replaceMode = ReplaceMode.MIDDLE;
				continue;
			}
			break;
		case ReplaceMode.MIDDLE:
			if (endIndex <= end) {
				const lastPart = text.substring(endIndex - start + 1);
				patchTextElement(paragraphElement.elements[run.index].elements[index], lastPart);
				const currentElement = paragraphElement.elements[run.index].elements[index];
				paragraphElement.elements[run.index].elements[index] = patchSpaceAttribute(currentElement);
				replaceMode = ReplaceMode.END;
			} else patchTextElement(paragraphElement.elements[run.index].elements[index], "");
			break;
		default:
	}
	return paragraphElement;
};
var patchTextElement = (element, text) => {
	element.elements = createTextElementContents(text);
	return element;
};
/**
* Renders a paragraph element into a structured representation with text content.
*
* Extracts all text content from a paragraph (w:p) element by processing its
* run (w:r) children. Calculates character positions for each text fragment
* to enable precise text replacement operations.
*
* @param node - The paragraph element wrapper to render
* @returns Rendered paragraph with text content, runs, and position information
* @throws Error if the node is not a paragraph element
*
* @example
* ```typescript
* const rendered = renderParagraphNode(paragraphWrapper);
* console.log(rendered.text); // "Hello World"
* console.log(rendered.runs.length); // 2 (if text is in separate runs)
* ```
*/
var renderParagraphNode = (node) => {
	if (node.element.name !== "w:p") throw new Error(`Invalid node type: ${node.element.name}`);
	if (!node.element.elements) return {
		text: "",
		runs: [],
		index: -1,
		pathToParagraph: []
	};
	let currentRunStringLength = 0;
	const runs = node.element.elements.map((element, i) => ({
		element,
		i
	})).filter(({ element }) => element.name === "w:r").map(({ element, i }) => {
		const renderedRunNode = renderRunNode(element, i, currentRunStringLength);
		currentRunStringLength += renderedRunNode.text.length;
		return renderedRunNode;
	}).filter((e) => !!e);
	return {
		text: runs.reduce((acc, curr) => acc + curr.text, ""),
		runs,
		index: node.index,
		pathToParagraph: buildNodePath(node)
	};
};
var renderRunNode = (node, index, currentRunStringIndex) => {
	if (!node.elements) return {
		text: "",
		parts: [],
		index: -1,
		start: currentRunStringIndex,
		end: currentRunStringIndex
	};
	let currentTextStringIndex = currentRunStringIndex;
	const parts = node.elements.map((element, i) => {
		var _element$elements$0$t, _element$elements$0$t2;
		return element.name === "w:t" && element.elements && element.elements.length > 0 ? {
			text: (_element$elements$0$t = (_element$elements$0$t2 = element.elements[0].text) === null || _element$elements$0$t2 === void 0 ? void 0 : _element$elements$0$t2.toString()) !== null && _element$elements$0$t !== void 0 ? _element$elements$0$t : "",
			index: i,
			start: currentTextStringIndex,
			end: (() => {
				var _element$elements$0$t3, _element$elements$0$t4;
				currentTextStringIndex += ((_element$elements$0$t3 = (_element$elements$0$t4 = element.elements[0].text) === null || _element$elements$0$t4 === void 0 ? void 0 : _element$elements$0$t4.toString()) !== null && _element$elements$0$t3 !== void 0 ? _element$elements$0$t3 : "").length - 1;
				return currentTextStringIndex;
			})()
		} : void 0;
	}).filter((e) => !!e).map((e) => e);
	return {
		text: parts.reduce((acc, curr) => acc + curr.text, ""),
		parts,
		index,
		start: currentRunStringIndex,
		end: currentTextStringIndex
	};
};
var buildNodePath = (node) => node.parent ? [...buildNodePath(node.parent), node.index] : [node.index];
var elementsToWrapper = (wrapper) => {
	var _wrapper$element$elem, _wrapper$element$elem2;
	return (_wrapper$element$elem = (_wrapper$element$elem2 = wrapper.element.elements) === null || _wrapper$element$elem2 === void 0 ? void 0 : _wrapper$element$elem2.map((e, i) => ({
		element: e,
		index: i,
		parent: wrapper
	}))) !== null && _wrapper$element$elem !== void 0 ? _wrapper$element$elem : [];
};
/**
* Traverses an XML document tree to find and render all paragraphs.
*
* Uses breadth-first search to walk through the XML structure, identifying
* all paragraph elements (w:p) and rendering their text content along with
* positional information.
*
* @param node - The root XML element to traverse
* @returns Array of rendered paragraph nodes with text content and positions
*
* @example
* ```typescript
* const paragraphs = traverse(documentElement);
* paragraphs.forEach(p => console.log(p.text));
* ```
*/
var traverse = (node) => {
	let renderedParagraphs = [];
	const queue = [...elementsToWrapper({
		element: node,
		index: 0,
		parent: void 0
	})];
	let currentNode;
	while (queue.length > 0) {
		currentNode = queue.shift();
		if (currentNode.element.name === "w:p") renderedParagraphs = [...renderedParagraphs, renderParagraphNode(currentNode)];
		queue.push(...elementsToWrapper(currentNode));
	}
	return renderedParagraphs;
};
/**
* Finds all paragraphs containing specific text.
*
* Traverses the document and filters paragraphs to find those containing
* the specified text string. Useful for locating placeholder text that
* needs to be replaced.
*
* @param node - The root XML element to search
* @param text - The text to search for
* @returns Array of paragraph nodes containing the text
*
* @example
* ```typescript
* const matches = findLocationOfText(documentElement, "{{name}}");
* // Returns all paragraphs containing "{{name}}"
* ```
*/
var findLocationOfText = (node, text) => traverse(node).filter((p) => p.text.includes(text));
/**
* Replacer module for performing placeholder substitution in XML structures.
*
* @module
*/
var formatter = new Formatter();
var SPLIT_TOKEN = "ɵ";
/**
* Replaces placeholder text in XML with new content from a patch.
*
* This function locates placeholder text within the XML structure and performs
* the appropriate replacement based on the patch type (document or paragraph level).
* It handles splitting runs, preserving styles, and injecting the new content.
*
* @param json - The XML element structure to search
* @param patch - The patch definition containing replacement content
* @param patchText - The placeholder text to find (e.g., "{{name}}")
* @param context - The document context for formatting
* @param keepOriginalStyles - Whether to preserve original text formatting
* @returns Result containing the modified element and whether a replacement occurred
*/
var replacer = ({ json, patch, patchText, context, keepOriginalStyles = true }) => {
	const renderedParagraphs = findLocationOfText(json, patchText);
	if (renderedParagraphs.length === 0) return {
		element: json,
		didFindOccurrence: false
	};
	for (const renderedParagraph of renderedParagraphs) {
		const textJson = patch.children.map((c) => toJson((0, import_xml.default)(formatter.format(c, context)))).map((c) => c.elements[0]);
		switch (patch.type) {
			case PatchType.DOCUMENT: {
				const parentElement = goToParentElementFromPath(json, renderedParagraph.pathToParagraph);
				const elementIndex = getLastElementIndexFromPath(renderedParagraph.pathToParagraph);
				parentElement.elements.splice(elementIndex, 1, ...textJson);
				break;
			}
			case PatchType.PARAGRAPH:
			default: {
				const paragraphElement = goToElementFromPath(json, renderedParagraph.pathToParagraph);
				replaceTokenInParagraphElement({
					paragraphElement,
					renderedParagraph,
					originalText: patchText,
					replacementText: SPLIT_TOKEN
				});
				const index = findRunElementIndexWithToken(paragraphElement, SPLIT_TOKEN);
				const runElementToBeReplaced = paragraphElement.elements[index];
				const { left, right } = splitRunElement(runElementToBeReplaced, SPLIT_TOKEN);
				let newRunElements = textJson;
				let patchedRightElement = right;
				if (keepOriginalStyles) {
					const runElementNonTextualElements = runElementToBeReplaced.elements.filter((e) => e.type === "element" && e.name === "w:rPr");
					newRunElements = textJson.map((e) => {
						var _e$elements;
						return _objectSpread2(_objectSpread2({}, e), {}, { elements: [...runElementNonTextualElements, ...(_e$elements = e.elements) !== null && _e$elements !== void 0 ? _e$elements : []] });
					});
					patchedRightElement = _objectSpread2(_objectSpread2({}, right), {}, { elements: [...runElementNonTextualElements, ...right.elements] });
				}
				paragraphElement.elements.splice(index, 1, left, ...newRunElements, patchedRightElement);
				break;
			}
		}
	}
	return {
		element: json,
		didFindOccurrence: true
	};
};
var goToElementFromPath = (json, path) => {
	let element = json;
	for (let i = 1; i < path.length; i++) {
		const index = path[i];
		element = element.elements[index];
	}
	return element;
};
var goToParentElementFromPath = (json, path) => goToElementFromPath(json, path.slice(0, path.length - 1));
var getLastElementIndexFromPath = (path) => path[path.length - 1];
/**
* Document patching module for modifying existing .docx files.
*
* This module provides functionality to patch existing Word documents by replacing
* placeholder text with new content while preserving the original document structure.
*
* @module
*/
/**
* Patch type enumeration.
*
* Determines how the replacement content should be inserted into the document.
*
* @publicApi
*/
var PatchType = {
	/** Replace entire file-level elements (e.g., whole paragraphs) */
	DOCUMENT: "file",
	/** Replace content within paragraphs (inline replacement) */
	PARAGRAPH: "paragraph"
};
var imageReplacer = new ImageReplacer();
var UTF16LE = new Uint8Array([255, 254]);
var UTF16BE = new Uint8Array([254, 255]);
var compareByteArrays = (a, b) => {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
	return true;
};
(function() {
	var _ref = _asyncToGenerator(function* ({ outputType, data, patches, keepOriginalStyles, placeholderDelimiters = {
		start: "{{",
		end: "}}"
	}, recursive = true }) {
		const zipContent = data instanceof import_jszip_min.default ? data : yield import_jszip_min.default.loadAsync(data);
		const contexts = /* @__PURE__ */ new Map();
		const file = { Media: new Media() };
		const map = /* @__PURE__ */ new Map();
		const imageRelationshipAdditions = [];
		const hyperlinkRelationshipAdditions = [];
		let hasMedia = false;
		const binaryContentMap = /* @__PURE__ */ new Map();
		for (const [key, value] of Object.entries(zipContent.files)) {
			const binaryValue = yield value.async("uint8array");
			const startBytes = binaryValue.slice(0, 2);
			if (compareByteArrays(startBytes, UTF16LE) || compareByteArrays(startBytes, UTF16BE)) {
				binaryContentMap.set(key, binaryValue);
				continue;
			}
			if (!key.endsWith(".xml") && !key.endsWith(".rels")) {
				binaryContentMap.set(key, binaryValue);
				continue;
			}
			const json = toJson(yield value.async("text"));
			if (key === "word/document.xml") {
				var _json$elements;
				const document = (_json$elements = json.elements) === null || _json$elements === void 0 ? void 0 : _json$elements.find((i) => i.name === "w:document");
				if (document && document.attributes) {
					for (const ns of [
						"mc",
						"wp",
						"r",
						"w15",
						"m"
					]) document.attributes[`xmlns:${ns}`] = DocumentAttributeNamespaces[ns];
					document.attributes["mc:Ignorable"] = `${document.attributes["mc:Ignorable"] || ""} w15`.trim();
				}
			}
			if (key.startsWith("word/") && !key.endsWith(".xml.rels")) {
				const context = {
					file,
					viewWrapper: { Relationships: { addRelationship: (linkId, _, target, __) => {
						hyperlinkRelationshipAdditions.push({
							key,
							hyperlink: {
								id: linkId,
								link: target
							}
						});
					} } },
					stack: []
				};
				contexts.set(key, context);
				if (!(placeholderDelimiters === null || placeholderDelimiters === void 0 ? void 0 : placeholderDelimiters.start.trim()) || !(placeholderDelimiters === null || placeholderDelimiters === void 0 ? void 0 : placeholderDelimiters.end.trim())) throw new Error("Both start and end delimiters must be non-empty strings.");
				const { start, end } = placeholderDelimiters;
				for (const [patchKey, patchValue] of Object.entries(patches)) {
					const patchText = `${start}${patchKey}${end}`;
					while (true) {
						const { didFindOccurrence } = replacer({
							json,
							patch: _objectSpread2(_objectSpread2({}, patchValue), {}, { children: patchValue.children.map((element) => {
								if (element instanceof ExternalHyperlink) {
									const concreteHyperlink = new ConcreteHyperlink(element.options.children, uniqueId());
									hyperlinkRelationshipAdditions.push({
										key,
										hyperlink: {
											id: concreteHyperlink.linkId,
											link: element.options.link
										}
									});
									return concreteHyperlink;
								} else return element;
							}) }),
							patchText,
							context,
							keepOriginalStyles
						});
						if (!recursive || !didFindOccurrence) break;
					}
				}
				const mediaDatas = imageReplacer.getMediaData(JSON.stringify(json), context.file.Media);
				if (mediaDatas.length > 0) {
					hasMedia = true;
					imageRelationshipAdditions.push({
						key,
						mediaDatas
					});
				}
			}
			map.set(key, json);
		}
		for (const { key, mediaDatas } of imageRelationshipAdditions) {
			var _map$get;
			const relationshipKey = `word/_rels/${key.split("/").pop()}.rels`;
			const relationshipsJson = (_map$get = map.get(relationshipKey)) !== null && _map$get !== void 0 ? _map$get : createRelationshipFile();
			map.set(relationshipKey, relationshipsJson);
			const index = getNextRelationshipIndex(relationshipsJson);
			const newJson = imageReplacer.replace(JSON.stringify(map.get(key)), mediaDatas, index);
			map.set(key, JSON.parse(newJson));
			for (let i = 0; i < mediaDatas.length; i++) {
				const { fileName } = mediaDatas[i];
				appendRelationship(relationshipsJson, index + i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${fileName}`);
			}
		}
		for (const { key, hyperlink } of hyperlinkRelationshipAdditions) {
			var _map$get2;
			const relationshipKey = `word/_rels/${key.split("/").pop()}.rels`;
			const relationshipsJson = (_map$get2 = map.get(relationshipKey)) !== null && _map$get2 !== void 0 ? _map$get2 : createRelationshipFile();
			map.set(relationshipKey, relationshipsJson);
			appendRelationship(relationshipsJson, hyperlink.id, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", hyperlink.link, TargetModeType.EXTERNAL);
		}
		if (hasMedia) {
			const contentTypesJson = map.get("[Content_Types].xml");
			if (!contentTypesJson) throw new Error("Could not find content types file");
			appendContentType(contentTypesJson, "image/png", "png");
			appendContentType(contentTypesJson, "image/jpeg", "jpeg");
			appendContentType(contentTypesJson, "image/jpeg", "jpg");
			appendContentType(contentTypesJson, "image/bmp", "bmp");
			appendContentType(contentTypesJson, "image/gif", "gif");
			appendContentType(contentTypesJson, "image/svg+xml", "svg");
		}
		const zip = new import_jszip_min.default();
		for (const [key, value] of map) {
			const output = toXml(value);
			zip.file(key, encodeUtf8(output));
		}
		for (const [key, value] of binaryContentMap) zip.file(key, value);
		for (const { data: stream, fileName } of file.Media.Array) zip.file(`word/media/${fileName}`, stream);
		return zip.generateAsync({
			type: outputType,
			mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
			compression: "DEFLATE"
		});
	});
	return function patchDocument(_x) {
		return _ref.apply(this, arguments);
	};
})();
var toXml = (jsonObj) => {
	return (0, import_lib.js2xml)(jsonObj, { attributeValueFn: (str) => String(str).replace(/&(?!amp;|lt;|gt;|quot;|apos;)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;") });
};
var createRelationshipFile = () => ({
	declaration: { attributes: {
		version: "1.0",
		encoding: "UTF-8",
		standalone: "yes"
	} },
	elements: [{
		type: "element",
		name: "Relationships",
		attributes: { xmlns: "http://schemas.openxmlformats.org/package/2006/relationships" },
		elements: []
	}]
});
(function() {
	var _ref = _asyncToGenerator(function* ({ data }) {
		const zipContent = data instanceof import_jszip_min.default ? data : yield import_jszip_min.default.loadAsync(data);
		const patches = /* @__PURE__ */ new Set();
		for (const [key, value] of Object.entries(zipContent.files)) {
			if (!key.endsWith(".xml") && !key.endsWith(".rels")) continue;
			if (key.startsWith("word/") && !key.endsWith(".xml.rels")) traverse(toJson(yield value.async("text"))).forEach((p) => findPatchKeys(p.text).forEach((patch) => patches.add(patch)));
		}
		return Array.from(patches);
	});
	return function patchDetector(_x) {
		return _ref.apply(this, arguments);
	};
})();
/**
* Extracts placeholder keys from text using regex pattern.
*
* @param text - Text to search for placeholders
* @returns Array of placeholder keys (without delimiters)
*/
var findPatchKeys = (text) => {
	var _text$match;
	const pattern = /* @__PURE__ */ new RegExp("(?<=\\{\\{).+?(?=\\}\\})", "gs");
	return (_text$match = text.match(pattern)) !== null && _text$match !== void 0 ? _text$match : [];
};
//#endregion
//#region ../CWSP-document/src/shared/other/document/docx/constants.ts
var ORDERED_LIST_REF = "cw-ordered-list";
var COLORS = {
	text: "1A1A1A",
	border: "D1D5DB",
	borderDark: "666666",
	link: "333333",
	codeBg: "F5F5F5",
	quoteBg: "FAFAFA",
	thBg: "E5E5E5"
};
var FONTS = {
	serif: "Times New Roman",
	mono: "Consolas",
	math: "Cambria Math"
};
var SIZES = {
	body: 24,
	code: 20,
	h1: 40,
	h2: 32,
	h3: 28,
	h4: 26,
	h5: 24,
	h6: 22
};
var GOST_LAYOUT = {
	page: {
		widthMm: 210,
		heightMm: 297,
		marginTopMm: 20,
		marginRightMm: 15,
		marginBottomMm: 20,
		marginLeftMm: 30
	},
	paragraph: {
		firstLineTwip: 708,
		lineTwip: 276
	}
};
//#endregion
//#region ../CWSP-document/src/shared/other/document/docx/download.ts
function safeFilename(name) {
	return ((name || "").trim() || "document").replace(/[\\/:*?"<>|\u0000-\u001F]+/g, "-").slice(0, 180);
}
function downloadBlob(blob, filename) {
	if (typeof showSaveFilePicker !== "undefined") showSaveFilePicker({
		suggestedName: filename,
		types: [{
			description: "Document files",
			accept: { "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"] }
		}]
	})?.then?.(async (fileHandle) => {
		if (fileHandle) {
			const writable = await fileHandle.createWritable();
			await writable.write(blob);
			await writable.close();
		} else return null;
		return fileHandle;
	})?.catch?.(() => {
		return null;
	});
	else {
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = filename;
		a.rel = "noopener";
		a.style.display = "none";
		document.body.appendChild(a);
		a.click();
		a.remove();
		setTimeout(() => URL.revokeObjectURL(url), 250);
	}
}
//#endregion
//#region ../CWSP-document/src/shared/other/document/docx/image.ts
function tryDecodeUriComponent(input) {
	try {
		return decodeURIComponent(input);
	} catch {
		return input;
	}
}
function parseDataUrlLocal(input) {
	const s = (input || "").trim();
	if (!s.toLowerCase().startsWith("data:")) return null;
	const m = s.match(/^data:(?<mime>[^;,]+)?(?<params>(?:;[^,]*)*?),(?<data>[\s\S]*)$/i);
	if (!m?.groups) return null;
	return {
		mimeType: (m.groups.mime || "application/octet-stream").trim() || "application/octet-stream",
		isBase64: (m.groups.params || "").toLowerCase().includes(";base64"),
		data: m.groups.data ?? ""
	};
}
function decodeBase64ToBytesLocal(base64) {
	const normalized = (base64 || "").trim().replace(/[\r\n\s]/g, "").replace(/-/g, "+").replace(/_/g, "/");
	const padLen = (4 - normalized.length % 4) % 4;
	const padded = normalized + "=".repeat(padLen);
	const bin = typeof atob === "function" ? atob(padded) : "";
	const out = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
	return out;
}
function isBase64LikeLocal(input) {
	const t = (input || "").trim().replace(/[\r\n\s]/g, "");
	if (!t || t.length < 8) return false;
	const normalized = t.replace(/-/g, "+").replace(/_/g, "/");
	return /^[A-Za-z0-9+/]*={0,2}$/.test(normalized);
}
function looksLikeSvgText(value) {
	return /^\s*(<\?xml[\s\S]*?)?<svg[\s\S]*?>/i.test(value || "");
}
function mimeHintFromEncodedSource(src) {
	const raw = (src || "").trim();
	if (!raw) return void 0;
	const parsed = parseDataUrlLocal(raw);
	if (parsed?.mimeType) return parsed.mimeType;
	const decoded = raw.includes("%") ? tryDecodeUriComponent(raw) : raw;
	const decodedDataUrl = parseDataUrlLocal(decoded);
	if (decodedDataUrl?.mimeType) return decodedDataUrl.mimeType;
	if (looksLikeSvgText(decoded)) return "image/svg+xml";
	const compact = decoded.replace(/[\r\n\s]/g, "");
	if (/^iVBORw0KGgo/i.test(compact)) return "image/png";
	if (/^\/9j\//.test(compact)) return "image/jpeg";
	if (/^R0lGOD/.test(compact)) return "image/gif";
	if (/^Qk/.test(compact)) return "image/bmp";
	if (/^UklGR/i.test(compact)) return "image/webp";
	if (/^(PHN2Zy|PD94bWwg)/i.test(compact)) return "image/svg+xml";
}
function sniffImageMimeFromBytes(bytes) {
	if (bytes.length >= 8 && bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71 && bytes[4] === 13 && bytes[5] === 10 && bytes[6] === 26 && bytes[7] === 10) return "image/png";
	if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return "image/jpeg";
	if (bytes.length >= 6 && bytes[0] === 71 && bytes[1] === 73 && bytes[2] === 70 && bytes[3] === 56 && (bytes[4] === 57 || bytes[4] === 55) && bytes[5] === 97) return "image/gif";
	if (bytes.length >= 2 && bytes[0] === 66 && bytes[1] === 77) return "image/bmp";
	if (bytes.length >= 12 && bytes[0] === 82 && bytes[1] === 73 && bytes[2] === 70 && bytes[3] === 70 && bytes[8] === 87 && bytes[9] === 69 && bytes[10] === 66 && bytes[11] === 80) return "image/webp";
	if (looksLikeSvgText(new TextDecoder("utf-8").decode(bytes.slice(0, Math.min(bytes.length, 512))).trimStart())) return "image/svg+xml";
}
function imageTypeFromMime(mime) {
	const m = (mime || "").toLowerCase();
	if (m.includes("png")) return "png";
	if (m.includes("jpeg")) return "jpg";
	if (m.includes("jpg")) return "jpg";
	if (m.includes("gif")) return "gif";
	if (m.includes("bmp")) return "bmp";
}
async function normalizeImageBinaryFromSource(src) {
	const raw = (src || "").trim();
	if (!raw) return null;
	const decoded = raw.includes("%") ? tryDecodeUriComponent(raw) : raw;
	const dataUrl = parseDataUrlLocal(raw) || parseDataUrlLocal(decoded);
	const hasEncodedPayload = !!dataUrl || isBase64LikeLocal(raw) || isBase64LikeLocal(decoded) || looksLikeSvgText(decoded);
	const mimeHint = mimeHintFromEncodedSource(raw);
	if (hasEncodedPayload) try {
		let bytes;
		let mimeType = mimeHint || "application/octet-stream";
		if (dataUrl) {
			mimeType = dataUrl.mimeType || mimeType;
			const payload = dataUrl.data || "";
			if (dataUrl.isBase64) bytes = decodeBase64ToBytesLocal(payload);
			else {
				const text = payload.includes("%") ? tryDecodeUriComponent(payload) : payload;
				bytes = new TextEncoder().encode(text);
			}
		} else if (isBase64LikeLocal(raw) || isBase64LikeLocal(decoded)) bytes = decodeBase64ToBytesLocal(isBase64LikeLocal(raw) ? raw : decoded);
		else bytes = new TextEncoder().encode(decoded);
		mimeType = mimeType || sniffImageMimeFromBytes(bytes) || "application/octet-stream";
		if (mimeType === "application/octet-stream") mimeType = sniffImageMimeFromBytes(bytes) || mimeType;
		return {
			bytes,
			mimeType
		};
	} catch {}
	try {
		const res = await fetch(raw);
		if (!res.ok) return null;
		const blob = await res.blob();
		const bytes = new Uint8Array(await blob.arrayBuffer());
		return {
			bytes,
			mimeType: blob.type || mimeHint || sniffImageMimeFromBytes(bytes) || "application/octet-stream"
		};
	} catch {
		return null;
	}
}
function bytesToArrayBuffer(bytes) {
	const buf = bytes.buffer;
	if (buf instanceof ArrayBuffer) return buf.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
	const ab = new ArrayBuffer(bytes.byteLength);
	new Uint8Array(ab).set(bytes);
	return ab;
}
async function rasterizeToPng(bytes, mimeType) {
	try {
		if (typeof document === "undefined") return null;
		const blob = new Blob([bytesToArrayBuffer(bytes)], { type: mimeType });
		const url = URL.createObjectURL(blob);
		try {
			const img = await new Promise((resolve, reject) => {
				const image = new Image();
				image.decoding = "async";
				image.onload = () => resolve(image);
				image.onerror = () => reject(/* @__PURE__ */ new Error("Failed to decode image"));
				image.src = url;
			});
			const width = Math.max(1, Math.round(img.naturalWidth || img.width || 600));
			const height = Math.max(1, Math.round(img.naturalHeight || img.height || 400));
			if (typeof OffscreenCanvas !== "undefined") {
				const canvas = new OffscreenCanvas(width, height);
				const ctx = canvas.getContext("2d");
				if (!ctx) return null;
				ctx.drawImage(img, 0, 0, width, height);
				const pngBlob = await canvas.convertToBlob({ type: "image/png" });
				return {
					bytes: new Uint8Array(await pngBlob.arrayBuffer()),
					width,
					height
				};
			}
			const canvas = document.createElement("canvas");
			canvas.width = width;
			canvas.height = height;
			const ctx = canvas.getContext("2d");
			if (!ctx) return null;
			ctx.drawImage(img, 0, 0, width, height);
			const pngBlob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
			if (!pngBlob) return null;
			return {
				bytes: new Uint8Array(await pngBlob.arrayBuffer()),
				width,
				height
			};
		} finally {
			URL.revokeObjectURL(url);
		}
	} catch {
		return null;
	}
}
async function getImageSize(bytes, mimeType) {
	try {
		if (typeof createImageBitmap !== "function") return {
			width: 600,
			height: 400
		};
		const blob = new Blob([bytesToArrayBuffer(bytes)], { type: mimeType });
		const bmp = await createImageBitmap(blob);
		const width = Number(bmp?.width || 600);
		const height = Number(bmp?.height || 400);
		try {
			bmp?.close?.();
		} catch {}
		return {
			width,
			height
		};
	} catch {
		return {
			width: 600,
			height: 400
		};
	}
}
function fitImageToWidth(width, height, maxWidth) {
	const w = Math.max(1, width || 1);
	const h = Math.max(1, height || 1);
	if (w <= maxWidth) return {
		width: w,
		height: h
	};
	const ratio = maxWidth / w;
	return {
		width: Math.round(w * ratio),
		height: Math.round(h * ratio)
	};
}
async function imageRunFromSrc(src, alt) {
	const data = await normalizeImageBinaryFromSource(src);
	if (!data) return null;
	let bytes = data.bytes;
	let mimeType = (data.mimeType || "").toLowerCase();
	let type = imageTypeFromMime(mimeType);
	if (!type) {
		const rasterized = await rasterizeToPng(bytes, mimeType || "application/octet-stream");
		if (!rasterized) return null;
		bytes = rasterized.bytes;
		mimeType = "image/png";
		type = "png";
	}
	const { width, height } = await getImageSize(bytes, mimeType);
	return new ImageRun({
		type,
		data: bytes,
		transformation: fitImageToWidth(width, height, 600),
		altText: alt ? {
			title: alt,
			description: alt,
			name: alt
		} : void 0
	});
}
//#endregion
//#region ../CWSP-document/src/shared/other/document/docx/markdown.ts
var MATH_DELIMITER_PATTERN = /\$\$[\s\S]*?\$\$|\\\[[\s\S]*?\\\]|(?<!\$)\$[^$\n]+\$|\\\([\s\S]*?\\\)/;
var FENCED_CODE_PATTERN = /(^|\n)(`{3,}|~{3,})[^\n]*\n[\s\S]*?\n\2(?=\n|$)/g;
var INLINE_CODE_PATTERN = /`[^`\n]+`/g;
var MATRIX_ENV_PATTERN = /\\begin\{((?:p|b|B|v|V)?matrix|smallmatrix)\}([\s\S]*?)\\end\{\1\}/g;
var markedConfigured = false;
function maskCodeSegments(markdown) {
	const maskedValues = [];
	const tokenPrefix = "__MD_MASK_";
	const tokenSuffix = "__";
	const mask = (value) => value.replace(FENCED_CODE_PATTERN, (segment) => {
		const token = `${tokenPrefix}${maskedValues.length}${tokenSuffix}`;
		maskedValues.push(segment);
		return token;
	});
	const maskInline = (value) => value.replace(INLINE_CODE_PATTERN, (segment) => {
		const token = `${tokenPrefix}${maskedValues.length}${tokenSuffix}`;
		maskedValues.push(segment);
		return token;
	});
	return {
		masked: maskInline(mask(markdown)),
		restore: (value) => value.replace(/__MD_MASK_(\d+)__/g, (_, index) => maskedValues[Number(index)] ?? "")
	};
}
function repairLatexMatrixRowBreaks(input) {
	return (input || "").replace(MATRIX_ENV_PATTERN, (_match, envName, body) => {
		return `\\begin{${envName}}${(body || "").replace(/(^|[^\\])\\\r?\n/g, "$1\\\\\n")}\\end{${envName}}`;
	});
}
function repairLatexInMathDelimiters(markdown) {
	return (markdown || "").replace(MATH_DELIMITER_PATTERN, (segment) => repairLatexMatrixRowBreaks(segment));
}
function replaceKatexNodeWithMathMl(domDoc, node, isDisplay) {
	const mathEl = node.querySelector(".katex-mathml")?.querySelector("math") || node.querySelector("math");
	if (!mathEl) return;
	const pureMath = mathEl.cloneNode(true);
	if (!isDisplay) {
		node.replaceWith(pureMath);
		return;
	}
	const wrapper = domDoc.createElement("div");
	wrapper.className = "math-display";
	wrapper.append(pureMath);
	node.replaceWith(wrapper);
}
function normalizeKatexToPureMathMlHtml(inputHtml) {
	const domDoc = new DOMParser().parseFromString(`<div id="katex-root">${inputHtml || ""}</div>`, "text/html");
	const root = domDoc.getElementById("katex-root");
	if (!root) return inputHtml || "";
	for (const node of Array.from(root.querySelectorAll(".katex-display"))) replaceKatexNodeWithMathMl(domDoc, node, true);
	for (const node of Array.from(root.querySelectorAll("span.katex"))) {
		if (node.closest(".katex-display")) continue;
		replaceKatexNodeWithMathMl(domDoc, node, false);
	}
	return root.innerHTML;
}
function ensureMarkedConfigured() {
	if (markedConfigured) return;
	markedConfigured = true;
	f?.use?.(src_default({
		throwOnError: false,
		nonStandard: true,
		output: "mathml",
		strict: false
	}), { hooks: { preprocess: (markdown) => {
		if (!MATH_DELIMITER_PATTERN.test(markdown)) return markdown;
		const { masked, restore } = maskCodeSegments(markdown);
		const katexNode = document.createElement("div");
		katexNode.textContent = repairLatexInMathDelimiters(masked);
		renderMathInElement(katexNode, {
			throwOnError: false,
			nonStandard: true,
			output: "mathml",
			strict: false,
			delimiters: [
				{
					left: "$$",
					right: "$$",
					display: true
				},
				{
					left: "\\[",
					right: "\\]",
					display: true
				},
				{
					left: "$",
					right: "$",
					display: false
				},
				{
					left: "\\(",
					right: "\\)",
					display: false
				}
			]
		});
		return restore(normalizeKatexToPureMathMlHtml(katexNode.innerHTML));
	} } });
}
async function markdownToHtml(markdown) {
	ensureMarkedConfigured();
	return f.parse(markdown ?? "", {
		gfm: true,
		breaks: true
	});
}
function htmlToBody(html) {
	return new DOMParser().parseFromString(html ?? "", "text/html").body;
}
//#endregion
//#region ../CWSP-document/src/shared/other/document/docx/rasterize.ts
var OPERATOR_REMAP$1 = {
	"−": "-",
	"–": "-",
	"—": "-",
	"∗": "*",
	"⋅": "*"
};
function normalizeMathText$1(s) {
	return (s ?? "").replace(/\s+/g, " ").trim();
}
function isFenceOperatorElement$1(el) {
	if (el.tagName.toLowerCase() !== "mo") return false;
	const fenceAttr = (el.getAttribute("fence") || "").toLowerCase();
	const text = normalizeMathOperator$1(el.textContent || "");
	return fenceAttr === "true" || [
		"(",
		")",
		"[",
		"]",
		"{",
		"}",
		"⟨",
		"⟩",
		"〈",
		"〉"
	].includes(text);
}
function normalizeMathOperator$1(text) {
	const normalized = normalizeMathText$1(text);
	return OPERATOR_REMAP$1[normalized] ?? normalized;
}
function dataUrlToUint8Array(dataUrl) {
	const match = /^data:image\/png;base64,(.+)$/i.exec(dataUrl || "");
	if (!match) return null;
	const binary = atob(match[1]);
	const bytes = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
	return bytes;
}
async function canvasToPngBytes(canvas) {
	const viaBlob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
	if (viaBlob) return new Uint8Array(await viaBlob.arrayBuffer());
	return dataUrlToUint8Array(canvas.toDataURL("image/png"));
}
function matrixFenceGlyph(rowIndex, rowCount, side, openFence, closeFence) {
	const open = openFence || "(";
	const close = closeFence || ")";
	if (rowCount <= 1) return side === "left" ? open : close;
	const top = rowIndex === 0;
	const bottom = rowIndex === rowCount - 1;
	if (open === "[" && close === "]") {
		if (top) return side === "left" ? "⎡" : "⎤";
		if (bottom) return side === "left" ? "⎣" : "⎦";
		return side === "left" ? "⎢" : "⎥";
	}
	if (open === "{" && close === "}") {
		if (top) return side === "left" ? "⎧" : "⎫";
		if (bottom) return side === "left" ? "⎩" : "⎭";
		return side === "left" ? "⎨" : "⎬";
	}
	if (open === "|" && close === "|") return "│";
	if (top) return side === "left" ? "⎛" : "⎞";
	if (bottom) return side === "left" ? "⎝" : "⎠";
	return side === "left" ? "⎜" : "⎟";
}
function matrixTextFromNode(node) {
	return normalizeMathText$1(node.textContent || "");
}
function stripRawTextFromMathContainers(root) {
	const containers = [root, ...Array.from(root.querySelectorAll("math,semantics,mstyle,annotation-xml,mphantom"))];
	for (const container of containers) for (const node of Array.from(container.childNodes)) {
		if (node.nodeType !== Node.TEXT_NODE) continue;
		if ((node.nodeValue || "").trim().length) node.remove();
	}
}
function loadImageFromObjectUrl(url) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("Failed to load math image"));
		img.src = url;
	});
}
async function renderMathAsPng(mathEl, opts) {
	try {
		const mathClone = mathEl.cloneNode(true);
		stripRawTextFromMathContainers(mathClone);
		const probe = document.createElement("div");
		probe.style.position = "fixed";
		probe.style.left = "-99999px";
		probe.style.top = "0";
		probe.style.visibility = "hidden";
		probe.style.whiteSpace = "nowrap";
		probe.style.padding = opts?.display ? "6px 8px" : "2px 4px";
		probe.style.fontFamily = `${FONTS.math}, ${FONTS.serif}`;
		probe.style.fontSize = opts?.display ? "24px" : "20px";
		probe.style.color = "#1A1A1A";
		probe.append(mathClone);
		document.body.append(probe);
		const bounds = probe.getBoundingClientRect();
		probe.remove();
		const width = Math.max(1, Math.ceil(bounds.width));
		const height = Math.max(1, Math.ceil(bounds.height));
		const serializedMath = new XMLSerializer().serializeToString(mathClone);
		const svgMarkup = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><foreignObject width="100%" height="100%"><div xmlns="http://www.w3.org/1999/xhtml" style="${`display:inline-block;white-space:nowrap;font-family:${FONTS.math}, ${FONTS.serif};font-size:${opts?.display ? 24 : 20}px;color:#1A1A1A;`}">${serializedMath}</div></foreignObject></svg>`;
		const svgBlob = new Blob([svgMarkup], { type: "image/svg+xml;charset=utf-8" });
		const svgUrl = URL.createObjectURL(svgBlob);
		try {
			const img = await loadImageFromObjectUrl(svgUrl);
			const maxWidth = opts?.display ? 1200 : 700;
			const fitted = fitImageToWidth(img.width || width, img.height || height, maxWidth);
			const scale = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(fitted.width * scale));
			canvas.height = Math.max(1, Math.round(fitted.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) return null;
			ctx.scale(scale, scale);
			ctx.drawImage(img, 0, 0, fitted.width, fitted.height);
			const data = await canvasToPngBytes(canvas);
			if (!data) return null;
			return {
				data,
				width: fitted.width,
				height: fitted.height
			};
		} finally {
			URL.revokeObjectURL(svgUrl);
		}
	} catch {
		return null;
	}
}
async function renderMatrixAsPng(mathEl) {
	try {
		const model = extractMatrixDisplayModel(mathEl);
		if (!model) return null;
		const rowCount = model.rows.length;
		const colCount = Math.max(...model.rows.map((r) => r.length), 1);
		const fontSize = 26;
		const rowHeight = 38;
		const colGap = 20;
		const sidePadding = 12;
		const edgeGap = 10;
		const outerPaddingX = 8;
		const outerPaddingY = 8;
		const prefixGap = model.prefix ? 14 : 0;
		const suffixGap = model.suffix ? 14 : 0;
		const measureCtx = document.createElement("canvas").getContext("2d");
		if (!measureCtx) return null;
		measureCtx.font = `${fontSize}px ${FONTS.math}, ${FONTS.serif}`;
		const colWidths = Array.from({ length: colCount }, (_, col) => {
			let max = 0;
			for (const row of model.rows) {
				const txt = row[col] || "";
				max = Math.max(max, measureCtx.measureText(txt || " ").width);
			}
			return Math.max(18, Math.ceil(max));
		});
		const prefixW = model.prefix ? Math.ceil(measureCtx.measureText(model.prefix).width) : 0;
		const suffixW = model.suffix ? Math.ceil(measureCtx.measureText(model.suffix).width) : 0;
		const bracketW = Math.ceil(measureCtx.measureText("⎢").width) + 4;
		const matrixInnerWidth = colWidths.reduce((a, b) => a + b, 0) + colGap * (colCount - 1);
		const matrixBlockWidth = bracketW + edgeGap + sidePadding + matrixInnerWidth + sidePadding + edgeGap + bracketW;
		const matrixBlockHeight = rowCount * rowHeight;
		const width = Math.max(1, 16 + prefixW + prefixGap + matrixBlockWidth + suffixGap + suffixW);
		const height = Math.max(1, 16 + matrixBlockHeight);
		const scaleRatio = fitImageToWidth(width, height, 1200).width / width;
		const drawWidth = Math.max(1, Math.round(width * scaleRatio));
		const drawHeight = Math.max(1, Math.round(height * scaleRatio));
		const scale = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
		const canvas = document.createElement("canvas");
		canvas.width = Math.max(1, Math.round(drawWidth * scale));
		canvas.height = Math.max(1, Math.round(drawHeight * scale));
		const ctx = canvas.getContext("2d");
		if (!ctx) return null;
		ctx.scale(scale, scale);
		ctx.scale(scaleRatio, scaleRatio);
		ctx.clearRect(0, 0, width, height);
		ctx.fillStyle = "#1A1A1A";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.font = `${fontSize}px ${FONTS.math}, ${FONTS.serif}`;
		const centerY = outerPaddingY + matrixBlockHeight / 2;
		let x = outerPaddingX;
		if (model.prefix) {
			ctx.textAlign = "left";
			ctx.fillText(model.prefix, x, centerY);
			x += prefixW + prefixGap;
		}
		const leftBracketX = x + bracketW / 2;
		const firstCellStart = x + bracketW + edgeGap + sidePadding;
		const rightBracketX = x + matrixBlockWidth - bracketW / 2;
		for (let rowIdx = 0; rowIdx < rowCount; rowIdx++) {
			const rowCenterY = outerPaddingY + rowHeight * rowIdx + rowHeight / 2;
			const leftGlyph = matrixFenceGlyph(rowIdx, rowCount, "left", model.openFence, model.closeFence);
			const rightGlyph = matrixFenceGlyph(rowIdx, rowCount, "right", model.openFence, model.closeFence);
			ctx.textAlign = "center";
			ctx.fillText(leftGlyph, leftBracketX, rowCenterY);
			ctx.fillText(rightGlyph, rightBracketX, rowCenterY);
			let cellX = firstCellStart;
			for (let colIdx = 0; colIdx < colCount; colIdx++) {
				const cw = colWidths[colIdx];
				const txt = model.rows[rowIdx]?.[colIdx] || " ";
				ctx.fillText(txt, cellX + cw / 2, rowCenterY);
				cellX += cw + colGap;
			}
		}
		if (model.suffix) {
			ctx.textAlign = "left";
			const suffixX = outerPaddingX + prefixW + prefixGap + matrixBlockWidth + suffixGap;
			ctx.fillText(model.suffix, suffixX, centerY);
		}
		const data = await canvasToPngBytes(canvas);
		if (!data) return null;
		return {
			data,
			width: drawWidth,
			height: drawHeight
		};
	} catch {
		return null;
	}
}
function extractMatrixDisplayModel(mathEl) {
	const mtable = mathEl.querySelector("mtable");
	if (!mtable) return null;
	const rows = Array.from(mtable.children).filter((el) => el.tagName.toLowerCase() === "mtr").map((row) => Array.from(row.children).filter((cell) => cell.tagName.toLowerCase() === "mtd").map((cell) => matrixTextFromNode(cell))).filter((row) => row.length > 0);
	if (!rows.length) return null;
	let openFence = "(";
	let closeFence = ")";
	const mtableParent = mtable.parentElement;
	if (mtableParent) {
		const parentTag = mtableParent.tagName.toLowerCase();
		if (parentTag === "mfenced") {
			openFence = normalizeMathOperator$1(mtableParent.getAttribute("open") || "(") || "(";
			closeFence = normalizeMathOperator$1(mtableParent.getAttribute("close") || ")") || ")";
		} else if (parentTag === "mrow") {
			const pChildren = Array.from(mtableParent.children);
			if (pChildren.length >= 3) {
				const first = pChildren[0];
				const last = pChildren[pChildren.length - 1];
				if (isFenceOperatorElement$1(first) && isFenceOperatorElement$1(last)) {
					openFence = normalizeMathOperator$1(first.textContent || "") || "(";
					closeFence = normalizeMathOperator$1(last.textContent || "") || ")";
				}
			}
		}
	}
	const rootRow = (() => {
		const children = Array.from(mathEl.children);
		if (children.length === 1 && children[0].tagName.toLowerCase() === "mrow") return children[0];
		return mathEl;
	})();
	const matrixExpr = (() => {
		if (!mtableParent) return mtable;
		const parentTag = mtableParent.tagName.toLowerCase();
		if (parentTag === "mrow" || parentTag === "mfenced") return mtableParent;
		return mtable;
	})();
	const rootChildren = Array.from(rootRow.children);
	const matrixIdx = rootChildren.findIndex((child) => child === matrixExpr || child.contains(mtable));
	return {
		rows,
		prefix: matrixIdx > 0 ? rootChildren.slice(0, matrixIdx).map((el) => matrixTextFromNode(el)).join(" ").trim() : "",
		suffix: matrixIdx >= 0 ? rootChildren.slice(matrixIdx + 1).map((el) => matrixTextFromNode(el)).join(" ").trim() : "",
		openFence,
		closeFence
	};
}
//#endregion
//#region ../CWSP-document/src/shared/other/document/docx/math.ts
function normalizeMathText(s) {
	return (s ?? "").replace(/\s+/g, " ").trim();
}
var OPERATOR_REMAP = {
	"−": "-",
	"–": "-",
	"—": "-",
	"∗": "*",
	"⋅": "*"
};
function normalizeMathOperator(text) {
	const normalized = normalizeMathText(text);
	return OPERATOR_REMAP[normalized] ?? normalized;
}
function bracketClassFromFence(open, close) {
	if (open === "(" && close === ")") return MathRoundBrackets;
	if (open === "[" && close === "]") return MathSquareBrackets;
	if (open === "{" && close === "}") return MathCurlyBrackets;
	if (open === "⟨" && close === "⟩" || open === "〈" && close === "〉") return MathAngledBrackets;
	return MathRoundBrackets;
}
function isFenceOperatorElement(el) {
	if (el.tagName.toLowerCase() !== "mo") return false;
	const fenceAttr = (el.getAttribute("fence") || "").toLowerCase();
	const text = normalizeMathOperator(el.textContent || "");
	return fenceAttr === "true" || [
		"(",
		")",
		"[",
		"]",
		"{",
		"}",
		"⟨",
		"⟩",
		"〈",
		"〉"
	].includes(text);
}
function matrixComponentsFromMtable(mtable) {
	const rows = Array.from(mtable.children).filter((el) => el.tagName.toLowerCase() === "mtr");
	const out = [];
	rows.forEach((row, rowIndex) => {
		const cells = Array.from(row.children).filter((el) => el.tagName.toLowerCase() === "mtd");
		const rowComponents = [];
		cells.forEach((cell, cellIndex) => {
			const cellMath = mathComponentsFromMathNode(cell);
			if (cellMath.length) rowComponents.push(...cellMath);
			else {
				const t = normalizeMathText(cell.textContent || "");
				if (t) rowComponents.push(new MathRun(t));
			}
			if (cellIndex < cells.length - 1) rowComponents.push(new MathRun(", "));
		});
		if (rowComponents.length) out.push(new MathRoundBrackets({ children: rowComponents }));
		if (rowIndex < rows.length - 1) out.push(new MathRun("; "));
	});
	return out;
}
function mathComponentsFromChildNodes(node) {
	const out = [];
	for (const child of Array.from(node.childNodes)) {
		if (child.nodeType === Node.TEXT_NODE) {
			const text = normalizeMathText(child.nodeValue || "");
			if (text) out.push(new MathRun(text));
			continue;
		}
		if (child.nodeType !== Node.ELEMENT_NODE) continue;
		out.push(...mathComponentsFromMathNode(child));
	}
	return out;
}
function mathComponentsFromElementChildren(node) {
	const out = [];
	for (const child of Array.from(node.children)) out.push(...mathComponentsFromMathNode(child));
	return out;
}
function mathComponentsFromMathNode(node) {
	const tag = node.tagName.toLowerCase();
	if (tag === "annotation") return [];
	if (tag === "math" || tag === "mstyle" || tag === "semantics" || tag === "annotation-xml" || tag === "mphantom") {
		const kids = mathComponentsFromElementChildren(node);
		if (kids.length) return kids;
		const t = normalizeMathText(Array.from(node.children).map((el) => el.textContent || "").join(" "));
		return t ? [new MathRun(t)] : [];
	}
	if (tag === "mrow") {
		const elementChildren = Array.from(node.children);
		if (elementChildren.length >= 3 && isFenceOperatorElement(elementChildren[0]) && isFenceOperatorElement(elementChildren[elementChildren.length - 1])) {
			const open = normalizeMathOperator(elementChildren[0].textContent || "");
			const close = normalizeMathOperator(elementChildren[elementChildren.length - 1].textContent || "");
			const inner = [];
			for (const child of elementChildren.slice(1, -1)) inner.push(...mathComponentsFromMathNode(child));
			return [new (bracketClassFromFence(open, close))({ children: inner })];
		}
		const kids = mathComponentsFromChildNodes(node);
		if (kids.length) return kids;
		const t = normalizeMathText(node.textContent || "");
		return t ? [new MathRun(t)] : [];
	}
	if (tag === "mi" || tag === "mn" || tag === "mtext" || tag === "ms") {
		const t = normalizeMathText(node.textContent || "");
		return t ? [new MathRun(t)] : [];
	}
	if (tag === "mo") {
		const t = normalizeMathOperator(node.textContent || "");
		return t ? [new MathRun(t)] : [];
	}
	if (tag === "mspace") return [new MathRun(" ")];
	if (tag === "mfrac") {
		const [num, den] = Array.from(node.children);
		return [new MathFraction({
			numerator: num ? mathComponentsFromMathNode(num) : [new MathRun(" ")],
			denominator: den ? mathComponentsFromMathNode(den) : [new MathRun(" ")]
		})];
	}
	if (tag === "msqrt") {
		const children = mathComponentsFromChildNodes(node);
		return [new MathRadical({ children: children.length ? children : [new MathRun(" ")] })];
	}
	if (tag === "mroot") {
		const [base, degree] = Array.from(node.children);
		return [new MathRadical({
			children: base ? mathComponentsFromMathNode(base) : [new MathRun(" ")],
			degree: degree ? mathComponentsFromMathNode(degree) : [new MathRun(" ")]
		})];
	}
	if (tag === "msup") {
		const [base, sup] = Array.from(node.children);
		return [new MathSuperScript({
			children: base ? mathComponentsFromMathNode(base) : [new MathRun(" ")],
			superScript: sup ? mathComponentsFromMathNode(sup) : [new MathRun(" ")]
		})];
	}
	if (tag === "msub") {
		const [base, sub] = Array.from(node.children);
		return [new MathSubScript({
			children: base ? mathComponentsFromMathNode(base) : [new MathRun(" ")],
			subScript: sub ? mathComponentsFromMathNode(sub) : [new MathRun(" ")]
		})];
	}
	if (tag === "msubsup") {
		const [base, sub, sup] = Array.from(node.children);
		return [new MathSubSuperScript({
			children: base ? mathComponentsFromMathNode(base) : [new MathRun(" ")],
			subScript: sub ? mathComponentsFromMathNode(sub) : [new MathRun(" ")],
			superScript: sup ? mathComponentsFromMathNode(sup) : [new MathRun(" ")]
		})];
	}
	if (tag === "munder") {
		const [base, under] = Array.from(node.children);
		return [new MathSubScript({
			children: base ? mathComponentsFromMathNode(base) : [new MathRun(" ")],
			subScript: under ? mathComponentsFromMathNode(under) : [new MathRun(" ")]
		})];
	}
	if (tag === "mover") {
		const [base, over] = Array.from(node.children);
		return [new MathSuperScript({
			children: base ? mathComponentsFromMathNode(base) : [new MathRun(" ")],
			superScript: over ? mathComponentsFromMathNode(over) : [new MathRun(" ")]
		})];
	}
	if (tag === "munderover") {
		const [base, under, over] = Array.from(node.children);
		return [new MathSubSuperScript({
			children: base ? mathComponentsFromMathNode(base) : [new MathRun(" ")],
			subScript: under ? mathComponentsFromMathNode(under) : [new MathRun(" ")],
			superScript: over ? mathComponentsFromMathNode(over) : [new MathRun(" ")]
		})];
	}
	if (tag === "mtable") return matrixComponentsFromMtable(node);
	if (tag === "mtr" || tag === "mtd") {
		const kids = mathComponentsFromChildNodes(node);
		if (kids.length) return kids;
		const t = normalizeMathText(node.textContent || "");
		return t ? [new MathRun(t)] : [];
	}
	if (tag === "mfenced") {
		const open = (node.getAttribute("open") || "(").trim();
		const close = (node.getAttribute("close") || ")").trim();
		const children = mathComponentsFromChildNodes(node);
		return [new (bracketClassFromFence(open, close))({ children: children.length ? children : [new MathRun(" ")] })];
	}
	if (tag === "math" || tag === "mrow" || tag === "mstyle" || tag === "semantics") {
		const kids = [];
		for (const c of Array.from(node.children)) kids.push(...mathComponentsFromMathNode(c));
		if (!kids.length) {
			const t = normalizeMathText(node.textContent || "");
			return t ? [new MathRun(t)] : [];
		}
		return kids;
	}
	const kids = mathComponentsFromChildNodes(node);
	if (kids.length) return kids;
	const t = normalizeMathText(node.textContent || "");
	return t ? [new MathRun(t)] : [];
}
function mathFromElement(el) {
	const components = mathComponentsFromMathNode(el);
	if (!components.length) return null;
	return new Math$1({ children: components });
}
function hasMatrixElement(mathEl) {
	if (mathEl.tagName.toLowerCase() === "mtable") return true;
	return !!mathEl.querySelector("mtable");
}
function hasLatexMatrixMarkup(text) {
	return /\\begin\{(?:p|b|B|v|V)?matrix\}|\\begin\{smallmatrix\}/.test(text || "");
}
async function buildDisplayMatrixBlocks(mathEl) {
	const rawMathText = (mathEl.textContent || "").trim();
	if (!hasMatrixElement(mathEl) && hasLatexMatrixMarkup(rawMathText)) {
		const host = document.createElement("div");
		host.textContent = /(\$\$[\s\S]*\$\$|\\\[[\s\S]*\\\])/.test(rawMathText) ? repairLatexMatrixRowBreaks(rawMathText) : `$$${repairLatexMatrixRowBreaks(rawMathText)}$$`;
		renderMathInElement(host, {
			throwOnError: false,
			nonStandard: true,
			output: "mathml",
			strict: false,
			delimiters: [
				{
					left: "$$",
					right: "$$",
					display: true
				},
				{
					left: "\\[",
					right: "\\]",
					display: true
				},
				{
					left: "$",
					right: "$",
					display: false
				},
				{
					left: "\\(",
					right: "\\)",
					display: false
				}
			]
		});
		const reparsedMath = host.querySelector("math");
		if (reparsedMath && hasMatrixElement(reparsedMath)) return await buildDisplayMatrixBlocks(reparsedMath);
	}
	if (hasMatrixElement(mathEl)) {
		const png = await renderMatrixAsPng(mathEl) ?? await renderMathAsPng(mathEl, { display: true });
		if (png) return [new Paragraph({
			alignment: AlignmentType.CENTER,
			keepLines: true,
			spacing: {
				before: 120,
				after: 120
			},
			indent: { firstLine: 0 },
			children: [new ImageRun({
				data: png.data,
				type: "png",
				transformation: {
					width: png.width,
					height: png.height
				}
			})]
		})];
		return [new Paragraph({
			alignment: AlignmentType.CENTER,
			keepLines: true,
			spacing: {
				before: 120,
				after: 120
			},
			indent: { firstLine: 0 },
			children: [new TextRun({ text: normalizeMathText(mathEl.textContent || "") || "[matrix]" })]
		})];
	}
	const math = mathFromElement(mathEl);
	if (!math) return null;
	return [new Paragraph({
		alignment: AlignmentType.CENTER,
		keepLines: true,
		spacing: {
			before: 120,
			after: 120
		},
		indent: { firstLine: 0 },
		children: [math]
	})];
}
async function convertDisplayMathMatrixParagraph(pEl) {
	const children = Array.from(pEl.childNodes).filter((n) => {
		if (n.nodeType === Node.TEXT_NODE) return (n.nodeValue || "").trim().length > 0;
		return true;
	});
	if (children.length !== 1) {
		const embeddedMath = pEl.querySelector("math");
		if (embeddedMath && (hasMatrixElement(embeddedMath) || hasLatexMatrixMarkup(embeddedMath.textContent || ""))) return await buildDisplayMatrixBlocks(embeddedMath);
		const raw = (pEl.textContent || "").trim();
		if (!raw) return null;
		if (!hasLatexMatrixMarkup(raw)) return null;
		const host = document.createElement("div");
		host.textContent = /(\$\$[\s\S]*\$\$|\\\[[\s\S]*\\\])/.test(raw) ? repairLatexMatrixRowBreaks(raw) : `$$${repairLatexMatrixRowBreaks(raw)}$$`;
		renderMathInElement(host, {
			throwOnError: false,
			nonStandard: true,
			output: "mathml",
			strict: false,
			delimiters: [
				{
					left: "$$",
					right: "$$",
					display: true
				},
				{
					left: "\\[",
					right: "\\]",
					display: true
				},
				{
					left: "$",
					right: "$",
					display: false
				},
				{
					left: "\\(",
					right: "\\)",
					display: false
				}
			]
		});
		const mathEl = host.querySelector("math");
		if (mathEl) return await buildDisplayMatrixBlocks(mathEl);
		return null;
	}
	const only = children[0];
	if (only.nodeType !== Node.ELEMENT_NODE) return null;
	const el = only;
	const tag = el.tagName.toLowerCase();
	if (tag === "math") return await buildDisplayMatrixBlocks(el);
	if (tag === "div" && (el.classList.contains("math-display") || el.classList.contains("katex-display"))) {
		const mathEl = el.querySelector("math");
		if (mathEl) return await buildDisplayMatrixBlocks(mathEl);
	}
	return null;
}
//#endregion
//#region ../CWSP-document/src/shared/other/document/DocxExport.ts
function textRun(text, style) {
	return new TextRun({
		text,
		bold: !!style.bold,
		italics: !!style.italic,
		font: style.code ? FONTS.mono : void 0
	});
}
function textRunHyperlink(text) {
	return new TextRun({
		text,
		style: "Hyperlink"
	});
}
function breakRun() {
	return new TextRun({ break: 1 });
}
function collectInline(node, style, out) {
	if (node.nodeType === Node.TEXT_NODE) {
		const text = node.nodeValue ?? "";
		if (!text) return;
		out.push(textRun(text, style));
		return;
	}
	if (node.nodeType !== Node.ELEMENT_NODE) return;
	const el = node;
	const tag = el.tagName.toLowerCase();
	if (tag === "br") {
		out.push(new TextRun({ break: 1 }));
		return;
	}
	if (tag === "strong" || tag === "b") {
		for (const child of Array.from(el.childNodes)) collectInline(child, {
			...style,
			bold: true
		}, out);
		return;
	}
	if (tag === "em" || tag === "i") {
		for (const child of Array.from(el.childNodes)) collectInline(child, {
			...style,
			italic: true
		}, out);
		return;
	}
	if (tag === "code" && el.parentElement?.tagName.toLowerCase() !== "pre") {
		const text = el.textContent ?? "";
		if (text) out.push(textRun(text, {
			...style,
			code: true
		}));
		return;
	}
	if (tag === "a") {
		const href = (el.getAttribute("href") || "").trim();
		const children = [];
		const tmp = [];
		for (const child of Array.from(el.childNodes)) collectInline(child, style, tmp);
		for (const c of tmp) if (c instanceof TextRun) children.push(c);
		else children.push(textRunHyperlink((el.textContent || href || "").trim() || href));
		out.push(new ExternalHyperlink({
			link: href || (el.textContent || "").trim() || "",
			children: children.length ? children : [textRunHyperlink(href || "link")]
		}));
		return;
	}
	if (tag === "math") {
		const m = mathFromElement(el);
		if (m) out.push(m);
		else {
			const text = (el.textContent || "").trim();
			if (text) out.push(textRun(text, style));
		}
		return;
	}
	if (tag === "span" && (el.classList.contains("katex") || el.classList.contains("katex-mathml"))) {
		const mathEl = el.querySelector("math");
		if (mathEl) {
			const m = mathFromElement(mathEl);
			if (m) {
				out.push(m);
				return;
			}
		}
	}
	if (tag === "svg") {
		const text = (el.textContent || "").trim();
		if (text) out.push(textRun(text, style));
		return;
	}
	for (const child of Array.from(el.childNodes)) collectInline(child, style, out);
}
function paragraphFromInlineNodes(nodes, options) {
	const children = [];
	for (const n of Array.from(nodes)) collectInline(n, {}, children);
	const rawText = Array.from(nodes).map((n) => n.nodeType === Node.TEXT_NODE ? n.nodeValue || "" : n.textContent || "").join(" ").replace(/\s+/g, " ").trim();
	const isShortParagraph = rawText.length > 0 && rawText.length <= 120;
	return new Paragraph({
		widowControl: true,
		alignment: options?.alignment ?? (isShortParagraph ? AlignmentType.LEFT : void 0),
		...options || {},
		children: children.length ? children : [new TextRun({ text: "" })]
	});
}
function headingLevelFromTag(tag) {
	if (tag === "h1") return HeadingLevel.HEADING_1;
	if (tag === "h2") return HeadingLevel.HEADING_2;
	if (tag === "h3") return HeadingLevel.HEADING_3;
	if (tag === "h4") return HeadingLevel.HEADING_4;
	if (tag === "h5") return HeadingLevel.HEADING_5;
	if (tag === "h6") return HeadingLevel.HEADING_6;
}
function convertList(listEl, ordered, level) {
	const out = [];
	const items = Array.from(listEl.children).filter((c) => c.tagName.toLowerCase() === "li");
	for (const li of items) {
		const nestedLists = Array.from(li.children).filter((c) => {
			const t = c.tagName.toLowerCase();
			return t === "ul" || t === "ol";
		});
		const inlineNodes = [];
		for (const child of Array.from(li.childNodes)) {
			if (child.nodeType === Node.ELEMENT_NODE) {
				const t = child.tagName.toLowerCase();
				if (t === "ul" || t === "ol") continue;
			}
			inlineNodes.push(child);
		}
		const left = 720 * Math.max(1, level + 1);
		out.push(paragraphFromInlineNodes(inlineNodes, {
			style: "ListParagraph",
			bullet: ordered ? void 0 : { level },
			numbering: ordered ? {
				reference: ORDERED_LIST_REF,
				level
			} : void 0,
			alignment: AlignmentType.LEFT,
			indent: {
				left,
				hanging: 360
			}
		}));
		for (const nested of nestedLists) {
			const t = nested.tagName.toLowerCase();
			out.push(...convertList(nested, t === "ol", level + 1));
		}
	}
	return out;
}
async function convertTable(tableEl, ctx) {
	const rows = await Promise.all(Array.from(tableEl.querySelectorAll("tr")).map(async (tr) => {
		const cells = Array.from(tr.children).filter((c) => {
			const t = c.tagName.toLowerCase();
			return t === "td" || t === "th";
		});
		return new TableRow({ children: await Promise.all(cells.map(async (cellEl) => {
			const children = [];
			const isHeader = cellEl.tagName.toLowerCase() === "th";
			if (Array.from(cellEl.children).some((c) => {
				const t = c.tagName.toLowerCase();
				return t === "p" || t === "ul" || t === "ol" || t === "pre" || t === "blockquote" || t === "div";
			})) for (const c of Array.from(cellEl.childNodes)) children.push(...await convertBlockNode(c, 0, ctx));
			else children.push(paragraphFromInlineNodes(cellEl.childNodes));
			return new TableCell({
				width: {
					size: 1,
					type: WidthType.AUTO
				},
				shading: isHeader ? {
					type: ShadingType.CLEAR,
					fill: COLORS.thBg,
					color: "auto"
				} : void 0,
				children
			});
		})) });
	}));
	return new Table({
		width: {
			size: 100,
			type: WidthType.PERCENTAGE
		},
		borders: {
			top: {
				style: BorderStyle.SINGLE,
				size: 2,
				color: COLORS.borderDark
			},
			bottom: {
				style: BorderStyle.SINGLE,
				size: 2,
				color: COLORS.borderDark
			},
			left: {
				style: BorderStyle.SINGLE,
				size: 2,
				color: COLORS.borderDark
			},
			right: {
				style: BorderStyle.SINGLE,
				size: 2,
				color: COLORS.borderDark
			},
			insideHorizontal: {
				style: BorderStyle.SINGLE,
				size: 2,
				color: COLORS.border
			},
			insideVertical: {
				style: BorderStyle.SINGLE,
				size: 2,
				color: COLORS.border
			}
		},
		rows
	});
}
function convertPre(preEl) {
	const lines = (preEl.querySelector("code")?.textContent ?? preEl.textContent ?? "").replace(/\r\n/g, "\n").split("\n");
	const children = [];
	for (let i = 0; i < lines.length; i++) {
		children.push(new TextRun({ text: lines[i] }));
		if (i !== lines.length - 1) children.push(breakRun());
	}
	return [new Paragraph({
		style: "CodeBlock",
		widowControl: true,
		keepLines: true,
		children,
		spacing: {
			before: 0,
			after: 0
		},
		border: {
			top: {
				style: BorderStyle.SINGLE,
				size: 2,
				color: COLORS.border
			},
			bottom: {
				style: BorderStyle.SINGLE,
				size: 2,
				color: COLORS.border
			},
			left: {
				style: BorderStyle.SINGLE,
				size: 2,
				color: COLORS.border
			},
			right: {
				style: BorderStyle.SINGLE,
				size: 2,
				color: COLORS.border
			}
		},
		shading: {
			type: ShadingType.CLEAR,
			fill: COLORS.codeBg,
			color: "auto"
		},
		alignment: AlignmentType.LEFT
	})];
}
async function convertBlockNode(node, listLevel, ctx) {
	if (node.nodeType === Node.TEXT_NODE) {
		const text = (node.nodeValue ?? "").trim();
		if (!text) return [];
		if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
		return [new Paragraph({ children: [textRun(text, {})] })];
	}
	if (node.nodeType !== Node.ELEMENT_NODE) return [];
	const el = node;
	const tag = el.tagName.toLowerCase();
	if (tag === "math") {
		const displayMatrix = await buildDisplayMatrixBlocks(el);
		if (displayMatrix) {
			if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
			return displayMatrix;
		}
	}
	if (tag === "div" && (el.classList.contains("math-display") || el.classList.contains("katex-display"))) {
		const mathEl = el.querySelector("math");
		if (mathEl) {
			const displayMatrix = await buildDisplayMatrixBlocks(mathEl);
			if (displayMatrix) {
				if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
				return displayMatrix;
			}
		}
	}
	if (tag === "p") {
		const displayMatrix = await convertDisplayMathMatrixParagraph(el);
		if (displayMatrix) {
			if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
			return displayMatrix;
		}
		if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
		const imgs = Array.from(el.children).filter((c) => c.tagName.toLowerCase() === "img");
		if (imgs.length === 1 && el.childNodes.length === 1 && el.firstElementChild?.tagName.toLowerCase() === "img") return await convertBlockNode(imgs[0], listLevel, ctx);
		return [paragraphFromInlineNodes(el.childNodes)];
	}
	const heading = headingLevelFromTag(tag);
	if (heading) {
		const isH1 = heading === HeadingLevel.HEADING_1;
		const isH2 = heading === HeadingLevel.HEADING_2;
		const skipBreakForImmediateFirstH2 = isH2 && ctx.firstH2AfterH1Pending && !ctx.sawContentSinceLastH1;
		const shouldBreakBeforeH2 = isH2 && ctx.blockIndex > 0 && !skipBreakForImmediateFirstH2;
		const wantsPageBreakBefore = ctx.chapterByH1 && isH1 && ctx.blockIndex > 0 || shouldBreakBeforeH2 || el.classList.contains("print-chapter") || el.classList.contains("print-break-before");
		if (isH1) {
			ctx.firstH2AfterH1Pending = true;
			ctx.sawContentSinceLastH1 = false;
		} else if (isH2) {
			ctx.firstH2AfterH1Pending = false;
			ctx.sawContentSinceLastH1 = false;
		} else if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
		const withBorder = heading === HeadingLevel.HEADING_1 || heading === HeadingLevel.HEADING_2 ? { border: { bottom: {
			style: BorderStyle.SINGLE,
			size: 4,
			color: COLORS.border
		} } } : void 0;
		return [paragraphFromInlineNodes(el.childNodes, {
			heading,
			spacing: {
				before: 200,
				after: 120
			},
			keepNext: true,
			keepLines: true,
			alignment: heading === HeadingLevel.HEADING_1 || heading === HeadingLevel.HEADING_2 ? AlignmentType.CENTER : AlignmentType.LEFT,
			pageBreakBefore: wantsPageBreakBefore || void 0,
			...withBorder
		})];
	}
	if (tag === "hr") {
		if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
		return [new Paragraph({
			thematicBreak: true,
			border: { bottom: {
				style: BorderStyle.SINGLE,
				size: 2,
				color: COLORS.border
			} },
			spacing: {
				before: 200,
				after: 200
			}
		})];
	}
	if (tag === "blockquote") {
		if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
		const out = [];
		const quoteDecor = {
			style: "Quote",
			indent: { left: 720 },
			border: { left: {
				style: BorderStyle.SINGLE,
				size: 6,
				color: COLORS.borderDark
			} },
			shading: {
				type: ShadingType.CLEAR,
				fill: COLORS.quoteBg,
				color: "auto"
			},
			spacing: { after: 240 }
		};
		for (const child of Array.from(el.childNodes)) {
			if (child.nodeType === Node.TEXT_NODE) {
				const t = (child.nodeValue ?? "").trim();
				if (t) out.push(new Paragraph({
					...quoteDecor,
					children: [textRun(t, {})]
				}));
				continue;
			}
			if (child.nodeType !== Node.ELEMENT_NODE) continue;
			const ce = child;
			const ct = ce.tagName.toLowerCase();
			if (ct === "p") {
				out.push(paragraphFromInlineNodes(ce.childNodes, quoteDecor));
				continue;
			}
			const heading = headingLevelFromTag(ct);
			if (heading) {
				out.push(paragraphFromInlineNodes(ce.childNodes, {
					...quoteDecor,
					heading,
					spacing: {
						before: 200,
						after: 120
					}
				}));
				continue;
			}
			if (ct === "ul" || ct === "ol") {
				out.push(...convertList(ce, ct === "ol", listLevel));
				continue;
			}
			if (ct === "pre") {
				const lines = (ce.querySelector("code")?.textContent ?? ce.textContent ?? "").replace(/\r\n/g, "\n").split("\n");
				const children = [];
				for (let i = 0; i < lines.length; i++) {
					children.push(new TextRun({ text: lines[i] }));
					if (i !== lines.length - 1) children.push(breakRun());
				}
				out.push(new Paragraph({
					...quoteDecor,
					style: "CodeBlock",
					keepLines: true,
					children,
					spacing: {
						before: 0,
						after: 0
					},
					shading: {
						type: ShadingType.CLEAR,
						fill: COLORS.codeBg,
						color: "auto"
					},
					alignment: AlignmentType.LEFT
				}));
				continue;
			}
			const t = (ce.textContent ?? "").trim();
			if (t) out.push(new Paragraph({
				...quoteDecor,
				children: [textRun(t, {})]
			}));
		}
		return out.length ? out : [new Paragraph({
			...quoteDecor,
			children: [textRun((el.textContent || "").trim(), {})]
		})];
	}
	if (tag === "pre") {
		if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
		return convertPre(el);
	}
	if (tag === "ul") {
		if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
		return convertList(el, false, listLevel);
	}
	if (tag === "ol") {
		if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
		return convertList(el, true, listLevel);
	}
	if (tag === "table") {
		if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
		return [await convertTable(el, ctx)];
	}
	if (tag === "img") {
		if (ctx.firstH2AfterH1Pending) ctx.sawContentSinceLastH1 = true;
		const alt = (el.getAttribute("alt") || "").trim();
		const src = (el.getAttribute("src") || "").trim();
		const img = await imageRunFromSrc(src, alt);
		if (!img) return [new Paragraph({ children: [textRun(`[image${alt ? `: ${alt}` : ""}] ${src ? `(${src})` : ""}`.trim(), {})] })];
		const blocks = [new Paragraph({
			alignment: AlignmentType.CENTER,
			keepLines: true,
			children: [img]
		})];
		if (alt) blocks.push(new Paragraph({
			style: "Caption",
			alignment: AlignmentType.CENTER,
			spacing: {
				before: 80,
				after: 200
			},
			children: [new TextRun({
				text: alt,
				italics: true
			})]
		}));
		return blocks;
	}
	if (tag === "div" || tag === "section" || tag === "article" || tag === "main") {
		const out = [];
		for (const child of Array.from(el.childNodes)) out.push(...await convertBlockNode(child, listLevel, ctx));
		return out;
	}
	if (ctx.firstH2AfterH1Pending && (el.textContent || "").trim()) ctx.sawContentSinceLastH1 = true;
	return [paragraphFromInlineNodes(el.childNodes)];
}
async function createDocxBlobFromHtml(html, options = {}) {
	const title = options.title || "Document";
	const body = htmlToBody(html);
	const children = [];
	const ctx = {
		blockIndex: 0,
		chapterByH1: true,
		firstH2AfterH1Pending: false,
		sawContentSinceLastH1: false
	};
	for (const node of Array.from(body.childNodes)) {
		children.push(...await convertBlockNode(node, 0, ctx));
		ctx.blockIndex++;
	}
	const doc = new File({
		creator: options.creator || "CWSP-shell",
		title,
		styles: {
			default: { document: {
				run: {
					font: FONTS.serif,
					size: SIZES.body,
					color: COLORS.text
				},
				paragraph: {
					spacing: {
						line: GOST_LAYOUT.paragraph.lineTwip,
						before: 0,
						after: 0
					},
					indent: { firstLine: GOST_LAYOUT.paragraph.firstLineTwip },
					alignment: AlignmentType.JUSTIFIED
				}
			} },
			characterStyles: [{
				id: "Hyperlink",
				name: "Hyperlink",
				basedOn: "DefaultParagraphFont",
				quickFormat: true,
				run: {
					color: COLORS.link,
					underline: {
						type: UnderlineType.SINGLE,
						color: COLORS.link
					}
				}
			}],
			paragraphStyles: [
				{
					id: "Normal",
					name: "Normal",
					next: "Normal",
					quickFormat: true,
					paragraph: {
						spacing: {
							line: GOST_LAYOUT.paragraph.lineTwip,
							before: 0,
							after: 0
						},
						indent: { firstLine: GOST_LAYOUT.paragraph.firstLineTwip },
						alignment: AlignmentType.JUSTIFIED
					},
					run: {
						font: FONTS.serif,
						color: COLORS.text,
						size: SIZES.body
					}
				},
				{
					id: "ListParagraph",
					name: "List Paragraph",
					basedOn: "Normal",
					next: "Normal",
					quickFormat: true,
					paragraph: {
						spacing: {
							before: 0,
							after: 0
						},
						contextualSpacing: true,
						indent: { firstLine: 0 }
					},
					run: {
						font: FONTS.serif,
						color: COLORS.text,
						size: SIZES.body
					}
				},
				{
					id: "Quote",
					name: "Quote",
					basedOn: "Normal",
					next: "Normal",
					quickFormat: true,
					paragraph: {
						spacing: { after: 240 },
						indent: {
							left: 720,
							firstLine: 0
						}
					},
					run: {
						font: FONTS.serif,
						color: COLORS.text,
						italics: true,
						size: SIZES.body
					}
				},
				{
					id: "CodeBlock",
					name: "Code Block",
					basedOn: "Normal",
					next: "Normal",
					quickFormat: true,
					paragraph: {
						spacing: {
							before: 120,
							after: 120
						},
						alignment: AlignmentType.LEFT,
						indent: { firstLine: 0 }
					},
					run: {
						font: FONTS.mono,
						color: COLORS.link,
						size: SIZES.code
					}
				},
				{
					id: "Caption",
					name: "Caption",
					basedOn: "Normal",
					next: "Normal",
					quickFormat: true,
					paragraph: {
						spacing: {
							before: 80,
							after: 160
						},
						indent: { firstLine: 0 }
					},
					run: {
						font: FONTS.serif,
						color: COLORS.link,
						size: 20,
						italics: true
					}
				},
				{
					id: "Heading1",
					name: "Heading 1",
					basedOn: "Normal",
					next: "Normal",
					quickFormat: true,
					run: {
						font: FONTS.serif,
						bold: true,
						color: COLORS.text,
						size: SIZES.h1
					},
					paragraph: {
						spacing: {
							before: 320,
							after: 160
						},
						alignment: AlignmentType.CENTER
					}
				},
				{
					id: "Heading2",
					name: "Heading 2",
					basedOn: "Normal",
					next: "Normal",
					quickFormat: true,
					run: {
						font: FONTS.serif,
						bold: true,
						color: COLORS.text,
						size: SIZES.h2
					},
					paragraph: {
						spacing: {
							before: 280,
							after: 140
						},
						alignment: AlignmentType.CENTER
					}
				},
				{
					id: "Heading3",
					name: "Heading 3",
					basedOn: "Normal",
					next: "Normal",
					quickFormat: true,
					run: {
						font: FONTS.serif,
						bold: true,
						color: COLORS.text,
						size: SIZES.h3
					},
					paragraph: {
						spacing: {
							before: 240,
							after: 120
						},
						alignment: AlignmentType.LEFT
					}
				},
				{
					id: "Heading4",
					name: "Heading 4",
					basedOn: "Normal",
					next: "Normal",
					quickFormat: true,
					run: {
						font: FONTS.serif,
						bold: true,
						color: COLORS.text,
						size: SIZES.h4
					},
					paragraph: {
						spacing: {
							before: 220,
							after: 120
						},
						alignment: AlignmentType.LEFT
					}
				},
				{
					id: "Heading5",
					name: "Heading 5",
					basedOn: "Normal",
					next: "Normal",
					quickFormat: true,
					run: {
						font: FONTS.serif,
						bold: true,
						color: COLORS.text,
						size: SIZES.h5
					},
					paragraph: {
						spacing: {
							before: 200,
							after: 100
						},
						alignment: AlignmentType.LEFT
					}
				},
				{
					id: "Heading6",
					name: "Heading 6",
					basedOn: "Normal",
					next: "Normal",
					quickFormat: true,
					run: {
						font: FONTS.serif,
						bold: true,
						color: COLORS.text,
						size: SIZES.h6
					},
					paragraph: {
						spacing: {
							before: 180,
							after: 100
						},
						alignment: AlignmentType.LEFT
					}
				}
			]
		},
		numbering: { config: [{
			reference: ORDERED_LIST_REF,
			levels: [
				{
					level: 0,
					format: LevelFormat.DECIMAL,
					text: "%1.",
					alignment: AlignmentType.LEFT
				},
				{
					level: 1,
					format: LevelFormat.LOWER_LETTER,
					text: "%2.",
					alignment: AlignmentType.LEFT
				},
				{
					level: 2,
					format: LevelFormat.LOWER_ROMAN,
					text: "%3.",
					alignment: AlignmentType.LEFT
				}
			]
		}] },
		sections: [{
			properties: { page: {
				size: {
					orientation: PageOrientation.PORTRAIT,
					width: convertMillimetersToTwip(GOST_LAYOUT.page.widthMm),
					height: convertMillimetersToTwip(GOST_LAYOUT.page.heightMm)
				},
				margin: {
					top: convertMillimetersToTwip(GOST_LAYOUT.page.marginTopMm),
					right: convertMillimetersToTwip(GOST_LAYOUT.page.marginRightMm),
					bottom: convertMillimetersToTwip(GOST_LAYOUT.page.marginBottomMm),
					left: convertMillimetersToTwip(GOST_LAYOUT.page.marginLeftMm)
				}
			} },
			children
		}]
	});
	try {
		doc.Settings?.addCompatibility?.()?.doNotExpandShiftReturn?.();
	} catch {}
	return await Packer.toBlob(doc);
}
async function createDocxBlobFromMarkdown(markdown, options = {}) {
	return await createDocxBlobFromHtml(await markdownToHtml(markdown ?? ""), options);
}
async function downloadMarkdownAsDocx(markdown, options = {}) {
	const title = options.title || "Document";
	const filename = options.filename || `${safeFilename(title)}.docx`;
	downloadBlob(await createDocxBlobFromMarkdown(markdown ?? "", options), filename);
}
//#endregion
export { downloadMarkdownAsDocx };
